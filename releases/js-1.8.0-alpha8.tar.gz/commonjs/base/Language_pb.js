// source: base/Language.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();

goog.exportSymbol('proto.opencannabis.base.Language', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.base.Language = {
  LANGUAGE_UNSPECIFIED: 0,
  ENGLISH: 1,
  SPANISH: 2,
  FRENCH: 3
};

goog.object.extend(exports, proto.opencannabis.base);
