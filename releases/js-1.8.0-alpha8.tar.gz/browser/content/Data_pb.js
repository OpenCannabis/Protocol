// source: content/Data.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.opencannabis.content.DataFormat', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.content.DataFormat = {
  UNKNOWN_FORMAT: 0,
  CSV: 10,
  TSV: 11,
  EXCEL_CSV: 12,
  EXCEL_XLS: 13,
  EXCEL_XLSX: 14,
  MSGPACK: 20,
  AVRO: 30,
  SQL: 40,
  JSON: 50,
  OCP_TEXT: 61,
  OCP_BINARY: 62
};

