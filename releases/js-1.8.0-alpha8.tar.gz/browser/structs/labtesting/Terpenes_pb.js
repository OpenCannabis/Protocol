// source: structs/labtesting/Terpenes.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.opencannabis.structs.labtesting.Terpene', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.structs.labtesting.Terpene = {
  CAMPHENE: 0,
  CARENE: 1,
  BETA_CARYOPHYLLENE: 2,
  CARYOPHYLLENE_OXIDE: 3,
  EUCALYPTOL: 4,
  FENCHOL: 5,
  ALPHA_HUMULENE: 6,
  LIMONENE: 7,
  LINALOOL: 8,
  MYRCENE: 9,
  ALPHA_OCIMENE: 10,
  BETA_OCIMENE: 11,
  ALPHA_PHELLANDRENE: 12,
  ALPHA_PINENE: 13,
  BETA_PINENE: 14,
  ALPHA_TERPINEOL: 15,
  ALPHA_TERPININE: 16,
  GAMMA_TERPININE: 17,
  TERPINOLENE: 18,
  VALENCENE: 19,
  GERANIOL: 20,
  PHELLANDRENE: 21,
  BORNEOL: 22,
  ISOBORNEOL: 23,
  BISABOLOL: 24,
  PHYTOL: 25,
  SABINENE: 26,
  CAMPHOR: 27,
  MENTHOL: 28,
  CEDRENE: 29,
  NEROL: 30,
  NEROLIDOL: 31,
  GUAIOL: 32,
  ISOPULEGOL: 33,
  GERANYL_ACETATE: 34,
  CYMENE: 35,
  PULEGONE: 36,
  CINEOLE: 37,
  FENCHONE: 38,
  TERPINENE: 39,
  CITRONELLOL: 40,
  DELTA_3_CARENE: 41
};

