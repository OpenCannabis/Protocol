// source: products/distribution/DistributionChannel.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.distribution.Channel');

/**
 * @enum {number}
 */
proto.opencannabis.products.distribution.Channel = {
  UNSPECIFIED_CHANNEL: 0,
  RETAIL: 1,
  WHOLESALE: 2,
  BULK: 3
};

