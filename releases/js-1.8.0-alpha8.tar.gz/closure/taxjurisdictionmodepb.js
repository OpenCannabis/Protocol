// source: accounting/Taxes.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.taxes.TaxJurisdictionMode');

/**
 * @enum {number}
 */
proto.opencannabis.taxes.TaxJurisdictionMode = {
  LOCAL: 0,
  PROVINCE: 1,
  FEDERAL: 2
};

