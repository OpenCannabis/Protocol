// source: google/cloudprint/GoogleCloudPrint.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.google.cloudprint.PrinterConnectionStatus');

/**
 * @enum {number}
 */
proto.google.cloudprint.PrinterConnectionStatus = {
  UNKNOWN: 0,
  DORMANT: 1,
  OFFLINE: 2,
  ONLINE: 3
};

