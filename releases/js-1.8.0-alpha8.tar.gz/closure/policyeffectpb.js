// source: catalog/Policy.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.catalog.policy.PolicyEffect');

/**
 * @enum {number}
 */
proto.opencannabis.catalog.policy.PolicyEffect = {
  NONE: 0,
  WARN: 1,
  ENFORCE: 2
};

