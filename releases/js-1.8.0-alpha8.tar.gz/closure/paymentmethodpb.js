// source: commerce/payments/Payment.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.commerce.PaymentMethod');

/**
 * @enum {number}
 */
proto.opencannabis.commerce.PaymentMethod = {
  CASH: 0,
  CHECK: 1,
  DEBIT: 2,
  CREDIT: 3,
  DIGITAL: 4,
  ACH: 5,
  WIRE: 6,
  BLOCKCHAIN: 7
};

