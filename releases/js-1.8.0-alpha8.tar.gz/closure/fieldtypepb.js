// source: core/Datamodel.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.core.FieldType');

/**
 * @enum {number}
 */
proto.core.FieldType = {
  STANDARD: 0,
  KEY: 1,
  ID: 2,
  TAGS: 3,
  FLAGS: 4,
  REFERENCE: 5,
  TIMESTAMP: 6,
  PARENT: 7
};

