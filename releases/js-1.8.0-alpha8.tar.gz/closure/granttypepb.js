// source: oauth/Client.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.oauth.GrantType');

/**
 * @enum {number}
 */
proto.opencannabis.oauth.GrantType = {
  UNSPECIFIED_GRANT_TYPE: 0,
  AUTHORIZATION_CODE: 1,
  REFRESH_TOKEN: 2,
  CLIENT_CREDENTIALS: 3
};

