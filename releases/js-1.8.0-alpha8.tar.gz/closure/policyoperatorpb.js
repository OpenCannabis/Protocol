// source: catalog/Policy.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.catalog.policy.PolicyOperator');

/**
 * @enum {number}
 */
proto.opencannabis.catalog.policy.PolicyOperator = {
  UNKNOWN_POLICY_OPERATOR: 0,
  SET: 1,
  UNSET: 2,
  EQUALS: 3,
  NOT_EQUALS: 4,
  GREATER_THAN: 5,
  GREATER_THAN_EQUAL_TO: 6,
  LESS_THAN: 7,
  LESS_THAN_EQUAL_TO: 8,
  CONTAINS: 9,
  NOT_CONTAINS: 10
};

