// source: core/Datamodel.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.core.FieldVisibility');

/**
 * @enum {number}
 */
proto.core.FieldVisibility = {
  DEFAULT_VISIBILITY: 0,
  OPEN: 1,
  AUTHORIZED: 2,
  OWNER: 3,
  INTERNAL: 4
};

