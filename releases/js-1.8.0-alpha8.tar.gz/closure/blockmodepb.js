// source: crypto/primitives/Keys.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.crypto.BlockMode');

/**
 * @enum {number}
 */
proto.opencannabis.crypto.BlockMode = {
  UNSPECIFIED_BLOCK_MODE: 0,
  ECB: 1,
  CBC: 2,
  CFB: 3,
  OFB: 4,
  CTR: 5,
  CCM: 6,
  GCM: 7,
  XTS: 8,
  KWP: 9
};

