// source: person/Person.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.person.GenderCategory');

/**
 * @enum {number}
 */
proto.opencannabis.person.GenderCategory = {
  UNSPECIFIED: 0,
  MALE: 1,
  CIS_MALE: 1,
  FEMALE: 2,
  CIS_FEMALE: 2,
  TRANS_MALE: 3,
  TRANS_FEMALE: 4,
  NON_BINARY: 5,
  GENDER_FLUID: 6,
  BI_GENDER: 7,
  PAN_GENDER: 8,
  DECLINE_TO_STATE: 99
};

