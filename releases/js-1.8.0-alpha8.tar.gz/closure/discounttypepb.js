// source: commerce/Discounts.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.commerce.DiscountType');

/**
 * @enum {number}
 */
proto.opencannabis.commerce.DiscountType = {
  CUSTOM: 0,
  STATUTORY: 1,
  COMMERCIAL: 2
};

