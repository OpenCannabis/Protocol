// source: media/MediaItem.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.media.MediaStatus');

/**
 * @enum {number}
 */
proto.opencannabis.media.MediaStatus = {
  PROVISIONED: 0,
  PENDING: 1,
  UPLOADED: 2,
  READY: 3
};

