// source: structs/labtesting/TestResults.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.structs.labtesting.TestMethod');

/**
 * @enum {number}
 */
proto.opencannabis.structs.labtesting.TestMethod = {
  UNSPECIFIED_METHOD: 0,
  GCMS: 1,
  LCMS: 2,
  CLASSIC_PCR: 3,
  QPCR: 4,
  ELISA: 5
};

