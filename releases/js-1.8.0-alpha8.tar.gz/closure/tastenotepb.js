// source: structs/labtesting/TestResults.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.structs.labtesting.TasteNote');

/**
 * @enum {number}
 */
proto.opencannabis.structs.labtesting.TasteNote = {
  NO_TASTE_PREFERENCE: 0,
  SWEET: 1,
  SOUR: 2,
  SPICE: 3,
  SMOOTH: 4,
  CITRUS: 5,
  PINE: 6,
  FRUIT: 7,
  TROPICS: 8,
  FLORAL: 9,
  HERB: 10,
  EARTH: 11
};

