// source: person/Person.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.person.KnownPronouns');

/**
 * @enum {number}
 */
proto.opencannabis.person.KnownPronouns = {
  NORMATIVE: 0,
  HE: 1,
  SHE: 2,
  IT: 3,
  THEY: 4,
  NE: 5,
  VE: 6,
  SPIVAK: 7,
  ZE: 8,
  XE: 9
};

