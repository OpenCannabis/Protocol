// source: commerce/Order.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.commerce.OrderStatus');

/**
 * @enum {number}
 */
proto.opencannabis.commerce.OrderStatus = {
  PENDING: 0,
  APPROVED: 1,
  REJECTED: 2,
  ASSIGNED: 3,
  EN_ROUTE: 4,
  FULFILLED: 5
};

