/**
 * @fileoverview gRPC-Web generated client stub for google.cloudprint
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


goog.provide('proto.google.cloudprint.CloudPrintClient');
goog.provide('proto.google.cloudprint.CloudPrintPromiseClient');

goog.require('grpc.web.GrpcWebClientBase');
goog.require('grpc.web.AbstractClientBase');
goog.require('grpc.web.ClientReadableStream');
goog.require('grpc.web.Error');
goog.require('grpc.web.MethodDescriptor');
goog.require('grpc.web.MethodType');
goog.require('proto.google.cloudprint.DeleteJobRequest');
goog.require('proto.google.cloudprint.DeleteJobResponse');
goog.require('proto.google.cloudprint.GetPrinterRequest');
goog.require('proto.google.cloudprint.GetPrinterResponse');
goog.require('proto.google.cloudprint.ListJobsRequest');
goog.require('proto.google.cloudprint.ListJobsResponse');
goog.require('proto.google.cloudprint.SearchPrintersRequest');
goog.require('proto.google.cloudprint.SearchPrintersResponse');
goog.require('proto.google.cloudprint.SubmitJobRequest');
goog.require('proto.google.cloudprint.SubmitJobResponse');



goog.scope(function() {

/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.google.cloudprint.CloudPrintClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @param {string} hostname
 * @param {?Object} credentials
 * @param {?Object} options
 * @constructor
 * @struct
 * @final
 */
proto.google.cloudprint.CloudPrintPromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options['format'] = 'text';

  /**
   * @private @const {!grpc.web.GrpcWebClientBase} The client
   */
  this.client_ = new grpc.web.GrpcWebClientBase(options);

  /**
   * @private @const {string} The hostname
   */
  this.hostname_ = hostname;

};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.google.cloudprint.SubmitJobRequest,
 *   !proto.google.cloudprint.SubmitJobResponse>}
 */
const methodDescriptor_CloudPrint_SubmitJob = new grpc.web.MethodDescriptor(
  '/google.cloudprint.CloudPrint/SubmitJob',
  grpc.web.MethodType.UNARY,
  proto.google.cloudprint.SubmitJobRequest,
  proto.google.cloudprint.SubmitJobResponse,
  /**
   * @param {!proto.google.cloudprint.SubmitJobRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.SubmitJobResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.google.cloudprint.SubmitJobRequest,
 *   !proto.google.cloudprint.SubmitJobResponse>}
 */
const methodInfo_CloudPrint_SubmitJob = new grpc.web.AbstractClientBase.MethodInfo(
  proto.google.cloudprint.SubmitJobResponse,
  /**
   * @param {!proto.google.cloudprint.SubmitJobRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.SubmitJobResponse.deserializeBinary
);


/**
 * @param {!proto.google.cloudprint.SubmitJobRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.google.cloudprint.SubmitJobResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.google.cloudprint.SubmitJobResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.google.cloudprint.CloudPrintClient.prototype.submitJob =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/SubmitJob',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_SubmitJob,
      callback);
};


/**
 * @param {!proto.google.cloudprint.SubmitJobRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.google.cloudprint.SubmitJobResponse>}
 *     A native promise that resolves to the response
 */
proto.google.cloudprint.CloudPrintPromiseClient.prototype.submitJob =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/SubmitJob',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_SubmitJob);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.google.cloudprint.DeleteJobRequest,
 *   !proto.google.cloudprint.DeleteJobResponse>}
 */
const methodDescriptor_CloudPrint_DeleteJob = new grpc.web.MethodDescriptor(
  '/google.cloudprint.CloudPrint/DeleteJob',
  grpc.web.MethodType.UNARY,
  proto.google.cloudprint.DeleteJobRequest,
  proto.google.cloudprint.DeleteJobResponse,
  /**
   * @param {!proto.google.cloudprint.DeleteJobRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.DeleteJobResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.google.cloudprint.DeleteJobRequest,
 *   !proto.google.cloudprint.DeleteJobResponse>}
 */
const methodInfo_CloudPrint_DeleteJob = new grpc.web.AbstractClientBase.MethodInfo(
  proto.google.cloudprint.DeleteJobResponse,
  /**
   * @param {!proto.google.cloudprint.DeleteJobRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.DeleteJobResponse.deserializeBinary
);


/**
 * @param {!proto.google.cloudprint.DeleteJobRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.google.cloudprint.DeleteJobResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.google.cloudprint.DeleteJobResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.google.cloudprint.CloudPrintClient.prototype.deleteJob =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/DeleteJob',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_DeleteJob,
      callback);
};


/**
 * @param {!proto.google.cloudprint.DeleteJobRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.google.cloudprint.DeleteJobResponse>}
 *     A native promise that resolves to the response
 */
proto.google.cloudprint.CloudPrintPromiseClient.prototype.deleteJob =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/DeleteJob',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_DeleteJob);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.google.cloudprint.ListJobsRequest,
 *   !proto.google.cloudprint.ListJobsResponse>}
 */
const methodDescriptor_CloudPrint_ListJobs = new grpc.web.MethodDescriptor(
  '/google.cloudprint.CloudPrint/ListJobs',
  grpc.web.MethodType.UNARY,
  proto.google.cloudprint.ListJobsRequest,
  proto.google.cloudprint.ListJobsResponse,
  /**
   * @param {!proto.google.cloudprint.ListJobsRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.ListJobsResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.google.cloudprint.ListJobsRequest,
 *   !proto.google.cloudprint.ListJobsResponse>}
 */
const methodInfo_CloudPrint_ListJobs = new grpc.web.AbstractClientBase.MethodInfo(
  proto.google.cloudprint.ListJobsResponse,
  /**
   * @param {!proto.google.cloudprint.ListJobsRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.ListJobsResponse.deserializeBinary
);


/**
 * @param {!proto.google.cloudprint.ListJobsRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.google.cloudprint.ListJobsResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.google.cloudprint.ListJobsResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.google.cloudprint.CloudPrintClient.prototype.listJobs =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/ListJobs',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_ListJobs,
      callback);
};


/**
 * @param {!proto.google.cloudprint.ListJobsRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.google.cloudprint.ListJobsResponse>}
 *     A native promise that resolves to the response
 */
proto.google.cloudprint.CloudPrintPromiseClient.prototype.listJobs =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/ListJobs',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_ListJobs);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.google.cloudprint.GetPrinterRequest,
 *   !proto.google.cloudprint.GetPrinterResponse>}
 */
const methodDescriptor_CloudPrint_GetPrinter = new grpc.web.MethodDescriptor(
  '/google.cloudprint.CloudPrint/GetPrinter',
  grpc.web.MethodType.UNARY,
  proto.google.cloudprint.GetPrinterRequest,
  proto.google.cloudprint.GetPrinterResponse,
  /**
   * @param {!proto.google.cloudprint.GetPrinterRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.GetPrinterResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.google.cloudprint.GetPrinterRequest,
 *   !proto.google.cloudprint.GetPrinterResponse>}
 */
const methodInfo_CloudPrint_GetPrinter = new grpc.web.AbstractClientBase.MethodInfo(
  proto.google.cloudprint.GetPrinterResponse,
  /**
   * @param {!proto.google.cloudprint.GetPrinterRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.GetPrinterResponse.deserializeBinary
);


/**
 * @param {!proto.google.cloudprint.GetPrinterRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.google.cloudprint.GetPrinterResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.google.cloudprint.GetPrinterResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.google.cloudprint.CloudPrintClient.prototype.getPrinter =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/GetPrinter',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_GetPrinter,
      callback);
};


/**
 * @param {!proto.google.cloudprint.GetPrinterRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.google.cloudprint.GetPrinterResponse>}
 *     A native promise that resolves to the response
 */
proto.google.cloudprint.CloudPrintPromiseClient.prototype.getPrinter =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/GetPrinter',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_GetPrinter);
};


/**
 * @const
 * @type {!grpc.web.MethodDescriptor<
 *   !proto.google.cloudprint.SearchPrintersRequest,
 *   !proto.google.cloudprint.SearchPrintersResponse>}
 */
const methodDescriptor_CloudPrint_SearchPrinters = new grpc.web.MethodDescriptor(
  '/google.cloudprint.CloudPrint/SearchPrinters',
  grpc.web.MethodType.UNARY,
  proto.google.cloudprint.SearchPrintersRequest,
  proto.google.cloudprint.SearchPrintersResponse,
  /**
   * @param {!proto.google.cloudprint.SearchPrintersRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.SearchPrintersResponse.deserializeBinary
);


/**
 * @const
 * @type {!grpc.web.AbstractClientBase.MethodInfo<
 *   !proto.google.cloudprint.SearchPrintersRequest,
 *   !proto.google.cloudprint.SearchPrintersResponse>}
 */
const methodInfo_CloudPrint_SearchPrinters = new grpc.web.AbstractClientBase.MethodInfo(
  proto.google.cloudprint.SearchPrintersResponse,
  /**
   * @param {!proto.google.cloudprint.SearchPrintersRequest} request
   * @return {!Uint8Array}
   */
  function(request) {
    return request.serializeBinary();
  },
  proto.google.cloudprint.SearchPrintersResponse.deserializeBinary
);


/**
 * @param {!proto.google.cloudprint.SearchPrintersRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @param {function(?grpc.web.Error, ?proto.google.cloudprint.SearchPrintersResponse)}
 *     callback The callback function(error, response)
 * @return {!grpc.web.ClientReadableStream<!proto.google.cloudprint.SearchPrintersResponse>|undefined}
 *     The XHR Node Readable Stream
 */
proto.google.cloudprint.CloudPrintClient.prototype.searchPrinters =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/SearchPrinters',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_SearchPrinters,
      callback);
};


/**
 * @param {!proto.google.cloudprint.SearchPrintersRequest} request The
 *     request proto
 * @param {?Object<string, string>} metadata User defined
 *     call metadata
 * @return {!Promise<!proto.google.cloudprint.SearchPrintersResponse>}
 *     A native promise that resolves to the response
 */
proto.google.cloudprint.CloudPrintPromiseClient.prototype.searchPrinters =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/google.cloudprint.CloudPrint/SearchPrinters',
      request,
      metadata || {},
      methodDescriptor_CloudPrint_SearchPrinters);
};


}); // goog.scope

