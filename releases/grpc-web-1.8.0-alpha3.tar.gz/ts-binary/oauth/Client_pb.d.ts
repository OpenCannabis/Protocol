import * as jspb from "google-protobuf"

import * as media_MediaItem_pb from '../media/MediaItem_pb';
import * as temporal_Instant_pb from '../temporal/Instant_pb';
import * as oauth_AuthorizationScope_pb from '../oauth/AuthorizationScope_pb';

export class Client extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getSecret(): string;
  setSecret(value: string): void;

  getName(): string;
  setName(value: string): void;

  getContactList(): Array<string>;
  setContactList(value: Array<string>): void;
  clearContactList(): void;
  addContact(value: string, index?: number): void;

  getGrantTypesList(): Array<GrantType>;
  setGrantTypesList(value: Array<GrantType>): void;
  clearGrantTypesList(): void;
  addGrantTypes(value: GrantType, index?: number): void;

  getBranding(): media_MediaItem_pb.MediaItem | undefined;
  setBranding(value?: media_MediaItem_pb.MediaItem): void;
  hasBranding(): boolean;
  clearBranding(): void;

  getOwner(): string;
  setOwner(value: string): void;

  getPolicy(): media_MediaItem_pb.MediaItem | undefined;
  setPolicy(value?: media_MediaItem_pb.MediaItem): void;
  hasPolicy(): boolean;
  clearPolicy(): void;

  getTerms(): media_MediaItem_pb.MediaItem | undefined;
  setTerms(value?: media_MediaItem_pb.MediaItem): void;
  hasTerms(): boolean;
  clearTerms(): void;

  getPublic(): boolean;
  setPublic(value: boolean): void;

  getRedirectUriList(): Array<string>;
  setRedirectUriList(value: Array<string>): void;
  clearRedirectUriList(): void;
  addRedirectUri(value: string, index?: number): void;

  getResponseTypeList(): Array<ResponseType>;
  setResponseTypeList(value: Array<ResponseType>): void;
  clearResponseTypeList(): void;
  addResponseType(value: ResponseType, index?: number): void;

  getScopeList(): Array<oauth_AuthorizationScope_pb.AuthorizationScope>;
  setScopeList(value: Array<oauth_AuthorizationScope_pb.AuthorizationScope>): void;
  clearScopeList(): void;
  addScope(value?: oauth_AuthorizationScope_pb.AuthorizationScope, index?: number): oauth_AuthorizationScope_pb.AuthorizationScope;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Client.AsObject;
  static toObject(includeInstance: boolean, msg: Client): Client.AsObject;
  static serializeBinaryToWriter(message: Client, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Client;
  static deserializeBinaryFromReader(message: Client, reader: jspb.BinaryReader): Client;
}

export namespace Client {
  export type AsObject = {
    id: string,
    secret: string,
    name: string,
    contactList: Array<string>,
    grantTypesList: Array<GrantType>,
    branding?: media_MediaItem_pb.MediaItem.AsObject,
    owner: string,
    policy?: media_MediaItem_pb.MediaItem.AsObject,
    terms?: media_MediaItem_pb.MediaItem.AsObject,
    pb_public: boolean,
    redirectUriList: Array<string>,
    responseTypeList: Array<ResponseType>,
    scopeList: Array<oauth_AuthorizationScope_pb.AuthorizationScope.AsObject>,
  }
}

export class Consent extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getClientId(): string;
  setClientId(value: string): void;

  getExpiresAt(): temporal_Instant_pb.Instant | undefined;
  setExpiresAt(value?: temporal_Instant_pb.Instant): void;
  hasExpiresAt(): boolean;
  clearExpiresAt(): void;

  getRedirectUri(): string;
  setRedirectUri(value: string): void;

  getRequestedScopeList(): Array<string>;
  setRequestedScopeList(value: Array<string>): void;
  clearRequestedScopeList(): void;
  addRequestedScope(value: string, index?: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Consent.AsObject;
  static toObject(includeInstance: boolean, msg: Consent): Consent.AsObject;
  static serializeBinaryToWriter(message: Consent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Consent;
  static deserializeBinaryFromReader(message: Consent, reader: jspb.BinaryReader): Consent;
}

export namespace Consent {
  export type AsObject = {
    id: string,
    clientId: string,
    expiresAt?: temporal_Instant_pb.Instant.AsObject,
    redirectUri: string,
    requestedScopeList: Array<string>,
  }
}

export class ConsentTicket extends jspb.Message {
  getClient(): Client | undefined;
  setClient(value?: Client): void;
  hasClient(): boolean;
  clearClient(): void;

  getConsent(): Consent | undefined;
  setConsent(value?: Consent): void;
  hasConsent(): boolean;
  clearConsent(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ConsentTicket.AsObject;
  static toObject(includeInstance: boolean, msg: ConsentTicket): ConsentTicket.AsObject;
  static serializeBinaryToWriter(message: ConsentTicket, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ConsentTicket;
  static deserializeBinaryFromReader(message: ConsentTicket, reader: jspb.BinaryReader): ConsentTicket;
}

export namespace ConsentTicket {
  export type AsObject = {
    client?: Client.AsObject,
    consent?: Consent.AsObject,
  }
}

export enum ResponseType { 
  UNSPECIFIED_RESPONSE_TYPE = 0,
  TOKEN = 1,
  CODE = 2,
  ID_TOKEN = 3,
}
export enum GrantType { 
  UNSPECIFIED_GRANT_TYPE = 0,
  AUTHORIZATION_CODE = 1,
  REFRESH_TOKEN = 2,
  CLIENT_CREDENTIALS = 3,
}
