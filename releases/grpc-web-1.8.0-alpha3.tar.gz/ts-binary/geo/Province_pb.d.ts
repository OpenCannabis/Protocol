import * as jspb from "google-protobuf"

import * as geo_USState_pb from '../geo/USState_pb';

export class Province extends jspb.Message {
  getState(): geo_USState_pb.USState;
  setState(value: geo_USState_pb.USState): void;

  getProvince(): string;
  setProvince(value: string): void;

  getSpecCase(): Province.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Province.AsObject;
  static toObject(includeInstance: boolean, msg: Province): Province.AsObject;
  static serializeBinaryToWriter(message: Province, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Province;
  static deserializeBinaryFromReader(message: Province, reader: jspb.BinaryReader): Province;
}

export namespace Province {
  export type AsObject = {
    state: geo_USState_pb.USState,
    province: string,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    STATE = 1,
    PROVINCE = 2,
  }
}

