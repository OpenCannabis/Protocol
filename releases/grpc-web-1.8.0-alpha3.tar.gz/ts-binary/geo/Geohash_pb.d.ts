import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as geo_Distance_pb from '../geo/Distance_pb';

export class Geohash extends jspb.Message {
  getComponentList(): Array<string>;
  setComponentList(value: Array<string>): void;
  clearComponentList(): void;
  addComponent(value: string, index?: number): void;

  getElevation(): geo_Distance_pb.Distance | undefined;
  setElevation(value?: geo_Distance_pb.Distance): void;
  hasElevation(): boolean;
  clearElevation(): void;

  getAccuracy(): geo_Distance_pb.Distance | undefined;
  setAccuracy(value?: geo_Distance_pb.Distance): void;
  hasAccuracy(): boolean;
  clearAccuracy(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Geohash.AsObject;
  static toObject(includeInstance: boolean, msg: Geohash): Geohash.AsObject;
  static serializeBinaryToWriter(message: Geohash, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Geohash;
  static deserializeBinaryFromReader(message: Geohash, reader: jspb.BinaryReader): Geohash;
}

export namespace Geohash {
  export type AsObject = {
    componentList: Array<string>,
    elevation?: geo_Distance_pb.Distance.AsObject,
    accuracy?: geo_Distance_pb.Distance.AsObject,
  }
}

