import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as geo_Distance_pb from '../geo/Distance_pb';

export class Point extends jspb.Message {
  getLatitude(): number;
  setLatitude(value: number): void;

  getLongitude(): number;
  setLongitude(value: number): void;

  getElevation(): geo_Distance_pb.Distance | undefined;
  setElevation(value?: geo_Distance_pb.Distance): void;
  hasElevation(): boolean;
  clearElevation(): void;

  getAccuracy(): geo_Distance_pb.Distance | undefined;
  setAccuracy(value?: geo_Distance_pb.Distance): void;
  hasAccuracy(): boolean;
  clearAccuracy(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Point.AsObject;
  static toObject(includeInstance: boolean, msg: Point): Point.AsObject;
  static serializeBinaryToWriter(message: Point, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Point;
  static deserializeBinaryFromReader(message: Point, reader: jspb.BinaryReader): Point;
}

export namespace Point {
  export type AsObject = {
    latitude: number,
    longitude: number,
    elevation?: geo_Distance_pb.Distance.AsObject,
    accuracy?: geo_Distance_pb.Distance.AsObject,
  }
}

export class WorldCoordinate extends jspb.Message {
  getRight(): number;
  setRight(value: number): void;

  getDown(): number;
  setDown(value: number): void;

  getElevation(): geo_Distance_pb.Distance | undefined;
  setElevation(value?: geo_Distance_pb.Distance): void;
  hasElevation(): boolean;
  clearElevation(): void;

  getAccuracy(): geo_Distance_pb.Distance | undefined;
  setAccuracy(value?: geo_Distance_pb.Distance): void;
  hasAccuracy(): boolean;
  clearAccuracy(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WorldCoordinate.AsObject;
  static toObject(includeInstance: boolean, msg: WorldCoordinate): WorldCoordinate.AsObject;
  static serializeBinaryToWriter(message: WorldCoordinate, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WorldCoordinate;
  static deserializeBinaryFromReader(message: WorldCoordinate, reader: jspb.BinaryReader): WorldCoordinate;
}

export namespace WorldCoordinate {
  export type AsObject = {
    right: number,
    down: number,
    elevation?: geo_Distance_pb.Distance.AsObject,
    accuracy?: geo_Distance_pb.Distance.AsObject,
  }
}

export class MapCoordinate extends jspb.Message {
  getX(): number;
  setX(value: number): void;

  getY(): number;
  setY(value: number): void;

  getRight(): number;
  setRight(value: number): void;

  getDown(): number;
  setDown(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MapCoordinate.AsObject;
  static toObject(includeInstance: boolean, msg: MapCoordinate): MapCoordinate.AsObject;
  static serializeBinaryToWriter(message: MapCoordinate, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MapCoordinate;
  static deserializeBinaryFromReader(message: MapCoordinate, reader: jspb.BinaryReader): MapCoordinate;
}

export namespace MapCoordinate {
  export type AsObject = {
    x: number,
    y: number,
    right: number,
    down: number,
  }
}

export class MapPosition extends jspb.Message {
  getPoint(): Point | undefined;
  setPoint(value?: Point): void;
  hasPoint(): boolean;
  clearPoint(): void;

  getTile(): MapCoordinate | undefined;
  setTile(value?: MapCoordinate): void;
  hasTile(): boolean;
  clearTile(): void;

  getCoordinate(): WorldCoordinate | undefined;
  setCoordinate(value?: WorldCoordinate): void;
  hasCoordinate(): boolean;
  clearCoordinate(): void;

  getZoom(): number;
  setZoom(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MapPosition.AsObject;
  static toObject(includeInstance: boolean, msg: MapPosition): MapPosition.AsObject;
  static serializeBinaryToWriter(message: MapPosition, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MapPosition;
  static deserializeBinaryFromReader(message: MapPosition, reader: jspb.BinaryReader): MapPosition;
}

export namespace MapPosition {
  export type AsObject = {
    point?: Point.AsObject,
    tile?: MapCoordinate.AsObject,
    coordinate?: WorldCoordinate.AsObject,
    zoom: number,
  }
}

