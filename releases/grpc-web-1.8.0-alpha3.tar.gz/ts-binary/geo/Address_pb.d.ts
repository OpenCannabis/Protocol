import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class Address extends jspb.Message {
  getFirstLine(): string;
  setFirstLine(value: string): void;

  getSecondLine(): string;
  setSecondLine(value: string): void;

  getCity(): string;
  setCity(value: string): void;

  getState(): string;
  setState(value: string): void;

  getZipcode(): string;
  setZipcode(value: string): void;

  getCountry(): string;
  setCountry(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Address.AsObject;
  static toObject(includeInstance: boolean, msg: Address): Address.AsObject;
  static serializeBinaryToWriter(message: Address, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Address;
  static deserializeBinaryFromReader(message: Address, reader: jspb.BinaryReader): Address;
}

export namespace Address {
  export type AsObject = {
    firstLine: string,
    secondLine: string,
    city: string,
    state: string,
    zipcode: string,
    country: string,
  }
}

