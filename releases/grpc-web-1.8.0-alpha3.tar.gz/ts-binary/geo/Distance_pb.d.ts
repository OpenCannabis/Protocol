import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class LocationAccuracy extends jspb.Message {
  getEstimate(): boolean;
  setEstimate(value: boolean): void;

  getValue(): DistanceValue | undefined;
  setValue(value?: DistanceValue): void;
  hasValue(): boolean;
  clearValue(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LocationAccuracy.AsObject;
  static toObject(includeInstance: boolean, msg: LocationAccuracy): LocationAccuracy.AsObject;
  static serializeBinaryToWriter(message: LocationAccuracy, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LocationAccuracy;
  static deserializeBinaryFromReader(message: LocationAccuracy, reader: jspb.BinaryReader): LocationAccuracy;
}

export namespace LocationAccuracy {
  export type AsObject = {
    estimate: boolean,
    value?: DistanceValue.AsObject,
  }
}

export class DistanceValue extends jspb.Message {
  getUnit(): DistanceUnit;
  setUnit(value: DistanceUnit): void;

  getValue(): number;
  setValue(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DistanceValue.AsObject;
  static toObject(includeInstance: boolean, msg: DistanceValue): DistanceValue.AsObject;
  static serializeBinaryToWriter(message: DistanceValue, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DistanceValue;
  static deserializeBinaryFromReader(message: DistanceValue, reader: jspb.BinaryReader): DistanceValue;
}

export namespace DistanceValue {
  export type AsObject = {
    unit: DistanceUnit,
    value: number,
  }
}

export class Distance extends jspb.Message {
  getEstimate(): boolean;
  setEstimate(value: boolean): void;

  getAccuracy(): LocationAccuracy | undefined;
  setAccuracy(value?: LocationAccuracy): void;
  hasAccuracy(): boolean;
  clearAccuracy(): void;

  getUnit(): DistanceUnit;
  setUnit(value: DistanceUnit): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Distance.AsObject;
  static toObject(includeInstance: boolean, msg: Distance): Distance.AsObject;
  static serializeBinaryToWriter(message: Distance, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Distance;
  static deserializeBinaryFromReader(message: Distance, reader: jspb.BinaryReader): Distance;
}

export namespace Distance {
  export type AsObject = {
    estimate: boolean,
    accuracy?: LocationAccuracy.AsObject,
    unit: DistanceUnit,
  }
}

export enum DistanceUnit { 
  METERS = 0,
  INCHES = 1,
  FEET = 2,
  MILLIMETERS = 3,
  CENTIMETERS = 4,
  KILOMETERS = 5,
  MILES = 6,
}
