import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as partner_PartnerKey_pb from '../partner/PartnerKey_pb';

export class LocationKey extends jspb.Message {
  getPartner(): partner_PartnerKey_pb.PartnerKey | undefined;
  setPartner(value?: partner_PartnerKey_pb.PartnerKey): void;
  hasPartner(): boolean;
  clearPartner(): void;

  getCode(): string;
  setCode(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LocationKey.AsObject;
  static toObject(includeInstance: boolean, msg: LocationKey): LocationKey.AsObject;
  static serializeBinaryToWriter(message: LocationKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LocationKey;
  static deserializeBinaryFromReader(message: LocationKey, reader: jspb.BinaryReader): LocationKey;
}

export namespace LocationKey {
  export type AsObject = {
    partner?: partner_PartnerKey_pb.PartnerKey.AsObject,
    code: string,
  }
}

