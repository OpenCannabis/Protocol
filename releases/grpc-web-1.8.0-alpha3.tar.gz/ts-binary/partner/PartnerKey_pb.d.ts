import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class PartnerKey extends jspb.Message {
  getCode(): string;
  setCode(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PartnerKey.AsObject;
  static toObject(includeInstance: boolean, msg: PartnerKey): PartnerKey.AsObject;
  static serializeBinaryToWriter(message: PartnerKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PartnerKey;
  static deserializeBinaryFromReader(message: PartnerKey, reader: jspb.BinaryReader): PartnerKey;
}

export namespace PartnerKey {
  export type AsObject = {
    code: string,
  }
}

