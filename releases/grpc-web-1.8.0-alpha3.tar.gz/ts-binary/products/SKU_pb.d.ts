import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as commerce_Item_pb from '../commerce/Item_pb';
import * as partner_integrations_IntegrationSettings_pb from '../partner/integrations/IntegrationSettings_pb';

export class MappedSKU extends jspb.Message {
  getSku(): string;
  setSku(value: string): void;

  getForeign(): string;
  setForeign(value: string): void;

  getType(): SKUType;
  setType(value: SKUType): void;

  getSystem(): partner_integrations_IntegrationSettings_pb.IntegrationPartner;
  setSystem(value: partner_integrations_IntegrationSettings_pb.IntegrationPartner): void;

  getUnit(): boolean;
  setUnit(value: boolean): void;

  getVariant(): commerce_Item_pb.VariantSpec | undefined;
  setVariant(value?: commerce_Item_pb.VariantSpec): void;
  hasVariant(): boolean;
  clearVariant(): void;

  getTargetCase(): MappedSKU.TargetCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MappedSKU.AsObject;
  static toObject(includeInstance: boolean, msg: MappedSKU): MappedSKU.AsObject;
  static serializeBinaryToWriter(message: MappedSKU, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MappedSKU;
  static deserializeBinaryFromReader(message: MappedSKU, reader: jspb.BinaryReader): MappedSKU;
}

export namespace MappedSKU {
  export type AsObject = {
    sku: string,
    foreign: string,
    type: SKUType,
    system: partner_integrations_IntegrationSettings_pb.IntegrationPartner,
    unit: boolean,
    variant?: commerce_Item_pb.VariantSpec.AsObject,
  }

  export enum TargetCase { 
    TARGET_NOT_SET = 0,
    UNIT = 10,
    VARIANT = 11,
  }
}

export enum SKUType { 
  ITEM = 0,
  PRODUCT = 1,
}
