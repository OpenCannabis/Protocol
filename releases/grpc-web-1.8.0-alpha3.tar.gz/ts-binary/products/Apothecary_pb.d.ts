import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';
import * as content_MaterialsData_pb from '../content/MaterialsData_pb';
import * as content_ProductContent_pb from '../content/ProductContent_pb';

export class Apothecary extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getType(): Apothecary.Type;
  setType(value: Apothecary.Type): void;

  getProduct(): content_ProductContent_pb.ProductContent | undefined;
  setProduct(value?: content_ProductContent_pb.ProductContent): void;
  hasProduct(): boolean;
  clearProduct(): void;

  getMaterial(): content_MaterialsData_pb.MaterialsData | undefined;
  setMaterial(value?: content_MaterialsData_pb.MaterialsData): void;
  hasMaterial(): boolean;
  clearMaterial(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Apothecary.AsObject;
  static toObject(includeInstance: boolean, msg: Apothecary): Apothecary.AsObject;
  static serializeBinaryToWriter(message: Apothecary, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Apothecary;
  static deserializeBinaryFromReader(message: Apothecary, reader: jspb.BinaryReader): Apothecary;
}

export namespace Apothecary {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    type: Apothecary.Type,
    product?: content_ProductContent_pb.ProductContent.AsObject,
    material?: content_MaterialsData_pb.MaterialsData.AsObject,
  }

  export enum Type { 
    UNSPECIFIED_APOTHECARY = 0,
    TOPICAL = 1,
    TINCTURE = 2,
    CAPSULE = 3,
    INJECTOR = 4,
    SPRAY = 5,
    SUBLINGUAL = 6,
    SUPPOSITORY = 7,
    TRANSDERMAL = 8,
    BATH_AND_BODY = 9,
    LOTION = 10,
  }
}

