import * as jspb from "google-protobuf"

import * as content_Name_pb from '../../content/Name_pb';
import * as media_MediaItem_pb from '../../media/MediaItem_pb';

export class CustomSection extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getFilter(): FilteredSection;
  setFilter(value: FilteredSection): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CustomSection.AsObject;
  static toObject(includeInstance: boolean, msg: CustomSection): CustomSection.AsObject;
  static serializeBinaryToWriter(message: CustomSection, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CustomSection;
  static deserializeBinaryFromReader(message: CustomSection, reader: jspb.BinaryReader): CustomSection;
}

export namespace CustomSection {
  export type AsObject = {
    id: string,
    filter: FilteredSection,
  }
}

export class SectionMedia extends jspb.Message {
  getTabletHomescreenMedia(): media_MediaItem_pb.MediaItem | undefined;
  setTabletHomescreenMedia(value?: media_MediaItem_pb.MediaItem): void;
  hasTabletHomescreenMedia(): boolean;
  clearTabletHomescreenMedia(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SectionMedia.AsObject;
  static toObject(includeInstance: boolean, msg: SectionMedia): SectionMedia.AsObject;
  static serializeBinaryToWriter(message: SectionMedia, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SectionMedia;
  static deserializeBinaryFromReader(message: SectionMedia, reader: jspb.BinaryReader): SectionMedia;
}

export namespace SectionMedia {
  export type AsObject = {
    tabletHomescreenMedia?: media_MediaItem_pb.MediaItem.AsObject,
  }
}

export class SectionSettings extends jspb.Message {
  getName(): content_Name_pb.Name | undefined;
  setName(value?: content_Name_pb.Name): void;
  hasName(): boolean;
  clearName(): void;

  getMedia(): SectionMedia | undefined;
  setMedia(value?: SectionMedia): void;
  hasMedia(): boolean;
  clearMedia(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SectionSettings.AsObject;
  static toObject(includeInstance: boolean, msg: SectionSettings): SectionSettings.AsObject;
  static serializeBinaryToWriter(message: SectionSettings, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SectionSettings;
  static deserializeBinaryFromReader(message: SectionSettings, reader: jspb.BinaryReader): SectionSettings;
}

export namespace SectionSettings {
  export type AsObject = {
    name?: content_Name_pb.Name.AsObject,
    media?: SectionMedia.AsObject,
  }
}

export class SectionSpec extends jspb.Message {
  getSection(): Section;
  setSection(value: Section): void;

  getCustomSection(): CustomSection | undefined;
  setCustomSection(value?: CustomSection): void;
  hasCustomSection(): boolean;
  clearCustomSection(): void;

  getName(): string;
  setName(value: string): void;

  getSettings(): SectionSettings | undefined;
  setSettings(value?: SectionSettings): void;
  hasSettings(): boolean;
  clearSettings(): void;

  getFlagsList(): Array<SectionFlag>;
  setFlagsList(value: Array<SectionFlag>): void;
  clearFlagsList(): void;
  addFlags(value: SectionFlag, index?: number): void;

  getSpecCase(): SectionSpec.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SectionSpec.AsObject;
  static toObject(includeInstance: boolean, msg: SectionSpec): SectionSpec.AsObject;
  static serializeBinaryToWriter(message: SectionSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SectionSpec;
  static deserializeBinaryFromReader(message: SectionSpec, reader: jspb.BinaryReader): SectionSpec;
}

export namespace SectionSpec {
  export type AsObject = {
    section: Section,
    customSection?: CustomSection.AsObject,
    name: string,
    settings?: SectionSettings.AsObject,
    flagsList: Array<SectionFlag>,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    SECTION = 1,
    CUSTOM_SECTION = 2,
    NAME = 3,
  }
}

export enum SectionFlag { 
  HIDDEN = 0,
  FEATURED = 1,
}
export enum Section { 
  UNSPECIFIED = 0,
  FLOWERS = 1,
  EXTRACTS = 2,
  EDIBLES = 3,
  CARTRIDGES = 4,
  APOTHECARY = 5,
  PREROLLS = 6,
  PLANTS = 7,
  MERCHANDISE = 8,
}
export enum FilteredSection { 
  ON_SALE = 0,
  HOUSE = 1,
  CBD = 2,
  SEARCH = 3,
}
