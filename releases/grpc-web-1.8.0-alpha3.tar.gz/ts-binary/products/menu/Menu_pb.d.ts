import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../../core/Datamodel_pb';
import * as base_ProductKey_pb from '../../base/ProductKey_pb';
import * as media_MediaKey_pb from '../../media/MediaKey_pb';
import * as temporal_Instant_pb from '../../temporal/Instant_pb';
import * as products_menu_Section_pb from '../../products/menu/Section_pb';
import * as crypto_primitives_Integrity_pb from '../../crypto/primitives/Integrity_pb';
import * as partner_LocationKey_pb from '../../partner/LocationKey_pb';
import * as products_SKU_pb from '../../products/SKU_pb';
import * as products_Apothecary_pb from '../../products/Apothecary_pb';
import * as products_Cartridge_pb from '../../products/Cartridge_pb';
import * as products_Edible_pb from '../../products/Edible_pb';
import * as products_Extract_pb from '../../products/Extract_pb';
import * as products_Flower_pb from '../../products/Flower_pb';
import * as products_Merchandise_pb from '../../products/Merchandise_pb';
import * as products_Plant_pb from '../../products/Plant_pb';
import * as products_Preroll_pb from '../../products/Preroll_pb';

export class MenuSettings extends jspb.Message {
  getFull(): boolean;
  setFull(value: boolean): void;

  getKeysOnly(): boolean;
  setKeysOnly(value: boolean): void;

  getSnapshot(): crypto_primitives_Integrity_pb.Hash | undefined;
  setSnapshot(value?: crypto_primitives_Integrity_pb.Hash): void;
  hasSnapshot(): boolean;
  clearSnapshot(): void;

  getFingerprint(): crypto_primitives_Integrity_pb.Hash | undefined;
  setFingerprint(value?: crypto_primitives_Integrity_pb.Hash): void;
  hasFingerprint(): boolean;
  clearFingerprint(): void;

  getSectionList(): Array<products_menu_Section_pb.Section>;
  setSectionList(value: Array<products_menu_Section_pb.Section>): void;
  clearSectionList(): void;
  addSection(value: products_menu_Section_pb.Section, index?: number): void;

  getAvailableSectionList(): Array<products_menu_Section_pb.Section>;
  setAvailableSectionList(value: Array<products_menu_Section_pb.Section>): void;
  clearAvailableSectionList(): void;
  addAvailableSection(value: products_menu_Section_pb.Section, index?: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuSettings.AsObject;
  static toObject(includeInstance: boolean, msg: MenuSettings): MenuSettings.AsObject;
  static serializeBinaryToWriter(message: MenuSettings, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuSettings;
  static deserializeBinaryFromReader(message: MenuSettings, reader: jspb.BinaryReader): MenuSettings;
}

export namespace MenuSettings {
  export type AsObject = {
    full: boolean,
    keysOnly: boolean,
    snapshot?: crypto_primitives_Integrity_pb.Hash.AsObject,
    fingerprint?: crypto_primitives_Integrity_pb.Hash.AsObject,
    sectionList: Array<products_menu_Section_pb.Section>,
    availableSectionList: Array<products_menu_Section_pb.Section>,
  }
}

export class Metadata extends jspb.Message {
  getScope(): string;
  setScope(value: string): void;

  getVersion(): number;
  setVersion(value: number): void;

  getStatus(): Status;
  setStatus(value: Status): void;

  getFlagsList(): Array<Flag>;
  setFlagsList(value: Array<Flag>): void;
  clearFlagsList(): void;
  addFlags(value: Flag, index?: number): void;

  getPublished(): temporal_Instant_pb.Instant | undefined;
  setPublished(value?: temporal_Instant_pb.Instant): void;
  hasPublished(): boolean;
  clearPublished(): void;

  getSettings(): MenuSettings | undefined;
  setSettings(value?: MenuSettings): void;
  hasSettings(): boolean;
  clearSettings(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Metadata.AsObject;
  static toObject(includeInstance: boolean, msg: Metadata): Metadata.AsObject;
  static serializeBinaryToWriter(message: Metadata, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Metadata;
  static deserializeBinaryFromReader(message: Metadata, reader: jspb.BinaryReader): Metadata;
}

export namespace Metadata {
  export type AsObject = {
    scope: string,
    version: number,
    status: Status,
    flagsList: Array<Flag>,
    published?: temporal_Instant_pb.Instant.AsObject,
    settings?: MenuSettings.AsObject,
  }
}

export class ProductTag extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getPartner(): string;
  setPartner(value: string): void;

  getLocation(): string;
  setLocation(value: string): void;

  getDisplay(): string;
  setDisplay(value: string): void;

  getColor(): string;
  setColor(value: string): void;

  getDescription(): string;
  setDescription(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ProductTag.AsObject;
  static toObject(includeInstance: boolean, msg: ProductTag): ProductTag.AsObject;
  static serializeBinaryToWriter(message: ProductTag, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ProductTag;
  static deserializeBinaryFromReader(message: ProductTag, reader: jspb.BinaryReader): ProductTag;
}

export namespace ProductTag {
  export type AsObject = {
    id: string,
    partner: string,
    location: string,
    display: string,
    color: string,
    description: string,
  }
}

export class ForeignReference extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getKey(): string;
  setKey(value: string): void;

  getPartner(): string;
  setPartner(value: string): void;

  getLocation(): string;
  setLocation(value: string): void;

  getDomain(): string;
  setDomain(value: string): void;

  getLink(): string;
  setLink(value: string): void;

  getAttached(): temporal_Instant_pb.Instant | undefined;
  setAttached(value?: temporal_Instant_pb.Instant): void;
  hasAttached(): boolean;
  clearAttached(): void;

  getValidated(): temporal_Instant_pb.Instant | undefined;
  setValidated(value?: temporal_Instant_pb.Instant): void;
  hasValidated(): boolean;
  clearValidated(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ForeignReference.AsObject;
  static toObject(includeInstance: boolean, msg: ForeignReference): ForeignReference.AsObject;
  static serializeBinaryToWriter(message: ForeignReference, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ForeignReference;
  static deserializeBinaryFromReader(message: ForeignReference, reader: jspb.BinaryReader): ForeignReference;
}

export namespace ForeignReference {
  export type AsObject = {
    id: string,
    key: string,
    partner: string,
    location: string,
    domain: string,
    link: string,
    attached?: temporal_Instant_pb.Instant.AsObject,
    validated?: temporal_Instant_pb.Instant.AsObject,
  }
}

export class MenuProduct extends jspb.Message {
  getKey(): base_ProductKey_pb.ProductKey | undefined;
  setKey(value?: base_ProductKey_pb.ProductKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getTagList(): Array<ProductTag>;
  setTagList(value: Array<ProductTag>): void;
  clearTagList(): void;
  addTag(value?: ProductTag, index?: number): ProductTag;

  getRefList(): Array<ForeignReference>;
  setRefList(value: Array<ForeignReference>): void;
  clearRefList(): void;
  addRef(value?: ForeignReference, index?: number): ForeignReference;

  getMediaList(): Array<media_MediaKey_pb.MediaReference>;
  setMediaList(value: Array<media_MediaKey_pb.MediaReference>): void;
  clearMediaList(): void;
  addMedia(value?: media_MediaKey_pb.MediaReference, index?: number): media_MediaKey_pb.MediaReference;

  getSkuList(): Array<products_SKU_pb.MappedSKU>;
  setSkuList(value: Array<products_SKU_pb.MappedSKU>): void;
  clearSkuList(): void;
  addSku(value?: products_SKU_pb.MappedSKU, index?: number): products_SKU_pb.MappedSKU;

  getOwner(): partner_LocationKey_pb.LocationKey | undefined;
  setOwner(value?: partner_LocationKey_pb.LocationKey): void;
  hasOwner(): boolean;
  clearOwner(): void;

  getApothecary(): products_Apothecary_pb.Apothecary | undefined;
  setApothecary(value?: products_Apothecary_pb.Apothecary): void;
  hasApothecary(): boolean;
  clearApothecary(): void;

  getCartridge(): products_Cartridge_pb.Cartridge | undefined;
  setCartridge(value?: products_Cartridge_pb.Cartridge): void;
  hasCartridge(): boolean;
  clearCartridge(): void;

  getEdible(): products_Edible_pb.Edible | undefined;
  setEdible(value?: products_Edible_pb.Edible): void;
  hasEdible(): boolean;
  clearEdible(): void;

  getExtract(): products_Extract_pb.Extract | undefined;
  setExtract(value?: products_Extract_pb.Extract): void;
  hasExtract(): boolean;
  clearExtract(): void;

  getFlower(): products_Flower_pb.Flower | undefined;
  setFlower(value?: products_Flower_pb.Flower): void;
  hasFlower(): boolean;
  clearFlower(): void;

  getMerchandise(): products_Merchandise_pb.Merchandise | undefined;
  setMerchandise(value?: products_Merchandise_pb.Merchandise): void;
  hasMerchandise(): boolean;
  clearMerchandise(): void;

  getPlant(): products_Plant_pb.Plant | undefined;
  setPlant(value?: products_Plant_pb.Plant): void;
  hasPlant(): boolean;
  clearPlant(): void;

  getPreroll(): products_Preroll_pb.Preroll | undefined;
  setPreroll(value?: products_Preroll_pb.Preroll): void;
  hasPreroll(): boolean;
  clearPreroll(): void;

  getProductCase(): MenuProduct.ProductCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuProduct.AsObject;
  static toObject(includeInstance: boolean, msg: MenuProduct): MenuProduct.AsObject;
  static serializeBinaryToWriter(message: MenuProduct, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuProduct;
  static deserializeBinaryFromReader(message: MenuProduct, reader: jspb.BinaryReader): MenuProduct;
}

export namespace MenuProduct {
  export type AsObject = {
    key?: base_ProductKey_pb.ProductKey.AsObject,
    tagList: Array<ProductTag.AsObject>,
    refList: Array<ForeignReference.AsObject>,
    mediaList: Array<media_MediaKey_pb.MediaReference.AsObject>,
    skuList: Array<products_SKU_pb.MappedSKU.AsObject>,
    owner?: partner_LocationKey_pb.LocationKey.AsObject,
    apothecary?: products_Apothecary_pb.Apothecary.AsObject,
    cartridge?: products_Cartridge_pb.Cartridge.AsObject,
    edible?: products_Edible_pb.Edible.AsObject,
    extract?: products_Extract_pb.Extract.AsObject,
    flower?: products_Flower_pb.Flower.AsObject,
    merchandise?: products_Merchandise_pb.Merchandise.AsObject,
    plant?: products_Plant_pb.Plant.AsObject,
    preroll?: products_Preroll_pb.Preroll.AsObject,
  }

  export enum ProductCase { 
    PRODUCT_NOT_SET = 0,
    APOTHECARY = 10,
    CARTRIDGE = 11,
    EDIBLE = 12,
    EXTRACT = 13,
    FLOWER = 14,
    MERCHANDISE = 15,
    PLANT = 16,
    PREROLL = 17,
  }
}

export class SectionData extends jspb.Message {
  getCount(): number;
  setCount(value: number): void;

  getSection(): products_menu_Section_pb.SectionSpec | undefined;
  setSection(value?: products_menu_Section_pb.SectionSpec): void;
  hasSection(): boolean;
  clearSection(): void;

  getProductList(): Array<MenuProduct>;
  setProductList(value: Array<MenuProduct>): void;
  clearProductList(): void;
  addProduct(value?: MenuProduct, index?: number): MenuProduct;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SectionData.AsObject;
  static toObject(includeInstance: boolean, msg: SectionData): SectionData.AsObject;
  static serializeBinaryToWriter(message: SectionData, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SectionData;
  static deserializeBinaryFromReader(message: SectionData, reader: jspb.BinaryReader): SectionData;
}

export namespace SectionData {
  export type AsObject = {
    count: number,
    section?: products_menu_Section_pb.SectionSpec.AsObject,
    productList: Array<MenuProduct.AsObject>,
  }
}

export class SectionedMenu extends jspb.Message {
  getCount(): number;
  setCount(value: number): void;

  getPayloadList(): Array<SectionData>;
  setPayloadList(value: Array<SectionData>): void;
  clearPayloadList(): void;
  addPayload(value?: SectionData, index?: number): SectionData;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SectionedMenu.AsObject;
  static toObject(includeInstance: boolean, msg: SectionedMenu): SectionedMenu.AsObject;
  static serializeBinaryToWriter(message: SectionedMenu, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SectionedMenu;
  static deserializeBinaryFromReader(message: SectionedMenu, reader: jspb.BinaryReader): SectionedMenu;
}

export namespace SectionedMenu {
  export type AsObject = {
    count: number,
    payloadList: Array<SectionData.AsObject>,
  }
}

export class StaticMenu extends jspb.Message {
  getApothecaryMap(): jspb.Map<string, products_Apothecary_pb.Apothecary>;
  clearApothecaryMap(): void;

  getCartridgesMap(): jspb.Map<string, products_Cartridge_pb.Cartridge>;
  clearCartridgesMap(): void;

  getEdiblesMap(): jspb.Map<string, products_Edible_pb.Edible>;
  clearEdiblesMap(): void;

  getExtractsMap(): jspb.Map<string, products_Extract_pb.Extract>;
  clearExtractsMap(): void;

  getFlowersMap(): jspb.Map<string, products_Flower_pb.Flower>;
  clearFlowersMap(): void;

  getMerchandiseMap(): jspb.Map<string, products_Merchandise_pb.Merchandise>;
  clearMerchandiseMap(): void;

  getPlantsMap(): jspb.Map<string, products_Plant_pb.Plant>;
  clearPlantsMap(): void;

  getPrerollsMap(): jspb.Map<string, products_Preroll_pb.Preroll>;
  clearPrerollsMap(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StaticMenu.AsObject;
  static toObject(includeInstance: boolean, msg: StaticMenu): StaticMenu.AsObject;
  static serializeBinaryToWriter(message: StaticMenu, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StaticMenu;
  static deserializeBinaryFromReader(message: StaticMenu, reader: jspb.BinaryReader): StaticMenu;
}

export namespace StaticMenu {
  export type AsObject = {
    apothecaryMap: Array<[string, products_Apothecary_pb.Apothecary.AsObject]>,
    cartridgesMap: Array<[string, products_Cartridge_pb.Cartridge.AsObject]>,
    ediblesMap: Array<[string, products_Edible_pb.Edible.AsObject]>,
    extractsMap: Array<[string, products_Extract_pb.Extract.AsObject]>,
    flowersMap: Array<[string, products_Flower_pb.Flower.AsObject]>,
    merchandiseMap: Array<[string, products_Merchandise_pb.Merchandise.AsObject]>,
    plantsMap: Array<[string, products_Plant_pb.Plant.AsObject]>,
    prerollsMap: Array<[string, products_Preroll_pb.Preroll.AsObject]>,
  }
}

export class Menu extends jspb.Message {
  getMetadata(): Metadata | undefined;
  setMetadata(value?: Metadata): void;
  hasMetadata(): boolean;
  clearMetadata(): void;

  getPayload(): SectionedMenu | undefined;
  setPayload(value?: SectionedMenu): void;
  hasPayload(): boolean;
  clearPayload(): void;

  getMenu(): StaticMenu | undefined;
  setMenu(value?: StaticMenu): void;
  hasMenu(): boolean;
  clearMenu(): void;

  getContentCase(): Menu.ContentCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Menu.AsObject;
  static toObject(includeInstance: boolean, msg: Menu): Menu.AsObject;
  static serializeBinaryToWriter(message: Menu, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Menu;
  static deserializeBinaryFromReader(message: Menu, reader: jspb.BinaryReader): Menu;
}

export namespace Menu {
  export type AsObject = {
    metadata?: Metadata.AsObject,
    payload?: SectionedMenu.AsObject,
    menu?: StaticMenu.AsObject,
  }

  export enum ContentCase { 
    CONTENT_NOT_SET = 0,
    PAYLOAD = 3,
    MENU = 4,
  }
}

export enum Status { 
  UNPUBLISHED = 0,
  LIVE = 1,
}
export enum Flag { 
  DRAFT = 0,
  PRIVATE = 1,
  OUT_OF_DATE = 2,
}
