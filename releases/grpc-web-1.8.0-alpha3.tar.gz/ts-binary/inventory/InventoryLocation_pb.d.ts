import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as contact_ContactInfo_pb from '../contact/ContactInfo_pb';
import * as inventory_InventoryProduct_pb from '../inventory/InventoryProduct_pb';

export class InventoryLocationKey extends jspb.Message {
  getUuid(): string;
  setUuid(value: string): void;

  getPartner(): string;
  setPartner(value: string): void;

  getLocation(): string;
  setLocation(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InventoryLocationKey.AsObject;
  static toObject(includeInstance: boolean, msg: InventoryLocationKey): InventoryLocationKey.AsObject;
  static serializeBinaryToWriter(message: InventoryLocationKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InventoryLocationKey;
  static deserializeBinaryFromReader(message: InventoryLocationKey, reader: jspb.BinaryReader): InventoryLocationKey;
}

export namespace InventoryLocationKey {
  export type AsObject = {
    uuid: string,
    partner: string,
    location: string,
  }
}

export class InventoryLocation extends jspb.Message {
  getKey(): InventoryLocationKey | undefined;
  setKey(value?: InventoryLocationKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getType(): InventoryLocationType;
  setType(value: InventoryLocationType): void;

  getName(): string;
  setName(value: string): void;

  getContact(): contact_ContactInfo_pb.ContactInfo | undefined;
  setContact(value?: contact_ContactInfo_pb.ContactInfo): void;
  hasContact(): boolean;
  clearContact(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InventoryLocation.AsObject;
  static toObject(includeInstance: boolean, msg: InventoryLocation): InventoryLocation.AsObject;
  static serializeBinaryToWriter(message: InventoryLocation, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InventoryLocation;
  static deserializeBinaryFromReader(message: InventoryLocation, reader: jspb.BinaryReader): InventoryLocation;
}

export namespace InventoryLocation {
  export type AsObject = {
    key?: InventoryLocationKey.AsObject,
    type: InventoryLocationType,
    name: string,
    contact?: contact_ContactInfo_pb.ContactInfo.AsObject,
  }
}

export class InventoryBinding extends jspb.Message {
  getHeldBy(): InventoryLocationKey | undefined;
  setHeldBy(value?: InventoryLocationKey): void;
  hasHeldBy(): boolean;
  clearHeldBy(): void;

  getItem(): inventory_InventoryProduct_pb.InventoryProduct | undefined;
  setItem(value?: inventory_InventoryProduct_pb.InventoryProduct): void;
  hasItem(): boolean;
  clearItem(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InventoryBinding.AsObject;
  static toObject(includeInstance: boolean, msg: InventoryBinding): InventoryBinding.AsObject;
  static serializeBinaryToWriter(message: InventoryBinding, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InventoryBinding;
  static deserializeBinaryFromReader(message: InventoryBinding, reader: jspb.BinaryReader): InventoryBinding;
}

export namespace InventoryBinding {
  export type AsObject = {
    heldBy?: InventoryLocationKey.AsObject,
    item?: inventory_InventoryProduct_pb.InventoryProduct.AsObject,
  }
}

export enum InventoryLocationType { 
  RETAIL = 0,
  WAREHOUSE = 1,
  PRODUCTION = 2,
}
