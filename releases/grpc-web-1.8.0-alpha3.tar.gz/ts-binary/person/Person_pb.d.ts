import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as temporal_Date_pb from '../temporal/Date_pb';
import * as contact_ContactInfo_pb from '../contact/ContactInfo_pb';
import * as person_PersonName_pb from '../person/PersonName_pb';

export class CustomPronouns extends jspb.Message {
  getNominative(): string;
  setNominative(value: string): void;

  getObjective(): string;
  setObjective(value: string): void;

  getDeterminer(): string;
  setDeterminer(value: string): void;

  getPronoun(): string;
  setPronoun(value: string): void;

  getReflexive(): string;
  setReflexive(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CustomPronouns.AsObject;
  static toObject(includeInstance: boolean, msg: CustomPronouns): CustomPronouns.AsObject;
  static serializeBinaryToWriter(message: CustomPronouns, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CustomPronouns;
  static deserializeBinaryFromReader(message: CustomPronouns, reader: jspb.BinaryReader): CustomPronouns;
}

export namespace CustomPronouns {
  export type AsObject = {
    nominative: string,
    objective: string,
    determiner: string,
    pronoun: string,
    reflexive: string,
  }
}

export class Gender extends jspb.Message {
  getGender(): GenderCategory;
  setGender(value: GenderCategory): void;

  getKnown(): KnownPronouns;
  setKnown(value: KnownPronouns): void;

  getCustom(): CustomPronouns | undefined;
  setCustom(value?: CustomPronouns): void;
  hasCustom(): boolean;
  clearCustom(): void;

  getPronounsCase(): Gender.PronounsCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Gender.AsObject;
  static toObject(includeInstance: boolean, msg: Gender): Gender.AsObject;
  static serializeBinaryToWriter(message: Gender, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Gender;
  static deserializeBinaryFromReader(message: Gender, reader: jspb.BinaryReader): Gender;
}

export namespace Gender {
  export type AsObject = {
    gender: GenderCategory,
    known: KnownPronouns,
    custom?: CustomPronouns.AsObject,
  }

  export enum PronounsCase { 
    PRONOUNS_NOT_SET = 0,
    KNOWN = 10,
    CUSTOM = 11,
  }
}

export class Person extends jspb.Message {
  getName(): person_PersonName_pb.Name | undefined;
  setName(value?: person_PersonName_pb.Name): void;
  hasName(): boolean;
  clearName(): void;

  getLegalName(): person_PersonName_pb.Name | undefined;
  setLegalName(value?: person_PersonName_pb.Name): void;
  hasLegalName(): boolean;
  clearLegalName(): void;

  getAlternateName(): person_PersonName_pb.Name | undefined;
  setAlternateName(value?: person_PersonName_pb.Name): void;
  hasAlternateName(): boolean;
  clearAlternateName(): void;

  getContact(): contact_ContactInfo_pb.ContactInfo | undefined;
  setContact(value?: contact_ContactInfo_pb.ContactInfo): void;
  hasContact(): boolean;
  clearContact(): void;

  getDateOfBirth(): temporal_Date_pb.Date | undefined;
  setDateOfBirth(value?: temporal_Date_pb.Date): void;
  hasDateOfBirth(): boolean;
  clearDateOfBirth(): void;

  getGender(): Gender | undefined;
  setGender(value?: Gender): void;
  hasGender(): boolean;
  clearGender(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Person.AsObject;
  static toObject(includeInstance: boolean, msg: Person): Person.AsObject;
  static serializeBinaryToWriter(message: Person, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Person;
  static deserializeBinaryFromReader(message: Person, reader: jspb.BinaryReader): Person;
}

export namespace Person {
  export type AsObject = {
    name?: person_PersonName_pb.Name.AsObject,
    legalName?: person_PersonName_pb.Name.AsObject,
    alternateName?: person_PersonName_pb.Name.AsObject,
    contact?: contact_ContactInfo_pb.ContactInfo.AsObject,
    dateOfBirth?: temporal_Date_pb.Date.AsObject,
    gender?: Gender.AsObject,
  }
}

export enum GenderCategory { 
  UNSPECIFIED = 0,
  MALE = 1,
  CIS_MALE = 1,
  FEMALE = 2,
  CIS_FEMALE = 2,
  TRANS_MALE = 3,
  TRANS_FEMALE = 4,
  NON_BINARY = 5,
  GENDER_FLUID = 6,
  BI_GENDER = 7,
  PAN_GENDER = 8,
  DECLINE_TO_STATE = 99,
}
export enum KnownPronouns { 
  NORMATIVE = 0,
  HE = 1,
  SHE = 2,
  IT = 3,
  THEY = 4,
  NE = 5,
  VE = 6,
  SPIVAK = 7,
  ZE = 8,
  XE = 9,
}
