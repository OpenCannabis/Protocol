import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as media_MediaType_pb from '../media/MediaType_pb';

export class MediaKey extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaKey.AsObject;
  static toObject(includeInstance: boolean, msg: MediaKey): MediaKey.AsObject;
  static serializeBinaryToWriter(message: MediaKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaKey;
  static deserializeBinaryFromReader(message: MediaKey, reader: jspb.BinaryReader): MediaKey;
}

export namespace MediaKey {
  export type AsObject = {
    id: string,
  }
}

export class MediaReference extends jspb.Message {
  getKey(): MediaKey | undefined;
  setKey(value?: MediaKey): void;
  hasKey(): boolean;
  clearKey(): void;

  getUri(): string;
  setUri(value: string): void;

  getType(): media_MediaType_pb.MediaType | undefined;
  setType(value?: media_MediaType_pb.MediaType): void;
  hasType(): boolean;
  clearType(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaReference.AsObject;
  static toObject(includeInstance: boolean, msg: MediaReference): MediaReference.AsObject;
  static serializeBinaryToWriter(message: MediaReference, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaReference;
  static deserializeBinaryFromReader(message: MediaReference, reader: jspb.BinaryReader): MediaReference;
}

export namespace MediaReference {
  export type AsObject = {
    key?: MediaKey.AsObject,
    uri: string,
    type?: media_MediaType_pb.MediaType.AsObject,
  }
}

