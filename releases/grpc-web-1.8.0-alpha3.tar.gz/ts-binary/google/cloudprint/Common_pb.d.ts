import * as jspb from "google-protobuf"

export class Marker extends jspb.Message {
  getVendorId(): string;
  setVendorId(value: string): void;

  getType(): Marker.Type;
  setType(value: Marker.Type): void;

  getColor(): Marker.Color | undefined;
  setColor(value?: Marker.Color): void;
  hasColor(): boolean;
  clearColor(): void;

  getCustomDisplayName(): string;
  setCustomDisplayName(value: string): void;

  getCustomDisplayNameLocalizedList(): Array<LocalizedString>;
  setCustomDisplayNameLocalizedList(value: Array<LocalizedString>): void;
  clearCustomDisplayNameLocalizedList(): void;
  addCustomDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Marker.AsObject;
  static toObject(includeInstance: boolean, msg: Marker): Marker.AsObject;
  static serializeBinaryToWriter(message: Marker, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Marker;
  static deserializeBinaryFromReader(message: Marker, reader: jspb.BinaryReader): Marker;
}

export namespace Marker {
  export type AsObject = {
    vendorId: string,
    type: Marker.Type,
    color?: Marker.Color.AsObject,
    customDisplayName: string,
    customDisplayNameLocalizedList: Array<LocalizedString.AsObject>,
  }

  export class Color extends jspb.Message {
    getType(): Marker.Color.Type;
    setType(value: Marker.Color.Type): void;

    getCustomDisplayName(): string;
    setCustomDisplayName(value: string): void;

    getCustomDisplayNameLocalizedList(): Array<LocalizedString>;
    setCustomDisplayNameLocalizedList(value: Array<LocalizedString>): void;
    clearCustomDisplayNameLocalizedList(): void;
    addCustomDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Color.AsObject;
    static toObject(includeInstance: boolean, msg: Color): Color.AsObject;
    static serializeBinaryToWriter(message: Color, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Color;
    static deserializeBinaryFromReader(message: Color, reader: jspb.BinaryReader): Color;
  }

  export namespace Color {
    export type AsObject = {
      type: Marker.Color.Type,
      customDisplayName: string,
      customDisplayNameLocalizedList: Array<LocalizedString.AsObject>,
    }

    export enum Type { 
      CUSTOM = 0,
      BLACK = 1,
      COLOR = 2,
      CYAN = 3,
      MAGENTA = 4,
      YELLOW = 5,
      LIGHT_CYAN = 6,
      LIGHT_MAGENTA = 7,
      GRAY = 8,
      LIGHT_GRAY = 9,
      PIGMENT_BLACK = 10,
      MATTE_BLACK = 11,
      PHOTO_CYAN = 12,
      PHOTO_MAGENTA = 13,
      PHOTO_YELLOW = 14,
      PHOTO_GRAY = 15,
      RED = 16,
      GREEN = 17,
      BLUE = 18,
    }
  }


  export enum Type { 
    CUSTOM = 0,
    TONER = 1,
    INK = 2,
    STAPLES = 3,
  }
}

export class Cover extends jspb.Message {
  getVendorId(): string;
  setVendorId(value: string): void;

  getType(): Cover.Type;
  setType(value: Cover.Type): void;

  getIndex(): number;
  setIndex(value: number): void;

  getCustomDisplayName(): string;
  setCustomDisplayName(value: string): void;

  getCustomDisplayNameLocalizedList(): Array<LocalizedString>;
  setCustomDisplayNameLocalizedList(value: Array<LocalizedString>): void;
  clearCustomDisplayNameLocalizedList(): void;
  addCustomDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Cover.AsObject;
  static toObject(includeInstance: boolean, msg: Cover): Cover.AsObject;
  static serializeBinaryToWriter(message: Cover, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Cover;
  static deserializeBinaryFromReader(message: Cover, reader: jspb.BinaryReader): Cover;
}

export namespace Cover {
  export type AsObject = {
    vendorId: string,
    type: Cover.Type,
    index: number,
    customDisplayName: string,
    customDisplayNameLocalizedList: Array<LocalizedString.AsObject>,
  }

  export enum Type { 
    CUSTOM = 0,
    DOOR = 1,
    COVER = 2,
  }
}

export class MediaPath extends jspb.Message {
  getVendorId(): string;
  setVendorId(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaPath.AsObject;
  static toObject(includeInstance: boolean, msg: MediaPath): MediaPath.AsObject;
  static serializeBinaryToWriter(message: MediaPath, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaPath;
  static deserializeBinaryFromReader(message: MediaPath, reader: jspb.BinaryReader): MediaPath;
}

export namespace MediaPath {
  export type AsObject = {
    vendorId: string,
  }
}

export class VendorCapability extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getDisplayName(): string;
  setDisplayName(value: string): void;

  getType(): VendorCapability.Type;
  setType(value: VendorCapability.Type): void;

  getRangeCap(): RangeCapability | undefined;
  setRangeCap(value?: RangeCapability): void;
  hasRangeCap(): boolean;
  clearRangeCap(): void;

  getSelectCap(): SelectCapability | undefined;
  setSelectCap(value?: SelectCapability): void;
  hasSelectCap(): boolean;
  clearSelectCap(): void;

  getTypedValueCap(): TypedValueCapability | undefined;
  setTypedValueCap(value?: TypedValueCapability): void;
  hasTypedValueCap(): boolean;
  clearTypedValueCap(): void;

  getDisplayNameLocalizedList(): Array<LocalizedString>;
  setDisplayNameLocalizedList(value: Array<LocalizedString>): void;
  clearDisplayNameLocalizedList(): void;
  addDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VendorCapability.AsObject;
  static toObject(includeInstance: boolean, msg: VendorCapability): VendorCapability.AsObject;
  static serializeBinaryToWriter(message: VendorCapability, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VendorCapability;
  static deserializeBinaryFromReader(message: VendorCapability, reader: jspb.BinaryReader): VendorCapability;
}

export namespace VendorCapability {
  export type AsObject = {
    id: string,
    displayName: string,
    type: VendorCapability.Type,
    rangeCap?: RangeCapability.AsObject,
    selectCap?: SelectCapability.AsObject,
    typedValueCap?: TypedValueCapability.AsObject,
    displayNameLocalizedList: Array<LocalizedString.AsObject>,
  }

  export enum Type { 
    RANGE = 0,
    SELECT = 1,
    TYPED_VALUE = 2,
  }
}

export class RangeCapability extends jspb.Message {
  getValueType(): RangeCapability.ValueType;
  setValueType(value: RangeCapability.ValueType): void;

  getDefault(): string;
  setDefault(value: string): void;

  getMin(): string;
  setMin(value: string): void;

  getMax(): string;
  setMax(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RangeCapability.AsObject;
  static toObject(includeInstance: boolean, msg: RangeCapability): RangeCapability.AsObject;
  static serializeBinaryToWriter(message: RangeCapability, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RangeCapability;
  static deserializeBinaryFromReader(message: RangeCapability, reader: jspb.BinaryReader): RangeCapability;
}

export namespace RangeCapability {
  export type AsObject = {
    valueType: RangeCapability.ValueType,
    pb_default: string,
    min: string,
    max: string,
  }

  export enum ValueType { 
    FLOAT = 0,
    INTEGER = 1,
  }
}

export class SelectCapability extends jspb.Message {
  getOptionList(): Array<SelectCapability.Option>;
  setOptionList(value: Array<SelectCapability.Option>): void;
  clearOptionList(): void;
  addOption(value?: SelectCapability.Option, index?: number): SelectCapability.Option;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SelectCapability.AsObject;
  static toObject(includeInstance: boolean, msg: SelectCapability): SelectCapability.AsObject;
  static serializeBinaryToWriter(message: SelectCapability, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SelectCapability;
  static deserializeBinaryFromReader(message: SelectCapability, reader: jspb.BinaryReader): SelectCapability;
}

export namespace SelectCapability {
  export type AsObject = {
    optionList: Array<SelectCapability.Option.AsObject>,
  }

  export class Option extends jspb.Message {
    getValue(): string;
    setValue(value: string): void;

    getDisplayName(): string;
    setDisplayName(value: string): void;

    getIsDefault(): boolean;
    setIsDefault(value: boolean): void;

    getDisplayNameLocalizedList(): Array<LocalizedString>;
    setDisplayNameLocalizedList(value: Array<LocalizedString>): void;
    clearDisplayNameLocalizedList(): void;
    addDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      value: string,
      displayName: string,
      isDefault: boolean,
      displayNameLocalizedList: Array<LocalizedString.AsObject>,
    }
  }

}

export class TypedValueCapability extends jspb.Message {
  getValueType(): TypedValueCapability.ValueType;
  setValueType(value: TypedValueCapability.ValueType): void;

  getDefault(): string;
  setDefault(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TypedValueCapability.AsObject;
  static toObject(includeInstance: boolean, msg: TypedValueCapability): TypedValueCapability.AsObject;
  static serializeBinaryToWriter(message: TypedValueCapability, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TypedValueCapability;
  static deserializeBinaryFromReader(message: TypedValueCapability, reader: jspb.BinaryReader): TypedValueCapability;
}

export namespace TypedValueCapability {
  export type AsObject = {
    valueType: TypedValueCapability.ValueType,
    pb_default: string,
  }

  export enum ValueType { 
    BOOLEAN = 0,
    FLOAT = 1,
    INTEGER = 2,
    STRING = 3,
  }
}

export class Color extends jspb.Message {
  getOptionList(): Array<Color.Option>;
  setOptionList(value: Array<Color.Option>): void;
  clearOptionList(): void;
  addOption(value?: Color.Option, index?: number): Color.Option;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Color.AsObject;
  static toObject(includeInstance: boolean, msg: Color): Color.AsObject;
  static serializeBinaryToWriter(message: Color, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Color;
  static deserializeBinaryFromReader(message: Color, reader: jspb.BinaryReader): Color;
}

export namespace Color {
  export type AsObject = {
    optionList: Array<Color.Option.AsObject>,
  }

  export class Option extends jspb.Message {
    getVendorId(): string;
    setVendorId(value: string): void;

    getType(): Color.Type;
    setType(value: Color.Type): void;

    getCustomDisplayName(): string;
    setCustomDisplayName(value: string): void;

    getIsDefault(): boolean;
    setIsDefault(value: boolean): void;

    getCustomDisplayNameLocalizedList(): Array<LocalizedString>;
    setCustomDisplayNameLocalizedList(value: Array<LocalizedString>): void;
    clearCustomDisplayNameLocalizedList(): void;
    addCustomDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      vendorId: string,
      type: Color.Type,
      customDisplayName: string,
      isDefault: boolean,
      customDisplayNameLocalizedList: Array<LocalizedString.AsObject>,
    }
  }


  export enum Type { 
    STANDARD_COLOR = 0,
    STANDARD_MONOCHROME = 1,
    CUSTOM_COLOR = 2,
    CUSTOM_MONOCHROME = 3,
    AUTO = 4,
  }
}

export class Duplex extends jspb.Message {
  getOptionList(): Array<Duplex.Option>;
  setOptionList(value: Array<Duplex.Option>): void;
  clearOptionList(): void;
  addOption(value?: Duplex.Option, index?: number): Duplex.Option;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Duplex.AsObject;
  static toObject(includeInstance: boolean, msg: Duplex): Duplex.AsObject;
  static serializeBinaryToWriter(message: Duplex, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Duplex;
  static deserializeBinaryFromReader(message: Duplex, reader: jspb.BinaryReader): Duplex;
}

export namespace Duplex {
  export type AsObject = {
    optionList: Array<Duplex.Option.AsObject>,
  }

  export class Option extends jspb.Message {
    getType(): Duplex.Type;
    setType(value: Duplex.Type): void;

    getIsDefault(): boolean;
    setIsDefault(value: boolean): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      type: Duplex.Type,
      isDefault: boolean,
    }
  }


  export enum Type { 
    NO_DUPLEX = 0,
    LONG_EDGE = 1,
    SHORT_EDGE = 2,
  }
}

export class PageOrientation extends jspb.Message {
  getOptionList(): Array<PageOrientation.Option>;
  setOptionList(value: Array<PageOrientation.Option>): void;
  clearOptionList(): void;
  addOption(value?: PageOrientation.Option, index?: number): PageOrientation.Option;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PageOrientation.AsObject;
  static toObject(includeInstance: boolean, msg: PageOrientation): PageOrientation.AsObject;
  static serializeBinaryToWriter(message: PageOrientation, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PageOrientation;
  static deserializeBinaryFromReader(message: PageOrientation, reader: jspb.BinaryReader): PageOrientation;
}

export namespace PageOrientation {
  export type AsObject = {
    optionList: Array<PageOrientation.Option.AsObject>,
  }

  export class Option extends jspb.Message {
    getType(): PageOrientation.Type;
    setType(value: PageOrientation.Type): void;

    getIsDefault(): boolean;
    setIsDefault(value: boolean): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      type: PageOrientation.Type,
      isDefault: boolean,
    }
  }


  export enum Type { 
    PORTRAIT = 0,
    LANDSCAPE = 1,
    AUTO = 2,
  }
}

export class Copies extends jspb.Message {
  getDefault(): number;
  setDefault(value: number): void;

  getMax(): number;
  setMax(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Copies.AsObject;
  static toObject(includeInstance: boolean, msg: Copies): Copies.AsObject;
  static serializeBinaryToWriter(message: Copies, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Copies;
  static deserializeBinaryFromReader(message: Copies, reader: jspb.BinaryReader): Copies;
}

export namespace Copies {
  export type AsObject = {
    pb_default: number,
    max: number,
  }
}

export class Margins extends jspb.Message {
  getOptionList(): Array<Margins.Option>;
  setOptionList(value: Array<Margins.Option>): void;
  clearOptionList(): void;
  addOption(value?: Margins.Option, index?: number): Margins.Option;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Margins.AsObject;
  static toObject(includeInstance: boolean, msg: Margins): Margins.AsObject;
  static serializeBinaryToWriter(message: Margins, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Margins;
  static deserializeBinaryFromReader(message: Margins, reader: jspb.BinaryReader): Margins;
}

export namespace Margins {
  export type AsObject = {
    optionList: Array<Margins.Option.AsObject>,
  }

  export class Option extends jspb.Message {
    getType(): Margins.Type;
    setType(value: Margins.Type): void;

    getTopMicrons(): number;
    setTopMicrons(value: number): void;

    getRightMicrons(): number;
    setRightMicrons(value: number): void;

    getBottomMicrons(): number;
    setBottomMicrons(value: number): void;

    getLeftMicrons(): number;
    setLeftMicrons(value: number): void;

    getIsDefault(): boolean;
    setIsDefault(value: boolean): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      type: Margins.Type,
      topMicrons: number,
      rightMicrons: number,
      bottomMicrons: number,
      leftMicrons: number,
      isDefault: boolean,
    }
  }


  export enum Type { 
    BORDERLESS = 0,
    STANDARD = 1,
    CUSTOM = 2,
  }
}

export class Dpi extends jspb.Message {
  getOptionList(): Array<Dpi.Option>;
  setOptionList(value: Array<Dpi.Option>): void;
  clearOptionList(): void;
  addOption(value?: Dpi.Option, index?: number): Dpi.Option;

  getMinHorizontalDpi(): number;
  setMinHorizontalDpi(value: number): void;

  getMaxHorizontalDpi(): number;
  setMaxHorizontalDpi(value: number): void;

  getMinVerticalDpi(): number;
  setMinVerticalDpi(value: number): void;

  getMaxVerticalDpi(): number;
  setMaxVerticalDpi(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Dpi.AsObject;
  static toObject(includeInstance: boolean, msg: Dpi): Dpi.AsObject;
  static serializeBinaryToWriter(message: Dpi, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Dpi;
  static deserializeBinaryFromReader(message: Dpi, reader: jspb.BinaryReader): Dpi;
}

export namespace Dpi {
  export type AsObject = {
    optionList: Array<Dpi.Option.AsObject>,
    minHorizontalDpi: number,
    maxHorizontalDpi: number,
    minVerticalDpi: number,
    maxVerticalDpi: number,
  }

  export class Option extends jspb.Message {
    getHorizontalDpi(): number;
    setHorizontalDpi(value: number): void;

    getVerticalDpi(): number;
    setVerticalDpi(value: number): void;

    getIsDefault(): boolean;
    setIsDefault(value: boolean): void;

    getCustomDisplayName(): string;
    setCustomDisplayName(value: string): void;

    getVendorId(): string;
    setVendorId(value: string): void;

    getCustomDisplayNameLocalizedList(): Array<LocalizedString>;
    setCustomDisplayNameLocalizedList(value: Array<LocalizedString>): void;
    clearCustomDisplayNameLocalizedList(): void;
    addCustomDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      horizontalDpi: number,
      verticalDpi: number,
      isDefault: boolean,
      customDisplayName: string,
      vendorId: string,
      customDisplayNameLocalizedList: Array<LocalizedString.AsObject>,
    }
  }

}

export class FitToPage extends jspb.Message {
  getOptionList(): Array<FitToPage.Option>;
  setOptionList(value: Array<FitToPage.Option>): void;
  clearOptionList(): void;
  addOption(value?: FitToPage.Option, index?: number): FitToPage.Option;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FitToPage.AsObject;
  static toObject(includeInstance: boolean, msg: FitToPage): FitToPage.AsObject;
  static serializeBinaryToWriter(message: FitToPage, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FitToPage;
  static deserializeBinaryFromReader(message: FitToPage, reader: jspb.BinaryReader): FitToPage;
}

export namespace FitToPage {
  export type AsObject = {
    optionList: Array<FitToPage.Option.AsObject>,
  }

  export class Option extends jspb.Message {
    getType(): FitToPage.Type;
    setType(value: FitToPage.Type): void;

    getIsDefault(): boolean;
    setIsDefault(value: boolean): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      type: FitToPage.Type,
      isDefault: boolean,
    }
  }


  export enum Type { 
    NO_FITTING = 0,
    FIT_TO_PAGE = 1,
    GROW_TO_PAGE = 2,
    SHRINK_TO_PAGE = 3,
    FILL_PAGE = 4,
  }
}

export class PageRange extends jspb.Message {
  getDefaultList(): Array<PageRange.Interval>;
  setDefaultList(value: Array<PageRange.Interval>): void;
  clearDefaultList(): void;
  addDefault(value?: PageRange.Interval, index?: number): PageRange.Interval;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PageRange.AsObject;
  static toObject(includeInstance: boolean, msg: PageRange): PageRange.AsObject;
  static serializeBinaryToWriter(message: PageRange, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PageRange;
  static deserializeBinaryFromReader(message: PageRange, reader: jspb.BinaryReader): PageRange;
}

export namespace PageRange {
  export type AsObject = {
    defaultList: Array<PageRange.Interval.AsObject>,
  }

  export class Interval extends jspb.Message {
    getStart(): number;
    setStart(value: number): void;

    getEnd(): number;
    setEnd(value: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Interval.AsObject;
    static toObject(includeInstance: boolean, msg: Interval): Interval.AsObject;
    static serializeBinaryToWriter(message: Interval, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Interval;
    static deserializeBinaryFromReader(message: Interval, reader: jspb.BinaryReader): Interval;
  }

  export namespace Interval {
    export type AsObject = {
      start: number,
      end: number,
    }
  }

}

export class MediaSize extends jspb.Message {
  getOptionList(): Array<MediaSize.Option>;
  setOptionList(value: Array<MediaSize.Option>): void;
  clearOptionList(): void;
  addOption(value?: MediaSize.Option, index?: number): MediaSize.Option;

  getMaxWidthMicrons(): number;
  setMaxWidthMicrons(value: number): void;

  getMaxHeightMicrons(): number;
  setMaxHeightMicrons(value: number): void;

  getMinWidthMicrons(): number;
  setMinWidthMicrons(value: number): void;

  getMinHeightMicrons(): number;
  setMinHeightMicrons(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaSize.AsObject;
  static toObject(includeInstance: boolean, msg: MediaSize): MediaSize.AsObject;
  static serializeBinaryToWriter(message: MediaSize, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaSize;
  static deserializeBinaryFromReader(message: MediaSize, reader: jspb.BinaryReader): MediaSize;
}

export namespace MediaSize {
  export type AsObject = {
    optionList: Array<MediaSize.Option.AsObject>,
    maxWidthMicrons: number,
    maxHeightMicrons: number,
    minWidthMicrons: number,
    minHeightMicrons: number,
  }

  export class Option extends jspb.Message {
    getName(): MediaSize.Name;
    setName(value: MediaSize.Name): void;

    getWidthMicrons(): number;
    setWidthMicrons(value: number): void;

    getHeightMicrons(): number;
    setHeightMicrons(value: number): void;

    getIsContinuousFeed(): boolean;
    setIsContinuousFeed(value: boolean): void;

    getIsDefault(): boolean;
    setIsDefault(value: boolean): void;

    getCustomDisplayName(): string;
    setCustomDisplayName(value: string): void;

    getVendorId(): string;
    setVendorId(value: string): void;

    getCustomDisplayNameLocalizedList(): Array<LocalizedString>;
    setCustomDisplayNameLocalizedList(value: Array<LocalizedString>): void;
    clearCustomDisplayNameLocalizedList(): void;
    addCustomDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      name: MediaSize.Name,
      widthMicrons: number,
      heightMicrons: number,
      isContinuousFeed: boolean,
      isDefault: boolean,
      customDisplayName: string,
      vendorId: string,
      customDisplayNameLocalizedList: Array<LocalizedString.AsObject>,
    }
  }


  export enum Name { 
    CUSTOM = 0,
    NA_INDEX_3X5 = 100,
    NA_PERSONAL = 101,
    NA_MONARCH = 102,
    NA_NUMBER_9 = 103,
    NA_INDEX_4X6 = 104,
    NA_NUMBER_10 = 105,
    NA_A2 = 106,
    NA_NUMBER_11 = 107,
    NA_NUMBER_12 = 108,
    NA_5X7 = 109,
    NA_INDEX_5X8 = 110,
    NA_NUMBER_14 = 111,
    NA_INVOICE = 112,
    NA_INDEX_4X6_EXT = 113,
    NA_6X9 = 114,
    NA_C5 = 115,
    NA_7X9 = 116,
    NA_EXECUTIVE = 117,
    NA_GOVT_LETTER = 118,
    NA_GOVT_LEGAL = 119,
    NA_QUARTO = 120,
    NA_LETTER = 121,
    NA_FANFOLD_EUR = 122,
    NA_LETTER_PLUS = 123,
    NA_FOOLSCAP = 124,
    NA_LEGAL = 125,
    NA_SUPER_A = 126,
    NA_9X11 = 127,
    NA_ARCH_A = 128,
    NA_LETTER_EXTRA = 129,
    NA_LEGAL_EXTRA = 130,
    NA_10X11 = 131,
    NA_10X13 = 132,
    NA_10X14 = 133,
    NA_10X15 = 134,
    NA_11X12 = 135,
    NA_EDP = 136,
    NA_FANFOLD_US = 137,
    NA_11X15 = 138,
    NA_LEDGER = 139,
    NA_EUR_EDP = 140,
    NA_ARCH_B = 141,
    NA_12X19 = 142,
    NA_B_PLUS = 143,
    NA_SUPER_B = 144,
    NA_C = 145,
    NA_ARCH_C = 146,
    NA_D = 147,
    NA_ARCH_D = 148,
    NA_ASME_F = 149,
    NA_WIDE_FORMAT = 150,
    NA_E = 151,
    NA_ARCH_E = 152,
    NA_F = 153,
    ROC_16K = 200,
    ROC_8K = 201,
    PRC_32K = 202,
    PRC_1 = 203,
    PRC_2 = 204,
    PRC_4 = 205,
    PRC_5 = 206,
    PRC_8 = 207,
    PRC_6 = 208,
    PRC_3 = 209,
    PRC_16K = 210,
    PRC_7 = 211,
    OM_JUURO_KU_KAI = 212,
    OM_PA_KAI = 213,
    OM_DAI_PA_KAI = 214,
    PRC_10 = 215,
    ISO_A10 = 301,
    ISO_A9 = 302,
    ISO_A8 = 303,
    ISO_A7 = 304,
    ISO_A6 = 305,
    ISO_A5 = 306,
    ISO_A5_EXTRA = 307,
    ISO_A4 = 308,
    ISO_A4_TAB = 309,
    ISO_A4_EXTRA = 310,
    ISO_A3 = 311,
    ISO_A4X3 = 312,
    ISO_A4X4 = 313,
    ISO_A4X5 = 314,
    ISO_A4X6 = 315,
    ISO_A4X7 = 316,
    ISO_A4X8 = 317,
    ISO_A4X9 = 318,
    ISO_A3_EXTRA = 319,
    ISO_A2 = 320,
    ISO_A3X3 = 321,
    ISO_A3X4 = 322,
    ISO_A3X5 = 323,
    ISO_A3X6 = 324,
    ISO_A3X7 = 325,
    ISO_A1 = 326,
    ISO_A2X3 = 327,
    ISO_A2X4 = 328,
    ISO_A2X5 = 329,
    ISO_A0 = 330,
    ISO_A1X3 = 331,
    ISO_A1X4 = 332,
    ISO_2A0 = 333,
    ISO_A0X3 = 334,
    ISO_B10 = 335,
    ISO_B9 = 336,
    ISO_B8 = 337,
    ISO_B7 = 338,
    ISO_B6 = 339,
    ISO_B6C4 = 340,
    ISO_B5 = 341,
    ISO_B5_EXTRA = 342,
    ISO_B4 = 343,
    ISO_B3 = 344,
    ISO_B2 = 345,
    ISO_B1 = 346,
    ISO_B0 = 347,
    ISO_C10 = 348,
    ISO_C9 = 349,
    ISO_C8 = 350,
    ISO_C7 = 351,
    ISO_C7C6 = 352,
    ISO_C6 = 353,
    ISO_C6C5 = 354,
    ISO_C5 = 355,
    ISO_C4 = 356,
    ISO_C3 = 357,
    ISO_C2 = 358,
    ISO_C1 = 359,
    ISO_C0 = 360,
    ISO_DL = 361,
    ISO_RA2 = 362,
    ISO_SRA2 = 363,
    ISO_RA1 = 364,
    ISO_SRA1 = 365,
    ISO_RA0 = 366,
    ISO_SRA0 = 367,
    JIS_B10 = 400,
    JIS_B9 = 401,
    JIS_B8 = 402,
    JIS_B7 = 403,
    JIS_B6 = 404,
    JIS_B5 = 405,
    JIS_B4 = 406,
    JIS_B3 = 407,
    JIS_B2 = 408,
    JIS_B1 = 409,
    JIS_B0 = 410,
    JIS_EXEC = 411,
    JPN_CHOU4 = 412,
    JPN_HAGAKI = 413,
    JPN_YOU4 = 414,
    JPN_CHOU2 = 415,
    JPN_CHOU3 = 416,
    JPN_OUFUKU = 417,
    JPN_KAHU = 418,
    JPN_KAKU2 = 419,
    OM_SMALL_PHOTO = 500,
    OM_ITALIAN = 501,
    OM_POSTFIX = 502,
    OM_LARGE_PHOTO = 503,
    OM_FOLIO = 504,
    OM_FOLIO_SP = 505,
    OM_INVITE = 506,
  }
}

export class Collate extends jspb.Message {
  getDefault(): boolean;
  setDefault(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Collate.AsObject;
  static toObject(includeInstance: boolean, msg: Collate): Collate.AsObject;
  static serializeBinaryToWriter(message: Collate, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Collate;
  static deserializeBinaryFromReader(message: Collate, reader: jspb.BinaryReader): Collate;
}

export namespace Collate {
  export type AsObject = {
    pb_default: boolean,
  }
}

export class ReverseOrder extends jspb.Message {
  getDefault(): boolean;
  setDefault(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ReverseOrder.AsObject;
  static toObject(includeInstance: boolean, msg: ReverseOrder): ReverseOrder.AsObject;
  static serializeBinaryToWriter(message: ReverseOrder, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ReverseOrder;
  static deserializeBinaryFromReader(message: ReverseOrder, reader: jspb.BinaryReader): ReverseOrder;
}

export namespace ReverseOrder {
  export type AsObject = {
    pb_default: boolean,
  }
}

export class LocalizedString extends jspb.Message {
  getLocale(): LocalizedString.Locale;
  setLocale(value: LocalizedString.Locale): void;

  getValue(): string;
  setValue(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LocalizedString.AsObject;
  static toObject(includeInstance: boolean, msg: LocalizedString): LocalizedString.AsObject;
  static serializeBinaryToWriter(message: LocalizedString, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LocalizedString;
  static deserializeBinaryFromReader(message: LocalizedString, reader: jspb.BinaryReader): LocalizedString;
}

export namespace LocalizedString {
  export type AsObject = {
    locale: LocalizedString.Locale,
    value: string,
  }

  export enum Locale { 
    AF = 0,
    AM = 1,
    AR = 2,
    AR_XB = 3,
    BG = 4,
    BN = 5,
    CA = 6,
    CS = 7,
    CY = 8,
    DA = 9,
    DE = 10,
    DE_AT = 11,
    DE_CH = 12,
    EL = 13,
    EN = 14,
    EN_GB = 15,
    EN_IE = 16,
    EN_IN = 17,
    EN_SG = 18,
    EN_XA = 19,
    EN_XC = 20,
    EN_ZA = 21,
    ES = 22,
    ES_419 = 23,
    ES_AR = 24,
    ES_BO = 25,
    ES_CL = 26,
    ES_CO = 27,
    ES_CR = 28,
    ES_DO = 29,
    ES_EC = 30,
    ES_GT = 31,
    ES_HN = 32,
    ES_MX = 33,
    ES_NI = 34,
    ES_PA = 35,
    ES_PE = 36,
    ES_PR = 37,
    ES_PY = 38,
    ES_SV = 39,
    ES_US = 40,
    ES_UY = 41,
    ES_VE = 42,
    ET = 43,
    EU = 44,
    FA = 45,
    FI = 46,
    FR = 47,
    FR_CA = 48,
    FR_CH = 49,
    GL = 50,
    GU = 51,
    HE = 52,
    HI = 53,
    HR = 54,
    HU = 55,
    HY = 56,
    ID = 57,
    IN = 58,
    IT = 59,
    JA = 60,
    KA = 61,
    KM = 62,
    KN = 63,
    KO = 64,
    LN = 65,
    LO = 66,
    LT = 67,
    LV = 68,
    ML = 69,
    MO = 70,
    MR = 71,
    MS = 72,
    NB = 73,
    NE = 74,
    NL = 75,
    NO = 76,
    PL = 77,
    PT = 78,
    PT_BR = 79,
    PT_PT = 80,
    RM = 81,
    RO = 82,
    RU = 83,
    SK = 84,
    SL = 85,
    SR = 86,
    SR_LATN = 87,
    SV = 88,
    SW = 89,
    TA = 90,
    TE = 91,
    TH = 92,
    TL = 93,
    TR = 94,
    UK = 95,
    UR = 96,
    VI = 97,
    ZH = 98,
    ZH_CN = 99,
    ZH_HK = 100,
    ZH_TW = 101,
    ZU = 102,
  }
}

export class SupportedContentType extends jspb.Message {
  getContentType(): string;
  setContentType(value: string): void;

  getMinVersion(): string;
  setMinVersion(value: string): void;

  getMaxVersion(): string;
  setMaxVersion(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SupportedContentType.AsObject;
  static toObject(includeInstance: boolean, msg: SupportedContentType): SupportedContentType.AsObject;
  static serializeBinaryToWriter(message: SupportedContentType, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SupportedContentType;
  static deserializeBinaryFromReader(message: SupportedContentType, reader: jspb.BinaryReader): SupportedContentType;
}

export namespace SupportedContentType {
  export type AsObject = {
    contentType: string,
    minVersion: string,
    maxVersion: string,
  }
}

export class PrintingSpeed extends jspb.Message {
  getOptionList(): Array<PrintingSpeed.Option>;
  setOptionList(value: Array<PrintingSpeed.Option>): void;
  clearOptionList(): void;
  addOption(value?: PrintingSpeed.Option, index?: number): PrintingSpeed.Option;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PrintingSpeed.AsObject;
  static toObject(includeInstance: boolean, msg: PrintingSpeed): PrintingSpeed.AsObject;
  static serializeBinaryToWriter(message: PrintingSpeed, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PrintingSpeed;
  static deserializeBinaryFromReader(message: PrintingSpeed, reader: jspb.BinaryReader): PrintingSpeed;
}

export namespace PrintingSpeed {
  export type AsObject = {
    optionList: Array<PrintingSpeed.Option.AsObject>,
  }

  export class Option extends jspb.Message {
    getSpeedPpm(): number;
    setSpeedPpm(value: number): void;

    getColorTypeList(): Array<Color.Type>;
    setColorTypeList(value: Array<Color.Type>): void;
    clearColorTypeList(): void;
    addColorType(value: Color.Type, index?: number): void;

    getMediaSizeNameList(): Array<MediaSize.Name>;
    setMediaSizeNameList(value: Array<MediaSize.Name>): void;
    clearMediaSizeNameList(): void;
    addMediaSizeName(value: MediaSize.Name, index?: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Option.AsObject;
    static toObject(includeInstance: boolean, msg: Option): Option.AsObject;
    static serializeBinaryToWriter(message: Option, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Option;
    static deserializeBinaryFromReader(message: Option, reader: jspb.BinaryReader): Option;
  }

  export namespace Option {
    export type AsObject = {
      speedPpm: number,
      colorTypeList: Array<Color.Type>,
      mediaSizeNameList: Array<MediaSize.Name>,
    }
  }

}

export class PwgRasterConfig extends jspb.Message {
  getDocumentResolutionSupportedList(): Array<PwgRasterConfig.Resolution>;
  setDocumentResolutionSupportedList(value: Array<PwgRasterConfig.Resolution>): void;
  clearDocumentResolutionSupportedList(): void;
  addDocumentResolutionSupported(value?: PwgRasterConfig.Resolution, index?: number): PwgRasterConfig.Resolution;

  getDocumentTypeSupportedList(): Array<PwgRasterConfig.PwgDocumentTypeSupported>;
  setDocumentTypeSupportedList(value: Array<PwgRasterConfig.PwgDocumentTypeSupported>): void;
  clearDocumentTypeSupportedList(): void;
  addDocumentTypeSupported(value: PwgRasterConfig.PwgDocumentTypeSupported, index?: number): void;

  getDocumentSheetBack(): PwgRasterConfig.DocumentSheetBack;
  setDocumentSheetBack(value: PwgRasterConfig.DocumentSheetBack): void;

  getReverseOrderStreaming(): boolean;
  setReverseOrderStreaming(value: boolean): void;

  getRotateAllPages(): boolean;
  setRotateAllPages(value: boolean): void;

  getTransformationList(): Array<PwgRasterConfig.Transformation>;
  setTransformationList(value: Array<PwgRasterConfig.Transformation>): void;
  clearTransformationList(): void;
  addTransformation(value?: PwgRasterConfig.Transformation, index?: number): PwgRasterConfig.Transformation;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PwgRasterConfig.AsObject;
  static toObject(includeInstance: boolean, msg: PwgRasterConfig): PwgRasterConfig.AsObject;
  static serializeBinaryToWriter(message: PwgRasterConfig, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PwgRasterConfig;
  static deserializeBinaryFromReader(message: PwgRasterConfig, reader: jspb.BinaryReader): PwgRasterConfig;
}

export namespace PwgRasterConfig {
  export type AsObject = {
    documentResolutionSupportedList: Array<PwgRasterConfig.Resolution.AsObject>,
    documentTypeSupportedList: Array<PwgRasterConfig.PwgDocumentTypeSupported>,
    documentSheetBack: PwgRasterConfig.DocumentSheetBack,
    reverseOrderStreaming: boolean,
    rotateAllPages: boolean,
    transformationList: Array<PwgRasterConfig.Transformation.AsObject>,
  }

  export class Resolution extends jspb.Message {
    getCrossFeedDir(): number;
    setCrossFeedDir(value: number): void;

    getFeedDir(): number;
    setFeedDir(value: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Resolution.AsObject;
    static toObject(includeInstance: boolean, msg: Resolution): Resolution.AsObject;
    static serializeBinaryToWriter(message: Resolution, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Resolution;
    static deserializeBinaryFromReader(message: Resolution, reader: jspb.BinaryReader): Resolution;
  }

  export namespace Resolution {
    export type AsObject = {
      crossFeedDir: number,
      feedDir: number,
    }
  }


  export class Transformation extends jspb.Message {
    getOperation(): PwgRasterConfig.Transformation.Operation;
    setOperation(value: PwgRasterConfig.Transformation.Operation): void;

    getOperand(): PwgRasterConfig.Transformation.Operand;
    setOperand(value: PwgRasterConfig.Transformation.Operand): void;

    getDuplexTypeList(): Array<Duplex.Type>;
    setDuplexTypeList(value: Array<Duplex.Type>): void;
    clearDuplexTypeList(): void;
    addDuplexType(value: Duplex.Type, index?: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Transformation.AsObject;
    static toObject(includeInstance: boolean, msg: Transformation): Transformation.AsObject;
    static serializeBinaryToWriter(message: Transformation, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Transformation;
    static deserializeBinaryFromReader(message: Transformation, reader: jspb.BinaryReader): Transformation;
  }

  export namespace Transformation {
    export type AsObject = {
      operation: PwgRasterConfig.Transformation.Operation,
      operand: PwgRasterConfig.Transformation.Operand,
      duplexTypeList: Array<Duplex.Type>,
    }

    export enum Operation { 
      ROTATE_180 = 0,
      FLIP_ON_LONG_EDGE = 1,
      FLIP_ON_SHORT_EDGE = 2,
    }

    export enum Operand { 
      ALL_PAGES = 0,
      ONLY_DUPLEXED_EVEN_PAGES = 1,
      ONLY_DUPLEXED_ODD_PAGES = 2,
      EVEN_PAGES = 3,
      ODD_PAGES = 4,
    }
  }


  export enum DocumentSheetBack { 
    NORMAL = 0,
    ROTATED = 1,
    MANUAL_TUMBLE = 2,
    FLIPPED = 3,
  }

  export enum PwgDocumentTypeSupported { 
    UNSPECIFIED_PWG_DOCUMENT_TYPE = 0,
    BLACK_1 = 1,
    SGRAY_1 = 2,
    ADOBE_RGB_8 = 3,
    BLACK_8 = 4,
    CMYK_8 = 5,
    DEVICE1_8 = 6,
    DEVICE2_8 = 7,
    DEVICE3_8 = 8,
    DEVICE4_8 = 9,
    DEVICE5_8 = 10,
    DEVICE6_8 = 11,
    DEVICE7_8 = 12,
    DEVICE8_8 = 13,
    DEVICE9_8 = 14,
    DEVICE10_8 = 15,
    DEVICE11_8 = 16,
    DEVICE12_8 = 17,
    DEVICE13_8 = 18,
    DEVICE14_8 = 19,
    DEVICE15_8 = 20,
    RGB_8 = 21,
    SGRAY_8 = 22,
    SRGB_8 = 23,
    ADOBE_RGB_16 = 24,
    BLACK_16 = 25,
    CMYK_16 = 26,
    DEVICE1_16 = 27,
    DEVICE2_16 = 28,
    DEVICE3_16 = 29,
    DEVICE4_16 = 30,
    DEVICE5_16 = 31,
    DEVICE6_16 = 32,
    DEVICE7_16 = 33,
    DEVICE8_16 = 34,
    DEVICE9_16 = 35,
    DEVICE10_16 = 36,
    DEVICE11_16 = 37,
    DEVICE12_16 = 38,
    DEVICE13_16 = 39,
    DEVICE14_16 = 40,
    DEVICE15_16 = 41,
    RGB_16 = 42,
    SGRAY_16 = 43,
    SRGB_16 = 44,
  }
}

export class InputTrayUnit extends jspb.Message {
  getVendorId(): string;
  setVendorId(value: string): void;

  getType(): InputTrayUnit.Type;
  setType(value: InputTrayUnit.Type): void;

  getIndex(): number;
  setIndex(value: number): void;

  getCustomDisplayName(): string;
  setCustomDisplayName(value: string): void;

  getCustomDisplayNameLocalizedList(): Array<LocalizedString>;
  setCustomDisplayNameLocalizedList(value: Array<LocalizedString>): void;
  clearCustomDisplayNameLocalizedList(): void;
  addCustomDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputTrayUnit.AsObject;
  static toObject(includeInstance: boolean, msg: InputTrayUnit): InputTrayUnit.AsObject;
  static serializeBinaryToWriter(message: InputTrayUnit, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputTrayUnit;
  static deserializeBinaryFromReader(message: InputTrayUnit, reader: jspb.BinaryReader): InputTrayUnit;
}

export namespace InputTrayUnit {
  export type AsObject = {
    vendorId: string,
    type: InputTrayUnit.Type,
    index: number,
    customDisplayName: string,
    customDisplayNameLocalizedList: Array<LocalizedString.AsObject>,
  }

  export enum Type { 
    CUSTOM = 0,
    INPUT_TRAY = 1,
    BYPASS_TRAY = 2,
    MANUAL_FEED_TRAY = 3,
    LCT = 4,
    ENVELOPE_TRAY = 5,
    ROLL = 6,
  }
}

export class OutputBinUnit extends jspb.Message {
  getVendorId(): string;
  setVendorId(value: string): void;

  getType(): OutputBinUnit.Type;
  setType(value: OutputBinUnit.Type): void;

  getIndex(): number;
  setIndex(value: number): void;

  getCustomDisplayName(): string;
  setCustomDisplayName(value: string): void;

  getCustomDisplayNameLocalizedList(): Array<LocalizedString>;
  setCustomDisplayNameLocalizedList(value: Array<LocalizedString>): void;
  clearCustomDisplayNameLocalizedList(): void;
  addCustomDisplayNameLocalized(value?: LocalizedString, index?: number): LocalizedString;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OutputBinUnit.AsObject;
  static toObject(includeInstance: boolean, msg: OutputBinUnit): OutputBinUnit.AsObject;
  static serializeBinaryToWriter(message: OutputBinUnit, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OutputBinUnit;
  static deserializeBinaryFromReader(message: OutputBinUnit, reader: jspb.BinaryReader): OutputBinUnit;
}

export namespace OutputBinUnit {
  export type AsObject = {
    vendorId: string,
    type: OutputBinUnit.Type,
    index: number,
    customDisplayName: string,
    customDisplayNameLocalizedList: Array<LocalizedString.AsObject>,
  }

  export enum Type { 
    CUSTOM = 0,
    OUTPUT_BIN = 1,
    MAILBOX = 2,
    STACKER = 3,
  }
}

export enum PrinterType { 
  NO_PRINTER_TYPE_FILTER = 0,
  GOOGLE = 1,
  HP = 2,
  DRIVE = 3,
  FEDEX = 4,
  ANDROID_CHROME_SNAPSHOT = 5,
  IOS_CHROME_SNAPSHOT = 6,
}
export enum NotificationChannel { 
  UNRECOGNIZED_CHANNEL = 0,
  XMPP_CHANNEL = 1,
}
