import * as jspb from "google-protobuf"

export class JobState extends jspb.Message {
  getType(): JobState.Type;
  setType(value: JobState.Type): void;

  getUserActionCause(): JobState.UserActionCause | undefined;
  setUserActionCause(value?: JobState.UserActionCause): void;
  hasUserActionCause(): boolean;
  clearUserActionCause(): void;

  getDeviceStateCause(): JobState.DeviceStateCause | undefined;
  setDeviceStateCause(value?: JobState.DeviceStateCause): void;
  hasDeviceStateCause(): boolean;
  clearDeviceStateCause(): void;

  getDeviceActionCause(): JobState.DeviceActionCause | undefined;
  setDeviceActionCause(value?: JobState.DeviceActionCause): void;
  hasDeviceActionCause(): boolean;
  clearDeviceActionCause(): void;

  getServiceActionCause(): JobState.ServiceActionCause | undefined;
  setServiceActionCause(value?: JobState.ServiceActionCause): void;
  hasServiceActionCause(): boolean;
  clearServiceActionCause(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): JobState.AsObject;
  static toObject(includeInstance: boolean, msg: JobState): JobState.AsObject;
  static serializeBinaryToWriter(message: JobState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): JobState;
  static deserializeBinaryFromReader(message: JobState, reader: jspb.BinaryReader): JobState;
}

export namespace JobState {
  export type AsObject = {
    type: JobState.Type,
    userActionCause?: JobState.UserActionCause.AsObject,
    deviceStateCause?: JobState.DeviceStateCause.AsObject,
    deviceActionCause?: JobState.DeviceActionCause.AsObject,
    serviceActionCause?: JobState.ServiceActionCause.AsObject,
  }

  export class UserActionCause extends jspb.Message {
    getActionCode(): JobState.UserActionCause.ActionCode;
    setActionCode(value: JobState.UserActionCause.ActionCode): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): UserActionCause.AsObject;
    static toObject(includeInstance: boolean, msg: UserActionCause): UserActionCause.AsObject;
    static serializeBinaryToWriter(message: UserActionCause, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): UserActionCause;
    static deserializeBinaryFromReader(message: UserActionCause, reader: jspb.BinaryReader): UserActionCause;
  }

  export namespace UserActionCause {
    export type AsObject = {
      actionCode: JobState.UserActionCause.ActionCode,
    }

    export enum ActionCode { 
      CANCELLED = 0,
      PAUSED = 1,
      OTHER = 100,
    }
  }


  export class DeviceStateCause extends jspb.Message {
    getErrorCode(): JobState.DeviceStateCause.ErrorCode;
    setErrorCode(value: JobState.DeviceStateCause.ErrorCode): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): DeviceStateCause.AsObject;
    static toObject(includeInstance: boolean, msg: DeviceStateCause): DeviceStateCause.AsObject;
    static serializeBinaryToWriter(message: DeviceStateCause, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): DeviceStateCause;
    static deserializeBinaryFromReader(message: DeviceStateCause, reader: jspb.BinaryReader): DeviceStateCause;
  }

  export namespace DeviceStateCause {
    export type AsObject = {
      errorCode: JobState.DeviceStateCause.ErrorCode,
    }

    export enum ErrorCode { 
      INPUT_TRAY = 0,
      MARKER = 1,
      MEDIA_PATH = 2,
      MEDIA_SIZE = 3,
      MEDIA_TYPE = 4,
      OTHER = 100,
    }
  }


  export class DeviceActionCause extends jspb.Message {
    getErrorCode(): JobState.DeviceActionCause.ErrorCode;
    setErrorCode(value: JobState.DeviceActionCause.ErrorCode): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): DeviceActionCause.AsObject;
    static toObject(includeInstance: boolean, msg: DeviceActionCause): DeviceActionCause.AsObject;
    static serializeBinaryToWriter(message: DeviceActionCause, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): DeviceActionCause;
    static deserializeBinaryFromReader(message: DeviceActionCause, reader: jspb.BinaryReader): DeviceActionCause;
  }

  export namespace DeviceActionCause {
    export type AsObject = {
      errorCode: JobState.DeviceActionCause.ErrorCode,
    }

    export enum ErrorCode { 
      DOWNLOAD_FAILURE = 0,
      INVALID_TICKET = 1,
      PRINT_FAILURE = 2,
      OTHER = 100,
    }
  }


  export class ServiceActionCause extends jspb.Message {
    getErrorCode(): JobState.ServiceActionCause.ErrorCode;
    setErrorCode(value: JobState.ServiceActionCause.ErrorCode): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ServiceActionCause.AsObject;
    static toObject(includeInstance: boolean, msg: ServiceActionCause): ServiceActionCause.AsObject;
    static serializeBinaryToWriter(message: ServiceActionCause, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ServiceActionCause;
    static deserializeBinaryFromReader(message: ServiceActionCause, reader: jspb.BinaryReader): ServiceActionCause;
  }

  export namespace ServiceActionCause {
    export type AsObject = {
      errorCode: JobState.ServiceActionCause.ErrorCode,
    }

    export enum ErrorCode { 
      COMMUNICATION_WITH_DEVICE_ERROR = 0,
      CONVERSION_ERROR = 1,
      CONVERSION_FILE_TOO_BIG = 2,
      CONVERSION_UNSUPPORTED_CONTENT_TYPE = 3,
      DELIVERY_FAILURE = 11,
      EXPIRATION = 14,
      FETCH_DOCUMENT_FORBIDDEN = 4,
      FETCH_DOCUMENT_NOT_FOUND = 5,
      GOOGLE_DRIVE_QUOTA = 15,
      INCONSISTENT_JOB = 6,
      INCONSISTENT_PRINTER = 13,
      PRINTER_DELETED = 12,
      REMOTE_JOB_NO_LONGER_EXISTS = 7,
      REMOTE_JOB_ERROR = 8,
      REMOTE_JOB_TIMEOUT = 9,
      REMOTE_JOB_ABORTED = 10,
      OTHER = 100,
    }
  }


  export enum Type { 
    DRAFT = 0,
    HELD = 1,
    QUEUED = 2,
    IN_PROGRESS = 3,
    STOPPED = 4,
    DONE = 5,
    ABORTED = 6,
  }
}

export class PrintJobUiState extends jspb.Message {
  getSummary(): PrintJobUiState.Summary;
  setSummary(value: PrintJobUiState.Summary): void;

  getProgress(): string;
  setProgress(value: string): void;

  getCause(): string;
  setCause(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PrintJobUiState.AsObject;
  static toObject(includeInstance: boolean, msg: PrintJobUiState): PrintJobUiState.AsObject;
  static serializeBinaryToWriter(message: PrintJobUiState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PrintJobUiState;
  static deserializeBinaryFromReader(message: PrintJobUiState, reader: jspb.BinaryReader): PrintJobUiState;
}

export namespace PrintJobUiState {
  export type AsObject = {
    summary: PrintJobUiState.Summary,
    progress: string,
    cause: string,
  }

  export enum Summary { 
    DRAFT = 0,
    QUEUED = 1,
    IN_PROGRESS = 2,
    PAUSED = 3,
    DONE = 4,
    CANCELLED = 5,
    ERROR = 6,
    EXPIRED = 7,
  }
}

