import * as jspb from "google-protobuf"

import * as google_api_annotations_pb from '../../google/api/annotations_pb';
import * as google_cloudprint_Common_pb from '../../google/cloudprint/Common_pb';
import * as google_cloudprint_JobState_pb from '../../google/cloudprint/JobState_pb';
import * as google_cloudprint_PrintTicket_pb from '../../google/cloudprint/PrintTicket_pb';
import * as google_cloudprint_PrinterDescription_pb from '../../google/cloudprint/PrinterDescription_pb';

export class SubmitJobRequest extends jspb.Message {
  getPrinterid(): string;
  setPrinterid(value: string): void;

  getTitle(): string;
  setTitle(value: string): void;

  getTicket(): CloudJobTicket | undefined;
  setTicket(value?: CloudJobTicket): void;
  hasTicket(): boolean;
  clearTicket(): void;

  getContent(): string;
  setContent(value: string): void;

  getContentType(): string;
  setContentType(value: string): void;

  getTagList(): Array<string>;
  setTagList(value: Array<string>): void;
  clearTagList(): void;
  addTag(value: string, index?: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SubmitJobRequest.AsObject;
  static toObject(includeInstance: boolean, msg: SubmitJobRequest): SubmitJobRequest.AsObject;
  static serializeBinaryToWriter(message: SubmitJobRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SubmitJobRequest;
  static deserializeBinaryFromReader(message: SubmitJobRequest, reader: jspb.BinaryReader): SubmitJobRequest;
}

export namespace SubmitJobRequest {
  export type AsObject = {
    printerid: string,
    title: string,
    ticket?: CloudJobTicket.AsObject,
    content: string,
    contentType: string,
    tagList: Array<string>,
  }
}

export class SubmitJobResponse extends jspb.Message {
  getSuccess(): boolean;
  setSuccess(value: boolean): void;

  getMessage(): string;
  setMessage(value: string): void;

  getErrorCode(): number;
  setErrorCode(value: number): void;

  getRequest(): SubmitJobRequest | undefined;
  setRequest(value?: SubmitJobRequest): void;
  hasRequest(): boolean;
  clearRequest(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SubmitJobResponse.AsObject;
  static toObject(includeInstance: boolean, msg: SubmitJobResponse): SubmitJobResponse.AsObject;
  static serializeBinaryToWriter(message: SubmitJobResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SubmitJobResponse;
  static deserializeBinaryFromReader(message: SubmitJobResponse, reader: jspb.BinaryReader): SubmitJobResponse;
}

export namespace SubmitJobResponse {
  export type AsObject = {
    success: boolean,
    message: string,
    errorCode: number,
    request?: SubmitJobRequest.AsObject,
  }
}

export class DeleteJobRequest extends jspb.Message {
  getJobid(): string;
  setJobid(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteJobRequest.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteJobRequest): DeleteJobRequest.AsObject;
  static serializeBinaryToWriter(message: DeleteJobRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteJobRequest;
  static deserializeBinaryFromReader(message: DeleteJobRequest, reader: jspb.BinaryReader): DeleteJobRequest;
}

export namespace DeleteJobRequest {
  export type AsObject = {
    jobid: string,
  }
}

export class DeleteJobResponse extends jspb.Message {
  getSuccess(): boolean;
  setSuccess(value: boolean): void;

  getMessage(): string;
  setMessage(value: string): void;

  getErrorCode(): number;
  setErrorCode(value: number): void;

  getRequest(): DeleteJobRequest | undefined;
  setRequest(value?: DeleteJobRequest): void;
  hasRequest(): boolean;
  clearRequest(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeleteJobResponse.AsObject;
  static toObject(includeInstance: boolean, msg: DeleteJobResponse): DeleteJobResponse.AsObject;
  static serializeBinaryToWriter(message: DeleteJobResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeleteJobResponse;
  static deserializeBinaryFromReader(message: DeleteJobResponse, reader: jspb.BinaryReader): DeleteJobResponse;
}

export namespace DeleteJobResponse {
  export type AsObject = {
    success: boolean,
    message: string,
    errorCode: number,
    request?: DeleteJobRequest.AsObject,
  }
}

export class ListJobsRequest extends jspb.Message {
  getPrinterid(): string;
  setPrinterid(value: string): void;

  getOwner(): string;
  setOwner(value: string): void;

  getStatus(): string;
  setStatus(value: string): void;

  getQ(): string;
  setQ(value: string): void;

  getOffset(): number;
  setOffset(value: number): void;

  getLimit(): number;
  setLimit(value: number): void;

  getSortorder(): ListJobsRequest.JobListSortOrder;
  setSortorder(value: ListJobsRequest.JobListSortOrder): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListJobsRequest.AsObject;
  static toObject(includeInstance: boolean, msg: ListJobsRequest): ListJobsRequest.AsObject;
  static serializeBinaryToWriter(message: ListJobsRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListJobsRequest;
  static deserializeBinaryFromReader(message: ListJobsRequest, reader: jspb.BinaryReader): ListJobsRequest;
}

export namespace ListJobsRequest {
  export type AsObject = {
    printerid: string,
    owner: string,
    status: string,
    q: string,
    offset: number,
    limit: number,
    sortorder: ListJobsRequest.JobListSortOrder,
  }

  export enum JobListSortOrder { 
    CREATE_TIME_DESC = 0,
    CREATE_TIME = 1,
    STATUS = 2,
    STATUS_DESC = 3,
    TITLE = 4,
    TITLE_DESC = 5,
  }
}

export class ListJobsResponse extends jspb.Message {
  getSuccess(): boolean;
  setSuccess(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ListJobsResponse.AsObject;
  static toObject(includeInstance: boolean, msg: ListJobsResponse): ListJobsResponse.AsObject;
  static serializeBinaryToWriter(message: ListJobsResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ListJobsResponse;
  static deserializeBinaryFromReader(message: ListJobsResponse, reader: jspb.BinaryReader): ListJobsResponse;
}

export namespace ListJobsResponse {
  export type AsObject = {
    success: boolean,
  }
}

export class GetPrinterRequest extends jspb.Message {
  getPrinterid(): string;
  setPrinterid(value: string): void;

  getClient(): string;
  setClient(value: string): void;

  getExtraFields(): string;
  setExtraFields(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetPrinterRequest.AsObject;
  static toObject(includeInstance: boolean, msg: GetPrinterRequest): GetPrinterRequest.AsObject;
  static serializeBinaryToWriter(message: GetPrinterRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetPrinterRequest;
  static deserializeBinaryFromReader(message: GetPrinterRequest, reader: jspb.BinaryReader): GetPrinterRequest;
}

export namespace GetPrinterRequest {
  export type AsObject = {
    printerid: string,
    client: string,
    extraFields: string,
  }
}

export class GetPrinterResponse extends jspb.Message {
  getSuccess(): boolean;
  setSuccess(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): GetPrinterResponse.AsObject;
  static toObject(includeInstance: boolean, msg: GetPrinterResponse): GetPrinterResponse.AsObject;
  static serializeBinaryToWriter(message: GetPrinterResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): GetPrinterResponse;
  static deserializeBinaryFromReader(message: GetPrinterResponse, reader: jspb.BinaryReader): GetPrinterResponse;
}

export namespace GetPrinterResponse {
  export type AsObject = {
    success: boolean,
  }
}

export class SearchPrintersRequest extends jspb.Message {
  getQ(): string;
  setQ(value: string): void;

  getType(): google_cloudprint_Common_pb.PrinterType;
  setType(value: google_cloudprint_Common_pb.PrinterType): void;

  getAllConnectionStatuses(): boolean;
  setAllConnectionStatuses(value: boolean): void;

  getConnectionStatus(): PrinterConnectionStatus;
  setConnectionStatus(value: PrinterConnectionStatus): void;

  getUseCdd(): boolean;
  setUseCdd(value: boolean): void;

  getExtraFieldsList(): Array<ExtraPrinterField>;
  setExtraFieldsList(value: Array<ExtraPrinterField>): void;
  clearExtraFieldsList(): void;
  addExtraFields(value: ExtraPrinterField, index?: number): void;

  getConnectionStatusFilterCase(): SearchPrintersRequest.ConnectionStatusFilterCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SearchPrintersRequest.AsObject;
  static toObject(includeInstance: boolean, msg: SearchPrintersRequest): SearchPrintersRequest.AsObject;
  static serializeBinaryToWriter(message: SearchPrintersRequest, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SearchPrintersRequest;
  static deserializeBinaryFromReader(message: SearchPrintersRequest, reader: jspb.BinaryReader): SearchPrintersRequest;
}

export namespace SearchPrintersRequest {
  export type AsObject = {
    q: string,
    type: google_cloudprint_Common_pb.PrinterType,
    allConnectionStatuses: boolean,
    connectionStatus: PrinterConnectionStatus,
    useCdd: boolean,
    extraFieldsList: Array<ExtraPrinterField>,
  }

  export enum ConnectionStatusFilterCase { 
    CONNECTION_STATUS_FILTER_NOT_SET = 0,
    ALL_CONNECTION_STATUSES = 3,
    CONNECTION_STATUS = 4,
  }
}

export class CloudPrinter extends jspb.Message {
  getGcpVersion(): string;
  setGcpVersion(value: string): void;

  getId(): string;
  setId(value: string): void;

  getUuid(): string;
  setUuid(value: string): void;

  getType(): google_cloudprint_Common_pb.PrinterType;
  setType(value: google_cloudprint_Common_pb.PrinterType): void;

  getName(): string;
  setName(value: string): void;

  getDisplayName(): string;
  setDisplayName(value: string): void;

  getDefaultDisplayName(): string;
  setDefaultDisplayName(value: string): void;

  getDescription(): string;
  setDescription(value: string): void;

  getOwnerId(): string;
  setOwnerId(value: string): void;

  getOwnerName(): string;
  setOwnerName(value: string): void;

  getProxy(): string;
  setProxy(value: string): void;

  getStatus(): PrinterConnectionStatus;
  setStatus(value: PrinterConnectionStatus): void;

  getTagsList(): Array<string>;
  setTagsList(value: Array<string>): void;
  clearTagsList(): void;
  addTags(value: string, index?: number): void;

  getCapsHash(): string;
  setCapsHash(value: string): void;

  getIsTosAccepted(): boolean;
  setIsTosAccepted(value: boolean): void;

  getSupportedContentTypes(): string;
  setSupportedContentTypes(value: string): void;

  getLocalSettings(): LocalSettings | undefined;
  setLocalSettings(value?: LocalSettings): void;
  hasLocalSettings(): boolean;
  clearLocalSettings(): void;

  getNotificationChannel(): google_cloudprint_Common_pb.NotificationChannel;
  setNotificationChannel(value: google_cloudprint_Common_pb.NotificationChannel): void;

  getManufacturer(): string;
  setManufacturer(value: string): void;

  getModel(): string;
  setModel(value: string): void;

  getSupportUrl(): string;
  setSupportUrl(value: string): void;

  getUpdateUrl(): string;
  setUpdateUrl(value: string): void;

  getSetupUrl(): string;
  setSetupUrl(value: string): void;

  getCertificationId(): string;
  setCertificationId(value: string): void;

  getFirmware(): string;
  setFirmware(value: string): void;

  getAccessTime(): string;
  setAccessTime(value: string): void;

  getUpdateTime(): string;
  setUpdateTime(value: string): void;

  getCreateTime(): string;
  setCreateTime(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CloudPrinter.AsObject;
  static toObject(includeInstance: boolean, msg: CloudPrinter): CloudPrinter.AsObject;
  static serializeBinaryToWriter(message: CloudPrinter, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CloudPrinter;
  static deserializeBinaryFromReader(message: CloudPrinter, reader: jspb.BinaryReader): CloudPrinter;
}

export namespace CloudPrinter {
  export type AsObject = {
    gcpVersion: string,
    id: string,
    uuid: string,
    type: google_cloudprint_Common_pb.PrinterType,
    name: string,
    displayName: string,
    defaultDisplayName: string,
    description: string,
    ownerId: string,
    ownerName: string,
    proxy: string,
    status: PrinterConnectionStatus,
    tagsList: Array<string>,
    capsHash: string,
    isTosAccepted: boolean,
    supportedContentTypes: string,
    localSettings?: LocalSettings.AsObject,
    notificationChannel: google_cloudprint_Common_pb.NotificationChannel,
    manufacturer: string,
    model: string,
    supportUrl: string,
    updateUrl: string,
    setupUrl: string,
    certificationId: string,
    firmware: string,
    accessTime: string,
    updateTime: string,
    createTime: string,
  }
}

export class SearchPrintersResponse extends jspb.Message {
  getSuccess(): boolean;
  setSuccess(value: boolean): void;

  getXsrfToken(): string;
  setXsrfToken(value: string): void;

  getPrintersList(): Array<CloudPrinter>;
  setPrintersList(value: Array<CloudPrinter>): void;
  clearPrintersList(): void;
  addPrinters(value?: CloudPrinter, index?: number): CloudPrinter;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SearchPrintersResponse.AsObject;
  static toObject(includeInstance: boolean, msg: SearchPrintersResponse): SearchPrintersResponse.AsObject;
  static serializeBinaryToWriter(message: SearchPrintersResponse, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SearchPrintersResponse;
  static deserializeBinaryFromReader(message: SearchPrintersResponse, reader: jspb.BinaryReader): SearchPrintersResponse;
}

export namespace SearchPrintersResponse {
  export type AsObject = {
    success: boolean,
    xsrfToken: string,
    printersList: Array<CloudPrinter.AsObject>,
  }
}

export class LocalSettings extends jspb.Message {
  getCurrent(): LocalSettings.Settings | undefined;
  setCurrent(value?: LocalSettings.Settings): void;
  hasCurrent(): boolean;
  clearCurrent(): void;

  getPending(): LocalSettings.Settings | undefined;
  setPending(value?: LocalSettings.Settings): void;
  hasPending(): boolean;
  clearPending(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LocalSettings.AsObject;
  static toObject(includeInstance: boolean, msg: LocalSettings): LocalSettings.AsObject;
  static serializeBinaryToWriter(message: LocalSettings, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LocalSettings;
  static deserializeBinaryFromReader(message: LocalSettings, reader: jspb.BinaryReader): LocalSettings;
}

export namespace LocalSettings {
  export type AsObject = {
    current?: LocalSettings.Settings.AsObject,
    pending?: LocalSettings.Settings.AsObject,
  }

  export class Settings extends jspb.Message {
    getLocalDiscovery(): boolean;
    setLocalDiscovery(value: boolean): void;

    getAccessTokenEnabled(): boolean;
    setAccessTokenEnabled(value: boolean): void;

    getLocalPrintingEnabled(): boolean;
    setLocalPrintingEnabled(value: boolean): void;

    getConversionPrintingEnabled(): boolean;
    setConversionPrintingEnabled(value: boolean): void;

    getXmppTimeoutValue(): number;
    setXmppTimeoutValue(value: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Settings.AsObject;
    static toObject(includeInstance: boolean, msg: Settings): Settings.AsObject;
    static serializeBinaryToWriter(message: Settings, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Settings;
    static deserializeBinaryFromReader(message: Settings, reader: jspb.BinaryReader): Settings;
  }

  export namespace Settings {
    export type AsObject = {
      localDiscovery: boolean,
      accessTokenEnabled: boolean,
      localPrintingEnabled: boolean,
      conversionPrintingEnabled: boolean,
      xmppTimeoutValue: number,
    }
  }

}

export class CloudJobTicket extends jspb.Message {
  getVersion(): string;
  setVersion(value: string): void;

  getPrint(): google_cloudprint_PrintTicket_pb.PrintTicketSection | undefined;
  setPrint(value?: google_cloudprint_PrintTicket_pb.PrintTicketSection): void;
  hasPrint(): boolean;
  clearPrint(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CloudJobTicket.AsObject;
  static toObject(includeInstance: boolean, msg: CloudJobTicket): CloudJobTicket.AsObject;
  static serializeBinaryToWriter(message: CloudJobTicket, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CloudJobTicket;
  static deserializeBinaryFromReader(message: CloudJobTicket, reader: jspb.BinaryReader): CloudJobTicket;
}

export namespace CloudJobTicket {
  export type AsObject = {
    version: string,
    print?: google_cloudprint_PrintTicket_pb.PrintTicketSection.AsObject,
  }
}

export class CloudDeviceDescription extends jspb.Message {
  getVersion(): string;
  setVersion(value: string): void;

  getPrinter(): google_cloudprint_PrinterDescription_pb.PrinterDescriptionSection | undefined;
  setPrinter(value?: google_cloudprint_PrinterDescription_pb.PrinterDescriptionSection): void;
  hasPrinter(): boolean;
  clearPrinter(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CloudDeviceDescription.AsObject;
  static toObject(includeInstance: boolean, msg: CloudDeviceDescription): CloudDeviceDescription.AsObject;
  static serializeBinaryToWriter(message: CloudDeviceDescription, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CloudDeviceDescription;
  static deserializeBinaryFromReader(message: CloudDeviceDescription, reader: jspb.BinaryReader): CloudDeviceDescription;
}

export namespace CloudDeviceDescription {
  export type AsObject = {
    version: string,
    printer?: google_cloudprint_PrinterDescription_pb.PrinterDescriptionSection.AsObject,
  }
}

export class PrintJobState extends jspb.Message {
  getVersion(): string;
  setVersion(value: string): void;

  getState(): google_cloudprint_JobState_pb.JobState | undefined;
  setState(value?: google_cloudprint_JobState_pb.JobState): void;
  hasState(): boolean;
  clearState(): void;

  getPagesPrinted(): number;
  setPagesPrinted(value: number): void;

  getDeliveryAttempts(): number;
  setDeliveryAttempts(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PrintJobState.AsObject;
  static toObject(includeInstance: boolean, msg: PrintJobState): PrintJobState.AsObject;
  static serializeBinaryToWriter(message: PrintJobState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PrintJobState;
  static deserializeBinaryFromReader(message: PrintJobState, reader: jspb.BinaryReader): PrintJobState;
}

export namespace PrintJobState {
  export type AsObject = {
    version: string,
    state?: google_cloudprint_JobState_pb.JobState.AsObject,
    pagesPrinted: number,
    deliveryAttempts: number,
  }
}

export class PrintJobStateDiff extends jspb.Message {
  getState(): google_cloudprint_JobState_pb.JobState | undefined;
  setState(value?: google_cloudprint_JobState_pb.JobState): void;
  hasState(): boolean;
  clearState(): void;

  getPagesPrinted(): number;
  setPagesPrinted(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PrintJobStateDiff.AsObject;
  static toObject(includeInstance: boolean, msg: PrintJobStateDiff): PrintJobStateDiff.AsObject;
  static serializeBinaryToWriter(message: PrintJobStateDiff, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PrintJobStateDiff;
  static deserializeBinaryFromReader(message: PrintJobStateDiff, reader: jspb.BinaryReader): PrintJobStateDiff;
}

export namespace PrintJobStateDiff {
  export type AsObject = {
    state?: google_cloudprint_JobState_pb.JobState.AsObject,
    pagesPrinted: number,
  }
}

export enum PrinterConnectionStatus { 
  UNKNOWN = 0,
  DORMANT = 1,
  OFFLINE = 2,
  ONLINE = 3,
}
export enum ExtraPrinterField { 
  UNKNOWN_EXTRA_FIELDS = 0,
  CONNECTION_STATUS = 1,
  SEMANTIC_STATE = 2,
  UI_STATE = 3,
  QUEUED_JOBS_COUNT = 4,
}
