/**
 * @fileoverview gRPC-Web generated client stub for google.cloudprint
 * @enhanceable
 * @public
 */

// GENERATED CODE -- DO NOT EDIT!


import * as grpcWeb from 'grpc-web';

import * as google_api_annotations_pb from '../../google/api/annotations_pb';
import * as google_cloudprint_Common_pb from '../../google/cloudprint/Common_pb';
import * as google_cloudprint_JobState_pb from '../../google/cloudprint/JobState_pb';
import * as google_cloudprint_PrintTicket_pb from '../../google/cloudprint/PrintTicket_pb';
import * as google_cloudprint_PrinterDescription_pb from '../../google/cloudprint/PrinterDescription_pb';

import {
  DeleteJobRequest,
  DeleteJobResponse,
  GetPrinterRequest,
  GetPrinterResponse,
  ListJobsRequest,
  ListJobsResponse,
  SearchPrintersRequest,
  SearchPrintersResponse,
  SubmitJobRequest,
  SubmitJobResponse} from './GoogleCloudPrint_pb';

export class CloudPrintClient {
  client_: grpcWeb.AbstractClientBase;
  hostname_: string;
  credentials_: null | { [index: string]: string; };
  options_: null | { [index: string]: string; };

  constructor (hostname: string,
               credentials?: null | { [index: string]: string; },
               options?: null | { [index: string]: string; }) {
    if (!options) options = {};
    if (!credentials) credentials = {};
    options['format'] = 'binary';

    this.client_ = new grpcWeb.GrpcWebClientBase(options);
    this.hostname_ = hostname;
    this.credentials_ = credentials;
    this.options_ = options;
  }

  methodInfoSubmitJob = new grpcWeb.AbstractClientBase.MethodInfo(
    SubmitJobResponse,
    (request: SubmitJobRequest) => {
      return request.serializeBinary();
    },
    SubmitJobResponse.deserializeBinary
  );

  submitJob(
    request: SubmitJobRequest,
    metadata: grpcWeb.Metadata | null,
    callback: (err: grpcWeb.Error,
               response: SubmitJobResponse) => void) {
    return this.client_.rpcCall(
      this.hostname_ +
        '/google.cloudprint.CloudPrint/SubmitJob',
      request,
      metadata || {},
      this.methodInfoSubmitJob,
      callback);
  }

  methodInfoDeleteJob = new grpcWeb.AbstractClientBase.MethodInfo(
    DeleteJobResponse,
    (request: DeleteJobRequest) => {
      return request.serializeBinary();
    },
    DeleteJobResponse.deserializeBinary
  );

  deleteJob(
    request: DeleteJobRequest,
    metadata: grpcWeb.Metadata | null,
    callback: (err: grpcWeb.Error,
               response: DeleteJobResponse) => void) {
    return this.client_.rpcCall(
      this.hostname_ +
        '/google.cloudprint.CloudPrint/DeleteJob',
      request,
      metadata || {},
      this.methodInfoDeleteJob,
      callback);
  }

  methodInfoListJobs = new grpcWeb.AbstractClientBase.MethodInfo(
    ListJobsResponse,
    (request: ListJobsRequest) => {
      return request.serializeBinary();
    },
    ListJobsResponse.deserializeBinary
  );

  listJobs(
    request: ListJobsRequest,
    metadata: grpcWeb.Metadata | null,
    callback: (err: grpcWeb.Error,
               response: ListJobsResponse) => void) {
    return this.client_.rpcCall(
      this.hostname_ +
        '/google.cloudprint.CloudPrint/ListJobs',
      request,
      metadata || {},
      this.methodInfoListJobs,
      callback);
  }

  methodInfoGetPrinter = new grpcWeb.AbstractClientBase.MethodInfo(
    GetPrinterResponse,
    (request: GetPrinterRequest) => {
      return request.serializeBinary();
    },
    GetPrinterResponse.deserializeBinary
  );

  getPrinter(
    request: GetPrinterRequest,
    metadata: grpcWeb.Metadata | null,
    callback: (err: grpcWeb.Error,
               response: GetPrinterResponse) => void) {
    return this.client_.rpcCall(
      this.hostname_ +
        '/google.cloudprint.CloudPrint/GetPrinter',
      request,
      metadata || {},
      this.methodInfoGetPrinter,
      callback);
  }

  methodInfoSearchPrinters = new grpcWeb.AbstractClientBase.MethodInfo(
    SearchPrintersResponse,
    (request: SearchPrintersRequest) => {
      return request.serializeBinary();
    },
    SearchPrintersResponse.deserializeBinary
  );

  searchPrinters(
    request: SearchPrintersRequest,
    metadata: grpcWeb.Metadata | null,
    callback: (err: grpcWeb.Error,
               response: SearchPrintersResponse) => void) {
    return this.client_.rpcCall(
      this.hostname_ +
        '/google.cloudprint.CloudPrint/SearchPrinters',
      request,
      metadata || {},
      this.methodInfoSearchPrinters,
      callback);
  }

}

