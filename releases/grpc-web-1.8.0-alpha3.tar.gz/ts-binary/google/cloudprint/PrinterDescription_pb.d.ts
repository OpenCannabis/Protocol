import * as jspb from "google-protobuf"

import * as google_cloudprint_Common_pb from '../../google/cloudprint/Common_pb';

export class PrinterDescriptionSection extends jspb.Message {
  getSupportedContentTypeList(): Array<google_cloudprint_Common_pb.SupportedContentType>;
  setSupportedContentTypeList(value: Array<google_cloudprint_Common_pb.SupportedContentType>): void;
  clearSupportedContentTypeList(): void;
  addSupportedContentType(value?: google_cloudprint_Common_pb.SupportedContentType, index?: number): google_cloudprint_Common_pb.SupportedContentType;

  getPrintingSpeed(): google_cloudprint_Common_pb.PrintingSpeed | undefined;
  setPrintingSpeed(value?: google_cloudprint_Common_pb.PrintingSpeed): void;
  hasPrintingSpeed(): boolean;
  clearPrintingSpeed(): void;

  getPwgRasterConfig(): google_cloudprint_Common_pb.PwgRasterConfig | undefined;
  setPwgRasterConfig(value?: google_cloudprint_Common_pb.PwgRasterConfig): void;
  hasPwgRasterConfig(): boolean;
  clearPwgRasterConfig(): void;

  getInputTrayUnitList(): Array<google_cloudprint_Common_pb.InputTrayUnit>;
  setInputTrayUnitList(value: Array<google_cloudprint_Common_pb.InputTrayUnit>): void;
  clearInputTrayUnitList(): void;
  addInputTrayUnit(value?: google_cloudprint_Common_pb.InputTrayUnit, index?: number): google_cloudprint_Common_pb.InputTrayUnit;

  getOutputBinUnitList(): Array<google_cloudprint_Common_pb.OutputBinUnit>;
  setOutputBinUnitList(value: Array<google_cloudprint_Common_pb.OutputBinUnit>): void;
  clearOutputBinUnitList(): void;
  addOutputBinUnit(value?: google_cloudprint_Common_pb.OutputBinUnit, index?: number): google_cloudprint_Common_pb.OutputBinUnit;

  getMarkerList(): Array<google_cloudprint_Common_pb.Marker>;
  setMarkerList(value: Array<google_cloudprint_Common_pb.Marker>): void;
  clearMarkerList(): void;
  addMarker(value?: google_cloudprint_Common_pb.Marker, index?: number): google_cloudprint_Common_pb.Marker;

  getCoverList(): Array<google_cloudprint_Common_pb.Cover>;
  setCoverList(value: Array<google_cloudprint_Common_pb.Cover>): void;
  clearCoverList(): void;
  addCover(value?: google_cloudprint_Common_pb.Cover, index?: number): google_cloudprint_Common_pb.Cover;

  getMediaPathList(): Array<google_cloudprint_Common_pb.MediaPath>;
  setMediaPathList(value: Array<google_cloudprint_Common_pb.MediaPath>): void;
  clearMediaPathList(): void;
  addMediaPath(value?: google_cloudprint_Common_pb.MediaPath, index?: number): google_cloudprint_Common_pb.MediaPath;

  getVendorCapabilityList(): Array<google_cloudprint_Common_pb.VendorCapability>;
  setVendorCapabilityList(value: Array<google_cloudprint_Common_pb.VendorCapability>): void;
  clearVendorCapabilityList(): void;
  addVendorCapability(value?: google_cloudprint_Common_pb.VendorCapability, index?: number): google_cloudprint_Common_pb.VendorCapability;

  getColor(): google_cloudprint_Common_pb.Color | undefined;
  setColor(value?: google_cloudprint_Common_pb.Color): void;
  hasColor(): boolean;
  clearColor(): void;

  getDuplex(): google_cloudprint_Common_pb.Duplex | undefined;
  setDuplex(value?: google_cloudprint_Common_pb.Duplex): void;
  hasDuplex(): boolean;
  clearDuplex(): void;

  getPageOrientation(): google_cloudprint_Common_pb.PageOrientation | undefined;
  setPageOrientation(value?: google_cloudprint_Common_pb.PageOrientation): void;
  hasPageOrientation(): boolean;
  clearPageOrientation(): void;

  getCopies(): google_cloudprint_Common_pb.Copies | undefined;
  setCopies(value?: google_cloudprint_Common_pb.Copies): void;
  hasCopies(): boolean;
  clearCopies(): void;

  getMargins(): google_cloudprint_Common_pb.Margins | undefined;
  setMargins(value?: google_cloudprint_Common_pb.Margins): void;
  hasMargins(): boolean;
  clearMargins(): void;

  getDpi(): google_cloudprint_Common_pb.Dpi | undefined;
  setDpi(value?: google_cloudprint_Common_pb.Dpi): void;
  hasDpi(): boolean;
  clearDpi(): void;

  getFitToPage(): google_cloudprint_Common_pb.FitToPage | undefined;
  setFitToPage(value?: google_cloudprint_Common_pb.FitToPage): void;
  hasFitToPage(): boolean;
  clearFitToPage(): void;

  getPageRange(): google_cloudprint_Common_pb.PageRange | undefined;
  setPageRange(value?: google_cloudprint_Common_pb.PageRange): void;
  hasPageRange(): boolean;
  clearPageRange(): void;

  getMediaSize(): google_cloudprint_Common_pb.MediaSize | undefined;
  setMediaSize(value?: google_cloudprint_Common_pb.MediaSize): void;
  hasMediaSize(): boolean;
  clearMediaSize(): void;

  getCollate(): google_cloudprint_Common_pb.Collate | undefined;
  setCollate(value?: google_cloudprint_Common_pb.Collate): void;
  hasCollate(): boolean;
  clearCollate(): void;

  getReverseOrder(): google_cloudprint_Common_pb.ReverseOrder | undefined;
  setReverseOrder(value?: google_cloudprint_Common_pb.ReverseOrder): void;
  hasReverseOrder(): boolean;
  clearReverseOrder(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PrinterDescriptionSection.AsObject;
  static toObject(includeInstance: boolean, msg: PrinterDescriptionSection): PrinterDescriptionSection.AsObject;
  static serializeBinaryToWriter(message: PrinterDescriptionSection, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PrinterDescriptionSection;
  static deserializeBinaryFromReader(message: PrinterDescriptionSection, reader: jspb.BinaryReader): PrinterDescriptionSection;
}

export namespace PrinterDescriptionSection {
  export type AsObject = {
    supportedContentTypeList: Array<google_cloudprint_Common_pb.SupportedContentType.AsObject>,
    printingSpeed?: google_cloudprint_Common_pb.PrintingSpeed.AsObject,
    pwgRasterConfig?: google_cloudprint_Common_pb.PwgRasterConfig.AsObject,
    inputTrayUnitList: Array<google_cloudprint_Common_pb.InputTrayUnit.AsObject>,
    outputBinUnitList: Array<google_cloudprint_Common_pb.OutputBinUnit.AsObject>,
    markerList: Array<google_cloudprint_Common_pb.Marker.AsObject>,
    coverList: Array<google_cloudprint_Common_pb.Cover.AsObject>,
    mediaPathList: Array<google_cloudprint_Common_pb.MediaPath.AsObject>,
    vendorCapabilityList: Array<google_cloudprint_Common_pb.VendorCapability.AsObject>,
    color?: google_cloudprint_Common_pb.Color.AsObject,
    duplex?: google_cloudprint_Common_pb.Duplex.AsObject,
    pageOrientation?: google_cloudprint_Common_pb.PageOrientation.AsObject,
    copies?: google_cloudprint_Common_pb.Copies.AsObject,
    margins?: google_cloudprint_Common_pb.Margins.AsObject,
    dpi?: google_cloudprint_Common_pb.Dpi.AsObject,
    fitToPage?: google_cloudprint_Common_pb.FitToPage.AsObject,
    pageRange?: google_cloudprint_Common_pb.PageRange.AsObject,
    mediaSize?: google_cloudprint_Common_pb.MediaSize.AsObject,
    collate?: google_cloudprint_Common_pb.Collate.AsObject,
    reverseOrder?: google_cloudprint_Common_pb.ReverseOrder.AsObject,
  }
}

