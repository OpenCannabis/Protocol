import * as jspb from "google-protobuf"

import * as google_cloudprint_Common_pb from '../../google/cloudprint/Common_pb';

export class PrintTicketSection extends jspb.Message {
  getVendorTicketItemList(): Array<PrintTicketSection.VendorTicketItem>;
  setVendorTicketItemList(value: Array<PrintTicketSection.VendorTicketItem>): void;
  clearVendorTicketItemList(): void;
  addVendorTicketItem(value?: PrintTicketSection.VendorTicketItem, index?: number): PrintTicketSection.VendorTicketItem;

  getColor(): PrintTicketSection.ColorTicketItem | undefined;
  setColor(value?: PrintTicketSection.ColorTicketItem): void;
  hasColor(): boolean;
  clearColor(): void;

  getDuplex(): PrintTicketSection.DuplexTicketItem | undefined;
  setDuplex(value?: PrintTicketSection.DuplexTicketItem): void;
  hasDuplex(): boolean;
  clearDuplex(): void;

  getPageOrientation(): PrintTicketSection.PageOrientationTicketItem | undefined;
  setPageOrientation(value?: PrintTicketSection.PageOrientationTicketItem): void;
  hasPageOrientation(): boolean;
  clearPageOrientation(): void;

  getCopies(): PrintTicketSection.CopiesTicketItem | undefined;
  setCopies(value?: PrintTicketSection.CopiesTicketItem): void;
  hasCopies(): boolean;
  clearCopies(): void;

  getMargins(): PrintTicketSection.MarginsTicketItem | undefined;
  setMargins(value?: PrintTicketSection.MarginsTicketItem): void;
  hasMargins(): boolean;
  clearMargins(): void;

  getDpi(): PrintTicketSection.DpiTicketItem | undefined;
  setDpi(value?: PrintTicketSection.DpiTicketItem): void;
  hasDpi(): boolean;
  clearDpi(): void;

  getFitToPage(): PrintTicketSection.FitToPageTicketItem | undefined;
  setFitToPage(value?: PrintTicketSection.FitToPageTicketItem): void;
  hasFitToPage(): boolean;
  clearFitToPage(): void;

  getPageRange(): PrintTicketSection.PageRangeTicketItem | undefined;
  setPageRange(value?: PrintTicketSection.PageRangeTicketItem): void;
  hasPageRange(): boolean;
  clearPageRange(): void;

  getMediaSize(): PrintTicketSection.MediaSizeTicketItem | undefined;
  setMediaSize(value?: PrintTicketSection.MediaSizeTicketItem): void;
  hasMediaSize(): boolean;
  clearMediaSize(): void;

  getCollate(): PrintTicketSection.CollateTicketItem | undefined;
  setCollate(value?: PrintTicketSection.CollateTicketItem): void;
  hasCollate(): boolean;
  clearCollate(): void;

  getReverseOrder(): PrintTicketSection.ReverseOrderTicketItem | undefined;
  setReverseOrder(value?: PrintTicketSection.ReverseOrderTicketItem): void;
  hasReverseOrder(): boolean;
  clearReverseOrder(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PrintTicketSection.AsObject;
  static toObject(includeInstance: boolean, msg: PrintTicketSection): PrintTicketSection.AsObject;
  static serializeBinaryToWriter(message: PrintTicketSection, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PrintTicketSection;
  static deserializeBinaryFromReader(message: PrintTicketSection, reader: jspb.BinaryReader): PrintTicketSection;
}

export namespace PrintTicketSection {
  export type AsObject = {
    vendorTicketItemList: Array<PrintTicketSection.VendorTicketItem.AsObject>,
    color?: PrintTicketSection.ColorTicketItem.AsObject,
    duplex?: PrintTicketSection.DuplexTicketItem.AsObject,
    pageOrientation?: PrintTicketSection.PageOrientationTicketItem.AsObject,
    copies?: PrintTicketSection.CopiesTicketItem.AsObject,
    margins?: PrintTicketSection.MarginsTicketItem.AsObject,
    dpi?: PrintTicketSection.DpiTicketItem.AsObject,
    fitToPage?: PrintTicketSection.FitToPageTicketItem.AsObject,
    pageRange?: PrintTicketSection.PageRangeTicketItem.AsObject,
    mediaSize?: PrintTicketSection.MediaSizeTicketItem.AsObject,
    collate?: PrintTicketSection.CollateTicketItem.AsObject,
    reverseOrder?: PrintTicketSection.ReverseOrderTicketItem.AsObject,
  }

  export class VendorTicketItem extends jspb.Message {
    getId(): string;
    setId(value: string): void;

    getValue(): string;
    setValue(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): VendorTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: VendorTicketItem): VendorTicketItem.AsObject;
    static serializeBinaryToWriter(message: VendorTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): VendorTicketItem;
    static deserializeBinaryFromReader(message: VendorTicketItem, reader: jspb.BinaryReader): VendorTicketItem;
  }

  export namespace VendorTicketItem {
    export type AsObject = {
      id: string,
      value: string,
    }
  }


  export class ColorTicketItem extends jspb.Message {
    getVendorId(): string;
    setVendorId(value: string): void;

    getType(): google_cloudprint_Common_pb.Color.Type;
    setType(value: google_cloudprint_Common_pb.Color.Type): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ColorTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: ColorTicketItem): ColorTicketItem.AsObject;
    static serializeBinaryToWriter(message: ColorTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ColorTicketItem;
    static deserializeBinaryFromReader(message: ColorTicketItem, reader: jspb.BinaryReader): ColorTicketItem;
  }

  export namespace ColorTicketItem {
    export type AsObject = {
      vendorId: string,
      type: google_cloudprint_Common_pb.Color.Type,
    }
  }


  export class DuplexTicketItem extends jspb.Message {
    getType(): google_cloudprint_Common_pb.Duplex.Type;
    setType(value: google_cloudprint_Common_pb.Duplex.Type): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): DuplexTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: DuplexTicketItem): DuplexTicketItem.AsObject;
    static serializeBinaryToWriter(message: DuplexTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): DuplexTicketItem;
    static deserializeBinaryFromReader(message: DuplexTicketItem, reader: jspb.BinaryReader): DuplexTicketItem;
  }

  export namespace DuplexTicketItem {
    export type AsObject = {
      type: google_cloudprint_Common_pb.Duplex.Type,
    }
  }


  export class PageOrientationTicketItem extends jspb.Message {
    getType(): google_cloudprint_Common_pb.PageOrientation.Type;
    setType(value: google_cloudprint_Common_pb.PageOrientation.Type): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): PageOrientationTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: PageOrientationTicketItem): PageOrientationTicketItem.AsObject;
    static serializeBinaryToWriter(message: PageOrientationTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): PageOrientationTicketItem;
    static deserializeBinaryFromReader(message: PageOrientationTicketItem, reader: jspb.BinaryReader): PageOrientationTicketItem;
  }

  export namespace PageOrientationTicketItem {
    export type AsObject = {
      type: google_cloudprint_Common_pb.PageOrientation.Type,
    }
  }


  export class CopiesTicketItem extends jspb.Message {
    getCopies(): number;
    setCopies(value: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CopiesTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: CopiesTicketItem): CopiesTicketItem.AsObject;
    static serializeBinaryToWriter(message: CopiesTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CopiesTicketItem;
    static deserializeBinaryFromReader(message: CopiesTicketItem, reader: jspb.BinaryReader): CopiesTicketItem;
  }

  export namespace CopiesTicketItem {
    export type AsObject = {
      copies: number,
    }
  }


  export class MarginsTicketItem extends jspb.Message {
    getTopMicrons(): number;
    setTopMicrons(value: number): void;

    getRightMicrons(): number;
    setRightMicrons(value: number): void;

    getBottomMicrons(): number;
    setBottomMicrons(value: number): void;

    getLeftMicrons(): number;
    setLeftMicrons(value: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): MarginsTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: MarginsTicketItem): MarginsTicketItem.AsObject;
    static serializeBinaryToWriter(message: MarginsTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): MarginsTicketItem;
    static deserializeBinaryFromReader(message: MarginsTicketItem, reader: jspb.BinaryReader): MarginsTicketItem;
  }

  export namespace MarginsTicketItem {
    export type AsObject = {
      topMicrons: number,
      rightMicrons: number,
      bottomMicrons: number,
      leftMicrons: number,
    }
  }


  export class DpiTicketItem extends jspb.Message {
    getHorizontalDpi(): number;
    setHorizontalDpi(value: number): void;

    getVerticalDpi(): number;
    setVerticalDpi(value: number): void;

    getVendorId(): string;
    setVendorId(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): DpiTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: DpiTicketItem): DpiTicketItem.AsObject;
    static serializeBinaryToWriter(message: DpiTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): DpiTicketItem;
    static deserializeBinaryFromReader(message: DpiTicketItem, reader: jspb.BinaryReader): DpiTicketItem;
  }

  export namespace DpiTicketItem {
    export type AsObject = {
      horizontalDpi: number,
      verticalDpi: number,
      vendorId: string,
    }
  }


  export class FitToPageTicketItem extends jspb.Message {
    getType(): google_cloudprint_Common_pb.FitToPage.Type;
    setType(value: google_cloudprint_Common_pb.FitToPage.Type): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): FitToPageTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: FitToPageTicketItem): FitToPageTicketItem.AsObject;
    static serializeBinaryToWriter(message: FitToPageTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): FitToPageTicketItem;
    static deserializeBinaryFromReader(message: FitToPageTicketItem, reader: jspb.BinaryReader): FitToPageTicketItem;
  }

  export namespace FitToPageTicketItem {
    export type AsObject = {
      type: google_cloudprint_Common_pb.FitToPage.Type,
    }
  }


  export class PageRangeTicketItem extends jspb.Message {
    getIntervalList(): Array<google_cloudprint_Common_pb.PageRange.Interval>;
    setIntervalList(value: Array<google_cloudprint_Common_pb.PageRange.Interval>): void;
    clearIntervalList(): void;
    addInterval(value?: google_cloudprint_Common_pb.PageRange.Interval, index?: number): google_cloudprint_Common_pb.PageRange.Interval;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): PageRangeTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: PageRangeTicketItem): PageRangeTicketItem.AsObject;
    static serializeBinaryToWriter(message: PageRangeTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): PageRangeTicketItem;
    static deserializeBinaryFromReader(message: PageRangeTicketItem, reader: jspb.BinaryReader): PageRangeTicketItem;
  }

  export namespace PageRangeTicketItem {
    export type AsObject = {
      intervalList: Array<google_cloudprint_Common_pb.PageRange.Interval.AsObject>,
    }
  }


  export class MediaSizeTicketItem extends jspb.Message {
    getWidthMicrons(): number;
    setWidthMicrons(value: number): void;

    getHeightMicrons(): number;
    setHeightMicrons(value: number): void;

    getIsContinuousFeed(): boolean;
    setIsContinuousFeed(value: boolean): void;

    getVendorId(): string;
    setVendorId(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): MediaSizeTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: MediaSizeTicketItem): MediaSizeTicketItem.AsObject;
    static serializeBinaryToWriter(message: MediaSizeTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): MediaSizeTicketItem;
    static deserializeBinaryFromReader(message: MediaSizeTicketItem, reader: jspb.BinaryReader): MediaSizeTicketItem;
  }

  export namespace MediaSizeTicketItem {
    export type AsObject = {
      widthMicrons: number,
      heightMicrons: number,
      isContinuousFeed: boolean,
      vendorId: string,
    }
  }


  export class CollateTicketItem extends jspb.Message {
    getCollate(): boolean;
    setCollate(value: boolean): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): CollateTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: CollateTicketItem): CollateTicketItem.AsObject;
    static serializeBinaryToWriter(message: CollateTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): CollateTicketItem;
    static deserializeBinaryFromReader(message: CollateTicketItem, reader: jspb.BinaryReader): CollateTicketItem;
  }

  export namespace CollateTicketItem {
    export type AsObject = {
      collate: boolean,
    }
  }


  export class ReverseOrderTicketItem extends jspb.Message {
    getReverseOrder(): boolean;
    setReverseOrder(value: boolean): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ReverseOrderTicketItem.AsObject;
    static toObject(includeInstance: boolean, msg: ReverseOrderTicketItem): ReverseOrderTicketItem.AsObject;
    static serializeBinaryToWriter(message: ReverseOrderTicketItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ReverseOrderTicketItem;
    static deserializeBinaryFromReader(message: ReverseOrderTicketItem, reader: jspb.BinaryReader): ReverseOrderTicketItem;
  }

  export namespace ReverseOrderTicketItem {
    export type AsObject = {
      reverseOrder: boolean,
    }
  }

}

