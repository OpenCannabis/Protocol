import * as jspb from "google-protobuf"

import * as google_cloudprint_Common_pb from '../../google/cloudprint/Common_pb';

export class CloudDeviceState extends jspb.Message {
  getVersion(): string;
  setVersion(value: string): void;

  getCloudConnectionState(): CloudDeviceState.CloudConnectionStateType;
  setCloudConnectionState(value: CloudDeviceState.CloudConnectionStateType): void;

  getPrinter(): PrinterStateSection | undefined;
  setPrinter(value?: PrinterStateSection): void;
  hasPrinter(): boolean;
  clearPrinter(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CloudDeviceState.AsObject;
  static toObject(includeInstance: boolean, msg: CloudDeviceState): CloudDeviceState.AsObject;
  static serializeBinaryToWriter(message: CloudDeviceState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CloudDeviceState;
  static deserializeBinaryFromReader(message: CloudDeviceState, reader: jspb.BinaryReader): CloudDeviceState;
}

export namespace CloudDeviceState {
  export type AsObject = {
    version: string,
    cloudConnectionState: CloudDeviceState.CloudConnectionStateType,
    printer?: PrinterStateSection.AsObject,
  }

  export enum StateType { 
    IDLE = 0,
    PROCESSING = 1,
    STOPPED = 2,
  }

  export enum CloudConnectionStateType { 
    UNKNOWN = 0,
    NOT_CONFIGURED = 1,
    ONLINE = 2,
    OFFLINE = 3,
  }
}

export class CloudDeviceUiState extends jspb.Message {
  getSummary(): CloudDeviceUiState.Summary;
  setSummary(value: CloudDeviceUiState.Summary): void;

  getSeverity(): CloudDeviceUiState.Severity;
  setSeverity(value: CloudDeviceUiState.Severity): void;

  getNumIssues(): number;
  setNumIssues(value: number): void;

  getCaption(): string;
  setCaption(value: string): void;

  getPrinter(): PrinterUiStateSection | undefined;
  setPrinter(value?: PrinterUiStateSection): void;
  hasPrinter(): boolean;
  clearPrinter(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CloudDeviceUiState.AsObject;
  static toObject(includeInstance: boolean, msg: CloudDeviceUiState): CloudDeviceUiState.AsObject;
  static serializeBinaryToWriter(message: CloudDeviceUiState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CloudDeviceUiState;
  static deserializeBinaryFromReader(message: CloudDeviceUiState, reader: jspb.BinaryReader): CloudDeviceUiState;
}

export namespace CloudDeviceUiState {
  export type AsObject = {
    summary: CloudDeviceUiState.Summary,
    severity: CloudDeviceUiState.Severity,
    numIssues: number,
    caption: string,
    printer?: PrinterUiStateSection.AsObject,
  }

  export enum Summary { 
    IDLE = 0,
    PROCESSING = 1,
    STOPPED = 2,
    OFFLINE = 3,
  }

  export enum Severity { 
    NONE = 0,
    LOW = 1,
    MEDIUM = 2,
    HIGH = 3,
  }
}

export class PrinterUiStateSection extends jspb.Message {
  getVendorItemList(): Array<PrinterUiStateSection.Item>;
  setVendorItemList(value: Array<PrinterUiStateSection.Item>): void;
  clearVendorItemList(): void;
  addVendorItem(value?: PrinterUiStateSection.Item, index?: number): PrinterUiStateSection.Item;

  getInputTrayItemList(): Array<PrinterUiStateSection.Item>;
  setInputTrayItemList(value: Array<PrinterUiStateSection.Item>): void;
  clearInputTrayItemList(): void;
  addInputTrayItem(value?: PrinterUiStateSection.Item, index?: number): PrinterUiStateSection.Item;

  getOutputBinItemList(): Array<PrinterUiStateSection.Item>;
  setOutputBinItemList(value: Array<PrinterUiStateSection.Item>): void;
  clearOutputBinItemList(): void;
  addOutputBinItem(value?: PrinterUiStateSection.Item, index?: number): PrinterUiStateSection.Item;

  getMarkerItemList(): Array<PrinterUiStateSection.Item>;
  setMarkerItemList(value: Array<PrinterUiStateSection.Item>): void;
  clearMarkerItemList(): void;
  addMarkerItem(value?: PrinterUiStateSection.Item, index?: number): PrinterUiStateSection.Item;

  getCoverItemList(): Array<PrinterUiStateSection.Item>;
  setCoverItemList(value: Array<PrinterUiStateSection.Item>): void;
  clearCoverItemList(): void;
  addCoverItem(value?: PrinterUiStateSection.Item, index?: number): PrinterUiStateSection.Item;

  getMediaPathItemList(): Array<PrinterUiStateSection.Item>;
  setMediaPathItemList(value: Array<PrinterUiStateSection.Item>): void;
  clearMediaPathItemList(): void;
  addMediaPathItem(value?: PrinterUiStateSection.Item, index?: number): PrinterUiStateSection.Item;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PrinterUiStateSection.AsObject;
  static toObject(includeInstance: boolean, msg: PrinterUiStateSection): PrinterUiStateSection.AsObject;
  static serializeBinaryToWriter(message: PrinterUiStateSection, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PrinterUiStateSection;
  static deserializeBinaryFromReader(message: PrinterUiStateSection, reader: jspb.BinaryReader): PrinterUiStateSection;
}

export namespace PrinterUiStateSection {
  export type AsObject = {
    vendorItemList: Array<PrinterUiStateSection.Item.AsObject>,
    inputTrayItemList: Array<PrinterUiStateSection.Item.AsObject>,
    outputBinItemList: Array<PrinterUiStateSection.Item.AsObject>,
    markerItemList: Array<PrinterUiStateSection.Item.AsObject>,
    coverItemList: Array<PrinterUiStateSection.Item.AsObject>,
    mediaPathItemList: Array<PrinterUiStateSection.Item.AsObject>,
  }

  export class Item extends jspb.Message {
    getSeverity(): CloudDeviceUiState.Severity;
    setSeverity(value: CloudDeviceUiState.Severity): void;

    getMessage(): string;
    setMessage(value: string): void;

    getVendorMessage(): string;
    setVendorMessage(value: string): void;

    getLevelPercent(): number;
    setLevelPercent(value: number): void;

    getColor(): google_cloudprint_Common_pb.Marker.Color.Type;
    setColor(value: google_cloudprint_Common_pb.Marker.Color.Type): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Item.AsObject;
    static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
    static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Item;
    static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
  }

  export namespace Item {
    export type AsObject = {
      severity: CloudDeviceUiState.Severity,
      message: string,
      vendorMessage: string,
      levelPercent: number,
      color: google_cloudprint_Common_pb.Marker.Color.Type,
    }
  }

}

export class PrinterStateSection extends jspb.Message {
  getState(): CloudDeviceState.StateType;
  setState(value: CloudDeviceState.StateType): void;

  getInputTrayState(): InputTrayState | undefined;
  setInputTrayState(value?: InputTrayState): void;
  hasInputTrayState(): boolean;
  clearInputTrayState(): void;

  getOutputBinState(): OutputBinState | undefined;
  setOutputBinState(value?: OutputBinState): void;
  hasOutputBinState(): boolean;
  clearOutputBinState(): void;

  getMarkerState(): MarkerState | undefined;
  setMarkerState(value?: MarkerState): void;
  hasMarkerState(): boolean;
  clearMarkerState(): void;

  getCoverState(): CoverState | undefined;
  setCoverState(value?: CoverState): void;
  hasCoverState(): boolean;
  clearCoverState(): void;

  getMediaPathState(): MediaPathState | undefined;
  setMediaPathState(value?: MediaPathState): void;
  hasMediaPathState(): boolean;
  clearMediaPathState(): void;

  getVendorState(): VendorState | undefined;
  setVendorState(value?: VendorState): void;
  hasVendorState(): boolean;
  clearVendorState(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PrinterStateSection.AsObject;
  static toObject(includeInstance: boolean, msg: PrinterStateSection): PrinterStateSection.AsObject;
  static serializeBinaryToWriter(message: PrinterStateSection, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PrinterStateSection;
  static deserializeBinaryFromReader(message: PrinterStateSection, reader: jspb.BinaryReader): PrinterStateSection;
}

export namespace PrinterStateSection {
  export type AsObject = {
    state: CloudDeviceState.StateType,
    inputTrayState?: InputTrayState.AsObject,
    outputBinState?: OutputBinState.AsObject,
    markerState?: MarkerState.AsObject,
    coverState?: CoverState.AsObject,
    mediaPathState?: MediaPathState.AsObject,
    vendorState?: VendorState.AsObject,
  }
}

export class InputTrayState extends jspb.Message {
  getItemList(): Array<InputTrayState.Item>;
  setItemList(value: Array<InputTrayState.Item>): void;
  clearItemList(): void;
  addItem(value?: InputTrayState.Item, index?: number): InputTrayState.Item;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputTrayState.AsObject;
  static toObject(includeInstance: boolean, msg: InputTrayState): InputTrayState.AsObject;
  static serializeBinaryToWriter(message: InputTrayState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputTrayState;
  static deserializeBinaryFromReader(message: InputTrayState, reader: jspb.BinaryReader): InputTrayState;
}

export namespace InputTrayState {
  export type AsObject = {
    itemList: Array<InputTrayState.Item.AsObject>,
  }

  export class Item extends jspb.Message {
    getVendorId(): string;
    setVendorId(value: string): void;

    getState(): InputTrayState.Item.StateType;
    setState(value: InputTrayState.Item.StateType): void;

    getLevelPercent(): number;
    setLevelPercent(value: number): void;

    getVendorMessage(): string;
    setVendorMessage(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Item.AsObject;
    static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
    static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Item;
    static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
  }

  export namespace Item {
    export type AsObject = {
      vendorId: string,
      state: InputTrayState.Item.StateType,
      levelPercent: number,
      vendorMessage: string,
    }

    export enum StateType { 
      OK = 0,
      EMPTY = 1,
      OPEN = 2,
      OFF = 3,
      FAILURE = 4,
    }
  }

}

export class OutputBinState extends jspb.Message {
  getItemList(): Array<OutputBinState.Item>;
  setItemList(value: Array<OutputBinState.Item>): void;
  clearItemList(): void;
  addItem(value?: OutputBinState.Item, index?: number): OutputBinState.Item;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OutputBinState.AsObject;
  static toObject(includeInstance: boolean, msg: OutputBinState): OutputBinState.AsObject;
  static serializeBinaryToWriter(message: OutputBinState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OutputBinState;
  static deserializeBinaryFromReader(message: OutputBinState, reader: jspb.BinaryReader): OutputBinState;
}

export namespace OutputBinState {
  export type AsObject = {
    itemList: Array<OutputBinState.Item.AsObject>,
  }

  export class Item extends jspb.Message {
    getVendorId(): string;
    setVendorId(value: string): void;

    getState(): OutputBinState.Item.StateType;
    setState(value: OutputBinState.Item.StateType): void;

    getLevelPercent(): number;
    setLevelPercent(value: number): void;

    getVendorMessage(): string;
    setVendorMessage(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Item.AsObject;
    static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
    static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Item;
    static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
  }

  export namespace Item {
    export type AsObject = {
      vendorId: string,
      state: OutputBinState.Item.StateType,
      levelPercent: number,
      vendorMessage: string,
    }

    export enum StateType { 
      OK = 0,
      FULL = 1,
      OPEN = 2,
      OFF = 3,
      FAILURE = 4,
    }
  }

}

export class MarkerState extends jspb.Message {
  getItemList(): Array<MarkerState.Item>;
  setItemList(value: Array<MarkerState.Item>): void;
  clearItemList(): void;
  addItem(value?: MarkerState.Item, index?: number): MarkerState.Item;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MarkerState.AsObject;
  static toObject(includeInstance: boolean, msg: MarkerState): MarkerState.AsObject;
  static serializeBinaryToWriter(message: MarkerState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MarkerState;
  static deserializeBinaryFromReader(message: MarkerState, reader: jspb.BinaryReader): MarkerState;
}

export namespace MarkerState {
  export type AsObject = {
    itemList: Array<MarkerState.Item.AsObject>,
  }

  export class Item extends jspb.Message {
    getVendorId(): string;
    setVendorId(value: string): void;

    getState(): MarkerState.Item.StateType;
    setState(value: MarkerState.Item.StateType): void;

    getLevelPercent(): number;
    setLevelPercent(value: number): void;

    getLevelPages(): number;
    setLevelPages(value: number): void;

    getVendorMessage(): string;
    setVendorMessage(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Item.AsObject;
    static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
    static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Item;
    static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
  }

  export namespace Item {
    export type AsObject = {
      vendorId: string,
      state: MarkerState.Item.StateType,
      levelPercent: number,
      levelPages: number,
      vendorMessage: string,
    }

    export enum StateType { 
      OK = 0,
      EXHAUSTED = 1,
      REMOVED = 2,
      FAILURE = 3,
    }
  }

}

export class CoverState extends jspb.Message {
  getItemList(): Array<CoverState.Item>;
  setItemList(value: Array<CoverState.Item>): void;
  clearItemList(): void;
  addItem(value?: CoverState.Item, index?: number): CoverState.Item;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CoverState.AsObject;
  static toObject(includeInstance: boolean, msg: CoverState): CoverState.AsObject;
  static serializeBinaryToWriter(message: CoverState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CoverState;
  static deserializeBinaryFromReader(message: CoverState, reader: jspb.BinaryReader): CoverState;
}

export namespace CoverState {
  export type AsObject = {
    itemList: Array<CoverState.Item.AsObject>,
  }

  export class Item extends jspb.Message {
    getVendorId(): string;
    setVendorId(value: string): void;

    getState(): CoverState.Item.StateType;
    setState(value: CoverState.Item.StateType): void;

    getVendorMessage(): string;
    setVendorMessage(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Item.AsObject;
    static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
    static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Item;
    static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
  }

  export namespace Item {
    export type AsObject = {
      vendorId: string,
      state: CoverState.Item.StateType,
      vendorMessage: string,
    }

    export enum StateType { 
      OK = 0,
      OPEN = 1,
      FAILURE = 2,
    }
  }

}

export class MediaPathState extends jspb.Message {
  getItemList(): Array<MediaPathState.Item>;
  setItemList(value: Array<MediaPathState.Item>): void;
  clearItemList(): void;
  addItem(value?: MediaPathState.Item, index?: number): MediaPathState.Item;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MediaPathState.AsObject;
  static toObject(includeInstance: boolean, msg: MediaPathState): MediaPathState.AsObject;
  static serializeBinaryToWriter(message: MediaPathState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MediaPathState;
  static deserializeBinaryFromReader(message: MediaPathState, reader: jspb.BinaryReader): MediaPathState;
}

export namespace MediaPathState {
  export type AsObject = {
    itemList: Array<MediaPathState.Item.AsObject>,
  }

  export class Item extends jspb.Message {
    getVendorId(): string;
    setVendorId(value: string): void;

    getState(): MediaPathState.Item.StateType;
    setState(value: MediaPathState.Item.StateType): void;

    getVendorMessage(): string;
    setVendorMessage(value: string): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Item.AsObject;
    static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
    static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Item;
    static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
  }

  export namespace Item {
    export type AsObject = {
      vendorId: string,
      state: MediaPathState.Item.StateType,
      vendorMessage: string,
    }

    export enum StateType { 
      OK = 0,
      MEDIA_JAM = 1,
      FAILURE = 2,
    }
  }

}

export class VendorState extends jspb.Message {
  getItemList(): Array<VendorState.Item>;
  setItemList(value: Array<VendorState.Item>): void;
  clearItemList(): void;
  addItem(value?: VendorState.Item, index?: number): VendorState.Item;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VendorState.AsObject;
  static toObject(includeInstance: boolean, msg: VendorState): VendorState.AsObject;
  static serializeBinaryToWriter(message: VendorState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VendorState;
  static deserializeBinaryFromReader(message: VendorState, reader: jspb.BinaryReader): VendorState;
}

export namespace VendorState {
  export type AsObject = {
    itemList: Array<VendorState.Item.AsObject>,
  }

  export class Item extends jspb.Message {
    getState(): VendorState.Item.StateType;
    setState(value: VendorState.Item.StateType): void;

    getDescription(): string;
    setDescription(value: string): void;

    getDescriptionLocalizedList(): Array<google_cloudprint_Common_pb.LocalizedString>;
    setDescriptionLocalizedList(value: Array<google_cloudprint_Common_pb.LocalizedString>): void;
    clearDescriptionLocalizedList(): void;
    addDescriptionLocalized(value?: google_cloudprint_Common_pb.LocalizedString, index?: number): google_cloudprint_Common_pb.LocalizedString;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Item.AsObject;
    static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
    static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Item;
    static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
  }

  export namespace Item {
    export type AsObject = {
      state: VendorState.Item.StateType,
      description: string,
      descriptionLocalizedList: Array<google_cloudprint_Common_pb.LocalizedString.AsObject>,
    }

    export enum StateType { 
      ERROR = 0,
      WARNING = 1,
      INFO = 2,
    }
  }

}

