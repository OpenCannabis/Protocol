import * as jspb from "google-protobuf"

import * as crypto_primitives_Keys_pb from '../crypto/primitives/Keys_pb';
import * as crypto_primitives_Integrity_pb from '../crypto/primitives/Integrity_pb';

export class Signature extends jspb.Message {
  getPublicKey(): crypto_primitives_Keys_pb.KeyMaterial | undefined;
  setPublicKey(value?: crypto_primitives_Keys_pb.KeyMaterial): void;
  hasPublicKey(): boolean;
  clearPublicKey(): void;

  getFingerprint(): crypto_primitives_Integrity_pb.Hash | undefined;
  setFingerprint(value?: crypto_primitives_Integrity_pb.Hash): void;
  hasFingerprint(): boolean;
  clearFingerprint(): void;

  getRaw(): Uint8Array | string;
  getRaw_asU8(): Uint8Array;
  getRaw_asB64(): string;
  setRaw(value: Uint8Array | string): void;

  getB64(): string;
  setB64(value: string): void;

  getHex(): string;
  setHex(value: string): void;

  getSignatureCase(): Signature.SignatureCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Signature.AsObject;
  static toObject(includeInstance: boolean, msg: Signature): Signature.AsObject;
  static serializeBinaryToWriter(message: Signature, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Signature;
  static deserializeBinaryFromReader(message: Signature, reader: jspb.BinaryReader): Signature;
}

export namespace Signature {
  export type AsObject = {
    publicKey?: crypto_primitives_Keys_pb.KeyMaterial.AsObject,
    fingerprint?: crypto_primitives_Integrity_pb.Hash.AsObject,
    raw: Uint8Array | string,
    b64: string,
    hex: string,
  }

  export enum SignatureCase { 
    SIGNATURE_NOT_SET = 0,
    RAW = 5,
    B64 = 6,
    HEX = 7,
  }
}

