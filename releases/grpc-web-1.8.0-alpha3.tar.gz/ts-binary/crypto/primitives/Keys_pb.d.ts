import * as jspb from "google-protobuf"

import * as crypto_primitives_Integrity_pb from '../../crypto/primitives/Integrity_pb';

export class BlockCipherParameters extends jspb.Message {
  getAlgorithm(): BlockCipher;
  setAlgorithm(value: BlockCipher): void;

  getMode(): BlockMode;
  setMode(value: BlockMode): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BlockCipherParameters.AsObject;
  static toObject(includeInstance: boolean, msg: BlockCipherParameters): BlockCipherParameters.AsObject;
  static serializeBinaryToWriter(message: BlockCipherParameters, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BlockCipherParameters;
  static deserializeBinaryFromReader(message: BlockCipherParameters, reader: jspb.BinaryReader): BlockCipherParameters;
}

export namespace BlockCipherParameters {
  export type AsObject = {
    algorithm: BlockCipher,
    mode: BlockMode,
  }
}

export class SymmetricKeyParameters extends jspb.Message {
  getStream(): StreamCipher;
  setStream(value: StreamCipher): void;

  getBlock(): BlockCipherParameters | undefined;
  setBlock(value?: BlockCipherParameters): void;
  hasBlock(): boolean;
  clearBlock(): void;

  getCipherCase(): SymmetricKeyParameters.CipherCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SymmetricKeyParameters.AsObject;
  static toObject(includeInstance: boolean, msg: SymmetricKeyParameters): SymmetricKeyParameters.AsObject;
  static serializeBinaryToWriter(message: SymmetricKeyParameters, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SymmetricKeyParameters;
  static deserializeBinaryFromReader(message: SymmetricKeyParameters, reader: jspb.BinaryReader): SymmetricKeyParameters;
}

export namespace SymmetricKeyParameters {
  export type AsObject = {
    stream: StreamCipher,
    block?: BlockCipherParameters.AsObject,
  }

  export enum CipherCase { 
    CIPHER_NOT_SET = 0,
    STREAM = 1,
    BLOCK = 2,
  }
}

export class AsymmetricKeypairParameters extends jspb.Message {
  getScheme(): KeyingScheme;
  setScheme(value: KeyingScheme): void;

  getFingerprint(): crypto_primitives_Integrity_pb.Hash | undefined;
  setFingerprint(value?: crypto_primitives_Integrity_pb.Hash): void;
  hasFingerprint(): boolean;
  clearFingerprint(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AsymmetricKeypairParameters.AsObject;
  static toObject(includeInstance: boolean, msg: AsymmetricKeypairParameters): AsymmetricKeypairParameters.AsObject;
  static serializeBinaryToWriter(message: AsymmetricKeypairParameters, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AsymmetricKeypairParameters;
  static deserializeBinaryFromReader(message: AsymmetricKeypairParameters, reader: jspb.BinaryReader): AsymmetricKeypairParameters;
}

export namespace AsymmetricKeypairParameters {
  export type AsObject = {
    scheme: KeyingScheme,
    fingerprint?: crypto_primitives_Integrity_pb.Hash.AsObject,
  }
}

export class KeyParameters extends jspb.Message {
  getAlgorithm(): string;
  setAlgorithm(value: string): void;

  getFormat(): string;
  setFormat(value: string): void;

  getBits(): number;
  setBits(value: number): void;

  getType(): KeyType;
  setType(value: KeyType): void;

  getDisposition(): KeyDisposition;
  setDisposition(value: KeyDisposition): void;

  getScheme(): KeyingScheme;
  setScheme(value: KeyingScheme): void;

  getSymmetric(): SymmetricKeyParameters | undefined;
  setSymmetric(value?: SymmetricKeyParameters): void;
  hasSymmetric(): boolean;
  clearSymmetric(): void;

  getArchitectureCase(): KeyParameters.ArchitectureCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): KeyParameters.AsObject;
  static toObject(includeInstance: boolean, msg: KeyParameters): KeyParameters.AsObject;
  static serializeBinaryToWriter(message: KeyParameters, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): KeyParameters;
  static deserializeBinaryFromReader(message: KeyParameters, reader: jspb.BinaryReader): KeyParameters;
}

export namespace KeyParameters {
  export type AsObject = {
    algorithm: string,
    format: string,
    bits: number,
    type: KeyType,
    disposition: KeyDisposition,
    scheme: KeyingScheme,
    symmetric?: SymmetricKeyParameters.AsObject,
  }

  export enum ArchitectureCase { 
    ARCHITECTURE_NOT_SET = 0,
    SCHEME = 10,
    SYMMETRIC = 11,
  }
}

export class InitializationVector extends jspb.Message {
  getMode(): InitializationVectorMode;
  setMode(value: InitializationVectorMode): void;

  getRaw(): Uint8Array | string;
  getRaw_asU8(): Uint8Array;
  getRaw_asB64(): string;
  setRaw(value: Uint8Array | string): void;

  getB64(): string;
  setB64(value: string): void;

  getNumber(): number;
  setNumber(value: number): void;

  getValueCase(): InitializationVector.ValueCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InitializationVector.AsObject;
  static toObject(includeInstance: boolean, msg: InitializationVector): InitializationVector.AsObject;
  static serializeBinaryToWriter(message: InitializationVector, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InitializationVector;
  static deserializeBinaryFromReader(message: InitializationVector, reader: jspb.BinaryReader): InitializationVector;
}

export namespace InitializationVector {
  export type AsObject = {
    mode: InitializationVectorMode,
    raw: Uint8Array | string,
    b64: string,
    number: number,
  }

  export enum ValueCase { 
    VALUE_NOT_SET = 0,
    RAW = 10,
    B64 = 11,
    NUMBER = 12,
  }
}

export class SymmetricKey extends jspb.Message {
  getBits(): number;
  setBits(value: number): void;

  getIv(): InitializationVector | undefined;
  setIv(value?: InitializationVector): void;
  hasIv(): boolean;
  clearIv(): void;

  getRaw(): Uint8Array | string;
  getRaw_asU8(): Uint8Array;
  getRaw_asB64(): string;
  setRaw(value: Uint8Array | string): void;

  getB64(): string;
  setB64(value: string): void;

  getDataCase(): SymmetricKey.DataCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SymmetricKey.AsObject;
  static toObject(includeInstance: boolean, msg: SymmetricKey): SymmetricKey.AsObject;
  static serializeBinaryToWriter(message: SymmetricKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SymmetricKey;
  static deserializeBinaryFromReader(message: SymmetricKey, reader: jspb.BinaryReader): SymmetricKey;
}

export namespace SymmetricKey {
  export type AsObject = {
    bits: number,
    iv?: InitializationVector.AsObject,
    raw: Uint8Array | string,
    b64: string,
  }

  export enum DataCase { 
    DATA_NOT_SET = 0,
    RAW = 10,
    B64 = 11,
  }
}

export class KeyMaterial extends jspb.Message {
  getFingerprint(): crypto_primitives_Integrity_pb.Hash | undefined;
  setFingerprint(value?: crypto_primitives_Integrity_pb.Hash): void;
  hasFingerprint(): boolean;
  clearFingerprint(): void;

  getParams(): KeyParameters | undefined;
  setParams(value?: KeyParameters): void;
  hasParams(): boolean;
  clearParams(): void;

  getRaw(): Uint8Array | string;
  getRaw_asU8(): Uint8Array;
  getRaw_asB64(): string;
  setRaw(value: Uint8Array | string): void;

  getPem(): string;
  setPem(value: string): void;

  getDataCase(): KeyMaterial.DataCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): KeyMaterial.AsObject;
  static toObject(includeInstance: boolean, msg: KeyMaterial): KeyMaterial.AsObject;
  static serializeBinaryToWriter(message: KeyMaterial, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): KeyMaterial;
  static deserializeBinaryFromReader(message: KeyMaterial, reader: jspb.BinaryReader): KeyMaterial;
}

export namespace KeyMaterial {
  export type AsObject = {
    fingerprint?: crypto_primitives_Integrity_pb.Hash.AsObject,
    params?: KeyParameters.AsObject,
    raw: Uint8Array | string,
    pem: string,
  }

  export enum DataCase { 
    DATA_NOT_SET = 0,
    RAW = 10,
    PEM = 11,
  }
}

export class Keypair extends jspb.Message {
  getPublic(): KeyMaterial | undefined;
  setPublic(value?: KeyMaterial): void;
  hasPublic(): boolean;
  clearPublic(): void;

  getPrivate(): KeyMaterial | undefined;
  setPrivate(value?: KeyMaterial): void;
  hasPrivate(): boolean;
  clearPrivate(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Keypair.AsObject;
  static toObject(includeInstance: boolean, msg: Keypair): Keypair.AsObject;
  static serializeBinaryToWriter(message: Keypair, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Keypair;
  static deserializeBinaryFromReader(message: Keypair, reader: jspb.BinaryReader): Keypair;
}

export namespace Keypair {
  export type AsObject = {
    pb_public?: KeyMaterial.AsObject,
    pb_private?: KeyMaterial.AsObject,
  }
}

export enum KeyType { 
  SYMMETRIC = 0,
  ASYMMETRIC = 1,
}
export enum KeyDisposition { 
  PRIVATE = 0,
  EPHEMERAL = 1,
  PUBLIC = 2,
}
export enum BlockCipher { 
  UNSPECIFIED_BLOCK_CIPHER = 0,
  AES = 1,
  CAMELLIA = 2,
}
export enum StreamCipher { 
  UNSPECIFIED_STREAM_CIPHER = 0,
  RC5 = 1,
  RC6 = 2,
  CHACHA20 = 3,
}
export enum KeyAgreement { 
  UNSPECIFIED_KEY_AGREEMENT = 0,
  DHE = 1,
  ECDHE = 2,
}
export enum BlockMode { 
  UNSPECIFIED_BLOCK_MODE = 0,
  ECB = 1,
  CBC = 2,
  CFB = 3,
  OFB = 4,
  CTR = 5,
  CCM = 6,
  GCM = 7,
  XTS = 8,
  KWP = 9,
}
export enum KeyingScheme { 
  RSA = 0,
  ECC = 1,
  DSA = 2,
  EDDSA = 3,
}
export enum InitializationVectorMode { 
  STATIC_IV = 0,
  TOTP = 1,
  COUNTER = 2,
}
