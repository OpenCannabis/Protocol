import * as jspb from "google-protobuf"

export class Hash extends jspb.Message {
  getAlgorithm(): HashAlgorithm;
  setAlgorithm(value: HashAlgorithm): void;

  getRaw(): Uint8Array | string;
  getRaw_asU8(): Uint8Array;
  getRaw_asB64(): string;
  setRaw(value: Uint8Array | string): void;

  getHex(): string;
  setHex(value: string): void;

  getB64(): string;
  setB64(value: string): void;

  getDigestCase(): Hash.DigestCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Hash.AsObject;
  static toObject(includeInstance: boolean, msg: Hash): Hash.AsObject;
  static serializeBinaryToWriter(message: Hash, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Hash;
  static deserializeBinaryFromReader(message: Hash, reader: jspb.BinaryReader): Hash;
}

export namespace Hash {
  export type AsObject = {
    algorithm: HashAlgorithm,
    raw: Uint8Array | string,
    hex: string,
    b64: string,
  }

  export enum DigestCase { 
    DIGEST_NOT_SET = 0,
    RAW = 2,
    HEX = 3,
    B64 = 4,
  }
}

export class HashedData extends jspb.Message {
  getData(): Uint8Array | string;
  getData_asU8(): Uint8Array;
  getData_asB64(): string;
  setData(value: Uint8Array | string): void;

  getHash(): Hash | undefined;
  setHash(value?: Hash): void;
  hasHash(): boolean;
  clearHash(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): HashedData.AsObject;
  static toObject(includeInstance: boolean, msg: HashedData): HashedData.AsObject;
  static serializeBinaryToWriter(message: HashedData, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): HashedData;
  static deserializeBinaryFromReader(message: HashedData, reader: jspb.BinaryReader): HashedData;
}

export namespace HashedData {
  export type AsObject = {
    data: Uint8Array | string,
    hash?: Hash.AsObject,
  }
}

export enum HashAlgorithm { 
  SHA1 = 0,
  MD5 = 1,
  SHA256 = 2,
  SHA384 = 3,
  SHA512 = 4,
  MURMUR = 6,
}
