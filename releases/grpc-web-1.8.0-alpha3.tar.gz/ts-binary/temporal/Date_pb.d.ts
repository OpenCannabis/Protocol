import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class Date extends jspb.Message {
  getIso8601(): string;
  setIso8601(value: string): void;

  getSpecCase(): Date.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Date.AsObject;
  static toObject(includeInstance: boolean, msg: Date): Date.AsObject;
  static serializeBinaryToWriter(message: Date, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Date;
  static deserializeBinaryFromReader(message: Date, reader: jspb.BinaryReader): Date;
}

export namespace Date {
  export type AsObject = {
    iso8601: string,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    ISO8601 = 1,
  }
}

