import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class Duration extends jspb.Message {
  getUnit(): TimeUnit;
  setUnit(value: TimeUnit): void;

  getAmount(): number;
  setAmount(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Duration.AsObject;
  static toObject(includeInstance: boolean, msg: Duration): Duration.AsObject;
  static serializeBinaryToWriter(message: Duration, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Duration;
  static deserializeBinaryFromReader(message: Duration, reader: jspb.BinaryReader): Duration;
}

export namespace Duration {
  export type AsObject = {
    unit: TimeUnit,
    amount: number,
  }
}

export enum TimeUnit { 
  MILLISECONDS = 0,
  MICROSECONDS = 1,
  SECONDS = 2,
  MINUTES = 3,
  HOURS = 4,
  DAYS = 5,
  WEEKS = 6,
  MONTHS = 7,
  YEARS = 8,
}
