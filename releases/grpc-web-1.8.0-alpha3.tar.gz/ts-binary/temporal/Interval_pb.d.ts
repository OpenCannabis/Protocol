import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class TimeInterval extends jspb.Message {
  getInterval(): Interval;
  setInterval(value: Interval): void;

  getEvery(): number;
  setEvery(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TimeInterval.AsObject;
  static toObject(includeInstance: boolean, msg: TimeInterval): TimeInterval.AsObject;
  static serializeBinaryToWriter(message: TimeInterval, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TimeInterval;
  static deserializeBinaryFromReader(message: TimeInterval, reader: jspb.BinaryReader): TimeInterval;
}

export namespace TimeInterval {
  export type AsObject = {
    interval: Interval,
    every: number,
  }
}

export enum Interval { 
  MINUTELY = 0,
  HOURLY = 1,
  DAILY = 2,
  WEEKLY = 3,
  MONTHLY = 4,
}
