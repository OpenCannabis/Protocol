import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class Instant extends jspb.Message {
  getIso8601(): string;
  setIso8601(value: string): void;

  getTimestamp(): number;
  setTimestamp(value: number): void;

  getSpecCase(): Instant.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Instant.AsObject;
  static toObject(includeInstance: boolean, msg: Instant): Instant.AsObject;
  static serializeBinaryToWriter(message: Instant, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Instant;
  static deserializeBinaryFromReader(message: Instant, reader: jspb.BinaryReader): Instant;
}

export namespace Instant {
  export type AsObject = {
    iso8601: string,
    timestamp: number,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    ISO8601 = 1,
    TIMESTAMP = 2,
  }
}

