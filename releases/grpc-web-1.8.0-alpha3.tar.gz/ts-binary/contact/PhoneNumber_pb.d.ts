import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class PhoneNumber extends jspb.Message {
  getE164(): string;
  setE164(value: string): void;

  getValidated(): boolean;
  setValidated(value: boolean): void;

  getDisplay(): string;
  setDisplay(value: string): void;

  getTextCapable(): boolean;
  setTextCapable(value: boolean): void;

  getVoiceCapable(): boolean;
  setVoiceCapable(value: boolean): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PhoneNumber.AsObject;
  static toObject(includeInstance: boolean, msg: PhoneNumber): PhoneNumber.AsObject;
  static serializeBinaryToWriter(message: PhoneNumber, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PhoneNumber;
  static deserializeBinaryFromReader(message: PhoneNumber, reader: jspb.BinaryReader): PhoneNumber;
}

export namespace PhoneNumber {
  export type AsObject = {
    e164: string,
    validated: boolean,
    display: string,
    textCapable: boolean,
    voiceCapable: boolean,
  }
}

