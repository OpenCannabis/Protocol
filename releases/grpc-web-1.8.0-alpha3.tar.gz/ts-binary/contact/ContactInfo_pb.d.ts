import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as geo_Location_pb from '../geo/Location_pb';
import * as contact_PhoneNumber_pb from '../contact/PhoneNumber_pb';
import * as contact_EmailAddress_pb from '../contact/EmailAddress_pb';
import * as contact_Website_pb from '../contact/Website_pb';

export class ContactInfo extends jspb.Message {
  getLocation(): geo_Location_pb.Location | undefined;
  setLocation(value?: geo_Location_pb.Location): void;
  hasLocation(): boolean;
  clearLocation(): void;

  getPhone(): contact_PhoneNumber_pb.PhoneNumber | undefined;
  setPhone(value?: contact_PhoneNumber_pb.PhoneNumber): void;
  hasPhone(): boolean;
  clearPhone(): void;

  getEmail(): contact_EmailAddress_pb.EmailAddress | undefined;
  setEmail(value?: contact_EmailAddress_pb.EmailAddress): void;
  hasEmail(): boolean;
  clearEmail(): void;

  getWebsite(): contact_Website_pb.Website | undefined;
  setWebsite(value?: contact_Website_pb.Website): void;
  hasWebsite(): boolean;
  clearWebsite(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ContactInfo.AsObject;
  static toObject(includeInstance: boolean, msg: ContactInfo): ContactInfo.AsObject;
  static serializeBinaryToWriter(message: ContactInfo, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ContactInfo;
  static deserializeBinaryFromReader(message: ContactInfo, reader: jspb.BinaryReader): ContactInfo;
}

export namespace ContactInfo {
  export type AsObject = {
    location?: geo_Location_pb.Location.AsObject,
    phone?: contact_PhoneNumber_pb.PhoneNumber.AsObject,
    email?: contact_EmailAddress_pb.EmailAddress.AsObject,
    website?: contact_Website_pb.Website.AsObject,
  }
}

export class SocialInfo extends jspb.Message {
  getProfileList(): Array<SocialInfo.SocialProfile>;
  setProfileList(value: Array<SocialInfo.SocialProfile>): void;
  clearProfileList(): void;
  addProfile(value?: SocialInfo.SocialProfile, index?: number): SocialInfo.SocialProfile;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SocialInfo.AsObject;
  static toObject(includeInstance: boolean, msg: SocialInfo): SocialInfo.AsObject;
  static serializeBinaryToWriter(message: SocialInfo, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SocialInfo;
  static deserializeBinaryFromReader(message: SocialInfo, reader: jspb.BinaryReader): SocialInfo;
}

export namespace SocialInfo {
  export type AsObject = {
    profileList: Array<SocialInfo.SocialProfile.AsObject>,
  }

  export class SocialProfile extends jspb.Message {
    getKnown(): SocialInfo.SocialProvider;
    setKnown(value: SocialInfo.SocialProvider): void;

    getCustom(): string;
    setCustom(value: string): void;

    getUsername(): string;
    setUsername(value: string): void;

    getUrl(): contact_Website_pb.Website | undefined;
    setUrl(value?: contact_Website_pb.Website): void;
    hasUrl(): boolean;
    clearUrl(): void;

    getProviderCase(): SocialProfile.ProviderCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SocialProfile.AsObject;
    static toObject(includeInstance: boolean, msg: SocialProfile): SocialProfile.AsObject;
    static serializeBinaryToWriter(message: SocialProfile, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SocialProfile;
    static deserializeBinaryFromReader(message: SocialProfile, reader: jspb.BinaryReader): SocialProfile;
  }

  export namespace SocialProfile {
    export type AsObject = {
      known: SocialInfo.SocialProvider,
      custom: string,
      username: string,
      url?: contact_Website_pb.Website.AsObject,
    }

    export enum ProviderCase { 
      PROVIDER_NOT_SET = 0,
      KNOWN = 10,
      CUSTOM = 11,
    }
  }


  export enum SocialProvider { 
    UNSPECIFIED_SOCIAL_PROVIDER = 0,
    FACEBOOK = 1,
    TWITTER = 2,
    INSTAGRAM = 3,
    YOUTUBE = 4,
    LEAFLY = 5,
    WEEDMAPS = 6,
  }
}

