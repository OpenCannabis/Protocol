import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class EmailAddress extends jspb.Message {
  getAddress(): string;
  setAddress(value: string): void;

  getValidated(): boolean;
  setValidated(value: boolean): void;

  getName(): string;
  setName(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): EmailAddress.AsObject;
  static toObject(includeInstance: boolean, msg: EmailAddress): EmailAddress.AsObject;
  static serializeBinaryToWriter(message: EmailAddress, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): EmailAddress;
  static deserializeBinaryFromReader(message: EmailAddress, reader: jspb.BinaryReader): EmailAddress;
}

export namespace EmailAddress {
  export type AsObject = {
    address: string,
    validated: boolean,
    name: string,
  }
}

