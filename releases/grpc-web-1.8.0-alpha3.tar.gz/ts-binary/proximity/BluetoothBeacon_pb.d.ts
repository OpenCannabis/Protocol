import * as jspb from "google-protobuf"

import * as geo_Location_pb from '../geo/Location_pb';
import * as geo_Distance_pb from '../geo/Distance_pb';
import * as temporal_Instant_pb from '../temporal/Instant_pb';

export class BluetoothBeacon extends jspb.Message {
  getUuid(): string;
  setUuid(value: string): void;

  getMajor(): number;
  setMajor(value: number): void;

  getMinor(): number;
  setMinor(value: number): void;

  getSeen(): temporal_Instant_pb.Instant | undefined;
  setSeen(value?: temporal_Instant_pb.Instant): void;
  hasSeen(): boolean;
  clearSeen(): void;

  getLocation(): geo_Location_pb.Location | undefined;
  setLocation(value?: geo_Location_pb.Location): void;
  hasLocation(): boolean;
  clearLocation(): void;

  getAccuracy(): geo_Distance_pb.LocationAccuracy | undefined;
  setAccuracy(value?: geo_Distance_pb.LocationAccuracy): void;
  hasAccuracy(): boolean;
  clearAccuracy(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BluetoothBeacon.AsObject;
  static toObject(includeInstance: boolean, msg: BluetoothBeacon): BluetoothBeacon.AsObject;
  static serializeBinaryToWriter(message: BluetoothBeacon, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BluetoothBeacon;
  static deserializeBinaryFromReader(message: BluetoothBeacon, reader: jspb.BinaryReader): BluetoothBeacon;
}

export namespace BluetoothBeacon {
  export type AsObject = {
    uuid: string,
    major: number,
    minor: number,
    seen?: temporal_Instant_pb.Instant.AsObject,
    location?: geo_Location_pb.Location.AsObject,
    accuracy?: geo_Distance_pb.LocationAccuracy.AsObject,
  }
}

