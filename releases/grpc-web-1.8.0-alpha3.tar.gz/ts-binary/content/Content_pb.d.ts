import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as base_Language_pb from '../base/Language_pb';
import * as base_Compression_pb from '../base/Compression_pb';

export class Content extends jspb.Message {
  getType(): Content.Type;
  setType(value: Content.Type): void;

  getEncoding(): Encoding;
  setEncoding(value: Encoding): void;

  getLanguage(): base_Language_pb.Language;
  setLanguage(value: base_Language_pb.Language): void;

  getCompression(): base_Compression_pb.Compression | undefined;
  setCompression(value?: base_Compression_pb.Compression): void;
  hasCompression(): boolean;
  clearCompression(): void;

  getContent(): string;
  setContent(value: string): void;

  getRaw(): Uint8Array | string;
  getRaw_asU8(): Uint8Array;
  getRaw_asB64(): string;
  setRaw(value: Uint8Array | string): void;

  getPayloadCase(): Content.PayloadCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Content.AsObject;
  static toObject(includeInstance: boolean, msg: Content): Content.AsObject;
  static serializeBinaryToWriter(message: Content, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Content;
  static deserializeBinaryFromReader(message: Content, reader: jspb.BinaryReader): Content;
}

export namespace Content {
  export type AsObject = {
    type: Content.Type,
    encoding: Encoding,
    language: base_Language_pb.Language,
    compression?: base_Compression_pb.Compression.AsObject,
    content: string,
    raw: Uint8Array | string,
  }

  export enum Type { 
    TEXT = 0,
    MARKDOWN = 1,
    HTML = 2,
    BINARY = 3,
  }

  export enum PayloadCase { 
    PAYLOAD_NOT_SET = 0,
    CONTENT = 10,
    RAW = 20,
  }
}

export enum Encoding { 
  UTF8 = 0,
  B64 = 1,
  B64_ASCII = 2,
}
