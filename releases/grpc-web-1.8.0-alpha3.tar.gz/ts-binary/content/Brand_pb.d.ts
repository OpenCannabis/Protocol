import * as jspb from "google-protobuf"

import * as content_Colors_pb from '../content/Colors_pb';
import * as content_Name_pb from '../content/Name_pb';
import * as content_Content_pb from '../content/Content_pb';
import * as media_MediaKey_pb from '../media/MediaKey_pb';

export class RasterGraphic extends jspb.Message {
  getStandard(): media_MediaKey_pb.MediaReference | undefined;
  setStandard(value?: media_MediaKey_pb.MediaReference): void;
  hasStandard(): boolean;
  clearStandard(): void;

  getRetina(): media_MediaKey_pb.MediaReference | undefined;
  setRetina(value?: media_MediaKey_pb.MediaReference): void;
  hasRetina(): boolean;
  clearRetina(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RasterGraphic.AsObject;
  static toObject(includeInstance: boolean, msg: RasterGraphic): RasterGraphic.AsObject;
  static serializeBinaryToWriter(message: RasterGraphic, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RasterGraphic;
  static deserializeBinaryFromReader(message: RasterGraphic, reader: jspb.BinaryReader): RasterGraphic;
}

export namespace RasterGraphic {
  export type AsObject = {
    standard?: media_MediaKey_pb.MediaReference.AsObject,
    retina?: media_MediaKey_pb.MediaReference.AsObject,
  }
}

export class BrandAsset extends jspb.Message {
  getRaster(): RasterGraphic | undefined;
  setRaster(value?: RasterGraphic): void;
  hasRaster(): boolean;
  clearRaster(): void;

  getVector(): media_MediaKey_pb.MediaReference | undefined;
  setVector(value?: media_MediaKey_pb.MediaReference): void;
  hasVector(): boolean;
  clearVector(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BrandAsset.AsObject;
  static toObject(includeInstance: boolean, msg: BrandAsset): BrandAsset.AsObject;
  static serializeBinaryToWriter(message: BrandAsset, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BrandAsset;
  static deserializeBinaryFromReader(message: BrandAsset, reader: jspb.BinaryReader): BrandAsset;
}

export namespace BrandAsset {
  export type AsObject = {
    raster?: RasterGraphic.AsObject,
    vector?: media_MediaKey_pb.MediaReference.AsObject,
  }
}

export class Brand extends jspb.Message {
  getName(): content_Name_pb.Name | undefined;
  setName(value?: content_Name_pb.Name): void;
  hasName(): boolean;
  clearName(): void;

  getParent(): Brand | undefined;
  setParent(value?: Brand): void;
  hasParent(): boolean;
  clearParent(): void;

  getSummary(): content_Content_pb.Content | undefined;
  setSummary(value?: content_Content_pb.Content): void;
  hasSummary(): boolean;
  clearSummary(): void;

  getMediaList(): Array<BrandAsset>;
  setMediaList(value: Array<BrandAsset>): void;
  clearMediaList(): void;
  addMedia(value?: BrandAsset, index?: number): BrandAsset;

  getTheme(): content_Colors_pb.ColorScheme | undefined;
  setTheme(value?: content_Colors_pb.ColorScheme): void;
  hasTheme(): boolean;
  clearTheme(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Brand.AsObject;
  static toObject(includeInstance: boolean, msg: Brand): Brand.AsObject;
  static serializeBinaryToWriter(message: Brand, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Brand;
  static deserializeBinaryFromReader(message: Brand, reader: jspb.BinaryReader): Brand;
}

export namespace Brand {
  export type AsObject = {
    name?: content_Name_pb.Name.AsObject,
    parent?: Brand.AsObject,
    summary?: content_Content_pb.Content.AsObject,
    mediaList: Array<BrandAsset.AsObject>,
    theme?: content_Colors_pb.ColorScheme.AsObject,
  }
}

