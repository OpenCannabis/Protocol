import * as jspb from "google-protobuf"

export class Name extends jspb.Message {
  getPrimary(): string;
  setPrimary(value: string): void;

  getDisplay(): string;
  setDisplay(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Name.AsObject;
  static toObject(includeInstance: boolean, msg: Name): Name.AsObject;
  static serializeBinaryToWriter(message: Name, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Name;
  static deserializeBinaryFromReader(message: Name, reader: jspb.BinaryReader): Name;
}

export namespace Name {
  export type AsObject = {
    primary: string,
    display: string,
  }
}

