import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as commerce_Item_pb from '../commerce/Item_pb';
import * as commerce_Delivery_pb from '../commerce/Delivery_pb';
import * as commerce_Customer_pb from '../commerce/Customer_pb';
import * as commerce_payments_Payment_pb from '../commerce/payments/Payment_pb';
import * as temporal_Instant_pb from '../temporal/Instant_pb';

export class OrderScheduling extends jspb.Message {
  getScheduling(): SchedulingType;
  setScheduling(value: SchedulingType): void;

  getDesiredTime(): temporal_Instant_pb.Instant | undefined;
  setDesiredTime(value?: temporal_Instant_pb.Instant): void;
  hasDesiredTime(): boolean;
  clearDesiredTime(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OrderScheduling.AsObject;
  static toObject(includeInstance: boolean, msg: OrderScheduling): OrderScheduling.AsObject;
  static serializeBinaryToWriter(message: OrderScheduling, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OrderScheduling;
  static deserializeBinaryFromReader(message: OrderScheduling, reader: jspb.BinaryReader): OrderScheduling;
}

export namespace OrderScheduling {
  export type AsObject = {
    scheduling: SchedulingType,
    desiredTime?: temporal_Instant_pb.Instant.AsObject,
  }
}

export class OrderPayment extends jspb.Message {
  getStatus(): commerce_payments_Payment_pb.PaymentStatus;
  setStatus(value: commerce_payments_Payment_pb.PaymentStatus): void;

  getMethod(): commerce_payments_Payment_pb.PaymentMethod;
  setMethod(value: commerce_payments_Payment_pb.PaymentMethod): void;

  getTax(): number;
  setTax(value: number): void;

  getPaid(): number;
  setPaid(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OrderPayment.AsObject;
  static toObject(includeInstance: boolean, msg: OrderPayment): OrderPayment.AsObject;
  static serializeBinaryToWriter(message: OrderPayment, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OrderPayment;
  static deserializeBinaryFromReader(message: OrderPayment, reader: jspb.BinaryReader): OrderPayment;
}

export namespace OrderPayment {
  export type AsObject = {
    status: commerce_payments_Payment_pb.PaymentStatus,
    method: commerce_payments_Payment_pb.PaymentMethod,
    tax: number,
    paid: number,
  }
}

export class StatusCheckin extends jspb.Message {
  getStatus(): OrderStatus;
  setStatus(value: OrderStatus): void;

  getInstant(): temporal_Instant_pb.Instant | undefined;
  setInstant(value?: temporal_Instant_pb.Instant): void;
  hasInstant(): boolean;
  clearInstant(): void;

  getMessage(): string;
  setMessage(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StatusCheckin.AsObject;
  static toObject(includeInstance: boolean, msg: StatusCheckin): StatusCheckin.AsObject;
  static serializeBinaryToWriter(message: StatusCheckin, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StatusCheckin;
  static deserializeBinaryFromReader(message: StatusCheckin, reader: jspb.BinaryReader): StatusCheckin;
}

export namespace StatusCheckin {
  export type AsObject = {
    status: OrderStatus,
    instant?: temporal_Instant_pb.Instant.AsObject,
    message: string,
  }
}

export class OrderKey extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OrderKey.AsObject;
  static toObject(includeInstance: boolean, msg: OrderKey): OrderKey.AsObject;
  static serializeBinaryToWriter(message: OrderKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OrderKey;
  static deserializeBinaryFromReader(message: OrderKey, reader: jspb.BinaryReader): OrderKey;
}

export namespace OrderKey {
  export type AsObject = {
    id: string,
  }
}

export class Order extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getType(): OrderType;
  setType(value: OrderType): void;

  getStatus(): OrderStatus;
  setStatus(value: OrderStatus): void;

  getCustomer(): commerce_Customer_pb.Customer | undefined;
  setCustomer(value?: commerce_Customer_pb.Customer): void;
  hasCustomer(): boolean;
  clearCustomer(): void;

  getScheduling(): OrderScheduling | undefined;
  setScheduling(value?: OrderScheduling): void;
  hasScheduling(): boolean;
  clearScheduling(): void;

  getDestination(): commerce_Delivery_pb.DeliveryDestination | undefined;
  setDestination(value?: commerce_Delivery_pb.DeliveryDestination): void;
  hasDestination(): boolean;
  clearDestination(): void;

  getNotes(): string;
  setNotes(value: string): void;

  getItemList(): Array<commerce_Item_pb.Item>;
  setItemList(value: Array<commerce_Item_pb.Item>): void;
  clearItemList(): void;
  addItem(value?: commerce_Item_pb.Item, index?: number): commerce_Item_pb.Item;

  getActionLogList(): Array<StatusCheckin>;
  setActionLogList(value: Array<StatusCheckin>): void;
  clearActionLogList(): void;
  addActionLog(value?: StatusCheckin, index?: number): StatusCheckin;

  getCreatedAt(): temporal_Instant_pb.Instant | undefined;
  setCreatedAt(value?: temporal_Instant_pb.Instant): void;
  hasCreatedAt(): boolean;
  clearCreatedAt(): void;

  getSubtotal(): number;
  setSubtotal(value: number): void;

  getUpdatedAt(): temporal_Instant_pb.Instant | undefined;
  setUpdatedAt(value?: temporal_Instant_pb.Instant): void;
  hasUpdatedAt(): boolean;
  clearUpdatedAt(): void;

  getSid(): string;
  setSid(value: string): void;

  getPayment(): OrderPayment | undefined;
  setPayment(value?: OrderPayment): void;
  hasPayment(): boolean;
  clearPayment(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Order.AsObject;
  static toObject(includeInstance: boolean, msg: Order): Order.AsObject;
  static serializeBinaryToWriter(message: Order, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Order;
  static deserializeBinaryFromReader(message: Order, reader: jspb.BinaryReader): Order;
}

export namespace Order {
  export type AsObject = {
    id: string,
    type: OrderType,
    status: OrderStatus,
    customer?: commerce_Customer_pb.Customer.AsObject,
    scheduling?: OrderScheduling.AsObject,
    destination?: commerce_Delivery_pb.DeliveryDestination.AsObject,
    notes: string,
    itemList: Array<commerce_Item_pb.Item.AsObject>,
    actionLogList: Array<StatusCheckin.AsObject>,
    createdAt?: temporal_Instant_pb.Instant.AsObject,
    subtotal: number,
    updatedAt?: temporal_Instant_pb.Instant.AsObject,
    sid: string,
    payment?: OrderPayment.AsObject,
  }
}

export enum OrderType { 
  PICKUP = 0,
  DELIVERY = 1,
  ONSITE = 2,
}
export enum SchedulingType { 
  ASAP = 0,
  TIMED = 1,
}
export enum OrderStatus { 
  PENDING = 0,
  APPROVED = 1,
  REJECTED = 2,
  ASSIGNED = 3,
  EN_ROUTE = 4,
  FULFILLED = 5,
}
