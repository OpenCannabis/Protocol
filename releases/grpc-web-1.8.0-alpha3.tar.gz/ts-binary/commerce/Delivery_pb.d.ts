import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as geo_Address_pb from '../geo/Address_pb';

export class DeliveryDestination extends jspb.Message {
  getAddress(): geo_Address_pb.Address | undefined;
  setAddress(value?: geo_Address_pb.Address): void;
  hasAddress(): boolean;
  clearAddress(): void;

  getInstructions(): string;
  setInstructions(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeliveryDestination.AsObject;
  static toObject(includeInstance: boolean, msg: DeliveryDestination): DeliveryDestination.AsObject;
  static serializeBinaryToWriter(message: DeliveryDestination, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeliveryDestination;
  static deserializeBinaryFromReader(message: DeliveryDestination, reader: jspb.BinaryReader): DeliveryDestination;
}

export namespace DeliveryDestination {
  export type AsObject = {
    address?: geo_Address_pb.Address.AsObject,
    instructions: string,
  }
}

