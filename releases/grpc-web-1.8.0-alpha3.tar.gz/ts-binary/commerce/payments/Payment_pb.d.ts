import * as jspb from "google-protobuf"

export enum PaymentMethod { 
  CASH = 0,
  CHECK = 1,
  DEBIT = 2,
  CREDIT = 3,
  DIGITAL = 4,
  ACH = 5,
  WIRE = 6,
  BLOCKCHAIN = 7,
}
export enum PaymentCardType { 
  NO_CARD_TYPE = 0,
  VISA = 1,
  MASTERCARD = 2,
  DISCOVER = 3,
  AMEX = 4,
  DINERS_CLUB = 5,
  MAESTRO = 6,
}
export enum DigitalPaymentNetwork { 
  UNSPECIFIED_NETWORK = 0,
  PAYPAL = 1,
  VENMO = 2,
  SQUARE = 3,
}
export enum PaymentStatus { 
  NOT_APPLICABLE = 0,
  WAITING = 1,
  PREAUTHORIZED = 2,
  BOUNCED = 3,
  RETRIED = 4,
}
export enum BillStatus { 
  SUSPENSE = 0,
  PARTIAL = 3,
  SETTLED = 4,
}
