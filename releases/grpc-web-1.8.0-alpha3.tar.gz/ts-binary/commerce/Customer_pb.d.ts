import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';
import * as person_Person_pb from '../person/Person_pb';

export class Customer extends jspb.Message {
  getPerson(): person_Person_pb.Person | undefined;
  setPerson(value?: person_Person_pb.Person): void;
  hasPerson(): boolean;
  clearPerson(): void;

  getForeignId(): string;
  setForeignId(value: string): void;

  getUserKey(): string;
  setUserKey(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Customer.AsObject;
  static toObject(includeInstance: boolean, msg: Customer): Customer.AsObject;
  static serializeBinaryToWriter(message: Customer, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Customer;
  static deserializeBinaryFromReader(message: Customer, reader: jspb.BinaryReader): Customer;
}

export namespace Customer {
  export type AsObject = {
    person?: person_Person_pb.Person.AsObject,
    foreignId: string,
    userKey: string,
  }
}

