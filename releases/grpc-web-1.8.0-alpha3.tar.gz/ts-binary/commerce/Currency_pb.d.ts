import * as jspb from "google-protobuf"

export class CurrencyValue extends jspb.Message {
  getValue(): number;
  setValue(value: number): void;

  getType(): CurrencyType;
  setType(value: CurrencyType): void;

  getFiat(): FiatCurrency;
  setFiat(value: FiatCurrency): void;

  getCustom(): string;
  setCustom(value: string): void;

  getSpecCase(): CurrencyValue.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CurrencyValue.AsObject;
  static toObject(includeInstance: boolean, msg: CurrencyValue): CurrencyValue.AsObject;
  static serializeBinaryToWriter(message: CurrencyValue, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CurrencyValue;
  static deserializeBinaryFromReader(message: CurrencyValue, reader: jspb.BinaryReader): CurrencyValue;
}

export namespace CurrencyValue {
  export type AsObject = {
    value: number,
    type: CurrencyType,
    fiat: FiatCurrency,
    custom: string,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    FIAT = 10,
    CUSTOM = 100,
  }
}

export enum CurrencyType { 
  FIAT = 0,
  REAL = 1,
  CRYPTO = 2,
}
export enum FiatCurrency { 
  USD = 0,
  CAD = 1,
  EUR = 2,
}
