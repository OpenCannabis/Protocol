import * as jspb from "google-protobuf"

import * as geo_Province_pb from '../geo/Province_pb';
import * as geo_Country_pb from '../geo/Country_pb';

export class LocalTax extends jspb.Message {
  getMunicipality(): string;
  setMunicipality(value: string): void;

  getProvince(): geo_Province_pb.Province | undefined;
  setProvince(value?: geo_Province_pb.Province): void;
  hasProvince(): boolean;
  clearProvince(): void;

  getCountry(): geo_Country_pb.Country | undefined;
  setCountry(value?: geo_Country_pb.Country): void;
  hasCountry(): boolean;
  clearCountry(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LocalTax.AsObject;
  static toObject(includeInstance: boolean, msg: LocalTax): LocalTax.AsObject;
  static serializeBinaryToWriter(message: LocalTax, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LocalTax;
  static deserializeBinaryFromReader(message: LocalTax, reader: jspb.BinaryReader): LocalTax;
}

export namespace LocalTax {
  export type AsObject = {
    municipality: string,
    province?: geo_Province_pb.Province.AsObject,
    country?: geo_Country_pb.Country.AsObject,
  }
}

export class ProvincialTax extends jspb.Message {
  getProvince(): geo_Province_pb.Province | undefined;
  setProvince(value?: geo_Province_pb.Province): void;
  hasProvince(): boolean;
  clearProvince(): void;

  getCountry(): geo_Country_pb.Country | undefined;
  setCountry(value?: geo_Country_pb.Country): void;
  hasCountry(): boolean;
  clearCountry(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ProvincialTax.AsObject;
  static toObject(includeInstance: boolean, msg: ProvincialTax): ProvincialTax.AsObject;
  static serializeBinaryToWriter(message: ProvincialTax, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ProvincialTax;
  static deserializeBinaryFromReader(message: ProvincialTax, reader: jspb.BinaryReader): ProvincialTax;
}

export namespace ProvincialTax {
  export type AsObject = {
    province?: geo_Province_pb.Province.AsObject,
    country?: geo_Country_pb.Country.AsObject,
  }
}

export class FederalTax extends jspb.Message {
  getCountry(): geo_Country_pb.Country | undefined;
  setCountry(value?: geo_Country_pb.Country): void;
  hasCountry(): boolean;
  clearCountry(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FederalTax.AsObject;
  static toObject(includeInstance: boolean, msg: FederalTax): FederalTax.AsObject;
  static serializeBinaryToWriter(message: FederalTax, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FederalTax;
  static deserializeBinaryFromReader(message: FederalTax, reader: jspb.BinaryReader): FederalTax;
}

export namespace FederalTax {
  export type AsObject = {
    country?: geo_Country_pb.Country.AsObject,
  }
}

export class TaxJurisdiction extends jspb.Message {
  getMode(): TaxJurisdictionMode;
  setMode(value: TaxJurisdictionMode): void;

  getLocal(): LocalTax | undefined;
  setLocal(value?: LocalTax): void;
  hasLocal(): boolean;
  clearLocal(): void;

  getProvincial(): ProvincialTax | undefined;
  setProvincial(value?: ProvincialTax): void;
  hasProvincial(): boolean;
  clearProvincial(): void;

  getFederal(): FederalTax | undefined;
  setFederal(value?: FederalTax): void;
  hasFederal(): boolean;
  clearFederal(): void;

  getJurisdictionCase(): TaxJurisdiction.JurisdictionCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TaxJurisdiction.AsObject;
  static toObject(includeInstance: boolean, msg: TaxJurisdiction): TaxJurisdiction.AsObject;
  static serializeBinaryToWriter(message: TaxJurisdiction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TaxJurisdiction;
  static deserializeBinaryFromReader(message: TaxJurisdiction, reader: jspb.BinaryReader): TaxJurisdiction;
}

export namespace TaxJurisdiction {
  export type AsObject = {
    mode: TaxJurisdictionMode,
    local?: LocalTax.AsObject,
    provincial?: ProvincialTax.AsObject,
    federal?: FederalTax.AsObject,
  }

  export enum JurisdictionCase { 
    JURISDICTION_NOT_SET = 0,
    LOCAL = 2,
    PROVINCIAL = 3,
    FEDERAL = 4,
  }
}

export class TaxSpec extends jspb.Message {
  getBasis(): TaxBasis;
  setBasis(value: TaxBasis): void;

  getJurisdiction(): TaxJurisdiction | undefined;
  setJurisdiction(value?: TaxJurisdiction): void;
  hasJurisdiction(): boolean;
  clearJurisdiction(): void;

  getTransactionLabel(): string;
  setTransactionLabel(value: string): void;

  getPercentage(): number;
  setPercentage(value: number): void;

  getStaticValue(): number;
  setStaticValue(value: number): void;

  getRateCase(): TaxSpec.RateCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TaxSpec.AsObject;
  static toObject(includeInstance: boolean, msg: TaxSpec): TaxSpec.AsObject;
  static serializeBinaryToWriter(message: TaxSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TaxSpec;
  static deserializeBinaryFromReader(message: TaxSpec, reader: jspb.BinaryReader): TaxSpec;
}

export namespace TaxSpec {
  export type AsObject = {
    basis: TaxBasis,
    jurisdiction?: TaxJurisdiction.AsObject,
    transactionLabel: string,
    percentage: number,
    staticValue: number,
  }

  export enum RateCase { 
    RATE_NOT_SET = 0,
    PERCENTAGE = 4,
    STATIC_VALUE = 5,
  }
}

export class Tax extends jspb.Message {
  getId(): string;
  setId(value: string): void;

  getSpec(): TaxSpec | undefined;
  setSpec(value?: TaxSpec): void;
  hasSpec(): boolean;
  clearSpec(): void;

  getName(): string;
  setName(value: string): void;

  getLabel(): string;
  setLabel(value: string): void;

  getDescription(): string;
  setDescription(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Tax.AsObject;
  static toObject(includeInstance: boolean, msg: Tax): Tax.AsObject;
  static serializeBinaryToWriter(message: Tax, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Tax;
  static deserializeBinaryFromReader(message: Tax, reader: jspb.BinaryReader): Tax;
}

export namespace Tax {
  export type AsObject = {
    id: string,
    spec?: TaxSpec.AsObject,
    name: string,
    label: string,
    description: string,
  }
}

export enum TaxJurisdictionMode { 
  LOCAL = 0,
  PROVINCE = 1,
  FEDERAL = 2,
}
export enum TaxBasis { 
  ITEM = 0,
  ORDER_SUBTOTAL = 1,
  ORDER_TOTAL = 2,
}
