import * as jspb from "google-protobuf"

import * as temporal_Instant_pb from '../../temporal/Instant_pb';

export class PercentageDiscount extends jspb.Message {
  getDiscount(): number;
  setDiscount(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PercentageDiscount.AsObject;
  static toObject(includeInstance: boolean, msg: PercentageDiscount): PercentageDiscount.AsObject;
  static serializeBinaryToWriter(message: PercentageDiscount, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PercentageDiscount;
  static deserializeBinaryFromReader(message: PercentageDiscount, reader: jspb.BinaryReader): PercentageDiscount;
}

export namespace PercentageDiscount {
  export type AsObject = {
    discount: number,
  }
}

export class BOGODiscount extends jspb.Message {
  getTrigger(): number;
  setTrigger(value: number): void;

  getReward(): number;
  setReward(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BOGODiscount.AsObject;
  static toObject(includeInstance: boolean, msg: BOGODiscount): BOGODiscount.AsObject;
  static serializeBinaryToWriter(message: BOGODiscount, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BOGODiscount;
  static deserializeBinaryFromReader(message: BOGODiscount, reader: jspb.BinaryReader): BOGODiscount;
}

export namespace BOGODiscount {
  export type AsObject = {
    trigger: number,
    reward: number,
  }
}

export class LoyaltyDiscount extends jspb.Message {
  getTrigger(): number;
  setTrigger(value: number): void;

  getReward(): number;
  setReward(value: number): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LoyaltyDiscount.AsObject;
  static toObject(includeInstance: boolean, msg: LoyaltyDiscount): LoyaltyDiscount.AsObject;
  static serializeBinaryToWriter(message: LoyaltyDiscount, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LoyaltyDiscount;
  static deserializeBinaryFromReader(message: LoyaltyDiscount, reader: jspb.BinaryReader): LoyaltyDiscount;
}

export namespace LoyaltyDiscount {
  export type AsObject = {
    trigger: number,
    reward: number,
  }
}

export class SaleDescriptor extends jspb.Message {
  getType(): SaleType;
  setType(value: SaleType): void;

  getEffective(): temporal_Instant_pb.Instant | undefined;
  setEffective(value?: temporal_Instant_pb.Instant): void;
  hasEffective(): boolean;
  clearEffective(): void;

  getExpiration(): temporal_Instant_pb.Instant | undefined;
  setExpiration(value?: temporal_Instant_pb.Instant): void;
  hasExpiration(): boolean;
  clearExpiration(): void;

  getPercentageOff(): PercentageDiscount | undefined;
  setPercentageOff(value?: PercentageDiscount): void;
  hasPercentageOff(): boolean;
  clearPercentageOff(): void;

  getBogo(): BOGODiscount | undefined;
  setBogo(value?: BOGODiscount): void;
  hasBogo(): boolean;
  clearBogo(): void;

  getLoyalty(): LoyaltyDiscount | undefined;
  setLoyalty(value?: LoyaltyDiscount): void;
  hasLoyalty(): boolean;
  clearLoyalty(): void;

  getSaleCase(): SaleDescriptor.SaleCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SaleDescriptor.AsObject;
  static toObject(includeInstance: boolean, msg: SaleDescriptor): SaleDescriptor.AsObject;
  static serializeBinaryToWriter(message: SaleDescriptor, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SaleDescriptor;
  static deserializeBinaryFromReader(message: SaleDescriptor, reader: jspb.BinaryReader): SaleDescriptor;
}

export namespace SaleDescriptor {
  export type AsObject = {
    type: SaleType,
    effective?: temporal_Instant_pb.Instant.AsObject,
    expiration?: temporal_Instant_pb.Instant.AsObject,
    percentageOff?: PercentageDiscount.AsObject,
    bogo?: BOGODiscount.AsObject,
    loyalty?: LoyaltyDiscount.AsObject,
  }

  export enum SaleCase { 
    SALE_NOT_SET = 0,
    PERCENTAGE_OFF = 4,
    BOGO = 5,
    LOYALTY = 6,
  }
}

export enum SaleType { 
  PERCENTAGE_REDUCTION = 0,
  VALUE_REDUCTION = 1,
  BOGO = 2,
  LOYALTY = 3,
}
