import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class VersionSpec extends jspb.Message {
  getName(): string;
  setName(value: string): void;

  getSpecCase(): VersionSpec.SpecCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VersionSpec.AsObject;
  static toObject(includeInstance: boolean, msg: VersionSpec): VersionSpec.AsObject;
  static serializeBinaryToWriter(message: VersionSpec, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VersionSpec;
  static deserializeBinaryFromReader(message: VersionSpec, reader: jspb.BinaryReader): VersionSpec;
}

export namespace VersionSpec {
  export type AsObject = {
    name: string,
  }

  export enum SpecCase { 
    SPEC_NOT_SET = 0,
    NAME = 1,
  }
}

