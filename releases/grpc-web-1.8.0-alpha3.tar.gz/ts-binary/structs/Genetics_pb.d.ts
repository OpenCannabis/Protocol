import * as jspb from "google-protobuf"

import * as base_ProductKey_pb from '../base/ProductKey_pb';

export class Genetics extends jspb.Message {
  getMale(): base_ProductKey_pb.ProductReference | undefined;
  setMale(value?: base_ProductKey_pb.ProductReference): void;
  hasMale(): boolean;
  clearMale(): void;

  getFemale(): base_ProductKey_pb.ProductReference | undefined;
  setFemale(value?: base_ProductKey_pb.ProductReference): void;
  hasFemale(): boolean;
  clearFemale(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Genetics.AsObject;
  static toObject(includeInstance: boolean, msg: Genetics): Genetics.AsObject;
  static serializeBinaryToWriter(message: Genetics, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Genetics;
  static deserializeBinaryFromReader(message: Genetics, reader: jspb.BinaryReader): Genetics;
}

export namespace Genetics {
  export type AsObject = {
    male?: base_ProductKey_pb.ProductReference.AsObject,
    female?: base_ProductKey_pb.ProductReference.AsObject,
  }
}

