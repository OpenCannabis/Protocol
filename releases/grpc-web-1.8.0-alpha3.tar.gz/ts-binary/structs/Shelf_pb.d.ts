import * as jspb from "google-protobuf"

export enum Shelf { 
  GENERIC_SHELF = 0,
  ECONOMY = 1,
  MIDSHELF = 2,
  TOPSHELF = 3,
}
