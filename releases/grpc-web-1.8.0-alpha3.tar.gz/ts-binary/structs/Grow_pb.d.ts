import * as jspb from "google-protobuf"

export enum Grow { 
  GENERIC = 0,
  INDOOR = 1,
  GREENHOUSE = 2,
  OUTDOOR = 3,
}
