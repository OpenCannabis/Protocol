import * as jspb from "google-protobuf"

export enum Cannabinoid { 
  THC = 0,
  THC_A = 1,
  THC_V = 2,
  THC_VA = 3,
  THC_8 = 4,
  THC_9 = 5,
  CBD = 10,
  CBD_A = 11,
  CBD_V = 12,
  CBD_VA = 13,
  CBC = 20,
  CBC_A = 21,
  CBG = 30,
  CBG_A = 31,
  CBN = 40,
  CBN_A = 41,
  CBV = 50,
  CBV_A = 51,
  TAC = 60,
  CBL = 70,
  CBL_A = 71,
}
export enum CannabinoidRatio { 
  NO_CANNABINOID_PREFERENCE = 0,
  THC_ONLY = 1,
  THC_OVER_CBD = 2,
  EQUAL = 3,
  CBD_OVER_THC = 4,
  CBD_ONLY = 5,
}
