import * as jspb from "google-protobuf"

import * as media_MediaItem_pb from '../../media/MediaItem_pb';

export class TestValue extends jspb.Message {
  getType(): TestValueType;
  setType(value: TestValueType): void;

  getError(): TestValue.TestError | undefined;
  setError(value?: TestValue.TestError): void;
  hasError(): boolean;
  clearError(): void;

  getMeasurement(): number;
  setMeasurement(value: number): void;

  getPresent(): boolean;
  setPresent(value: boolean): void;

  getValueCase(): TestValue.ValueCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TestValue.AsObject;
  static toObject(includeInstance: boolean, msg: TestValue): TestValue.AsObject;
  static serializeBinaryToWriter(message: TestValue, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TestValue;
  static deserializeBinaryFromReader(message: TestValue, reader: jspb.BinaryReader): TestValue;
}

export namespace TestValue {
  export type AsObject = {
    type: TestValueType,
    error?: TestValue.TestError.AsObject,
    measurement: number,
    present: boolean,
  }

  export class TestError extends jspb.Message {
    getType(): TestErrorType;
    setType(value: TestErrorType): void;

    getValue(): number;
    setValue(value: number): void;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): TestError.AsObject;
    static toObject(includeInstance: boolean, msg: TestError): TestError.AsObject;
    static serializeBinaryToWriter(message: TestError, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): TestError;
    static deserializeBinaryFromReader(message: TestError, reader: jspb.BinaryReader): TestError;
  }

  export namespace TestError {
    export type AsObject = {
      type: TestErrorType,
      value: number,
    }
  }


  export enum ValueCase { 
    VALUE_NOT_SET = 0,
    MEASUREMENT = 10,
    PRESENT = 20,
  }
}

export class TestMedia extends jspb.Message {
  getType(): TestMediaType;
  setType(value: TestMediaType): void;

  getMediaItem(): media_MediaItem_pb.MediaItem | undefined;
  setMediaItem(value?: media_MediaItem_pb.MediaItem): void;
  hasMediaItem(): boolean;
  clearMediaItem(): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): TestMedia.AsObject;
  static toObject(includeInstance: boolean, msg: TestMedia): TestMedia.AsObject;
  static serializeBinaryToWriter(message: TestMedia, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): TestMedia;
  static deserializeBinaryFromReader(message: TestMedia, reader: jspb.BinaryReader): TestMedia;
}

export namespace TestMedia {
  export type AsObject = {
    type: TestMediaType,
    mediaItem?: media_MediaItem_pb.MediaItem.AsObject,
  }
}

export enum TestValueType { 
  MILLIGRAMS = 0,
  PERCENTAGE = 1,
  PRESENCE = 2,
  MILLIGRAMS_PER_GRAM = 3,
}
export enum TestErrorType { 
  PERCENT = 0,
  ABSOLUTE = 1,
  RELATIVE = 2,
}
export enum TestMediaType { 
  CERTIFICATE = 0,
  RESULTS = 1,
  PRODUCT_IMAGE = 2,
}
