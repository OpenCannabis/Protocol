import * as jspb from "google-protobuf"

import * as core_Datamodel_pb from '../core/Datamodel_pb';

export class UserKey extends jspb.Message {
  getUid(): string;
  setUid(value: string): void;

  getIdentity(): string;
  setIdentity(value: string): void;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UserKey.AsObject;
  static toObject(includeInstance: boolean, msg: UserKey): UserKey.AsObject;
  static serializeBinaryToWriter(message: UserKey, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UserKey;
  static deserializeBinaryFromReader(message: UserKey, reader: jspb.BinaryReader): UserKey;
}

export namespace UserKey {
  export type AsObject = {
    uid: string,
    identity: string,
  }
}

