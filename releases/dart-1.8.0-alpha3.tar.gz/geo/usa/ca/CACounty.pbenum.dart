///
//  Generated code. Do not modify.
//  source: geo/usa/ca/CACounty.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class CaliforniaCounty extends $pb.ProtobufEnum {
  static const CaliforniaCounty UNKNOWN_COUNTY = CaliforniaCounty._(0, 'UNKNOWN_COUNTY');
  static const CaliforniaCounty ALAMEDA = CaliforniaCounty._(1, 'ALAMEDA');
  static const CaliforniaCounty ALPINE = CaliforniaCounty._(2, 'ALPINE');
  static const CaliforniaCounty AMADOR = CaliforniaCounty._(3, 'AMADOR');
  static const CaliforniaCounty BUTTE = CaliforniaCounty._(4, 'BUTTE');
  static const CaliforniaCounty CALAVERAS = CaliforniaCounty._(5, 'CALAVERAS');
  static const CaliforniaCounty COLUSA = CaliforniaCounty._(6, 'COLUSA');
  static const CaliforniaCounty CONTRA_COSTA = CaliforniaCounty._(7, 'CONTRA_COSTA');
  static const CaliforniaCounty DEL_NORTE = CaliforniaCounty._(8, 'DEL_NORTE');
  static const CaliforniaCounty EL_DORADO = CaliforniaCounty._(9, 'EL_DORADO');
  static const CaliforniaCounty FRESNO = CaliforniaCounty._(10, 'FRESNO');
  static const CaliforniaCounty GLENN = CaliforniaCounty._(11, 'GLENN');
  static const CaliforniaCounty HUMBOLDT = CaliforniaCounty._(12, 'HUMBOLDT');
  static const CaliforniaCounty IMERIAL = CaliforniaCounty._(13, 'IMERIAL');
  static const CaliforniaCounty INYO = CaliforniaCounty._(14, 'INYO');
  static const CaliforniaCounty KERN = CaliforniaCounty._(15, 'KERN');
  static const CaliforniaCounty KINGS = CaliforniaCounty._(16, 'KINGS');
  static const CaliforniaCounty LAKE = CaliforniaCounty._(17, 'LAKE');
  static const CaliforniaCounty LASSEN = CaliforniaCounty._(18, 'LASSEN');
  static const CaliforniaCounty LOS_ANGELES = CaliforniaCounty._(19, 'LOS_ANGELES');
  static const CaliforniaCounty MADERA = CaliforniaCounty._(20, 'MADERA');
  static const CaliforniaCounty MARIN = CaliforniaCounty._(21, 'MARIN');
  static const CaliforniaCounty MARIPOSA = CaliforniaCounty._(22, 'MARIPOSA');
  static const CaliforniaCounty MENDOCINO = CaliforniaCounty._(23, 'MENDOCINO');
  static const CaliforniaCounty MERCED = CaliforniaCounty._(24, 'MERCED');
  static const CaliforniaCounty MODOC = CaliforniaCounty._(25, 'MODOC');
  static const CaliforniaCounty MONO = CaliforniaCounty._(26, 'MONO');
  static const CaliforniaCounty MONTEREY = CaliforniaCounty._(27, 'MONTEREY');
  static const CaliforniaCounty NAPA = CaliforniaCounty._(28, 'NAPA');
  static const CaliforniaCounty ORANGE = CaliforniaCounty._(29, 'ORANGE');
  static const CaliforniaCounty PLACER = CaliforniaCounty._(30, 'PLACER');
  static const CaliforniaCounty PLUMAS = CaliforniaCounty._(31, 'PLUMAS');
  static const CaliforniaCounty RIVERSIDE = CaliforniaCounty._(32, 'RIVERSIDE');
  static const CaliforniaCounty SACRAMENTO = CaliforniaCounty._(33, 'SACRAMENTO');
  static const CaliforniaCounty SAN_BENITO = CaliforniaCounty._(34, 'SAN_BENITO');
  static const CaliforniaCounty SAN_BERNADINO = CaliforniaCounty._(35, 'SAN_BERNADINO');
  static const CaliforniaCounty SAN_DIEGO = CaliforniaCounty._(36, 'SAN_DIEGO');
  static const CaliforniaCounty SAN_FRANCISCO = CaliforniaCounty._(37, 'SAN_FRANCISCO');
  static const CaliforniaCounty SAN_JOAQUIN = CaliforniaCounty._(38, 'SAN_JOAQUIN');
  static const CaliforniaCounty SAN_LUIS_OBISPO = CaliforniaCounty._(39, 'SAN_LUIS_OBISPO');
  static const CaliforniaCounty SAN_MATEO = CaliforniaCounty._(40, 'SAN_MATEO');
  static const CaliforniaCounty SANTA_CLARA = CaliforniaCounty._(41, 'SANTA_CLARA');
  static const CaliforniaCounty SANTA_CRUZ = CaliforniaCounty._(42, 'SANTA_CRUZ');
  static const CaliforniaCounty SHASTA = CaliforniaCounty._(43, 'SHASTA');
  static const CaliforniaCounty SIERRA = CaliforniaCounty._(44, 'SIERRA');
  static const CaliforniaCounty SISKIYOU = CaliforniaCounty._(45, 'SISKIYOU');
  static const CaliforniaCounty SONOMA = CaliforniaCounty._(46, 'SONOMA');
  static const CaliforniaCounty STANISLAUS = CaliforniaCounty._(47, 'STANISLAUS');
  static const CaliforniaCounty SUTTER = CaliforniaCounty._(48, 'SUTTER');
  static const CaliforniaCounty TRINITY = CaliforniaCounty._(49, 'TRINITY');
  static const CaliforniaCounty TULARE = CaliforniaCounty._(50, 'TULARE');
  static const CaliforniaCounty TUOLOMNE = CaliforniaCounty._(51, 'TUOLOMNE');
  static const CaliforniaCounty VENTURA = CaliforniaCounty._(52, 'VENTURA');
  static const CaliforniaCounty YOLO = CaliforniaCounty._(53, 'YOLO');
  static const CaliforniaCounty YUBA = CaliforniaCounty._(54, 'YUBA');

  static const $core.List<CaliforniaCounty> values = <CaliforniaCounty> [
    UNKNOWN_COUNTY,
    ALAMEDA,
    ALPINE,
    AMADOR,
    BUTTE,
    CALAVERAS,
    COLUSA,
    CONTRA_COSTA,
    DEL_NORTE,
    EL_DORADO,
    FRESNO,
    GLENN,
    HUMBOLDT,
    IMERIAL,
    INYO,
    KERN,
    KINGS,
    LAKE,
    LASSEN,
    LOS_ANGELES,
    MADERA,
    MARIN,
    MARIPOSA,
    MENDOCINO,
    MERCED,
    MODOC,
    MONO,
    MONTEREY,
    NAPA,
    ORANGE,
    PLACER,
    PLUMAS,
    RIVERSIDE,
    SACRAMENTO,
    SAN_BENITO,
    SAN_BERNADINO,
    SAN_DIEGO,
    SAN_FRANCISCO,
    SAN_JOAQUIN,
    SAN_LUIS_OBISPO,
    SAN_MATEO,
    SANTA_CLARA,
    SANTA_CRUZ,
    SHASTA,
    SIERRA,
    SISKIYOU,
    SONOMA,
    STANISLAUS,
    SUTTER,
    TRINITY,
    TULARE,
    TUOLOMNE,
    VENTURA,
    YOLO,
    YUBA,
  ];

  static final $core.Map<$core.int, CaliforniaCounty> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CaliforniaCounty valueOf($core.int value) => _byValue[value];

  const CaliforniaCounty._($core.int v, $core.String n) : super(v, n);
}

