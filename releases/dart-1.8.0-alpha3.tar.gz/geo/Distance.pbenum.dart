///
//  Generated code. Do not modify.
//  source: geo/Distance.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class DistanceUnit extends $pb.ProtobufEnum {
  static const DistanceUnit METERS = DistanceUnit._(0, 'METERS');
  static const DistanceUnit INCHES = DistanceUnit._(1, 'INCHES');
  static const DistanceUnit FEET = DistanceUnit._(2, 'FEET');
  static const DistanceUnit MILLIMETERS = DistanceUnit._(3, 'MILLIMETERS');
  static const DistanceUnit CENTIMETERS = DistanceUnit._(4, 'CENTIMETERS');
  static const DistanceUnit KILOMETERS = DistanceUnit._(5, 'KILOMETERS');
  static const DistanceUnit MILES = DistanceUnit._(6, 'MILES');

  static const $core.List<DistanceUnit> values = <DistanceUnit> [
    METERS,
    INCHES,
    FEET,
    MILLIMETERS,
    CENTIMETERS,
    KILOMETERS,
    MILES,
  ];

  static final $core.Map<$core.int, DistanceUnit> _byValue = $pb.ProtobufEnum.initByValue(values);
  static DistanceUnit valueOf($core.int value) => _byValue[value];

  const DistanceUnit._($core.int v, $core.String n) : super(v, n);
}

