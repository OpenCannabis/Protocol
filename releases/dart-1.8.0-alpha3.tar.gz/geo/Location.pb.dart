///
//  Generated code. Do not modify.
//  source: geo/Location.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../content/Name.pb.dart' as $3;
import 'Address.pb.dart' as $1;
import 'Point.pb.dart' as $4;
import 'Distance.pb.dart' as $2;

class Location extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Location', package: const $pb.PackageName('opencannabis.geo'))
    ..a<$3.Name>(1, 'name', $pb.PbFieldType.OM, $3.Name.getDefault, $3.Name.create)
    ..a<$1.Address>(2, 'address', $pb.PbFieldType.OM, $1.Address.getDefault, $1.Address.create)
    ..a<$4.Point>(3, 'point', $pb.PbFieldType.OM, $4.Point.getDefault, $4.Point.create)
    ..a<$2.LocationAccuracy>(4, 'accuracy', $pb.PbFieldType.OM, $2.LocationAccuracy.getDefault, $2.LocationAccuracy.create)
    ..hasRequiredFields = false
  ;

  Location() : super();
  Location.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Location.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Location clone() => Location()..mergeFromMessage(this);
  Location copyWith(void Function(Location) updates) => super.copyWith((message) => updates(message as Location));
  $pb.BuilderInfo get info_ => _i;
  static Location create() => Location();
  Location createEmptyInstance() => create();
  static $pb.PbList<Location> createRepeated() => $pb.PbList<Location>();
  static Location getDefault() => _defaultInstance ??= create()..freeze();
  static Location _defaultInstance;

  $3.Name get name => $_getN(0);
  set name($3.Name v) { setField(1, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  $1.Address get address => $_getN(1);
  set address($1.Address v) { setField(2, v); }
  $core.bool hasAddress() => $_has(1);
  void clearAddress() => clearField(2);

  $4.Point get point => $_getN(2);
  set point($4.Point v) { setField(3, v); }
  $core.bool hasPoint() => $_has(2);
  void clearPoint() => clearField(3);

  $2.LocationAccuracy get accuracy => $_getN(3);
  set accuracy($2.LocationAccuracy v) { setField(4, v); }
  $core.bool hasAccuracy() => $_has(3);
  void clearAccuracy() => clearField(4);
}

