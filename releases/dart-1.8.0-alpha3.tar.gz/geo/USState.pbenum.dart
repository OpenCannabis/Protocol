///
//  Generated code. Do not modify.
//  source: geo/USState.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class USState extends $pb.ProtobufEnum {
  static const USState UNSPECIFIED = USState._(0, 'UNSPECIFIED');
  static const USState AL = USState._(1, 'AL');
  static const USState AK = USState._(2, 'AK');
  static const USState AZ = USState._(3, 'AZ');
  static const USState AR = USState._(4, 'AR');
  static const USState CA = USState._(5, 'CA');
  static const USState CO = USState._(6, 'CO');
  static const USState CT = USState._(7, 'CT');
  static const USState DE = USState._(8, 'DE');
  static const USState DC = USState._(9, 'DC');
  static const USState FL = USState._(10, 'FL');
  static const USState GA = USState._(11, 'GA');
  static const USState HI = USState._(12, 'HI');
  static const USState ID = USState._(13, 'ID');
  static const USState IL = USState._(14, 'IL');
  static const USState IN = USState._(15, 'IN');
  static const USState IA = USState._(16, 'IA');
  static const USState KS = USState._(17, 'KS');
  static const USState KY = USState._(18, 'KY');
  static const USState LA = USState._(19, 'LA');
  static const USState ME = USState._(20, 'ME');
  static const USState MD = USState._(21, 'MD');
  static const USState MA = USState._(22, 'MA');
  static const USState MI = USState._(23, 'MI');
  static const USState MN = USState._(24, 'MN');
  static const USState MS = USState._(25, 'MS');
  static const USState MO = USState._(26, 'MO');
  static const USState MT = USState._(27, 'MT');
  static const USState NE = USState._(28, 'NE');
  static const USState NV = USState._(29, 'NV');
  static const USState NH = USState._(30, 'NH');
  static const USState NJ = USState._(31, 'NJ');
  static const USState NM = USState._(32, 'NM');
  static const USState NY = USState._(33, 'NY');
  static const USState NC = USState._(34, 'NC');
  static const USState ND = USState._(35, 'ND');
  static const USState OH = USState._(36, 'OH');
  static const USState OK = USState._(37, 'OK');
  static const USState OR = USState._(38, 'OR');
  static const USState PA = USState._(39, 'PA');
  static const USState RI = USState._(40, 'RI');
  static const USState SC = USState._(41, 'SC');
  static const USState SD = USState._(42, 'SD');
  static const USState TN = USState._(43, 'TN');
  static const USState TX = USState._(44, 'TX');
  static const USState UT = USState._(45, 'UT');
  static const USState VT = USState._(46, 'VT');
  static const USState VA = USState._(47, 'VA');
  static const USState WA = USState._(48, 'WA');
  static const USState WV = USState._(49, 'WV');
  static const USState WI = USState._(50, 'WI');
  static const USState WYOMING = USState._(51, 'WYOMING');

  static const USState ALABAMA = AL;
  static const USState ALASKA = AK;
  static const USState ARIZONA = AZ;
  static const USState ARKANSAS = AR;
  static const USState CALIFORNIA = CA;
  static const USState COLORADO = CO;
  static const USState CONNECTICUT = CT;
  static const USState Delaware = DE;
  static const USState DISTRICT_OF_COLUMBIA = DC;
  static const USState FLORIDA = FL;
  static const USState GEORGIA = GA;
  static const USState HAWAII = HI;
  static const USState IDAHO = ID;
  static const USState ILLINOIS = IL;
  static const USState INDIANA = IN;
  static const USState IOWA = IA;
  static const USState KANSAS = KS;
  static const USState KENTUCKY = KY;
  static const USState LOISIANA = LA;
  static const USState MAINE = ME;
  static const USState MARYLAND = MD;
  static const USState MASSACHUSETTS = MA;
  static const USState MICHIGAN = MI;
  static const USState MINNESOTA = MN;
  static const USState MISSISSIPPI = MS;
  static const USState MISSOURI = MO;
  static const USState MONTANA = MT;
  static const USState NEBRASKA = NE;
  static const USState NEVADA = NV;
  static const USState NEW_HAMPSHIRE = NH;
  static const USState NEW_JERSEY = NJ;
  static const USState NEW_MEXICO = NM;
  static const USState NEW_YORK = NY;
  static const USState NORTH_CAROLINA = NC;
  static const USState NORTH_DAKOTA = ND;
  static const USState OHIO = OH;
  static const USState OKLAHOMA = OK;
  static const USState OREGON = OR;
  static const USState PENNSYLVANIA = PA;
  static const USState RHODE_ISLAND = RI;
  static const USState SOUTH_CAROLINA = SC;
  static const USState SOUTH_DAKOTA = SD;
  static const USState TENNESSEE = TN;
  static const USState TEXAS = TX;
  static const USState UTAH = UT;
  static const USState VERMONT = VT;
  static const USState VIRGINIA = VA;
  static const USState WASHINGTON = WA;
  static const USState WEST_VIRGINIA = WV;
  static const USState WISCONSIN = WI;
  static const USState WY = WYOMING;

  static const $core.List<USState> values = <USState> [
    UNSPECIFIED,
    AL,
    AK,
    AZ,
    AR,
    CA,
    CO,
    CT,
    DE,
    DC,
    FL,
    GA,
    HI,
    ID,
    IL,
    IN,
    IA,
    KS,
    KY,
    LA,
    ME,
    MD,
    MA,
    MI,
    MN,
    MS,
    MO,
    MT,
    NE,
    NV,
    NH,
    NJ,
    NM,
    NY,
    NC,
    ND,
    OH,
    OK,
    OR,
    PA,
    RI,
    SC,
    SD,
    TN,
    TX,
    UT,
    VT,
    VA,
    WA,
    WV,
    WI,
    WYOMING,
  ];

  static final $core.Map<$core.int, USState> _byValue = $pb.ProtobufEnum.initByValue(values);
  static USState valueOf($core.int value) => _byValue[value];

  const USState._($core.int v, $core.String n) : super(v, n);
}

