///
//  Generated code. Do not modify.
//  source: geo/Point.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Point$json = const {
  '1': 'Point',
  '2': const [
    const {'1': 'latitude', '3': 1, '4': 1, '5': 1, '8': const {}, '10': 'latitude'},
    const {'1': 'longitude', '3': 2, '4': 1, '5': 1, '8': const {}, '10': 'longitude'},
    const {'1': 'elevation', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.geo.Distance', '8': const {}, '10': 'elevation'},
    const {'1': 'accuracy', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.geo.Distance', '8': const {}, '10': 'accuracy'},
  ],
};

const WorldCoordinate$json = const {
  '1': 'WorldCoordinate',
  '2': const [
    const {'1': 'right', '3': 1, '4': 1, '5': 1, '8': const {}, '10': 'right'},
    const {'1': 'down', '3': 2, '4': 1, '5': 1, '8': const {}, '10': 'down'},
    const {'1': 'elevation', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.geo.Distance', '8': const {}, '10': 'elevation'},
    const {'1': 'accuracy', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.geo.Distance', '8': const {}, '10': 'accuracy'},
  ],
};

const MapCoordinate$json = const {
  '1': 'MapCoordinate',
  '2': const [
    const {'1': 'x', '3': 1, '4': 1, '5': 13, '10': 'x'},
    const {'1': 'y', '3': 2, '4': 1, '5': 13, '10': 'y'},
    const {'1': 'right', '3': 3, '4': 1, '5': 13, '10': 'right'},
    const {'1': 'down', '3': 4, '4': 1, '5': 13, '10': 'down'},
  ],
};

const MapPosition$json = const {
  '1': 'MapPosition',
  '2': const [
    const {'1': 'point', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.geo.Point', '8': const {}, '10': 'point'},
    const {'1': 'tile', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.geo.MapCoordinate', '8': const {}, '10': 'tile'},
    const {'1': 'coordinate', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.geo.WorldCoordinate', '8': const {}, '10': 'coordinate'},
    const {'1': 'zoom', '3': 4, '4': 1, '5': 13, '8': const {}, '10': 'zoom'},
  ],
};

