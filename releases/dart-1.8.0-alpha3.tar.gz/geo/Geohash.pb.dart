///
//  Generated code. Do not modify.
//  source: geo/Geohash.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Distance.pb.dart' as $2;

class Geohash extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Geohash', package: const $pb.PackageName('opencannabis.geo'))
    ..pPS(1, 'component')
    ..a<$2.Distance>(2, 'elevation', $pb.PbFieldType.OM, $2.Distance.getDefault, $2.Distance.create)
    ..a<$2.Distance>(3, 'accuracy', $pb.PbFieldType.OM, $2.Distance.getDefault, $2.Distance.create)
    ..hasRequiredFields = false
  ;

  Geohash() : super();
  Geohash.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Geohash.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Geohash clone() => Geohash()..mergeFromMessage(this);
  Geohash copyWith(void Function(Geohash) updates) => super.copyWith((message) => updates(message as Geohash));
  $pb.BuilderInfo get info_ => _i;
  static Geohash create() => Geohash();
  Geohash createEmptyInstance() => create();
  static $pb.PbList<Geohash> createRepeated() => $pb.PbList<Geohash>();
  static Geohash getDefault() => _defaultInstance ??= create()..freeze();
  static Geohash _defaultInstance;

  $core.List<$core.String> get component => $_getList(0);

  $2.Distance get elevation => $_getN(1);
  set elevation($2.Distance v) { setField(2, v); }
  $core.bool hasElevation() => $_has(1);
  void clearElevation() => clearField(2);

  $2.Distance get accuracy => $_getN(2);
  set accuracy($2.Distance v) { setField(3, v); }
  $core.bool hasAccuracy() => $_has(2);
  void clearAccuracy() => clearField(3);
}

