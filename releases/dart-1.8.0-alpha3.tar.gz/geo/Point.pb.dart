///
//  Generated code. Do not modify.
//  source: geo/Point.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Distance.pb.dart' as $2;

class Point extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Point', package: const $pb.PackageName('opencannabis.geo'))
    ..a<$core.double>(1, 'latitude', $pb.PbFieldType.OD)
    ..a<$core.double>(2, 'longitude', $pb.PbFieldType.OD)
    ..a<$2.Distance>(3, 'elevation', $pb.PbFieldType.OM, $2.Distance.getDefault, $2.Distance.create)
    ..a<$2.Distance>(4, 'accuracy', $pb.PbFieldType.OM, $2.Distance.getDefault, $2.Distance.create)
    ..hasRequiredFields = false
  ;

  Point() : super();
  Point.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Point.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Point clone() => Point()..mergeFromMessage(this);
  Point copyWith(void Function(Point) updates) => super.copyWith((message) => updates(message as Point));
  $pb.BuilderInfo get info_ => _i;
  static Point create() => Point();
  Point createEmptyInstance() => create();
  static $pb.PbList<Point> createRepeated() => $pb.PbList<Point>();
  static Point getDefault() => _defaultInstance ??= create()..freeze();
  static Point _defaultInstance;

  $core.double get latitude => $_getN(0);
  set latitude($core.double v) { $_setDouble(0, v); }
  $core.bool hasLatitude() => $_has(0);
  void clearLatitude() => clearField(1);

  $core.double get longitude => $_getN(1);
  set longitude($core.double v) { $_setDouble(1, v); }
  $core.bool hasLongitude() => $_has(1);
  void clearLongitude() => clearField(2);

  $2.Distance get elevation => $_getN(2);
  set elevation($2.Distance v) { setField(3, v); }
  $core.bool hasElevation() => $_has(2);
  void clearElevation() => clearField(3);

  $2.Distance get accuracy => $_getN(3);
  set accuracy($2.Distance v) { setField(4, v); }
  $core.bool hasAccuracy() => $_has(3);
  void clearAccuracy() => clearField(4);
}

class WorldCoordinate extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('WorldCoordinate', package: const $pb.PackageName('opencannabis.geo'))
    ..a<$core.double>(1, 'right', $pb.PbFieldType.OD)
    ..a<$core.double>(2, 'down', $pb.PbFieldType.OD)
    ..a<$2.Distance>(3, 'elevation', $pb.PbFieldType.OM, $2.Distance.getDefault, $2.Distance.create)
    ..a<$2.Distance>(4, 'accuracy', $pb.PbFieldType.OM, $2.Distance.getDefault, $2.Distance.create)
    ..hasRequiredFields = false
  ;

  WorldCoordinate() : super();
  WorldCoordinate.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  WorldCoordinate.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  WorldCoordinate clone() => WorldCoordinate()..mergeFromMessage(this);
  WorldCoordinate copyWith(void Function(WorldCoordinate) updates) => super.copyWith((message) => updates(message as WorldCoordinate));
  $pb.BuilderInfo get info_ => _i;
  static WorldCoordinate create() => WorldCoordinate();
  WorldCoordinate createEmptyInstance() => create();
  static $pb.PbList<WorldCoordinate> createRepeated() => $pb.PbList<WorldCoordinate>();
  static WorldCoordinate getDefault() => _defaultInstance ??= create()..freeze();
  static WorldCoordinate _defaultInstance;

  $core.double get right => $_getN(0);
  set right($core.double v) { $_setDouble(0, v); }
  $core.bool hasRight() => $_has(0);
  void clearRight() => clearField(1);

  $core.double get down => $_getN(1);
  set down($core.double v) { $_setDouble(1, v); }
  $core.bool hasDown() => $_has(1);
  void clearDown() => clearField(2);

  $2.Distance get elevation => $_getN(2);
  set elevation($2.Distance v) { setField(3, v); }
  $core.bool hasElevation() => $_has(2);
  void clearElevation() => clearField(3);

  $2.Distance get accuracy => $_getN(3);
  set accuracy($2.Distance v) { setField(4, v); }
  $core.bool hasAccuracy() => $_has(3);
  void clearAccuracy() => clearField(4);
}

class MapCoordinate extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MapCoordinate', package: const $pb.PackageName('opencannabis.geo'))
    ..a<$core.int>(1, 'x', $pb.PbFieldType.OU3)
    ..a<$core.int>(2, 'y', $pb.PbFieldType.OU3)
    ..a<$core.int>(3, 'right', $pb.PbFieldType.OU3)
    ..a<$core.int>(4, 'down', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  MapCoordinate() : super();
  MapCoordinate.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MapCoordinate.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MapCoordinate clone() => MapCoordinate()..mergeFromMessage(this);
  MapCoordinate copyWith(void Function(MapCoordinate) updates) => super.copyWith((message) => updates(message as MapCoordinate));
  $pb.BuilderInfo get info_ => _i;
  static MapCoordinate create() => MapCoordinate();
  MapCoordinate createEmptyInstance() => create();
  static $pb.PbList<MapCoordinate> createRepeated() => $pb.PbList<MapCoordinate>();
  static MapCoordinate getDefault() => _defaultInstance ??= create()..freeze();
  static MapCoordinate _defaultInstance;

  $core.int get x => $_get(0, 0);
  set x($core.int v) { $_setUnsignedInt32(0, v); }
  $core.bool hasX() => $_has(0);
  void clearX() => clearField(1);

  $core.int get y => $_get(1, 0);
  set y($core.int v) { $_setUnsignedInt32(1, v); }
  $core.bool hasY() => $_has(1);
  void clearY() => clearField(2);

  $core.int get right => $_get(2, 0);
  set right($core.int v) { $_setUnsignedInt32(2, v); }
  $core.bool hasRight() => $_has(2);
  void clearRight() => clearField(3);

  $core.int get down => $_get(3, 0);
  set down($core.int v) { $_setUnsignedInt32(3, v); }
  $core.bool hasDown() => $_has(3);
  void clearDown() => clearField(4);
}

class MapPosition extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MapPosition', package: const $pb.PackageName('opencannabis.geo'))
    ..a<Point>(1, 'point', $pb.PbFieldType.OM, Point.getDefault, Point.create)
    ..a<MapCoordinate>(2, 'tile', $pb.PbFieldType.OM, MapCoordinate.getDefault, MapCoordinate.create)
    ..a<WorldCoordinate>(3, 'coordinate', $pb.PbFieldType.OM, WorldCoordinate.getDefault, WorldCoordinate.create)
    ..a<$core.int>(4, 'zoom', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  MapPosition() : super();
  MapPosition.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MapPosition.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MapPosition clone() => MapPosition()..mergeFromMessage(this);
  MapPosition copyWith(void Function(MapPosition) updates) => super.copyWith((message) => updates(message as MapPosition));
  $pb.BuilderInfo get info_ => _i;
  static MapPosition create() => MapPosition();
  MapPosition createEmptyInstance() => create();
  static $pb.PbList<MapPosition> createRepeated() => $pb.PbList<MapPosition>();
  static MapPosition getDefault() => _defaultInstance ??= create()..freeze();
  static MapPosition _defaultInstance;

  Point get point => $_getN(0);
  set point(Point v) { setField(1, v); }
  $core.bool hasPoint() => $_has(0);
  void clearPoint() => clearField(1);

  MapCoordinate get tile => $_getN(1);
  set tile(MapCoordinate v) { setField(2, v); }
  $core.bool hasTile() => $_has(1);
  void clearTile() => clearField(2);

  WorldCoordinate get coordinate => $_getN(2);
  set coordinate(WorldCoordinate v) { setField(3, v); }
  $core.bool hasCoordinate() => $_has(2);
  void clearCoordinate() => clearField(3);

  $core.int get zoom => $_get(3, 0);
  set zoom($core.int v) { $_setUnsignedInt32(3, v); }
  $core.bool hasZoom() => $_has(3);
  void clearZoom() => clearField(4);
}

