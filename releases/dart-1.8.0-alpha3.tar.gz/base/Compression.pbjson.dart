///
//  Generated code. Do not modify.
//  source: base/Compression.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Compression$json = const {
  '1': 'Compression',
  '2': const [
    const {'1': 'enabled', '3': 1, '4': 1, '5': 8, '10': 'enabled'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.base.Compression.Type', '10': 'type'},
  ],
  '4': const [Compression_Type$json],
};

const Compression_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'NO_COMPRESSION', '2': 0},
    const {'1': 'GZIP', '2': 1},
    const {'1': 'BROTLI', '2': 2},
    const {'1': 'SNAPPY', '2': 3},
  ],
};

