///
//  Generated code. Do not modify.
//  source: base/ProductKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ProductReference$json = const {
  '1': 'ProductReference',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.content.Name', '8': const {}, '10': 'name'},
    const {'1': 'key', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '8': const {}, '10': 'key'},
  ],
};

const ProductKey$json = const {
  '1': 'ProductKey',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'id'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.base.ProductKind', '8': const {}, '10': 'type'},
  ],
};

