///
//  Generated code. Do not modify.
//  source: base/Language.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Language extends $pb.ProtobufEnum {
  static const Language LANGUAGE_UNSPECIFIED = Language._(0, 'LANGUAGE_UNSPECIFIED');
  static const Language ENGLISH = Language._(1, 'ENGLISH');
  static const Language SPANISH = Language._(2, 'SPANISH');
  static const Language FRENCH = Language._(3, 'FRENCH');

  static const $core.List<Language> values = <Language> [
    LANGUAGE_UNSPECIFIED,
    ENGLISH,
    SPANISH,
    FRENCH,
  ];

  static final $core.Map<$core.int, Language> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Language valueOf($core.int value) => _byValue[value];

  const Language._($core.int v, $core.String n) : super(v, n);
}

