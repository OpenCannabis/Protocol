///
//  Generated code. Do not modify.
//  source: base/Compression.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Compression_Type extends $pb.ProtobufEnum {
  static const Compression_Type NO_COMPRESSION = Compression_Type._(0, 'NO_COMPRESSION');
  static const Compression_Type GZIP = Compression_Type._(1, 'GZIP');
  static const Compression_Type BROTLI = Compression_Type._(2, 'BROTLI');
  static const Compression_Type SNAPPY = Compression_Type._(3, 'SNAPPY');

  static const $core.List<Compression_Type> values = <Compression_Type> [
    NO_COMPRESSION,
    GZIP,
    BROTLI,
    SNAPPY,
  ];

  static final $core.Map<$core.int, Compression_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Compression_Type valueOf($core.int value) => _byValue[value];

  const Compression_Type._($core.int v, $core.String n) : super(v, n);
}

