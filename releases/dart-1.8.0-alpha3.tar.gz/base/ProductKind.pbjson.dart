///
//  Generated code. Do not modify.
//  source: base/ProductKind.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ProductKind$json = const {
  '1': 'ProductKind',
  '2': const [
    const {'1': 'FLOWERS', '2': 0},
    const {'1': 'EDIBLES', '2': 1},
    const {'1': 'EXTRACTS', '2': 2},
    const {'1': 'PREROLLS', '2': 3},
    const {'1': 'APOTHECARY', '2': 4},
    const {'1': 'CARTRIDGES', '2': 5},
    const {'1': 'PLANTS', '2': 6},
    const {'1': 'MERCHANDISE', '2': 7},
  ],
};

