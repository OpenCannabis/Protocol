///
//  Generated code. Do not modify.
//  source: content/Colors.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart' as $pb;

import 'Colors.pbenum.dart';

export 'Colors.pbenum.dart';

class RGBAColorSpec extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('RGBAColorSpec', package: const $pb.PackageName('opencannabis.content'))
    ..a<Int64>(1, 'r', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(2, 'g', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(3, 'b', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(4, 'a', $pb.PbFieldType.OU6, Int64.ZERO)
    ..hasRequiredFields = false
  ;

  RGBAColorSpec() : super();
  RGBAColorSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  RGBAColorSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  RGBAColorSpec clone() => RGBAColorSpec()..mergeFromMessage(this);
  RGBAColorSpec copyWith(void Function(RGBAColorSpec) updates) => super.copyWith((message) => updates(message as RGBAColorSpec));
  $pb.BuilderInfo get info_ => _i;
  static RGBAColorSpec create() => RGBAColorSpec();
  RGBAColorSpec createEmptyInstance() => create();
  static $pb.PbList<RGBAColorSpec> createRepeated() => $pb.PbList<RGBAColorSpec>();
  static RGBAColorSpec getDefault() => _defaultInstance ??= create()..freeze();
  static RGBAColorSpec _defaultInstance;

  Int64 get r => $_getI64(0);
  set r(Int64 v) { $_setInt64(0, v); }
  $core.bool hasR() => $_has(0);
  void clearR() => clearField(1);

  Int64 get g => $_getI64(1);
  set g(Int64 v) { $_setInt64(1, v); }
  $core.bool hasG() => $_has(1);
  void clearG() => clearField(2);

  Int64 get b => $_getI64(2);
  set b(Int64 v) { $_setInt64(2, v); }
  $core.bool hasB() => $_has(2);
  void clearB() => clearField(3);

  Int64 get a => $_getI64(3);
  set a(Int64 v) { $_setInt64(3, v); }
  $core.bool hasA() => $_has(3);
  void clearA() => clearField(4);
}

class HSBColorSpec extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('HSBColorSpec', package: const $pb.PackageName('opencannabis.content'))
    ..a<Int64>(1, 'h', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(2, 's', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(3, 'b', $pb.PbFieldType.OU6, Int64.ZERO)
    ..hasRequiredFields = false
  ;

  HSBColorSpec() : super();
  HSBColorSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  HSBColorSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  HSBColorSpec clone() => HSBColorSpec()..mergeFromMessage(this);
  HSBColorSpec copyWith(void Function(HSBColorSpec) updates) => super.copyWith((message) => updates(message as HSBColorSpec));
  $pb.BuilderInfo get info_ => _i;
  static HSBColorSpec create() => HSBColorSpec();
  HSBColorSpec createEmptyInstance() => create();
  static $pb.PbList<HSBColorSpec> createRepeated() => $pb.PbList<HSBColorSpec>();
  static HSBColorSpec getDefault() => _defaultInstance ??= create()..freeze();
  static HSBColorSpec _defaultInstance;

  Int64 get h => $_getI64(0);
  set h(Int64 v) { $_setInt64(0, v); }
  $core.bool hasH() => $_has(0);
  void clearH() => clearField(1);

  Int64 get s => $_getI64(1);
  set s(Int64 v) { $_setInt64(1, v); }
  $core.bool hasS() => $_has(1);
  void clearS() => clearField(2);

  Int64 get b => $_getI64(2);
  set b(Int64 v) { $_setInt64(2, v); }
  $core.bool hasB() => $_has(2);
  void clearB() => clearField(3);
}

class CMYKColorSpec extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CMYKColorSpec', package: const $pb.PackageName('opencannabis.content'))
    ..a<Int64>(1, 'c', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(2, 'm', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(3, 'y', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(4, 'k', $pb.PbFieldType.OU6, Int64.ZERO)
    ..hasRequiredFields = false
  ;

  CMYKColorSpec() : super();
  CMYKColorSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CMYKColorSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CMYKColorSpec clone() => CMYKColorSpec()..mergeFromMessage(this);
  CMYKColorSpec copyWith(void Function(CMYKColorSpec) updates) => super.copyWith((message) => updates(message as CMYKColorSpec));
  $pb.BuilderInfo get info_ => _i;
  static CMYKColorSpec create() => CMYKColorSpec();
  CMYKColorSpec createEmptyInstance() => create();
  static $pb.PbList<CMYKColorSpec> createRepeated() => $pb.PbList<CMYKColorSpec>();
  static CMYKColorSpec getDefault() => _defaultInstance ??= create()..freeze();
  static CMYKColorSpec _defaultInstance;

  Int64 get c => $_getI64(0);
  set c(Int64 v) { $_setInt64(0, v); }
  $core.bool hasC() => $_has(0);
  void clearC() => clearField(1);

  Int64 get m => $_getI64(1);
  set m(Int64 v) { $_setInt64(1, v); }
  $core.bool hasM() => $_has(1);
  void clearM() => clearField(2);

  Int64 get y => $_getI64(2);
  set y(Int64 v) { $_setInt64(2, v); }
  $core.bool hasY() => $_has(2);
  void clearY() => clearField(3);

  Int64 get k => $_getI64(3);
  set k(Int64 v) { $_setInt64(3, v); }
  $core.bool hasK() => $_has(3);
  void clearK() => clearField(4);
}

enum Color_Spec {
  standard, 
  hex, 
  rgba, 
  hsb, 
  cmyk, 
  notSet
}

class Color extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Color_Spec> _Color_SpecByTag = {
    1 : Color_Spec.standard,
    2 : Color_Spec.hex,
    3 : Color_Spec.rgba,
    4 : Color_Spec.hsb,
    5 : Color_Spec.cmyk,
    0 : Color_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Color', package: const $pb.PackageName('opencannabis.content'))
    ..e<StandardColor>(1, 'standard', $pb.PbFieldType.OE, StandardColor.UNSPECIFIED_COLOR, StandardColor.valueOf, StandardColor.values)
    ..aOS(2, 'hex')
    ..a<RGBAColorSpec>(3, 'rgba', $pb.PbFieldType.OM, RGBAColorSpec.getDefault, RGBAColorSpec.create)
    ..a<HSBColorSpec>(4, 'hsb', $pb.PbFieldType.OM, HSBColorSpec.getDefault, HSBColorSpec.create)
    ..a<CMYKColorSpec>(5, 'cmyk', $pb.PbFieldType.OM, CMYKColorSpec.getDefault, CMYKColorSpec.create)
    ..oo(0, [1, 2, 3, 4, 5])
    ..hasRequiredFields = false
  ;

  Color() : super();
  Color.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Color.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Color clone() => Color()..mergeFromMessage(this);
  Color copyWith(void Function(Color) updates) => super.copyWith((message) => updates(message as Color));
  $pb.BuilderInfo get info_ => _i;
  static Color create() => Color();
  Color createEmptyInstance() => create();
  static $pb.PbList<Color> createRepeated() => $pb.PbList<Color>();
  static Color getDefault() => _defaultInstance ??= create()..freeze();
  static Color _defaultInstance;

  Color_Spec whichSpec() => _Color_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  StandardColor get standard => $_getN(0);
  set standard(StandardColor v) { setField(1, v); }
  $core.bool hasStandard() => $_has(0);
  void clearStandard() => clearField(1);

  $core.String get hex => $_getS(1, '');
  set hex($core.String v) { $_setString(1, v); }
  $core.bool hasHex() => $_has(1);
  void clearHex() => clearField(2);

  RGBAColorSpec get rgba => $_getN(2);
  set rgba(RGBAColorSpec v) { setField(3, v); }
  $core.bool hasRgba() => $_has(2);
  void clearRgba() => clearField(3);

  HSBColorSpec get hsb => $_getN(3);
  set hsb(HSBColorSpec v) { setField(4, v); }
  $core.bool hasHsb() => $_has(3);
  void clearHsb() => clearField(4);

  CMYKColorSpec get cmyk => $_getN(4);
  set cmyk(CMYKColorSpec v) { setField(5, v); }
  $core.bool hasCmyk() => $_has(4);
  void clearCmyk() => clearField(5);
}

class ColorScheme extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ColorScheme', package: const $pb.PackageName('opencannabis.content'))
    ..a<Color>(1, 'primary', $pb.PbFieldType.OM, Color.getDefault, Color.create)
    ..a<Color>(2, 'secondary', $pb.PbFieldType.OM, Color.getDefault, Color.create)
    ..a<Color>(3, 'alert', $pb.PbFieldType.OM, Color.getDefault, Color.create)
    ..pc<Color>(4, 'shades', $pb.PbFieldType.PM,Color.create)
    ..hasRequiredFields = false
  ;

  ColorScheme() : super();
  ColorScheme.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ColorScheme.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ColorScheme clone() => ColorScheme()..mergeFromMessage(this);
  ColorScheme copyWith(void Function(ColorScheme) updates) => super.copyWith((message) => updates(message as ColorScheme));
  $pb.BuilderInfo get info_ => _i;
  static ColorScheme create() => ColorScheme();
  ColorScheme createEmptyInstance() => create();
  static $pb.PbList<ColorScheme> createRepeated() => $pb.PbList<ColorScheme>();
  static ColorScheme getDefault() => _defaultInstance ??= create()..freeze();
  static ColorScheme _defaultInstance;

  Color get primary => $_getN(0);
  set primary(Color v) { setField(1, v); }
  $core.bool hasPrimary() => $_has(0);
  void clearPrimary() => clearField(1);

  Color get secondary => $_getN(1);
  set secondary(Color v) { setField(2, v); }
  $core.bool hasSecondary() => $_has(1);
  void clearSecondary() => clearField(2);

  Color get alert => $_getN(2);
  set alert(Color v) { setField(3, v); }
  $core.bool hasAlert() => $_has(2);
  void clearAlert() => clearField(3);

  $core.List<Color> get shades => $_getList(3);
}

