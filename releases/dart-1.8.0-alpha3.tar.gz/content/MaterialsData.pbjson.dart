///
//  Generated code. Do not modify.
//  source: content/MaterialsData.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const MaterialsData$json = const {
  '1': 'MaterialsData',
  '2': const [
    const {'1': 'species', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.Species', '10': 'species'},
    const {'1': 'genetics', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.Genetics', '10': 'genetics'},
    const {'1': 'grow', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.structs.Grow', '10': 'grow'},
    const {'1': 'shelf', '3': 4, '4': 1, '5': 14, '6': '.opencannabis.structs.Shelf', '10': 'shelf'},
    const {'1': 'channel', '3': 5, '4': 3, '5': 11, '6': '.opencannabis.products.distribution.DistributionPolicy', '10': 'channel'},
  ],
};

