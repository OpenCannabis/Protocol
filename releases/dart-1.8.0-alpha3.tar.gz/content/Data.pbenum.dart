///
//  Generated code. Do not modify.
//  source: content/Data.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class DataFormat extends $pb.ProtobufEnum {
  static const DataFormat UNKNOWN_FORMAT = DataFormat._(0, 'UNKNOWN_FORMAT');
  static const DataFormat CSV = DataFormat._(10, 'CSV');
  static const DataFormat TSV = DataFormat._(11, 'TSV');
  static const DataFormat EXCEL_CSV = DataFormat._(12, 'EXCEL_CSV');
  static const DataFormat EXCEL_XLS = DataFormat._(13, 'EXCEL_XLS');
  static const DataFormat EXCEL_XLSX = DataFormat._(14, 'EXCEL_XLSX');
  static const DataFormat MSGPACK = DataFormat._(20, 'MSGPACK');
  static const DataFormat AVRO = DataFormat._(30, 'AVRO');
  static const DataFormat SQL = DataFormat._(40, 'SQL');
  static const DataFormat JSON = DataFormat._(50, 'JSON');
  static const DataFormat OCP_TEXT = DataFormat._(61, 'OCP_TEXT');
  static const DataFormat OCP_BINARY = DataFormat._(62, 'OCP_BINARY');

  static const $core.List<DataFormat> values = <DataFormat> [
    UNKNOWN_FORMAT,
    CSV,
    TSV,
    EXCEL_CSV,
    EXCEL_XLS,
    EXCEL_XLSX,
    MSGPACK,
    AVRO,
    SQL,
    JSON,
    OCP_TEXT,
    OCP_BINARY,
  ];

  static final $core.Map<$core.int, DataFormat> _byValue = $pb.ProtobufEnum.initByValue(values);
  static DataFormat valueOf($core.int value) => _byValue[value];

  const DataFormat._($core.int v, $core.String n) : super(v, n);
}

