///
//  Generated code. Do not modify.
//  source: content/Name.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class Name extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Name', package: const $pb.PackageName('opencannabis.content'))
    ..aOS(1, 'primary')
    ..aOS(2, 'display')
    ..hasRequiredFields = false
  ;

  Name() : super();
  Name.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Name.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Name clone() => Name()..mergeFromMessage(this);
  Name copyWith(void Function(Name) updates) => super.copyWith((message) => updates(message as Name));
  $pb.BuilderInfo get info_ => _i;
  static Name create() => Name();
  Name createEmptyInstance() => create();
  static $pb.PbList<Name> createRepeated() => $pb.PbList<Name>();
  static Name getDefault() => _defaultInstance ??= create()..freeze();
  static Name _defaultInstance;

  $core.String get primary => $_getS(0, '');
  set primary($core.String v) { $_setString(0, v); }
  $core.bool hasPrimary() => $_has(0);
  void clearPrimary() => clearField(1);

  $core.String get display => $_getS(1, '');
  set display($core.String v) { $_setString(1, v); }
  $core.bool hasDisplay() => $_has(1);
  void clearDisplay() => clearField(2);
}

