///
//  Generated code. Do not modify.
//  source: content/MaterialsData.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../structs/Genetics.pb.dart' as $37;
import '../products/distribution/DistributionChannel.pb.dart' as $38;

import '../structs/Species.pbenum.dart' as $39;
import '../structs/Grow.pbenum.dart' as $40;
import '../structs/Shelf.pbenum.dart' as $41;

class MaterialsData extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MaterialsData', package: const $pb.PackageName('opencannabis.content'))
    ..e<$39.Species>(1, 'species', $pb.PbFieldType.OE, $39.Species.UNSPECIFIED, $39.Species.valueOf, $39.Species.values)
    ..a<$37.Genetics>(2, 'genetics', $pb.PbFieldType.OM, $37.Genetics.getDefault, $37.Genetics.create)
    ..e<$40.Grow>(3, 'grow', $pb.PbFieldType.OE, $40.Grow.GENERIC, $40.Grow.valueOf, $40.Grow.values)
    ..e<$41.Shelf>(4, 'shelf', $pb.PbFieldType.OE, $41.Shelf.GENERIC_SHELF, $41.Shelf.valueOf, $41.Shelf.values)
    ..pc<$38.DistributionPolicy>(5, 'channel', $pb.PbFieldType.PM,$38.DistributionPolicy.create)
    ..hasRequiredFields = false
  ;

  MaterialsData() : super();
  MaterialsData.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MaterialsData.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MaterialsData clone() => MaterialsData()..mergeFromMessage(this);
  MaterialsData copyWith(void Function(MaterialsData) updates) => super.copyWith((message) => updates(message as MaterialsData));
  $pb.BuilderInfo get info_ => _i;
  static MaterialsData create() => MaterialsData();
  MaterialsData createEmptyInstance() => create();
  static $pb.PbList<MaterialsData> createRepeated() => $pb.PbList<MaterialsData>();
  static MaterialsData getDefault() => _defaultInstance ??= create()..freeze();
  static MaterialsData _defaultInstance;

  $39.Species get species => $_getN(0);
  set species($39.Species v) { setField(1, v); }
  $core.bool hasSpecies() => $_has(0);
  void clearSpecies() => clearField(1);

  $37.Genetics get genetics => $_getN(1);
  set genetics($37.Genetics v) { setField(2, v); }
  $core.bool hasGenetics() => $_has(1);
  void clearGenetics() => clearField(2);

  $40.Grow get grow => $_getN(2);
  set grow($40.Grow v) { setField(3, v); }
  $core.bool hasGrow() => $_has(2);
  void clearGrow() => clearField(3);

  $41.Shelf get shelf => $_getN(3);
  set shelf($41.Shelf v) { setField(4, v); }
  $core.bool hasShelf() => $_has(3);
  void clearShelf() => clearField(4);

  $core.List<$38.DistributionPolicy> get channel => $_getList(4);
}

