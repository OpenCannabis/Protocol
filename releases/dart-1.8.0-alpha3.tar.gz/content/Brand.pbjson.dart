///
//  Generated code. Do not modify.
//  source: content/Brand.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const RasterGraphic$json = const {
  '1': 'RasterGraphic',
  '2': const [
    const {'1': 'standard', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.media.MediaReference', '10': 'standard'},
    const {'1': 'retina', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.media.MediaReference', '10': 'retina'},
  ],
};

const BrandAsset$json = const {
  '1': 'BrandAsset',
  '2': const [
    const {'1': 'raster', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.content.RasterGraphic', '10': 'raster'},
    const {'1': 'vector', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.media.MediaReference', '10': 'vector'},
  ],
};

const Brand$json = const {
  '1': 'Brand',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.content.Name', '10': 'name'},
    const {'1': 'parent', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.content.Brand', '10': 'parent'},
    const {'1': 'summary', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.content.Content', '10': 'summary'},
    const {'1': 'media', '3': 20, '4': 3, '5': 11, '6': '.opencannabis.content.BrandAsset', '10': 'media'},
    const {'1': 'theme', '3': 21, '4': 1, '5': 11, '6': '.opencannabis.content.ColorScheme', '10': 'theme'},
  ],
};

