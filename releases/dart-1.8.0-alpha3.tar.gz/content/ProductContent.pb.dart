///
//  Generated code. Do not modify.
//  source: content/ProductContent.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../temporal/Instant.pb.dart' as $0;
import 'Name.pb.dart' as $3;
import 'Brand.pb.dart' as $49;
import 'Content.pb.dart' as $44;
import '../media/MediaKey.pb.dart' as $26;
import '../structs/pricing/PricingDescriptor.pb.dart' as $17;
import '../structs/labtesting/TestResults.pb.dart' as $50;

import '../structs/ProductFlags.pbenum.dart' as $51;

class ProductTimestamps extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProductTimestamps', package: const $pb.PackageName('opencannabis.content'))
    ..a<$0.Instant>(1, 'created', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(2, 'modified', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(3, 'published', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..hasRequiredFields = false
  ;

  ProductTimestamps() : super();
  ProductTimestamps.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductTimestamps.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductTimestamps clone() => ProductTimestamps()..mergeFromMessage(this);
  ProductTimestamps copyWith(void Function(ProductTimestamps) updates) => super.copyWith((message) => updates(message as ProductTimestamps));
  $pb.BuilderInfo get info_ => _i;
  static ProductTimestamps create() => ProductTimestamps();
  ProductTimestamps createEmptyInstance() => create();
  static $pb.PbList<ProductTimestamps> createRepeated() => $pb.PbList<ProductTimestamps>();
  static ProductTimestamps getDefault() => _defaultInstance ??= create()..freeze();
  static ProductTimestamps _defaultInstance;

  $0.Instant get created => $_getN(0);
  set created($0.Instant v) { setField(1, v); }
  $core.bool hasCreated() => $_has(0);
  void clearCreated() => clearField(1);

  $0.Instant get modified => $_getN(1);
  set modified($0.Instant v) { setField(2, v); }
  $core.bool hasModified() => $_has(1);
  void clearModified() => clearField(2);

  $0.Instant get published => $_getN(2);
  set published($0.Instant v) { setField(3, v); }
  $core.bool hasPublished() => $_has(2);
  void clearPublished() => clearField(3);
}

class ProductContent extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProductContent', package: const $pb.PackageName('opencannabis.content'))
    ..a<$3.Name>(1, 'name', $pb.PbFieldType.OM, $3.Name.getDefault, $3.Name.create)
    ..a<$49.Brand>(2, 'brand', $pb.PbFieldType.OM, $49.Brand.getDefault, $49.Brand.create)
    ..a<$44.Content>(3, 'summary', $pb.PbFieldType.OM, $44.Content.getDefault, $44.Content.create)
    ..a<$44.Content>(4, 'usage', $pb.PbFieldType.OM, $44.Content.getDefault, $44.Content.create)
    ..a<$44.Content>(5, 'dosage', $pb.PbFieldType.OM, $44.Content.getDefault, $44.Content.create)
    ..pc<$26.MediaReference>(6, 'media', $pb.PbFieldType.PM,$26.MediaReference.create)
    ..a<$17.ProductPricing>(7, 'pricing', $pb.PbFieldType.OM, $17.ProductPricing.getDefault, $17.ProductPricing.create)
    ..a<$50.TestResults>(8, 'tests', $pb.PbFieldType.OM, $50.TestResults.getDefault, $50.TestResults.create)
    ..pc<$51.ProductFlag>(9, 'flags', $pb.PbFieldType.PE, null, $51.ProductFlag.valueOf, $51.ProductFlag.values)
    ..a<ProductTimestamps>(10, 'ts', $pb.PbFieldType.OM, ProductTimestamps.getDefault, ProductTimestamps.create)
    ..hasRequiredFields = false
  ;

  ProductContent() : super();
  ProductContent.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductContent.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductContent clone() => ProductContent()..mergeFromMessage(this);
  ProductContent copyWith(void Function(ProductContent) updates) => super.copyWith((message) => updates(message as ProductContent));
  $pb.BuilderInfo get info_ => _i;
  static ProductContent create() => ProductContent();
  ProductContent createEmptyInstance() => create();
  static $pb.PbList<ProductContent> createRepeated() => $pb.PbList<ProductContent>();
  static ProductContent getDefault() => _defaultInstance ??= create()..freeze();
  static ProductContent _defaultInstance;

  $3.Name get name => $_getN(0);
  set name($3.Name v) { setField(1, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  $49.Brand get brand => $_getN(1);
  set brand($49.Brand v) { setField(2, v); }
  $core.bool hasBrand() => $_has(1);
  void clearBrand() => clearField(2);

  $44.Content get summary => $_getN(2);
  set summary($44.Content v) { setField(3, v); }
  $core.bool hasSummary() => $_has(2);
  void clearSummary() => clearField(3);

  $44.Content get usage => $_getN(3);
  set usage($44.Content v) { setField(4, v); }
  $core.bool hasUsage() => $_has(3);
  void clearUsage() => clearField(4);

  $44.Content get dosage => $_getN(4);
  set dosage($44.Content v) { setField(5, v); }
  $core.bool hasDosage() => $_has(4);
  void clearDosage() => clearField(5);

  $core.List<$26.MediaReference> get media => $_getList(5);

  $17.ProductPricing get pricing => $_getN(6);
  set pricing($17.ProductPricing v) { setField(7, v); }
  $core.bool hasPricing() => $_has(6);
  void clearPricing() => clearField(7);

  $50.TestResults get tests => $_getN(7);
  set tests($50.TestResults v) { setField(8, v); }
  $core.bool hasTests() => $_has(7);
  void clearTests() => clearField(8);

  $core.List<$51.ProductFlag> get flags => $_getList(8);

  ProductTimestamps get ts => $_getN(9);
  set ts(ProductTimestamps v) { setField(10, v); }
  $core.bool hasTs() => $_has(9);
  void clearTs() => clearField(10);
}

