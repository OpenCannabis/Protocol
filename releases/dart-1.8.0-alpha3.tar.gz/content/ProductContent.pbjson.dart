///
//  Generated code. Do not modify.
//  source: content/ProductContent.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ProductTimestamps$json = const {
  '1': 'ProductTimestamps',
  '2': const [
    const {'1': 'created', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'created'},
    const {'1': 'modified', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'modified'},
    const {'1': 'published', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'published'},
  ],
};

const ProductContent$json = const {
  '1': 'ProductContent',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.content.Name', '10': 'name'},
    const {'1': 'brand', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.content.Brand', '10': 'brand'},
    const {'1': 'summary', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.content.Content', '10': 'summary'},
    const {'1': 'usage', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.content.Content', '10': 'usage'},
    const {'1': 'dosage', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.content.Content', '10': 'dosage'},
    const {'1': 'media', '3': 6, '4': 3, '5': 11, '6': '.opencannabis.media.MediaReference', '8': const {}, '10': 'media'},
    const {'1': 'pricing', '3': 7, '4': 1, '5': 11, '6': '.opencannabis.structs.pricing.ProductPricing', '10': 'pricing'},
    const {'1': 'tests', '3': 8, '4': 1, '5': 11, '6': '.opencannabis.structs.labtesting.TestResults', '10': 'tests'},
    const {'1': 'flags', '3': 9, '4': 3, '5': 14, '6': '.opencannabis.structs.ProductFlag', '10': 'flags'},
    const {'1': 'ts', '3': 10, '4': 1, '5': 11, '6': '.opencannabis.content.ProductTimestamps', '10': 'ts'},
  ],
};

