///
//  Generated code. Do not modify.
//  source: content/Data.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const DataFormat$json = const {
  '1': 'DataFormat',
  '2': const [
    const {'1': 'UNKNOWN_FORMAT', '2': 0},
    const {'1': 'CSV', '2': 10},
    const {'1': 'TSV', '2': 11},
    const {'1': 'EXCEL_CSV', '2': 12},
    const {'1': 'EXCEL_XLS', '2': 13},
    const {'1': 'EXCEL_XLSX', '2': 14},
    const {'1': 'MSGPACK', '2': 20},
    const {'1': 'AVRO', '2': 30},
    const {'1': 'SQL', '2': 40},
    const {'1': 'JSON', '2': 50},
    const {'1': 'OCP_TEXT', '2': 61},
    const {'1': 'OCP_BINARY', '2': 62},
  ],
};

