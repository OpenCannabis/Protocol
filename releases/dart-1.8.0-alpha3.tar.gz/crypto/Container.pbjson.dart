///
//  Generated code. Do not modify.
//  source: crypto/Container.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const EncryptedData$json = const {
  '1': 'EncryptedData',
  '2': const [
    const {'1': 'data', '3': 1, '4': 1, '5': 12, '10': 'data'},
    const {'1': 'encoding', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.content.Encoding', '10': 'encoding'},
    const {'1': 'compression', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.base.Compression', '10': 'compression'},
    const {'1': 'fingerprint', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.crypto.Hash', '10': 'fingerprint'},
  ],
};

const EncryptedContainer$json = const {
  '1': 'EncryptedContainer',
  '2': const [
    const {'1': 'payload', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.crypto.EncryptedData', '10': 'payload'},
    const {'1': 'keying', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.crypto.KeyType', '10': 'keying'},
    const {'1': 'vector', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.crypto.InitializationVector', '10': 'vector'},
    const {'1': 'key', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.crypto.SymmetricKeyParameters', '9': 0, '10': 'key'},
    const {'1': 'keypair', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.crypto.AsymmetricKeypairParameters', '9': 0, '10': 'keypair'},
  ],
  '8': const [
    const {'1': 'parameters'},
  ],
};

