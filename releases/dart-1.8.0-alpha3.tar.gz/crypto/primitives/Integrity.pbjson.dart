///
//  Generated code. Do not modify.
//  source: crypto/primitives/Integrity.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const HashAlgorithm$json = const {
  '1': 'HashAlgorithm',
  '2': const [
    const {'1': 'SHA1', '2': 0},
    const {'1': 'MD5', '2': 1},
    const {'1': 'SHA256', '2': 2},
    const {'1': 'SHA384', '2': 3},
    const {'1': 'SHA512', '2': 4},
    const {'1': 'MURMUR', '2': 6},
  ],
};

const Hash$json = const {
  '1': 'Hash',
  '2': const [
    const {'1': 'algorithm', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.crypto.HashAlgorithm', '10': 'algorithm'},
    const {'1': 'raw', '3': 2, '4': 1, '5': 12, '9': 0, '10': 'raw'},
    const {'1': 'hex', '3': 3, '4': 1, '5': 9, '9': 0, '10': 'hex'},
    const {'1': 'b64', '3': 4, '4': 1, '5': 9, '9': 0, '10': 'b64'},
  ],
  '8': const [
    const {'1': 'digest'},
  ],
};

const HashedData$json = const {
  '1': 'HashedData',
  '2': const [
    const {'1': 'data', '3': 1, '4': 1, '5': 12, '10': 'data'},
    const {'1': 'hash', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.crypto.Hash', '10': 'hash'},
  ],
};

