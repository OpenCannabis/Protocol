///
//  Generated code. Do not modify.
//  source: crypto/Signature.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Signature$json = const {
  '1': 'Signature',
  '2': const [
    const {'1': 'public_key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.crypto.KeyMaterial', '10': 'publicKey'},
    const {'1': 'fingerprint', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.crypto.Hash', '10': 'fingerprint'},
    const {'1': 'raw', '3': 5, '4': 1, '5': 12, '9': 0, '10': 'raw'},
    const {'1': 'b64', '3': 6, '4': 1, '5': 9, '9': 0, '10': 'b64'},
    const {'1': 'hex', '3': 7, '4': 1, '5': 9, '9': 0, '10': 'hex'},
  ],
  '8': const [
    const {'1': 'signature'},
  ],
};

