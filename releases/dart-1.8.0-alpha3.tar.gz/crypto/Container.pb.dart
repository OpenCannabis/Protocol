///
//  Generated code. Do not modify.
//  source: crypto/Container.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/Compression.pb.dart' as $42;
import 'primitives/Integrity.pb.dart' as $54;
import 'primitives/Keys.pb.dart' as $67;

import '../content/Content.pbenum.dart' as $44;
import 'primitives/Keys.pbenum.dart' as $67;

class EncryptedData extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('EncryptedData', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<$core.List<$core.int>>(1, 'data', $pb.PbFieldType.OY)
    ..e<$44.Encoding>(2, 'encoding', $pb.PbFieldType.OE, $44.Encoding.UTF8, $44.Encoding.valueOf, $44.Encoding.values)
    ..a<$42.Compression>(3, 'compression', $pb.PbFieldType.OM, $42.Compression.getDefault, $42.Compression.create)
    ..a<$54.Hash>(4, 'fingerprint', $pb.PbFieldType.OM, $54.Hash.getDefault, $54.Hash.create)
    ..hasRequiredFields = false
  ;

  EncryptedData() : super();
  EncryptedData.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  EncryptedData.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  EncryptedData clone() => EncryptedData()..mergeFromMessage(this);
  EncryptedData copyWith(void Function(EncryptedData) updates) => super.copyWith((message) => updates(message as EncryptedData));
  $pb.BuilderInfo get info_ => _i;
  static EncryptedData create() => EncryptedData();
  EncryptedData createEmptyInstance() => create();
  static $pb.PbList<EncryptedData> createRepeated() => $pb.PbList<EncryptedData>();
  static EncryptedData getDefault() => _defaultInstance ??= create()..freeze();
  static EncryptedData _defaultInstance;

  $core.List<$core.int> get data => $_getN(0);
  set data($core.List<$core.int> v) { $_setBytes(0, v); }
  $core.bool hasData() => $_has(0);
  void clearData() => clearField(1);

  $44.Encoding get encoding => $_getN(1);
  set encoding($44.Encoding v) { setField(2, v); }
  $core.bool hasEncoding() => $_has(1);
  void clearEncoding() => clearField(2);

  $42.Compression get compression => $_getN(2);
  set compression($42.Compression v) { setField(3, v); }
  $core.bool hasCompression() => $_has(2);
  void clearCompression() => clearField(3);

  $54.Hash get fingerprint => $_getN(3);
  set fingerprint($54.Hash v) { setField(4, v); }
  $core.bool hasFingerprint() => $_has(3);
  void clearFingerprint() => clearField(4);
}

enum EncryptedContainer_Parameters {
  key, 
  keypair, 
  notSet
}

class EncryptedContainer extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, EncryptedContainer_Parameters> _EncryptedContainer_ParametersByTag = {
    4 : EncryptedContainer_Parameters.key,
    5 : EncryptedContainer_Parameters.keypair,
    0 : EncryptedContainer_Parameters.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('EncryptedContainer', package: const $pb.PackageName('opencannabis.crypto'))
    ..a<EncryptedData>(1, 'payload', $pb.PbFieldType.OM, EncryptedData.getDefault, EncryptedData.create)
    ..e<$67.KeyType>(2, 'keying', $pb.PbFieldType.OE, $67.KeyType.SYMMETRIC, $67.KeyType.valueOf, $67.KeyType.values)
    ..a<$67.InitializationVector>(3, 'vector', $pb.PbFieldType.OM, $67.InitializationVector.getDefault, $67.InitializationVector.create)
    ..a<$67.SymmetricKeyParameters>(4, 'key', $pb.PbFieldType.OM, $67.SymmetricKeyParameters.getDefault, $67.SymmetricKeyParameters.create)
    ..a<$67.AsymmetricKeypairParameters>(5, 'keypair', $pb.PbFieldType.OM, $67.AsymmetricKeypairParameters.getDefault, $67.AsymmetricKeypairParameters.create)
    ..oo(0, [4, 5])
    ..hasRequiredFields = false
  ;

  EncryptedContainer() : super();
  EncryptedContainer.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  EncryptedContainer.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  EncryptedContainer clone() => EncryptedContainer()..mergeFromMessage(this);
  EncryptedContainer copyWith(void Function(EncryptedContainer) updates) => super.copyWith((message) => updates(message as EncryptedContainer));
  $pb.BuilderInfo get info_ => _i;
  static EncryptedContainer create() => EncryptedContainer();
  EncryptedContainer createEmptyInstance() => create();
  static $pb.PbList<EncryptedContainer> createRepeated() => $pb.PbList<EncryptedContainer>();
  static EncryptedContainer getDefault() => _defaultInstance ??= create()..freeze();
  static EncryptedContainer _defaultInstance;

  EncryptedContainer_Parameters whichParameters() => _EncryptedContainer_ParametersByTag[$_whichOneof(0)];
  void clearParameters() => clearField($_whichOneof(0));

  EncryptedData get payload => $_getN(0);
  set payload(EncryptedData v) { setField(1, v); }
  $core.bool hasPayload() => $_has(0);
  void clearPayload() => clearField(1);

  $67.KeyType get keying => $_getN(1);
  set keying($67.KeyType v) { setField(2, v); }
  $core.bool hasKeying() => $_has(1);
  void clearKeying() => clearField(2);

  $67.InitializationVector get vector => $_getN(2);
  set vector($67.InitializationVector v) { setField(3, v); }
  $core.bool hasVector() => $_has(2);
  void clearVector() => clearField(3);

  $67.SymmetricKeyParameters get key => $_getN(3);
  set key($67.SymmetricKeyParameters v) { setField(4, v); }
  $core.bool hasKey() => $_has(3);
  void clearKey() => clearField(4);

  $67.AsymmetricKeypairParameters get keypair => $_getN(4);
  set keypair($67.AsymmetricKeypairParameters v) { setField(5, v); }
  $core.bool hasKeypair() => $_has(4);
  void clearKeypair() => clearField(5);
}

