///
//  Generated code. Do not modify.
//  source: media/MediaKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'MediaType.pb.dart' as $25;

class MediaKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaKey', package: const $pb.PackageName('opencannabis.media'))
    ..aOS(1, 'id')
    ..hasRequiredFields = false
  ;

  MediaKey() : super();
  MediaKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaKey clone() => MediaKey()..mergeFromMessage(this);
  MediaKey copyWith(void Function(MediaKey) updates) => super.copyWith((message) => updates(message as MediaKey));
  $pb.BuilderInfo get info_ => _i;
  static MediaKey create() => MediaKey();
  MediaKey createEmptyInstance() => create();
  static $pb.PbList<MediaKey> createRepeated() => $pb.PbList<MediaKey>();
  static MediaKey getDefault() => _defaultInstance ??= create()..freeze();
  static MediaKey _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);
}

class MediaReference extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaReference', package: const $pb.PackageName('opencannabis.media'))
    ..a<MediaKey>(1, 'key', $pb.PbFieldType.OM, MediaKey.getDefault, MediaKey.create)
    ..aOS(2, 'uri')
    ..a<$25.MediaType>(3, 'type', $pb.PbFieldType.OM, $25.MediaType.getDefault, $25.MediaType.create)
    ..hasRequiredFields = false
  ;

  MediaReference() : super();
  MediaReference.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaReference.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaReference clone() => MediaReference()..mergeFromMessage(this);
  MediaReference copyWith(void Function(MediaReference) updates) => super.copyWith((message) => updates(message as MediaReference));
  $pb.BuilderInfo get info_ => _i;
  static MediaReference create() => MediaReference();
  MediaReference createEmptyInstance() => create();
  static $pb.PbList<MediaReference> createRepeated() => $pb.PbList<MediaReference>();
  static MediaReference getDefault() => _defaultInstance ??= create()..freeze();
  static MediaReference _defaultInstance;

  MediaKey get key => $_getN(0);
  set key(MediaKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $core.String get uri => $_getS(1, '');
  set uri($core.String v) { $_setString(1, v); }
  $core.bool hasUri() => $_has(1);
  void clearUri() => clearField(2);

  $25.MediaType get type => $_getN(2);
  set type($25.MediaType v) { setField(3, v); }
  $core.bool hasType() => $_has(2);
  void clearType() => clearField(3);
}

