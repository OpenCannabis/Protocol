///
//  Generated code. Do not modify.
//  source: media/MediaType.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'MediaType.pbenum.dart';

export 'MediaType.pbenum.dart';

enum MediaType_Content {
  imageType, 
  documentType, 
  videoType, 
  notSet
}

class MediaType extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, MediaType_Content> _MediaType_ContentByTag = {
    101 : MediaType_Content.imageType,
    201 : MediaType_Content.documentType,
    301 : MediaType_Content.videoType,
    0 : MediaType_Content.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaType', package: const $pb.PackageName('opencannabis.media'))
    ..e<MediaType_Kind>(1, 'kind', $pb.PbFieldType.OE, MediaType_Kind.LINK, MediaType_Kind.valueOf, MediaType_Kind.values)
    ..e<MediaType_ImageKind>(101, 'imageType', $pb.PbFieldType.OE, MediaType_ImageKind.UNSPECIFIED_IMAGE_TYPE, MediaType_ImageKind.valueOf, MediaType_ImageKind.values)
    ..e<MediaType_DocumentKind>(201, 'documentType', $pb.PbFieldType.OE, MediaType_DocumentKind.UNSPECIFIED_DOCUMENT_TYPE, MediaType_DocumentKind.valueOf, MediaType_DocumentKind.values)
    ..e<MediaType_VideoKind>(301, 'videoType', $pb.PbFieldType.OE, MediaType_VideoKind.UNSPECIFIED_VIDEO_TYPE, MediaType_VideoKind.valueOf, MediaType_VideoKind.values)
    ..oo(0, [101, 201, 301])
    ..hasRequiredFields = false
  ;

  MediaType() : super();
  MediaType.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaType.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaType clone() => MediaType()..mergeFromMessage(this);
  MediaType copyWith(void Function(MediaType) updates) => super.copyWith((message) => updates(message as MediaType));
  $pb.BuilderInfo get info_ => _i;
  static MediaType create() => MediaType();
  MediaType createEmptyInstance() => create();
  static $pb.PbList<MediaType> createRepeated() => $pb.PbList<MediaType>();
  static MediaType getDefault() => _defaultInstance ??= create()..freeze();
  static MediaType _defaultInstance;

  MediaType_Content whichContent() => _MediaType_ContentByTag[$_whichOneof(0)];
  void clearContent() => clearField($_whichOneof(0));

  MediaType_Kind get kind => $_getN(0);
  set kind(MediaType_Kind v) { setField(1, v); }
  $core.bool hasKind() => $_has(0);
  void clearKind() => clearField(1);

  MediaType_ImageKind get imageType => $_getN(1);
  set imageType(MediaType_ImageKind v) { setField(101, v); }
  $core.bool hasImageType() => $_has(1);
  void clearImageType() => clearField(101);

  MediaType_DocumentKind get documentType => $_getN(2);
  set documentType(MediaType_DocumentKind v) { setField(201, v); }
  $core.bool hasDocumentType() => $_has(2);
  void clearDocumentType() => clearField(201);

  MediaType_VideoKind get videoType => $_getN(3);
  set videoType(MediaType_VideoKind v) { setField(301, v); }
  $core.bool hasVideoType() => $_has(3);
  void clearVideoType() => clearField(301);
}

