///
//  Generated code. Do not modify.
//  source: media/MediaOrientation.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const MediaOrientation$json = const {
  '1': 'MediaOrientation',
  '2': const [
    const {'1': 'UP', '2': 0},
    const {'1': 'DOWN', '2': 1},
    const {'1': 'LEFT', '2': 2},
    const {'1': 'RIGHT', '2': 3},
    const {'1': 'UP_MIRRORED', '2': 4},
    const {'1': 'DOWN_MIRRORED', '2': 5},
    const {'1': 'LEFT_MIRRORED', '2': 6},
    const {'1': 'RIGHT_MIRRORED', '2': 7},
  ],
};

