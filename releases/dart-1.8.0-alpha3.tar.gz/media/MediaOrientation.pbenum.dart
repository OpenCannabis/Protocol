///
//  Generated code. Do not modify.
//  source: media/MediaOrientation.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class MediaOrientation extends $pb.ProtobufEnum {
  static const MediaOrientation UP = MediaOrientation._(0, 'UP');
  static const MediaOrientation DOWN = MediaOrientation._(1, 'DOWN');
  static const MediaOrientation LEFT = MediaOrientation._(2, 'LEFT');
  static const MediaOrientation RIGHT = MediaOrientation._(3, 'RIGHT');
  static const MediaOrientation UP_MIRRORED = MediaOrientation._(4, 'UP_MIRRORED');
  static const MediaOrientation DOWN_MIRRORED = MediaOrientation._(5, 'DOWN_MIRRORED');
  static const MediaOrientation LEFT_MIRRORED = MediaOrientation._(6, 'LEFT_MIRRORED');
  static const MediaOrientation RIGHT_MIRRORED = MediaOrientation._(7, 'RIGHT_MIRRORED');

  static const $core.List<MediaOrientation> values = <MediaOrientation> [
    UP,
    DOWN,
    LEFT,
    RIGHT,
    UP_MIRRORED,
    DOWN_MIRRORED,
    LEFT_MIRRORED,
    RIGHT_MIRRORED,
  ];

  static final $core.Map<$core.int, MediaOrientation> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaOrientation valueOf($core.int value) => _byValue[value];

  const MediaOrientation._($core.int v, $core.String n) : super(v, n);
}

