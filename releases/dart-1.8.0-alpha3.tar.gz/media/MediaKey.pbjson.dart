///
//  Generated code. Do not modify.
//  source: media/MediaKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const MediaKey$json = const {
  '1': 'MediaKey',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'id'},
  ],
};

const MediaReference$json = const {
  '1': 'MediaReference',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.media.MediaKey', '8': const {}, '10': 'key'},
    const {'1': 'uri', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'uri'},
    const {'1': 'type', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.media.MediaType', '8': const {}, '10': 'type'},
  ],
};

