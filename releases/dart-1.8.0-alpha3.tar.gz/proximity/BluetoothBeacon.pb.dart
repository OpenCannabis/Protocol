///
//  Generated code. Do not modify.
//  source: proximity/BluetoothBeacon.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../temporal/Instant.pb.dart' as $0;
import '../geo/Location.pb.dart' as $5;
import '../geo/Distance.pb.dart' as $2;

class BluetoothBeacon extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('BluetoothBeacon', package: const $pb.PackageName('opencannabis.proximity'))
    ..aOS(1, 'uuid')
    ..a<$core.int>(2, 'major', $pb.PbFieldType.OU3)
    ..a<$core.int>(3, 'minor', $pb.PbFieldType.OU3)
    ..a<$0.Instant>(4, 'seen', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$5.Location>(5, 'location', $pb.PbFieldType.OM, $5.Location.getDefault, $5.Location.create)
    ..a<$2.LocationAccuracy>(6, 'accuracy', $pb.PbFieldType.OM, $2.LocationAccuracy.getDefault, $2.LocationAccuracy.create)
    ..hasRequiredFields = false
  ;

  BluetoothBeacon() : super();
  BluetoothBeacon.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BluetoothBeacon.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BluetoothBeacon clone() => BluetoothBeacon()..mergeFromMessage(this);
  BluetoothBeacon copyWith(void Function(BluetoothBeacon) updates) => super.copyWith((message) => updates(message as BluetoothBeacon));
  $pb.BuilderInfo get info_ => _i;
  static BluetoothBeacon create() => BluetoothBeacon();
  BluetoothBeacon createEmptyInstance() => create();
  static $pb.PbList<BluetoothBeacon> createRepeated() => $pb.PbList<BluetoothBeacon>();
  static BluetoothBeacon getDefault() => _defaultInstance ??= create()..freeze();
  static BluetoothBeacon _defaultInstance;

  $core.String get uuid => $_getS(0, '');
  set uuid($core.String v) { $_setString(0, v); }
  $core.bool hasUuid() => $_has(0);
  void clearUuid() => clearField(1);

  $core.int get major => $_get(1, 0);
  set major($core.int v) { $_setUnsignedInt32(1, v); }
  $core.bool hasMajor() => $_has(1);
  void clearMajor() => clearField(2);

  $core.int get minor => $_get(2, 0);
  set minor($core.int v) { $_setUnsignedInt32(2, v); }
  $core.bool hasMinor() => $_has(2);
  void clearMinor() => clearField(3);

  $0.Instant get seen => $_getN(3);
  set seen($0.Instant v) { setField(4, v); }
  $core.bool hasSeen() => $_has(3);
  void clearSeen() => clearField(4);

  $5.Location get location => $_getN(4);
  set location($5.Location v) { setField(5, v); }
  $core.bool hasLocation() => $_has(4);
  void clearLocation() => clearField(5);

  $2.LocationAccuracy get accuracy => $_getN(5);
  set accuracy($2.LocationAccuracy v) { setField(6, v); }
  $core.bool hasAccuracy() => $_has(5);
  void clearAccuracy() => clearField(6);
}

