///
//  Generated code. Do not modify.
//  source: proximity/BluetoothBeacon.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const BluetoothBeacon$json = const {
  '1': 'BluetoothBeacon',
  '2': const [
    const {'1': 'uuid', '3': 1, '4': 1, '5': 9, '10': 'uuid'},
    const {'1': 'major', '3': 2, '4': 1, '5': 13, '10': 'major'},
    const {'1': 'minor', '3': 3, '4': 1, '5': 13, '10': 'minor'},
    const {'1': 'seen', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'seen'},
    const {'1': 'location', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.geo.Location', '10': 'location'},
    const {'1': 'accuracy', '3': 6, '4': 1, '5': 11, '6': '.opencannabis.geo.LocationAccuracy', '10': 'accuracy'},
  ],
};

