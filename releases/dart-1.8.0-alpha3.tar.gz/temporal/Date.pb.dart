///
//  Generated code. Do not modify.
//  source: temporal/Date.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

enum Date_Spec {
  iso8601, 
  notSet
}

class Date extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Date_Spec> _Date_SpecByTag = {
    1 : Date_Spec.iso8601,
    0 : Date_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Date', package: const $pb.PackageName('opencannabis.temporal'))
    ..aOS(1, 'iso8601')
    ..oo(0, [1])
    ..hasRequiredFields = false
  ;

  Date() : super();
  Date.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Date.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Date clone() => Date()..mergeFromMessage(this);
  Date copyWith(void Function(Date) updates) => super.copyWith((message) => updates(message as Date));
  $pb.BuilderInfo get info_ => _i;
  static Date create() => Date();
  Date createEmptyInstance() => create();
  static $pb.PbList<Date> createRepeated() => $pb.PbList<Date>();
  static Date getDefault() => _defaultInstance ??= create()..freeze();
  static Date _defaultInstance;

  Date_Spec whichSpec() => _Date_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  $core.String get iso8601 => $_getS(0, '');
  set iso8601($core.String v) { $_setString(0, v); }
  $core.bool hasIso8601() => $_has(0);
  void clearIso8601() => clearField(1);
}

