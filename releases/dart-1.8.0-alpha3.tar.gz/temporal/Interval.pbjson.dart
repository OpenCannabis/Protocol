///
//  Generated code. Do not modify.
//  source: temporal/Interval.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Interval$json = const {
  '1': 'Interval',
  '2': const [
    const {'1': 'MINUTELY', '2': 0},
    const {'1': 'HOURLY', '2': 1},
    const {'1': 'DAILY', '2': 2},
    const {'1': 'WEEKLY', '2': 3},
    const {'1': 'MONTHLY', '2': 4},
  ],
};

const TimeInterval$json = const {
  '1': 'TimeInterval',
  '2': const [
    const {'1': 'interval', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.temporal.Interval', '8': const {}, '10': 'interval'},
    const {'1': 'every', '3': 2, '4': 1, '5': 13, '8': const {}, '10': 'every'},
  ],
};

