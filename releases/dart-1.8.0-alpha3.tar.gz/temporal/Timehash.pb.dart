///
//  Generated code. Do not modify.
//  source: temporal/Timehash.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class Timehash extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Timehash', package: const $pb.PackageName('opencannabis.temporal'))
    ..pPS(1, 'component')
    ..hasRequiredFields = false
  ;

  Timehash() : super();
  Timehash.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Timehash.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Timehash clone() => Timehash()..mergeFromMessage(this);
  Timehash copyWith(void Function(Timehash) updates) => super.copyWith((message) => updates(message as Timehash));
  $pb.BuilderInfo get info_ => _i;
  static Timehash create() => Timehash();
  Timehash createEmptyInstance() => create();
  static $pb.PbList<Timehash> createRepeated() => $pb.PbList<Timehash>();
  static Timehash getDefault() => _defaultInstance ??= create()..freeze();
  static Timehash _defaultInstance;

  $core.List<$core.String> get component => $_getList(0);
}

