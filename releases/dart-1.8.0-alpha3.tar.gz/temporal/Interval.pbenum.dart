///
//  Generated code. Do not modify.
//  source: temporal/Interval.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Interval extends $pb.ProtobufEnum {
  static const Interval MINUTELY = Interval._(0, 'MINUTELY');
  static const Interval HOURLY = Interval._(1, 'HOURLY');
  static const Interval DAILY = Interval._(2, 'DAILY');
  static const Interval WEEKLY = Interval._(3, 'WEEKLY');
  static const Interval MONTHLY = Interval._(4, 'MONTHLY');

  static const $core.List<Interval> values = <Interval> [
    MINUTELY,
    HOURLY,
    DAILY,
    WEEKLY,
    MONTHLY,
  ];

  static final $core.Map<$core.int, Interval> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Interval valueOf($core.int value) => _byValue[value];

  const Interval._($core.int v, $core.String n) : super(v, n);
}

