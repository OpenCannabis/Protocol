///
//  Generated code. Do not modify.
//  source: temporal/Duration.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class TimeUnit extends $pb.ProtobufEnum {
  static const TimeUnit MILLISECONDS = TimeUnit._(0, 'MILLISECONDS');
  static const TimeUnit MICROSECONDS = TimeUnit._(1, 'MICROSECONDS');
  static const TimeUnit SECONDS = TimeUnit._(2, 'SECONDS');
  static const TimeUnit MINUTES = TimeUnit._(3, 'MINUTES');
  static const TimeUnit HOURS = TimeUnit._(4, 'HOURS');
  static const TimeUnit DAYS = TimeUnit._(5, 'DAYS');
  static const TimeUnit WEEKS = TimeUnit._(6, 'WEEKS');
  static const TimeUnit MONTHS = TimeUnit._(7, 'MONTHS');
  static const TimeUnit YEARS = TimeUnit._(8, 'YEARS');

  static const $core.List<TimeUnit> values = <TimeUnit> [
    MILLISECONDS,
    MICROSECONDS,
    SECONDS,
    MINUTES,
    HOURS,
    DAYS,
    WEEKS,
    MONTHS,
    YEARS,
  ];

  static final $core.Map<$core.int, TimeUnit> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TimeUnit valueOf($core.int value) => _byValue[value];

  const TimeUnit._($core.int v, $core.String n) : super(v, n);
}

