///
//  Generated code. Do not modify.
//  source: temporal/Interval.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Interval.pbenum.dart';

export 'Interval.pbenum.dart';

class TimeInterval extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TimeInterval', package: const $pb.PackageName('opencannabis.temporal'))
    ..e<Interval>(1, 'interval', $pb.PbFieldType.OE, Interval.MINUTELY, Interval.valueOf, Interval.values)
    ..a<$core.int>(2, 'every', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  TimeInterval() : super();
  TimeInterval.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TimeInterval.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TimeInterval clone() => TimeInterval()..mergeFromMessage(this);
  TimeInterval copyWith(void Function(TimeInterval) updates) => super.copyWith((message) => updates(message as TimeInterval));
  $pb.BuilderInfo get info_ => _i;
  static TimeInterval create() => TimeInterval();
  TimeInterval createEmptyInstance() => create();
  static $pb.PbList<TimeInterval> createRepeated() => $pb.PbList<TimeInterval>();
  static TimeInterval getDefault() => _defaultInstance ??= create()..freeze();
  static TimeInterval _defaultInstance;

  Interval get interval => $_getN(0);
  set interval(Interval v) { setField(1, v); }
  $core.bool hasInterval() => $_has(0);
  void clearInterval() => clearField(1);

  $core.int get every => $_get(1, 0);
  set every($core.int v) { $_setUnsignedInt32(1, v); }
  $core.bool hasEvery() => $_has(1);
  void clearEvery() => clearField(2);
}

