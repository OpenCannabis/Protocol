///
//  Generated code. Do not modify.
//  source: temporal/Time.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

enum Time_Spec {
  iso8601, 
  notSet
}

class Time extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Time_Spec> _Time_SpecByTag = {
    1 : Time_Spec.iso8601,
    0 : Time_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Time', package: const $pb.PackageName('opencannabis.temporal'))
    ..aOS(1, 'iso8601')
    ..oo(0, [1])
    ..hasRequiredFields = false
  ;

  Time() : super();
  Time.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Time.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Time clone() => Time()..mergeFromMessage(this);
  Time copyWith(void Function(Time) updates) => super.copyWith((message) => updates(message as Time));
  $pb.BuilderInfo get info_ => _i;
  static Time create() => Time();
  Time createEmptyInstance() => create();
  static $pb.PbList<Time> createRepeated() => $pb.PbList<Time>();
  static Time getDefault() => _defaultInstance ??= create()..freeze();
  static Time _defaultInstance;

  Time_Spec whichSpec() => _Time_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  $core.String get iso8601 => $_getS(0, '');
  set iso8601($core.String v) { $_setString(0, v); }
  $core.bool hasIso8601() => $_has(0);
  void clearIso8601() => clearField(1);
}

