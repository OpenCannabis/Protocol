///
//  Generated code. Do not modify.
//  source: partner/PartnerKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class PartnerKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PartnerKey', package: const $pb.PackageName('bloombox.partner'))
    ..aOS(1, 'code')
    ..hasRequiredFields = false
  ;

  PartnerKey() : super();
  PartnerKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PartnerKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PartnerKey clone() => PartnerKey()..mergeFromMessage(this);
  PartnerKey copyWith(void Function(PartnerKey) updates) => super.copyWith((message) => updates(message as PartnerKey));
  $pb.BuilderInfo get info_ => _i;
  static PartnerKey create() => PartnerKey();
  PartnerKey createEmptyInstance() => create();
  static $pb.PbList<PartnerKey> createRepeated() => $pb.PbList<PartnerKey>();
  static PartnerKey getDefault() => _defaultInstance ??= create()..freeze();
  static PartnerKey _defaultInstance;

  $core.String get code => $_getS(0, '');
  set code($core.String v) { $_setString(0, v); }
  $core.bool hasCode() => $_has(0);
  void clearCode() => clearField(1);
}

