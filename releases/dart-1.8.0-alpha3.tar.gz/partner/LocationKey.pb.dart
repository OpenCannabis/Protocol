///
//  Generated code. Do not modify.
//  source: partner/LocationKey.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'PartnerKey.pb.dart' as $28;

class LocationKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('LocationKey', package: const $pb.PackageName('bloombox.partner'))
    ..a<$28.PartnerKey>(1, 'partner', $pb.PbFieldType.OM, $28.PartnerKey.getDefault, $28.PartnerKey.create)
    ..aOS(2, 'code')
    ..hasRequiredFields = false
  ;

  LocationKey() : super();
  LocationKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  LocationKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  LocationKey clone() => LocationKey()..mergeFromMessage(this);
  LocationKey copyWith(void Function(LocationKey) updates) => super.copyWith((message) => updates(message as LocationKey));
  $pb.BuilderInfo get info_ => _i;
  static LocationKey create() => LocationKey();
  LocationKey createEmptyInstance() => create();
  static $pb.PbList<LocationKey> createRepeated() => $pb.PbList<LocationKey>();
  static LocationKey getDefault() => _defaultInstance ??= create()..freeze();
  static LocationKey _defaultInstance;

  $28.PartnerKey get partner => $_getN(0);
  set partner($28.PartnerKey v) { setField(1, v); }
  $core.bool hasPartner() => $_has(0);
  void clearPartner() => clearField(1);

  $core.String get code => $_getS(1, '');
  set code($core.String v) { $_setString(1, v); }
  $core.bool hasCode() => $_has(1);
  void clearCode() => clearField(2);
}

