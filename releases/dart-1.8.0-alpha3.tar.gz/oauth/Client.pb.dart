///
//  Generated code. Do not modify.
//  source: oauth/Client.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../media/MediaItem.pb.dart' as $27;
import 'AuthorizationScope.pb.dart' as $72;
import '../temporal/Instant.pb.dart' as $0;

import 'Client.pbenum.dart';

export 'Client.pbenum.dart';

class Client extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Client', package: const $pb.PackageName('opencannabis.oauth'))
    ..aOS(1, 'id')
    ..aOS(2, 'secret')
    ..aOS(3, 'name')
    ..pPS(4, 'contact')
    ..pc<GrantType>(5, 'grantTypes', $pb.PbFieldType.PE, null, GrantType.valueOf, GrantType.values)
    ..a<$27.MediaItem>(6, 'branding', $pb.PbFieldType.OM, $27.MediaItem.getDefault, $27.MediaItem.create)
    ..aOS(7, 'owner')
    ..a<$27.MediaItem>(8, 'policy', $pb.PbFieldType.OM, $27.MediaItem.getDefault, $27.MediaItem.create)
    ..a<$27.MediaItem>(9, 'terms', $pb.PbFieldType.OM, $27.MediaItem.getDefault, $27.MediaItem.create)
    ..aOB(10, 'public')
    ..pPS(11, 'redirectUri')
    ..pc<ResponseType>(12, 'responseType', $pb.PbFieldType.PE, null, ResponseType.valueOf, ResponseType.values)
    ..pc<$72.AuthorizationScope>(13, 'scope', $pb.PbFieldType.PM,$72.AuthorizationScope.create)
    ..hasRequiredFields = false
  ;

  Client() : super();
  Client.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Client.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Client clone() => Client()..mergeFromMessage(this);
  Client copyWith(void Function(Client) updates) => super.copyWith((message) => updates(message as Client));
  $pb.BuilderInfo get info_ => _i;
  static Client create() => Client();
  Client createEmptyInstance() => create();
  static $pb.PbList<Client> createRepeated() => $pb.PbList<Client>();
  static Client getDefault() => _defaultInstance ??= create()..freeze();
  static Client _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $core.String get secret => $_getS(1, '');
  set secret($core.String v) { $_setString(1, v); }
  $core.bool hasSecret() => $_has(1);
  void clearSecret() => clearField(2);

  $core.String get name => $_getS(2, '');
  set name($core.String v) { $_setString(2, v); }
  $core.bool hasName() => $_has(2);
  void clearName() => clearField(3);

  $core.List<$core.String> get contact => $_getList(3);

  $core.List<GrantType> get grantTypes => $_getList(4);

  $27.MediaItem get branding => $_getN(5);
  set branding($27.MediaItem v) { setField(6, v); }
  $core.bool hasBranding() => $_has(5);
  void clearBranding() => clearField(6);

  $core.String get owner => $_getS(6, '');
  set owner($core.String v) { $_setString(6, v); }
  $core.bool hasOwner() => $_has(6);
  void clearOwner() => clearField(7);

  $27.MediaItem get policy => $_getN(7);
  set policy($27.MediaItem v) { setField(8, v); }
  $core.bool hasPolicy() => $_has(7);
  void clearPolicy() => clearField(8);

  $27.MediaItem get terms => $_getN(8);
  set terms($27.MediaItem v) { setField(9, v); }
  $core.bool hasTerms() => $_has(8);
  void clearTerms() => clearField(9);

  $core.bool get public => $_get(9, false);
  set public($core.bool v) { $_setBool(9, v); }
  $core.bool hasPublic() => $_has(9);
  void clearPublic() => clearField(10);

  $core.List<$core.String> get redirectUri => $_getList(10);

  $core.List<ResponseType> get responseType => $_getList(11);

  $core.List<$72.AuthorizationScope> get scope => $_getList(12);
}

class Consent extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Consent', package: const $pb.PackageName('opencannabis.oauth'))
    ..aOS(1, 'id')
    ..aOS(2, 'clientId')
    ..a<$0.Instant>(3, 'expiresAt', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..aOS(4, 'redirectUri')
    ..pPS(5, 'requestedScope')
    ..hasRequiredFields = false
  ;

  Consent() : super();
  Consent.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Consent.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Consent clone() => Consent()..mergeFromMessage(this);
  Consent copyWith(void Function(Consent) updates) => super.copyWith((message) => updates(message as Consent));
  $pb.BuilderInfo get info_ => _i;
  static Consent create() => Consent();
  Consent createEmptyInstance() => create();
  static $pb.PbList<Consent> createRepeated() => $pb.PbList<Consent>();
  static Consent getDefault() => _defaultInstance ??= create()..freeze();
  static Consent _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $core.String get clientId => $_getS(1, '');
  set clientId($core.String v) { $_setString(1, v); }
  $core.bool hasClientId() => $_has(1);
  void clearClientId() => clearField(2);

  $0.Instant get expiresAt => $_getN(2);
  set expiresAt($0.Instant v) { setField(3, v); }
  $core.bool hasExpiresAt() => $_has(2);
  void clearExpiresAt() => clearField(3);

  $core.String get redirectUri => $_getS(3, '');
  set redirectUri($core.String v) { $_setString(3, v); }
  $core.bool hasRedirectUri() => $_has(3);
  void clearRedirectUri() => clearField(4);

  $core.List<$core.String> get requestedScope => $_getList(4);
}

class ConsentTicket extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ConsentTicket', package: const $pb.PackageName('opencannabis.oauth'))
    ..a<Client>(1, 'client', $pb.PbFieldType.OM, Client.getDefault, Client.create)
    ..a<Consent>(2, 'consent', $pb.PbFieldType.OM, Consent.getDefault, Consent.create)
    ..hasRequiredFields = false
  ;

  ConsentTicket() : super();
  ConsentTicket.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ConsentTicket.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ConsentTicket clone() => ConsentTicket()..mergeFromMessage(this);
  ConsentTicket copyWith(void Function(ConsentTicket) updates) => super.copyWith((message) => updates(message as ConsentTicket));
  $pb.BuilderInfo get info_ => _i;
  static ConsentTicket create() => ConsentTicket();
  ConsentTicket createEmptyInstance() => create();
  static $pb.PbList<ConsentTicket> createRepeated() => $pb.PbList<ConsentTicket>();
  static ConsentTicket getDefault() => _defaultInstance ??= create()..freeze();
  static ConsentTicket _defaultInstance;

  Client get client => $_getN(0);
  set client(Client v) { setField(1, v); }
  $core.bool hasClient() => $_has(0);
  void clearClient() => clearField(1);

  Consent get consent => $_getN(1);
  set consent(Consent v) { setField(2, v); }
  $core.bool hasConsent() => $_has(1);
  void clearConsent() => clearField(2);
}

