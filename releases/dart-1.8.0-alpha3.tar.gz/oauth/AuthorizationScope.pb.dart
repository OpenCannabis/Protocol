///
//  Generated code. Do not modify.
//  source: oauth/AuthorizationScope.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class AuthorizationScope extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('AuthorizationScope', package: const $pb.PackageName('opencannabis.oauth'))
    ..aOS(1, 'id')
    ..aOS(2, 'label')
    ..aOS(3, 'uri')
    ..aOS(4, 'icon')
    ..hasRequiredFields = false
  ;

  AuthorizationScope() : super();
  AuthorizationScope.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  AuthorizationScope.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  AuthorizationScope clone() => AuthorizationScope()..mergeFromMessage(this);
  AuthorizationScope copyWith(void Function(AuthorizationScope) updates) => super.copyWith((message) => updates(message as AuthorizationScope));
  $pb.BuilderInfo get info_ => _i;
  static AuthorizationScope create() => AuthorizationScope();
  AuthorizationScope createEmptyInstance() => create();
  static $pb.PbList<AuthorizationScope> createRepeated() => $pb.PbList<AuthorizationScope>();
  static AuthorizationScope getDefault() => _defaultInstance ??= create()..freeze();
  static AuthorizationScope _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $core.String get label => $_getS(1, '');
  set label($core.String v) { $_setString(1, v); }
  $core.bool hasLabel() => $_has(1);
  void clearLabel() => clearField(2);

  $core.String get uri => $_getS(2, '');
  set uri($core.String v) { $_setString(2, v); }
  $core.bool hasUri() => $_has(2);
  void clearUri() => clearField(3);

  $core.String get icon => $_getS(3, '');
  set icon($core.String v) { $_setString(3, v); }
  $core.bool hasIcon() => $_has(3);
  void clearIcon() => clearField(4);
}

