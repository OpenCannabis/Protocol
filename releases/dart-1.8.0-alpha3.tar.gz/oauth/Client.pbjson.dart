///
//  Generated code. Do not modify.
//  source: oauth/Client.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ResponseType$json = const {
  '1': 'ResponseType',
  '2': const [
    const {'1': 'UNSPECIFIED_RESPONSE_TYPE', '2': 0},
    const {'1': 'TOKEN', '2': 1},
    const {'1': 'CODE', '2': 2},
    const {'1': 'ID_TOKEN', '2': 3},
  ],
};

const GrantType$json = const {
  '1': 'GrantType',
  '2': const [
    const {'1': 'UNSPECIFIED_GRANT_TYPE', '2': 0},
    const {'1': 'AUTHORIZATION_CODE', '2': 1},
    const {'1': 'REFRESH_TOKEN', '2': 2},
    const {'1': 'CLIENT_CREDENTIALS', '2': 3},
  ],
};

const Client$json = const {
  '1': 'Client',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'secret', '3': 2, '4': 1, '5': 9, '10': 'secret'},
    const {'1': 'name', '3': 3, '4': 1, '5': 9, '10': 'name'},
    const {'1': 'contact', '3': 4, '4': 3, '5': 9, '10': 'contact'},
    const {'1': 'grant_types', '3': 5, '4': 3, '5': 14, '6': '.opencannabis.oauth.GrantType', '10': 'grantTypes'},
    const {'1': 'branding', '3': 6, '4': 1, '5': 11, '6': '.opencannabis.media.MediaItem', '10': 'branding'},
    const {'1': 'owner', '3': 7, '4': 1, '5': 9, '10': 'owner'},
    const {'1': 'policy', '3': 8, '4': 1, '5': 11, '6': '.opencannabis.media.MediaItem', '10': 'policy'},
    const {'1': 'terms', '3': 9, '4': 1, '5': 11, '6': '.opencannabis.media.MediaItem', '10': 'terms'},
    const {'1': 'public', '3': 10, '4': 1, '5': 8, '10': 'public'},
    const {'1': 'redirect_uri', '3': 11, '4': 3, '5': 9, '10': 'redirectUri'},
    const {'1': 'response_type', '3': 12, '4': 3, '5': 14, '6': '.opencannabis.oauth.ResponseType', '10': 'responseType'},
    const {'1': 'scope', '3': 13, '4': 3, '5': 11, '6': '.opencannabis.oauth.AuthorizationScope', '10': 'scope'},
  ],
};

const Consent$json = const {
  '1': 'Consent',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'client_id', '3': 2, '4': 1, '5': 9, '10': 'clientId'},
    const {'1': 'expires_at', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'expiresAt'},
    const {'1': 'redirect_uri', '3': 4, '4': 1, '5': 9, '10': 'redirectUri'},
    const {'1': 'requested_scope', '3': 5, '4': 3, '5': 9, '10': 'requestedScope'},
  ],
};

const ConsentTicket$json = const {
  '1': 'ConsentTicket',
  '2': const [
    const {'1': 'client', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.oauth.Client', '10': 'client'},
    const {'1': 'consent', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.oauth.Consent', '10': 'consent'},
  ],
};

