///
//  Generated code. Do not modify.
//  source: structs/Genetics.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Genetics$json = const {
  '1': 'Genetics',
  '2': const [
    const {'1': 'male', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductReference', '10': 'male'},
    const {'1': 'female', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.base.ProductReference', '10': 'female'},
  ],
};

