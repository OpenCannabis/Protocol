///
//  Generated code. Do not modify.
//  source: structs/Version.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

enum VersionSpec_Spec {
  name, 
  notSet
}

class VersionSpec extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, VersionSpec_Spec> _VersionSpec_SpecByTag = {
    1 : VersionSpec_Spec.name,
    0 : VersionSpec_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('VersionSpec', package: const $pb.PackageName('opencannabis.structs'))
    ..aOS(1, 'name')
    ..oo(0, [1])
    ..hasRequiredFields = false
  ;

  VersionSpec() : super();
  VersionSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  VersionSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  VersionSpec clone() => VersionSpec()..mergeFromMessage(this);
  VersionSpec copyWith(void Function(VersionSpec) updates) => super.copyWith((message) => updates(message as VersionSpec));
  $pb.BuilderInfo get info_ => _i;
  static VersionSpec create() => VersionSpec();
  VersionSpec createEmptyInstance() => create();
  static $pb.PbList<VersionSpec> createRepeated() => $pb.PbList<VersionSpec>();
  static VersionSpec getDefault() => _defaultInstance ??= create()..freeze();
  static VersionSpec _defaultInstance;

  VersionSpec_Spec whichSpec() => _VersionSpec_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  $core.String get name => $_getS(0, '');
  set name($core.String v) { $_setString(0, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);
}

