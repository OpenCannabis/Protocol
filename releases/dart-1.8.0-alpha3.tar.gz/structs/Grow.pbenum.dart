///
//  Generated code. Do not modify.
//  source: structs/Grow.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Grow extends $pb.ProtobufEnum {
  static const Grow GENERIC = Grow._(0, 'GENERIC');
  static const Grow INDOOR = Grow._(1, 'INDOOR');
  static const Grow GREENHOUSE = Grow._(2, 'GREENHOUSE');
  static const Grow OUTDOOR = Grow._(3, 'OUTDOOR');

  static const $core.List<Grow> values = <Grow> [
    GENERIC,
    INDOOR,
    GREENHOUSE,
    OUTDOOR,
  ];

  static final $core.Map<$core.int, Grow> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Grow valueOf($core.int value) => _byValue[value];

  const Grow._($core.int v, $core.String n) : super(v, n);
}

