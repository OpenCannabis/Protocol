///
//  Generated code. Do not modify.
//  source: structs/ProductFlags.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ProductFlag$json = const {
  '1': 'ProductFlag',
  '2': const [
    const {'1': 'VISIBLE', '2': 0},
    const {'1': 'HIDDEN', '2': 1},
    const {'1': 'PREMIUM', '2': 2},
    const {'1': 'FEATURED', '2': 3},
    const {'1': 'EXCLUSIVE', '2': 4},
    const {'1': 'IN_HOUSE', '2': 5},
    const {'1': 'LAST_CHANCE', '2': 6},
    const {'1': 'LIMITED_TIME', '2': 7},
    const {'1': 'LOCAL', '2': 8},
    const {'1': 'DELETED', '2': 9},
    const {'1': 'ON_SALE', '2': 20},
  ],
};

