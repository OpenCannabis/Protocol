///
//  Generated code. Do not modify.
//  source: structs/labtesting/Terpenes.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Terpene$json = const {
  '1': 'Terpene',
  '2': const [
    const {'1': 'CAMPHENE', '2': 0},
    const {'1': 'CARENE', '2': 1},
    const {'1': 'BETA_CARYOPHYLLENE', '2': 2},
    const {'1': 'CARYOPHYLLENE_OXIDE', '2': 3},
    const {'1': 'EUCALYPTOL', '2': 4},
    const {'1': 'FENCHOL', '2': 5},
    const {'1': 'ALPHA_HUMULENE', '2': 6},
    const {'1': 'LIMONENE', '2': 7},
    const {'1': 'LINALOOL', '2': 8},
    const {'1': 'MYRCENE', '2': 9},
    const {'1': 'ALPHA_OCIMENE', '2': 10},
    const {'1': 'BETA_OCIMENE', '2': 11},
    const {'1': 'ALPHA_PHELLANDRENE', '2': 12},
    const {'1': 'ALPHA_PINENE', '2': 13},
    const {'1': 'BETA_PINENE', '2': 14},
    const {'1': 'ALPHA_TERPINEOL', '2': 15},
    const {'1': 'ALPHA_TERPININE', '2': 16},
    const {'1': 'GAMMA_TERPININE', '2': 17},
    const {'1': 'TERPINOLENE', '2': 18},
    const {'1': 'VALENCENE', '2': 19},
    const {'1': 'GERANIOL', '2': 20},
    const {'1': 'PHELLANDRENE', '2': 21},
    const {'1': 'BORNEOL', '2': 22},
    const {'1': 'ISOBORNEOL', '2': 23},
    const {'1': 'BISABOLOL', '2': 24},
    const {'1': 'PHYTOL', '2': 25},
    const {'1': 'SABINENE', '2': 26},
    const {'1': 'CAMPHOR', '2': 27},
    const {'1': 'MENTHOL', '2': 28},
    const {'1': 'CEDRENE', '2': 29},
    const {'1': 'NEROL', '2': 30},
    const {'1': 'NEROLIDOL', '2': 31},
    const {'1': 'GUAIOL', '2': 32},
    const {'1': 'ISOPULEGOL', '2': 33},
    const {'1': 'GERANYL_ACETATE', '2': 34},
    const {'1': 'CYMENE', '2': 35},
    const {'1': 'PULEGONE', '2': 36},
    const {'1': 'CINEOLE', '2': 37},
    const {'1': 'FENCHONE', '2': 38},
    const {'1': 'TERPINENE', '2': 39},
    const {'1': 'CITRONELLOL', '2': 40},
    const {'1': 'DELTA_3_CARENE', '2': 41},
  ],
};

