///
//  Generated code. Do not modify.
//  source: structs/labtesting/TestValue.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../../media/MediaItem.pb.dart' as $27;

import 'TestValue.pbenum.dart';

export 'TestValue.pbenum.dart';

class TestValue_TestError extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TestValue.TestError', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..e<TestErrorType>(1, 'type', $pb.PbFieldType.OE, TestErrorType.PERCENT, TestErrorType.valueOf, TestErrorType.values)
    ..a<$core.double>(2, 'value', $pb.PbFieldType.OD)
    ..hasRequiredFields = false
  ;

  TestValue_TestError() : super();
  TestValue_TestError.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestValue_TestError.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestValue_TestError clone() => TestValue_TestError()..mergeFromMessage(this);
  TestValue_TestError copyWith(void Function(TestValue_TestError) updates) => super.copyWith((message) => updates(message as TestValue_TestError));
  $pb.BuilderInfo get info_ => _i;
  static TestValue_TestError create() => TestValue_TestError();
  TestValue_TestError createEmptyInstance() => create();
  static $pb.PbList<TestValue_TestError> createRepeated() => $pb.PbList<TestValue_TestError>();
  static TestValue_TestError getDefault() => _defaultInstance ??= create()..freeze();
  static TestValue_TestError _defaultInstance;

  TestErrorType get type => $_getN(0);
  set type(TestErrorType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.double get value => $_getN(1);
  set value($core.double v) { $_setDouble(1, v); }
  $core.bool hasValue() => $_has(1);
  void clearValue() => clearField(2);
}

enum TestValue_Value {
  measurement, 
  present, 
  notSet
}

class TestValue extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, TestValue_Value> _TestValue_ValueByTag = {
    10 : TestValue_Value.measurement,
    20 : TestValue_Value.present,
    0 : TestValue_Value.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TestValue', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..e<TestValueType>(1, 'type', $pb.PbFieldType.OE, TestValueType.MILLIGRAMS, TestValueType.valueOf, TestValueType.values)
    ..a<TestValue_TestError>(2, 'error', $pb.PbFieldType.OM, TestValue_TestError.getDefault, TestValue_TestError.create)
    ..a<$core.double>(10, 'measurement', $pb.PbFieldType.OD)
    ..aOB(20, 'present')
    ..oo(0, [10, 20])
    ..hasRequiredFields = false
  ;

  TestValue() : super();
  TestValue.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestValue.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestValue clone() => TestValue()..mergeFromMessage(this);
  TestValue copyWith(void Function(TestValue) updates) => super.copyWith((message) => updates(message as TestValue));
  $pb.BuilderInfo get info_ => _i;
  static TestValue create() => TestValue();
  TestValue createEmptyInstance() => create();
  static $pb.PbList<TestValue> createRepeated() => $pb.PbList<TestValue>();
  static TestValue getDefault() => _defaultInstance ??= create()..freeze();
  static TestValue _defaultInstance;

  TestValue_Value whichValue() => _TestValue_ValueByTag[$_whichOneof(0)];
  void clearValue() => clearField($_whichOneof(0));

  TestValueType get type => $_getN(0);
  set type(TestValueType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  TestValue_TestError get error => $_getN(1);
  set error(TestValue_TestError v) { setField(2, v); }
  $core.bool hasError() => $_has(1);
  void clearError() => clearField(2);

  $core.double get measurement => $_getN(2);
  set measurement($core.double v) { $_setDouble(2, v); }
  $core.bool hasMeasurement() => $_has(2);
  void clearMeasurement() => clearField(10);

  $core.bool get present => $_get(3, false);
  set present($core.bool v) { $_setBool(3, v); }
  $core.bool hasPresent() => $_has(3);
  void clearPresent() => clearField(20);
}

class TestMedia extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TestMedia', package: const $pb.PackageName('opencannabis.structs.labtesting'))
    ..e<TestMediaType>(1, 'type', $pb.PbFieldType.OE, TestMediaType.CERTIFICATE, TestMediaType.valueOf, TestMediaType.values)
    ..a<$27.MediaItem>(2, 'mediaItem', $pb.PbFieldType.OM, $27.MediaItem.getDefault, $27.MediaItem.create)
    ..hasRequiredFields = false
  ;

  TestMedia() : super();
  TestMedia.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TestMedia.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TestMedia clone() => TestMedia()..mergeFromMessage(this);
  TestMedia copyWith(void Function(TestMedia) updates) => super.copyWith((message) => updates(message as TestMedia));
  $pb.BuilderInfo get info_ => _i;
  static TestMedia create() => TestMedia();
  TestMedia createEmptyInstance() => create();
  static $pb.PbList<TestMedia> createRepeated() => $pb.PbList<TestMedia>();
  static TestMedia getDefault() => _defaultInstance ??= create()..freeze();
  static TestMedia _defaultInstance;

  TestMediaType get type => $_getN(0);
  set type(TestMediaType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $27.MediaItem get mediaItem => $_getN(1);
  set mediaItem($27.MediaItem v) { setField(2, v); }
  $core.bool hasMediaItem() => $_has(1);
  void clearMediaItem() => clearField(2);
}

