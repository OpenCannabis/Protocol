///
//  Generated code. Do not modify.
//  source: structs/labtesting/TestValue.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class TestValueType extends $pb.ProtobufEnum {
  static const TestValueType MILLIGRAMS = TestValueType._(0, 'MILLIGRAMS');
  static const TestValueType PERCENTAGE = TestValueType._(1, 'PERCENTAGE');
  static const TestValueType PRESENCE = TestValueType._(2, 'PRESENCE');
  static const TestValueType MILLIGRAMS_PER_GRAM = TestValueType._(3, 'MILLIGRAMS_PER_GRAM');

  static const $core.List<TestValueType> values = <TestValueType> [
    MILLIGRAMS,
    PERCENTAGE,
    PRESENCE,
    MILLIGRAMS_PER_GRAM,
  ];

  static final $core.Map<$core.int, TestValueType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TestValueType valueOf($core.int value) => _byValue[value];

  const TestValueType._($core.int v, $core.String n) : super(v, n);
}

class TestErrorType extends $pb.ProtobufEnum {
  static const TestErrorType PERCENT = TestErrorType._(0, 'PERCENT');
  static const TestErrorType ABSOLUTE = TestErrorType._(1, 'ABSOLUTE');
  static const TestErrorType RELATIVE = TestErrorType._(2, 'RELATIVE');

  static const $core.List<TestErrorType> values = <TestErrorType> [
    PERCENT,
    ABSOLUTE,
    RELATIVE,
  ];

  static final $core.Map<$core.int, TestErrorType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TestErrorType valueOf($core.int value) => _byValue[value];

  const TestErrorType._($core.int v, $core.String n) : super(v, n);
}

class TestMediaType extends $pb.ProtobufEnum {
  static const TestMediaType CERTIFICATE = TestMediaType._(0, 'CERTIFICATE');
  static const TestMediaType RESULTS = TestMediaType._(1, 'RESULTS');
  static const TestMediaType PRODUCT_IMAGE = TestMediaType._(2, 'PRODUCT_IMAGE');

  static const $core.List<TestMediaType> values = <TestMediaType> [
    CERTIFICATE,
    RESULTS,
    PRODUCT_IMAGE,
  ];

  static final $core.Map<$core.int, TestMediaType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TestMediaType valueOf($core.int value) => _byValue[value];

  const TestMediaType._($core.int v, $core.String n) : super(v, n);
}

