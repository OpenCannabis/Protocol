///
//  Generated code. Do not modify.
//  source: structs/labtesting/Terpenes.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Terpene extends $pb.ProtobufEnum {
  static const Terpene CAMPHENE = Terpene._(0, 'CAMPHENE');
  static const Terpene CARENE = Terpene._(1, 'CARENE');
  static const Terpene BETA_CARYOPHYLLENE = Terpene._(2, 'BETA_CARYOPHYLLENE');
  static const Terpene CARYOPHYLLENE_OXIDE = Terpene._(3, 'CARYOPHYLLENE_OXIDE');
  static const Terpene EUCALYPTOL = Terpene._(4, 'EUCALYPTOL');
  static const Terpene FENCHOL = Terpene._(5, 'FENCHOL');
  static const Terpene ALPHA_HUMULENE = Terpene._(6, 'ALPHA_HUMULENE');
  static const Terpene LIMONENE = Terpene._(7, 'LIMONENE');
  static const Terpene LINALOOL = Terpene._(8, 'LINALOOL');
  static const Terpene MYRCENE = Terpene._(9, 'MYRCENE');
  static const Terpene ALPHA_OCIMENE = Terpene._(10, 'ALPHA_OCIMENE');
  static const Terpene BETA_OCIMENE = Terpene._(11, 'BETA_OCIMENE');
  static const Terpene ALPHA_PHELLANDRENE = Terpene._(12, 'ALPHA_PHELLANDRENE');
  static const Terpene ALPHA_PINENE = Terpene._(13, 'ALPHA_PINENE');
  static const Terpene BETA_PINENE = Terpene._(14, 'BETA_PINENE');
  static const Terpene ALPHA_TERPINEOL = Terpene._(15, 'ALPHA_TERPINEOL');
  static const Terpene ALPHA_TERPININE = Terpene._(16, 'ALPHA_TERPININE');
  static const Terpene GAMMA_TERPININE = Terpene._(17, 'GAMMA_TERPININE');
  static const Terpene TERPINOLENE = Terpene._(18, 'TERPINOLENE');
  static const Terpene VALENCENE = Terpene._(19, 'VALENCENE');
  static const Terpene GERANIOL = Terpene._(20, 'GERANIOL');
  static const Terpene PHELLANDRENE = Terpene._(21, 'PHELLANDRENE');
  static const Terpene BORNEOL = Terpene._(22, 'BORNEOL');
  static const Terpene ISOBORNEOL = Terpene._(23, 'ISOBORNEOL');
  static const Terpene BISABOLOL = Terpene._(24, 'BISABOLOL');
  static const Terpene PHYTOL = Terpene._(25, 'PHYTOL');
  static const Terpene SABINENE = Terpene._(26, 'SABINENE');
  static const Terpene CAMPHOR = Terpene._(27, 'CAMPHOR');
  static const Terpene MENTHOL = Terpene._(28, 'MENTHOL');
  static const Terpene CEDRENE = Terpene._(29, 'CEDRENE');
  static const Terpene NEROL = Terpene._(30, 'NEROL');
  static const Terpene NEROLIDOL = Terpene._(31, 'NEROLIDOL');
  static const Terpene GUAIOL = Terpene._(32, 'GUAIOL');
  static const Terpene ISOPULEGOL = Terpene._(33, 'ISOPULEGOL');
  static const Terpene GERANYL_ACETATE = Terpene._(34, 'GERANYL_ACETATE');
  static const Terpene CYMENE = Terpene._(35, 'CYMENE');
  static const Terpene PULEGONE = Terpene._(36, 'PULEGONE');
  static const Terpene CINEOLE = Terpene._(37, 'CINEOLE');
  static const Terpene FENCHONE = Terpene._(38, 'FENCHONE');
  static const Terpene TERPINENE = Terpene._(39, 'TERPINENE');
  static const Terpene CITRONELLOL = Terpene._(40, 'CITRONELLOL');
  static const Terpene DELTA_3_CARENE = Terpene._(41, 'DELTA_3_CARENE');

  static const $core.List<Terpene> values = <Terpene> [
    CAMPHENE,
    CARENE,
    BETA_CARYOPHYLLENE,
    CARYOPHYLLENE_OXIDE,
    EUCALYPTOL,
    FENCHOL,
    ALPHA_HUMULENE,
    LIMONENE,
    LINALOOL,
    MYRCENE,
    ALPHA_OCIMENE,
    BETA_OCIMENE,
    ALPHA_PHELLANDRENE,
    ALPHA_PINENE,
    BETA_PINENE,
    ALPHA_TERPINEOL,
    ALPHA_TERPININE,
    GAMMA_TERPININE,
    TERPINOLENE,
    VALENCENE,
    GERANIOL,
    PHELLANDRENE,
    BORNEOL,
    ISOBORNEOL,
    BISABOLOL,
    PHYTOL,
    SABINENE,
    CAMPHOR,
    MENTHOL,
    CEDRENE,
    NEROL,
    NEROLIDOL,
    GUAIOL,
    ISOPULEGOL,
    GERANYL_ACETATE,
    CYMENE,
    PULEGONE,
    CINEOLE,
    FENCHONE,
    TERPINENE,
    CITRONELLOL,
    DELTA_3_CARENE,
  ];

  static final $core.Map<$core.int, Terpene> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Terpene valueOf($core.int value) => _byValue[value];

  const Terpene._($core.int v, $core.String n) : super(v, n);
}

