///
//  Generated code. Do not modify.
//  source: structs/labtesting/Cannabinoids.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Cannabinoid extends $pb.ProtobufEnum {
  static const Cannabinoid THC = Cannabinoid._(0, 'THC');
  static const Cannabinoid THC_A = Cannabinoid._(1, 'THC_A');
  static const Cannabinoid THC_V = Cannabinoid._(2, 'THC_V');
  static const Cannabinoid THC_VA = Cannabinoid._(3, 'THC_VA');
  static const Cannabinoid THC_8 = Cannabinoid._(4, 'THC_8');
  static const Cannabinoid THC_9 = Cannabinoid._(5, 'THC_9');
  static const Cannabinoid CBD = Cannabinoid._(10, 'CBD');
  static const Cannabinoid CBD_A = Cannabinoid._(11, 'CBD_A');
  static const Cannabinoid CBD_V = Cannabinoid._(12, 'CBD_V');
  static const Cannabinoid CBD_VA = Cannabinoid._(13, 'CBD_VA');
  static const Cannabinoid CBC = Cannabinoid._(20, 'CBC');
  static const Cannabinoid CBC_A = Cannabinoid._(21, 'CBC_A');
  static const Cannabinoid CBG = Cannabinoid._(30, 'CBG');
  static const Cannabinoid CBG_A = Cannabinoid._(31, 'CBG_A');
  static const Cannabinoid CBN = Cannabinoid._(40, 'CBN');
  static const Cannabinoid CBN_A = Cannabinoid._(41, 'CBN_A');
  static const Cannabinoid CBV = Cannabinoid._(50, 'CBV');
  static const Cannabinoid CBV_A = Cannabinoid._(51, 'CBV_A');
  static const Cannabinoid TAC = Cannabinoid._(60, 'TAC');
  static const Cannabinoid CBL = Cannabinoid._(70, 'CBL');
  static const Cannabinoid CBL_A = Cannabinoid._(71, 'CBL_A');

  static const $core.List<Cannabinoid> values = <Cannabinoid> [
    THC,
    THC_A,
    THC_V,
    THC_VA,
    THC_8,
    THC_9,
    CBD,
    CBD_A,
    CBD_V,
    CBD_VA,
    CBC,
    CBC_A,
    CBG,
    CBG_A,
    CBN,
    CBN_A,
    CBV,
    CBV_A,
    TAC,
    CBL,
    CBL_A,
  ];

  static final $core.Map<$core.int, Cannabinoid> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Cannabinoid valueOf($core.int value) => _byValue[value];

  const Cannabinoid._($core.int v, $core.String n) : super(v, n);
}

class CannabinoidRatio extends $pb.ProtobufEnum {
  static const CannabinoidRatio NO_CANNABINOID_PREFERENCE = CannabinoidRatio._(0, 'NO_CANNABINOID_PREFERENCE');
  static const CannabinoidRatio THC_ONLY = CannabinoidRatio._(1, 'THC_ONLY');
  static const CannabinoidRatio THC_OVER_CBD = CannabinoidRatio._(2, 'THC_OVER_CBD');
  static const CannabinoidRatio EQUAL = CannabinoidRatio._(3, 'EQUAL');
  static const CannabinoidRatio CBD_OVER_THC = CannabinoidRatio._(4, 'CBD_OVER_THC');
  static const CannabinoidRatio CBD_ONLY = CannabinoidRatio._(5, 'CBD_ONLY');

  static const $core.List<CannabinoidRatio> values = <CannabinoidRatio> [
    NO_CANNABINOID_PREFERENCE,
    THC_ONLY,
    THC_OVER_CBD,
    EQUAL,
    CBD_OVER_THC,
    CBD_ONLY,
  ];

  static final $core.Map<$core.int, CannabinoidRatio> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CannabinoidRatio valueOf($core.int value) => _byValue[value];

  const CannabinoidRatio._($core.int v, $core.String n) : super(v, n);
}

