///
//  Generated code. Do not modify.
//  source: structs/labtesting/Cannabinoids.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Cannabinoid$json = const {
  '1': 'Cannabinoid',
  '2': const [
    const {'1': 'THC', '2': 0},
    const {'1': 'THC_A', '2': 1},
    const {'1': 'THC_V', '2': 2},
    const {'1': 'THC_VA', '2': 3},
    const {'1': 'THC_8', '2': 4},
    const {'1': 'THC_9', '2': 5},
    const {'1': 'CBD', '2': 10},
    const {'1': 'CBD_A', '2': 11},
    const {'1': 'CBD_V', '2': 12},
    const {'1': 'CBD_VA', '2': 13},
    const {'1': 'CBC', '2': 20},
    const {'1': 'CBC_A', '2': 21},
    const {'1': 'CBG', '2': 30},
    const {'1': 'CBG_A', '2': 31},
    const {'1': 'CBN', '2': 40},
    const {'1': 'CBN_A', '2': 41},
    const {'1': 'CBV', '2': 50},
    const {'1': 'CBV_A', '2': 51},
    const {'1': 'TAC', '2': 60},
    const {'1': 'CBL', '2': 70},
    const {'1': 'CBL_A', '2': 71},
  ],
};

const CannabinoidRatio$json = const {
  '1': 'CannabinoidRatio',
  '2': const [
    const {'1': 'NO_CANNABINOID_PREFERENCE', '2': 0},
    const {'1': 'THC_ONLY', '2': 1},
    const {'1': 'THC_OVER_CBD', '2': 2},
    const {'1': 'EQUAL', '2': 3},
    const {'1': 'CBD_OVER_THC', '2': 4},
    const {'1': 'CBD_ONLY', '2': 5},
  ],
};

