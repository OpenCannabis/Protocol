///
//  Generated code. Do not modify.
//  source: structs/labtesting/TestResults.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class TestMethod extends $pb.ProtobufEnum {
  static const TestMethod UNSPECIFIED_METHOD = TestMethod._(0, 'UNSPECIFIED_METHOD');
  static const TestMethod GCMS = TestMethod._(1, 'GCMS');
  static const TestMethod LCMS = TestMethod._(2, 'LCMS');
  static const TestMethod CLASSIC_PCR = TestMethod._(3, 'CLASSIC_PCR');
  static const TestMethod qPCR = TestMethod._(4, 'qPCR');
  static const TestMethod ELISA = TestMethod._(5, 'ELISA');

  static const $core.List<TestMethod> values = <TestMethod> [
    UNSPECIFIED_METHOD,
    GCMS,
    LCMS,
    CLASSIC_PCR,
    qPCR,
    ELISA,
  ];

  static final $core.Map<$core.int, TestMethod> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TestMethod valueOf($core.int value) => _byValue[value];

  const TestMethod._($core.int v, $core.String n) : super(v, n);
}

class Feeling extends $pb.ProtobufEnum {
  static const Feeling NO_FEELING_PREFERENCE = Feeling._(0, 'NO_FEELING_PREFERENCE');
  static const Feeling GROUNDING = Feeling._(1, 'GROUNDING');
  static const Feeling SLEEP = Feeling._(2, 'SLEEP');
  static const Feeling CALMING = Feeling._(3, 'CALMING');
  static const Feeling STIMULATING = Feeling._(4, 'STIMULATING');
  static const Feeling FUNNY = Feeling._(5, 'FUNNY');
  static const Feeling FOCUS = Feeling._(6, 'FOCUS');
  static const Feeling PASSION = Feeling._(7, 'PASSION');

  static const $core.List<Feeling> values = <Feeling> [
    NO_FEELING_PREFERENCE,
    GROUNDING,
    SLEEP,
    CALMING,
    STIMULATING,
    FUNNY,
    FOCUS,
    PASSION,
  ];

  static final $core.Map<$core.int, Feeling> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Feeling valueOf($core.int value) => _byValue[value];

  const Feeling._($core.int v, $core.String n) : super(v, n);
}

class TasteNote extends $pb.ProtobufEnum {
  static const TasteNote NO_TASTE_PREFERENCE = TasteNote._(0, 'NO_TASTE_PREFERENCE');
  static const TasteNote SWEET = TasteNote._(1, 'SWEET');
  static const TasteNote SOUR = TasteNote._(2, 'SOUR');
  static const TasteNote SPICE = TasteNote._(3, 'SPICE');
  static const TasteNote SMOOTH = TasteNote._(4, 'SMOOTH');
  static const TasteNote CITRUS = TasteNote._(5, 'CITRUS');
  static const TasteNote PINE = TasteNote._(6, 'PINE');
  static const TasteNote FRUIT = TasteNote._(7, 'FRUIT');
  static const TasteNote TROPICS = TasteNote._(8, 'TROPICS');
  static const TasteNote FLORAL = TasteNote._(9, 'FLORAL');
  static const TasteNote HERB = TasteNote._(10, 'HERB');
  static const TasteNote EARTH = TasteNote._(11, 'EARTH');

  static const $core.List<TasteNote> values = <TasteNote> [
    NO_TASTE_PREFERENCE,
    SWEET,
    SOUR,
    SPICE,
    SMOOTH,
    CITRUS,
    PINE,
    FRUIT,
    TROPICS,
    FLORAL,
    HERB,
    EARTH,
  ];

  static final $core.Map<$core.int, TasteNote> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TasteNote valueOf($core.int value) => _byValue[value];

  const TasteNote._($core.int v, $core.String n) : super(v, n);
}

class PotencyEstimate extends $pb.ProtobufEnum {
  static const PotencyEstimate LIGHT = PotencyEstimate._(0, 'LIGHT');
  static const PotencyEstimate MEDIUM = PotencyEstimate._(1, 'MEDIUM');
  static const PotencyEstimate HEAVY = PotencyEstimate._(2, 'HEAVY');
  static const PotencyEstimate SUPER = PotencyEstimate._(3, 'SUPER');

  static const $core.List<PotencyEstimate> values = <PotencyEstimate> [
    LIGHT,
    MEDIUM,
    HEAVY,
    SUPER,
  ];

  static final $core.Map<$core.int, PotencyEstimate> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PotencyEstimate valueOf($core.int value) => _byValue[value];

  const PotencyEstimate._($core.int v, $core.String n) : super(v, n);
}

