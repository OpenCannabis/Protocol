///
//  Generated code. Do not modify.
//  source: structs/pricing/PricingDescriptor.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const PricingType$json = const {
  '1': 'PricingType',
  '2': const [
    const {'1': 'UNIT', '2': 0},
    const {'1': 'WEIGHTED', '2': 1},
  ],
};

const PricingWeightTier$json = const {
  '1': 'PricingWeightTier',
  '2': const [
    const {'1': 'NO_WEIGHT', '2': 0},
    const {'1': 'GRAM', '2': 1},
    const {'1': 'HALFGRAM', '2': 2},
    const {'1': 'QUARTERGRAM', '2': 3},
    const {'1': 'DUB', '2': 4},
    const {'1': 'EIGHTH', '2': 5},
    const {'1': 'QUARTER', '2': 6},
    const {'1': 'HALF', '2': 7},
    const {'1': 'OUNCE', '2': 8},
    const {'1': 'QUARTERPOUND', '2': 9},
    const {'1': 'HALFPOUND', '2': 10},
    const {'1': 'POUND', '2': 11},
    const {'1': 'KILO', '2': 12},
    const {'1': 'TON', '2': 13},
    const {'1': 'OTHER', '2': 99},
  ],
};

const PricingTierAvailability$json = const {
  '1': 'PricingTierAvailability',
  '2': const [
    const {'1': 'offered', '3': 1, '4': 1, '5': 8, '10': 'offered'},
    const {'1': 'available', '3': 2, '4': 1, '5': 8, '10': 'available'},
  ],
};

const UnitPricingDescriptor$json = const {
  '1': 'UnitPricingDescriptor',
  '2': const [
    const {'1': 'price', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.commerce.CurrencyValue', '10': 'price'},
    const {'1': 'status', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.pricing.PricingTierAvailability', '10': 'status'},
    const {'1': 'discounts', '3': 3, '4': 3, '5': 11, '6': '.opencannabis.structs.pricing.SaleDescriptor', '10': 'discounts'},
  ],
};

const WeightedPricingDescriptor$json = const {
  '1': 'WeightedPricingDescriptor',
  '2': const [
    const {'1': 'weight', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.pricing.PricingWeightTier', '10': 'weight'},
    const {'1': 'tier', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.structs.pricing.UnitPricingDescriptor', '10': 'tier'},
    const {'1': 'weight_in_grams', '3': 3, '4': 1, '5': 2, '10': 'weightInGrams'},
  ],
};

const PricingDescriptor$json = const {
  '1': 'PricingDescriptor',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.pricing.PricingType', '10': 'type'},
    const {'1': 'unit', '3': 20, '4': 1, '5': 11, '6': '.opencannabis.structs.pricing.UnitPricingDescriptor', '9': 0, '10': 'unit'},
    const {'1': 'weighted', '3': 21, '4': 1, '5': 11, '6': '.opencannabis.structs.pricing.WeightedPricingDescriptor', '9': 0, '10': 'weighted'},
  ],
  '8': const [
    const {'1': 'tier'},
  ],
};

const ProductPricing$json = const {
  '1': 'ProductPricing',
  '2': const [
    const {'1': 'discounts', '3': 1, '4': 3, '5': 11, '6': '.opencannabis.structs.pricing.SaleDescriptor', '10': 'discounts'},
    const {'1': 'manifest', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.structs.pricing.PricingDescriptor', '10': 'manifest'},
  ],
};

