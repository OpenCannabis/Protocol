///
//  Generated code. Do not modify.
//  source: structs/pricing/PricingDescriptor.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../../commerce/Currency.pb.dart' as $14;
import 'SaleDescriptor.pb.dart' as $15;

import 'PricingDescriptor.pbenum.dart';

export 'PricingDescriptor.pbenum.dart';

class PricingTierAvailability extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PricingTierAvailability', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..aOB(1, 'offered')
    ..aOB(2, 'available')
    ..hasRequiredFields = false
  ;

  PricingTierAvailability() : super();
  PricingTierAvailability.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PricingTierAvailability.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PricingTierAvailability clone() => PricingTierAvailability()..mergeFromMessage(this);
  PricingTierAvailability copyWith(void Function(PricingTierAvailability) updates) => super.copyWith((message) => updates(message as PricingTierAvailability));
  $pb.BuilderInfo get info_ => _i;
  static PricingTierAvailability create() => PricingTierAvailability();
  PricingTierAvailability createEmptyInstance() => create();
  static $pb.PbList<PricingTierAvailability> createRepeated() => $pb.PbList<PricingTierAvailability>();
  static PricingTierAvailability getDefault() => _defaultInstance ??= create()..freeze();
  static PricingTierAvailability _defaultInstance;

  $core.bool get offered => $_get(0, false);
  set offered($core.bool v) { $_setBool(0, v); }
  $core.bool hasOffered() => $_has(0);
  void clearOffered() => clearField(1);

  $core.bool get available => $_get(1, false);
  set available($core.bool v) { $_setBool(1, v); }
  $core.bool hasAvailable() => $_has(1);
  void clearAvailable() => clearField(2);
}

class UnitPricingDescriptor extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('UnitPricingDescriptor', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..a<$14.CurrencyValue>(1, 'price', $pb.PbFieldType.OM, $14.CurrencyValue.getDefault, $14.CurrencyValue.create)
    ..a<PricingTierAvailability>(2, 'status', $pb.PbFieldType.OM, PricingTierAvailability.getDefault, PricingTierAvailability.create)
    ..pc<$15.SaleDescriptor>(3, 'discounts', $pb.PbFieldType.PM,$15.SaleDescriptor.create)
    ..hasRequiredFields = false
  ;

  UnitPricingDescriptor() : super();
  UnitPricingDescriptor.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  UnitPricingDescriptor.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  UnitPricingDescriptor clone() => UnitPricingDescriptor()..mergeFromMessage(this);
  UnitPricingDescriptor copyWith(void Function(UnitPricingDescriptor) updates) => super.copyWith((message) => updates(message as UnitPricingDescriptor));
  $pb.BuilderInfo get info_ => _i;
  static UnitPricingDescriptor create() => UnitPricingDescriptor();
  UnitPricingDescriptor createEmptyInstance() => create();
  static $pb.PbList<UnitPricingDescriptor> createRepeated() => $pb.PbList<UnitPricingDescriptor>();
  static UnitPricingDescriptor getDefault() => _defaultInstance ??= create()..freeze();
  static UnitPricingDescriptor _defaultInstance;

  $14.CurrencyValue get price => $_getN(0);
  set price($14.CurrencyValue v) { setField(1, v); }
  $core.bool hasPrice() => $_has(0);
  void clearPrice() => clearField(1);

  PricingTierAvailability get status => $_getN(1);
  set status(PricingTierAvailability v) { setField(2, v); }
  $core.bool hasStatus() => $_has(1);
  void clearStatus() => clearField(2);

  $core.List<$15.SaleDescriptor> get discounts => $_getList(2);
}

class WeightedPricingDescriptor extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('WeightedPricingDescriptor', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..e<PricingWeightTier>(1, 'weight', $pb.PbFieldType.OE, PricingWeightTier.NO_WEIGHT, PricingWeightTier.valueOf, PricingWeightTier.values)
    ..a<UnitPricingDescriptor>(2, 'tier', $pb.PbFieldType.OM, UnitPricingDescriptor.getDefault, UnitPricingDescriptor.create)
    ..a<$core.double>(3, 'weightInGrams', $pb.PbFieldType.OF)
    ..hasRequiredFields = false
  ;

  WeightedPricingDescriptor() : super();
  WeightedPricingDescriptor.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  WeightedPricingDescriptor.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  WeightedPricingDescriptor clone() => WeightedPricingDescriptor()..mergeFromMessage(this);
  WeightedPricingDescriptor copyWith(void Function(WeightedPricingDescriptor) updates) => super.copyWith((message) => updates(message as WeightedPricingDescriptor));
  $pb.BuilderInfo get info_ => _i;
  static WeightedPricingDescriptor create() => WeightedPricingDescriptor();
  WeightedPricingDescriptor createEmptyInstance() => create();
  static $pb.PbList<WeightedPricingDescriptor> createRepeated() => $pb.PbList<WeightedPricingDescriptor>();
  static WeightedPricingDescriptor getDefault() => _defaultInstance ??= create()..freeze();
  static WeightedPricingDescriptor _defaultInstance;

  PricingWeightTier get weight => $_getN(0);
  set weight(PricingWeightTier v) { setField(1, v); }
  $core.bool hasWeight() => $_has(0);
  void clearWeight() => clearField(1);

  UnitPricingDescriptor get tier => $_getN(1);
  set tier(UnitPricingDescriptor v) { setField(2, v); }
  $core.bool hasTier() => $_has(1);
  void clearTier() => clearField(2);

  $core.double get weightInGrams => $_getN(2);
  set weightInGrams($core.double v) { $_setFloat(2, v); }
  $core.bool hasWeightInGrams() => $_has(2);
  void clearWeightInGrams() => clearField(3);
}

enum PricingDescriptor_Tier {
  unit, 
  weighted, 
  notSet
}

class PricingDescriptor extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, PricingDescriptor_Tier> _PricingDescriptor_TierByTag = {
    20 : PricingDescriptor_Tier.unit,
    21 : PricingDescriptor_Tier.weighted,
    0 : PricingDescriptor_Tier.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PricingDescriptor', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..e<PricingType>(1, 'type', $pb.PbFieldType.OE, PricingType.UNIT, PricingType.valueOf, PricingType.values)
    ..a<UnitPricingDescriptor>(20, 'unit', $pb.PbFieldType.OM, UnitPricingDescriptor.getDefault, UnitPricingDescriptor.create)
    ..a<WeightedPricingDescriptor>(21, 'weighted', $pb.PbFieldType.OM, WeightedPricingDescriptor.getDefault, WeightedPricingDescriptor.create)
    ..oo(0, [20, 21])
    ..hasRequiredFields = false
  ;

  PricingDescriptor() : super();
  PricingDescriptor.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PricingDescriptor.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PricingDescriptor clone() => PricingDescriptor()..mergeFromMessage(this);
  PricingDescriptor copyWith(void Function(PricingDescriptor) updates) => super.copyWith((message) => updates(message as PricingDescriptor));
  $pb.BuilderInfo get info_ => _i;
  static PricingDescriptor create() => PricingDescriptor();
  PricingDescriptor createEmptyInstance() => create();
  static $pb.PbList<PricingDescriptor> createRepeated() => $pb.PbList<PricingDescriptor>();
  static PricingDescriptor getDefault() => _defaultInstance ??= create()..freeze();
  static PricingDescriptor _defaultInstance;

  PricingDescriptor_Tier whichTier() => _PricingDescriptor_TierByTag[$_whichOneof(0)];
  void clearTier() => clearField($_whichOneof(0));

  PricingType get type => $_getN(0);
  set type(PricingType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  UnitPricingDescriptor get unit => $_getN(1);
  set unit(UnitPricingDescriptor v) { setField(20, v); }
  $core.bool hasUnit() => $_has(1);
  void clearUnit() => clearField(20);

  WeightedPricingDescriptor get weighted => $_getN(2);
  set weighted(WeightedPricingDescriptor v) { setField(21, v); }
  $core.bool hasWeighted() => $_has(2);
  void clearWeighted() => clearField(21);
}

class ProductPricing extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProductPricing', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..pc<$15.SaleDescriptor>(1, 'discounts', $pb.PbFieldType.PM,$15.SaleDescriptor.create)
    ..pc<PricingDescriptor>(2, 'manifest', $pb.PbFieldType.PM,PricingDescriptor.create)
    ..hasRequiredFields = false
  ;

  ProductPricing() : super();
  ProductPricing.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductPricing.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductPricing clone() => ProductPricing()..mergeFromMessage(this);
  ProductPricing copyWith(void Function(ProductPricing) updates) => super.copyWith((message) => updates(message as ProductPricing));
  $pb.BuilderInfo get info_ => _i;
  static ProductPricing create() => ProductPricing();
  ProductPricing createEmptyInstance() => create();
  static $pb.PbList<ProductPricing> createRepeated() => $pb.PbList<ProductPricing>();
  static ProductPricing getDefault() => _defaultInstance ??= create()..freeze();
  static ProductPricing _defaultInstance;

  $core.List<$15.SaleDescriptor> get discounts => $_getList(0);

  $core.List<PricingDescriptor> get manifest => $_getList(1);
}

