///
//  Generated code. Do not modify.
//  source: structs/pricing/SaleDescriptor.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const SaleType$json = const {
  '1': 'SaleType',
  '2': const [
    const {'1': 'PERCENTAGE_REDUCTION', '2': 0},
    const {'1': 'VALUE_REDUCTION', '2': 1},
    const {'1': 'BOGO', '2': 2},
    const {'1': 'LOYALTY', '2': 3},
  ],
};

const PercentageDiscount$json = const {
  '1': 'PercentageDiscount',
  '2': const [
    const {'1': 'discount', '3': 20, '4': 1, '5': 13, '10': 'discount'},
  ],
};

const BOGODiscount$json = const {
  '1': 'BOGODiscount',
  '2': const [
    const {'1': 'trigger', '3': 21, '4': 1, '5': 13, '10': 'trigger'},
    const {'1': 'reward', '3': 22, '4': 1, '5': 13, '10': 'reward'},
  ],
};

const LoyaltyDiscount$json = const {
  '1': 'LoyaltyDiscount',
  '2': const [
    const {'1': 'trigger', '3': 23, '4': 1, '5': 13, '10': 'trigger'},
    const {'1': 'reward', '3': 24, '4': 1, '5': 13, '10': 'reward'},
  ],
};

const SaleDescriptor$json = const {
  '1': 'SaleDescriptor',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.structs.pricing.SaleType', '10': 'type'},
    const {'1': 'effective', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'effective'},
    const {'1': 'expiration', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'expiration'},
    const {'1': 'percentage_off', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.structs.pricing.PercentageDiscount', '9': 0, '10': 'percentageOff'},
    const {'1': 'bogo', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.structs.pricing.BOGODiscount', '9': 0, '10': 'bogo'},
    const {'1': 'loyalty', '3': 6, '4': 1, '5': 11, '6': '.opencannabis.structs.pricing.LoyaltyDiscount', '9': 0, '10': 'loyalty'},
  ],
  '8': const [
    const {'1': 'sale'},
  ],
};

