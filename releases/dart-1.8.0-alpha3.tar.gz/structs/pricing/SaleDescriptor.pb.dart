///
//  Generated code. Do not modify.
//  source: structs/pricing/SaleDescriptor.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../../temporal/Instant.pb.dart' as $0;

import 'SaleDescriptor.pbenum.dart';

export 'SaleDescriptor.pbenum.dart';

class PercentageDiscount extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PercentageDiscount', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..a<$core.int>(20, 'discount', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  PercentageDiscount() : super();
  PercentageDiscount.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PercentageDiscount.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PercentageDiscount clone() => PercentageDiscount()..mergeFromMessage(this);
  PercentageDiscount copyWith(void Function(PercentageDiscount) updates) => super.copyWith((message) => updates(message as PercentageDiscount));
  $pb.BuilderInfo get info_ => _i;
  static PercentageDiscount create() => PercentageDiscount();
  PercentageDiscount createEmptyInstance() => create();
  static $pb.PbList<PercentageDiscount> createRepeated() => $pb.PbList<PercentageDiscount>();
  static PercentageDiscount getDefault() => _defaultInstance ??= create()..freeze();
  static PercentageDiscount _defaultInstance;

  $core.int get discount => $_get(0, 0);
  set discount($core.int v) { $_setUnsignedInt32(0, v); }
  $core.bool hasDiscount() => $_has(0);
  void clearDiscount() => clearField(20);
}

class BOGODiscount extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('BOGODiscount', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..a<$core.int>(21, 'trigger', $pb.PbFieldType.OU3)
    ..a<$core.int>(22, 'reward', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  BOGODiscount() : super();
  BOGODiscount.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BOGODiscount.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BOGODiscount clone() => BOGODiscount()..mergeFromMessage(this);
  BOGODiscount copyWith(void Function(BOGODiscount) updates) => super.copyWith((message) => updates(message as BOGODiscount));
  $pb.BuilderInfo get info_ => _i;
  static BOGODiscount create() => BOGODiscount();
  BOGODiscount createEmptyInstance() => create();
  static $pb.PbList<BOGODiscount> createRepeated() => $pb.PbList<BOGODiscount>();
  static BOGODiscount getDefault() => _defaultInstance ??= create()..freeze();
  static BOGODiscount _defaultInstance;

  $core.int get trigger => $_get(0, 0);
  set trigger($core.int v) { $_setUnsignedInt32(0, v); }
  $core.bool hasTrigger() => $_has(0);
  void clearTrigger() => clearField(21);

  $core.int get reward => $_get(1, 0);
  set reward($core.int v) { $_setUnsignedInt32(1, v); }
  $core.bool hasReward() => $_has(1);
  void clearReward() => clearField(22);
}

class LoyaltyDiscount extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('LoyaltyDiscount', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..a<$core.int>(23, 'trigger', $pb.PbFieldType.OU3)
    ..a<$core.int>(24, 'reward', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  LoyaltyDiscount() : super();
  LoyaltyDiscount.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  LoyaltyDiscount.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  LoyaltyDiscount clone() => LoyaltyDiscount()..mergeFromMessage(this);
  LoyaltyDiscount copyWith(void Function(LoyaltyDiscount) updates) => super.copyWith((message) => updates(message as LoyaltyDiscount));
  $pb.BuilderInfo get info_ => _i;
  static LoyaltyDiscount create() => LoyaltyDiscount();
  LoyaltyDiscount createEmptyInstance() => create();
  static $pb.PbList<LoyaltyDiscount> createRepeated() => $pb.PbList<LoyaltyDiscount>();
  static LoyaltyDiscount getDefault() => _defaultInstance ??= create()..freeze();
  static LoyaltyDiscount _defaultInstance;

  $core.int get trigger => $_get(0, 0);
  set trigger($core.int v) { $_setUnsignedInt32(0, v); }
  $core.bool hasTrigger() => $_has(0);
  void clearTrigger() => clearField(23);

  $core.int get reward => $_get(1, 0);
  set reward($core.int v) { $_setUnsignedInt32(1, v); }
  $core.bool hasReward() => $_has(1);
  void clearReward() => clearField(24);
}

enum SaleDescriptor_Sale {
  percentageOff, 
  bogo, 
  loyalty, 
  notSet
}

class SaleDescriptor extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, SaleDescriptor_Sale> _SaleDescriptor_SaleByTag = {
    4 : SaleDescriptor_Sale.percentageOff,
    5 : SaleDescriptor_Sale.bogo,
    6 : SaleDescriptor_Sale.loyalty,
    0 : SaleDescriptor_Sale.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SaleDescriptor', package: const $pb.PackageName('opencannabis.structs.pricing'))
    ..e<SaleType>(1, 'type', $pb.PbFieldType.OE, SaleType.PERCENTAGE_REDUCTION, SaleType.valueOf, SaleType.values)
    ..a<$0.Instant>(2, 'effective', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(3, 'expiration', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<PercentageDiscount>(4, 'percentageOff', $pb.PbFieldType.OM, PercentageDiscount.getDefault, PercentageDiscount.create)
    ..a<BOGODiscount>(5, 'bogo', $pb.PbFieldType.OM, BOGODiscount.getDefault, BOGODiscount.create)
    ..a<LoyaltyDiscount>(6, 'loyalty', $pb.PbFieldType.OM, LoyaltyDiscount.getDefault, LoyaltyDiscount.create)
    ..oo(0, [4, 5, 6])
    ..hasRequiredFields = false
  ;

  SaleDescriptor() : super();
  SaleDescriptor.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SaleDescriptor.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SaleDescriptor clone() => SaleDescriptor()..mergeFromMessage(this);
  SaleDescriptor copyWith(void Function(SaleDescriptor) updates) => super.copyWith((message) => updates(message as SaleDescriptor));
  $pb.BuilderInfo get info_ => _i;
  static SaleDescriptor create() => SaleDescriptor();
  SaleDescriptor createEmptyInstance() => create();
  static $pb.PbList<SaleDescriptor> createRepeated() => $pb.PbList<SaleDescriptor>();
  static SaleDescriptor getDefault() => _defaultInstance ??= create()..freeze();
  static SaleDescriptor _defaultInstance;

  SaleDescriptor_Sale whichSale() => _SaleDescriptor_SaleByTag[$_whichOneof(0)];
  void clearSale() => clearField($_whichOneof(0));

  SaleType get type => $_getN(0);
  set type(SaleType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $0.Instant get effective => $_getN(1);
  set effective($0.Instant v) { setField(2, v); }
  $core.bool hasEffective() => $_has(1);
  void clearEffective() => clearField(2);

  $0.Instant get expiration => $_getN(2);
  set expiration($0.Instant v) { setField(3, v); }
  $core.bool hasExpiration() => $_has(2);
  void clearExpiration() => clearField(3);

  PercentageDiscount get percentageOff => $_getN(3);
  set percentageOff(PercentageDiscount v) { setField(4, v); }
  $core.bool hasPercentageOff() => $_has(3);
  void clearPercentageOff() => clearField(4);

  BOGODiscount get bogo => $_getN(4);
  set bogo(BOGODiscount v) { setField(5, v); }
  $core.bool hasBogo() => $_has(4);
  void clearBogo() => clearField(5);

  LoyaltyDiscount get loyalty => $_getN(5);
  set loyalty(LoyaltyDiscount v) { setField(6, v); }
  $core.bool hasLoyalty() => $_has(5);
  void clearLoyalty() => clearField(6);
}

