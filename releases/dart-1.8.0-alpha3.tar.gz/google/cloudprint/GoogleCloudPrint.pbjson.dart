///
//  Generated code. Do not modify.
//  source: google/cloudprint/GoogleCloudPrint.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'PrintTicket.pbjson.dart' as $31;
import 'Common.pbjson.dart' as $30;

const PrinterConnectionStatus$json = const {
  '1': 'PrinterConnectionStatus',
  '2': const [
    const {'1': 'UNKNOWN', '2': 0},
    const {'1': 'DORMANT', '2': 1},
    const {'1': 'OFFLINE', '2': 2},
    const {'1': 'ONLINE', '2': 3},
  ],
};

const ExtraPrinterField$json = const {
  '1': 'ExtraPrinterField',
  '2': const [
    const {'1': 'UNKNOWN_EXTRA_FIELDS', '2': 0},
    const {'1': 'CONNECTION_STATUS', '2': 1},
    const {'1': 'SEMANTIC_STATE', '2': 2},
    const {'1': 'UI_STATE', '2': 3},
    const {'1': 'QUEUED_JOBS_COUNT', '2': 4},
  ],
};

const SubmitJobRequest$json = const {
  '1': 'SubmitJobRequest',
  '2': const [
    const {'1': 'printerid', '3': 1, '4': 1, '5': 9, '10': 'printerid'},
    const {'1': 'title', '3': 2, '4': 1, '5': 9, '10': 'title'},
    const {'1': 'ticket', '3': 3, '4': 1, '5': 11, '6': '.google.cloudprint.CloudJobTicket', '10': 'ticket'},
    const {'1': 'content', '3': 4, '4': 1, '5': 9, '10': 'content'},
    const {'1': 'content_type', '3': 5, '4': 1, '5': 9, '10': 'contentType'},
    const {'1': 'tag', '3': 6, '4': 3, '5': 9, '10': 'tag'},
  ],
};

const SubmitJobResponse$json = const {
  '1': 'SubmitJobResponse',
  '2': const [
    const {'1': 'success', '3': 1, '4': 1, '5': 8, '10': 'success'},
    const {'1': 'message', '3': 2, '4': 1, '5': 9, '10': 'message'},
    const {'1': 'error_code', '3': 3, '4': 1, '5': 13, '10': 'errorCode'},
    const {'1': 'request', '3': 4, '4': 1, '5': 11, '6': '.google.cloudprint.SubmitJobRequest', '10': 'request'},
  ],
};

const DeleteJobRequest$json = const {
  '1': 'DeleteJobRequest',
  '2': const [
    const {'1': 'jobid', '3': 1, '4': 1, '5': 9, '10': 'jobid'},
  ],
};

const DeleteJobResponse$json = const {
  '1': 'DeleteJobResponse',
  '2': const [
    const {'1': 'success', '3': 1, '4': 1, '5': 8, '10': 'success'},
    const {'1': 'message', '3': 2, '4': 1, '5': 9, '10': 'message'},
    const {'1': 'error_code', '3': 3, '4': 1, '5': 13, '10': 'errorCode'},
    const {'1': 'request', '3': 4, '4': 1, '5': 11, '6': '.google.cloudprint.DeleteJobRequest', '10': 'request'},
  ],
};

const ListJobsRequest$json = const {
  '1': 'ListJobsRequest',
  '2': const [
    const {'1': 'printerid', '3': 1, '4': 1, '5': 9, '10': 'printerid'},
    const {'1': 'owner', '3': 2, '4': 1, '5': 9, '10': 'owner'},
    const {'1': 'status', '3': 3, '4': 1, '5': 9, '10': 'status'},
    const {'1': 'q', '3': 4, '4': 1, '5': 9, '10': 'q'},
    const {'1': 'offset', '3': 5, '4': 1, '5': 13, '10': 'offset'},
    const {'1': 'limit', '3': 6, '4': 1, '5': 13, '10': 'limit'},
    const {'1': 'sortorder', '3': 7, '4': 1, '5': 14, '6': '.google.cloudprint.ListJobsRequest.JobListSortOrder', '10': 'sortorder'},
  ],
  '4': const [ListJobsRequest_JobListSortOrder$json],
};

const ListJobsRequest_JobListSortOrder$json = const {
  '1': 'JobListSortOrder',
  '2': const [
    const {'1': 'CREATE_TIME_DESC', '2': 0},
    const {'1': 'CREATE_TIME', '2': 1},
    const {'1': 'STATUS', '2': 2},
    const {'1': 'STATUS_DESC', '2': 3},
    const {'1': 'TITLE', '2': 4},
    const {'1': 'TITLE_DESC', '2': 5},
  ],
};

const ListJobsResponse$json = const {
  '1': 'ListJobsResponse',
  '2': const [
    const {'1': 'success', '3': 1, '4': 1, '5': 8, '10': 'success'},
  ],
};

const GetPrinterRequest$json = const {
  '1': 'GetPrinterRequest',
  '2': const [
    const {'1': 'printerid', '3': 1, '4': 1, '5': 9, '10': 'printerid'},
    const {'1': 'client', '3': 2, '4': 1, '5': 9, '10': 'client'},
    const {'1': 'extra_fields', '3': 3, '4': 1, '5': 9, '10': 'extraFields'},
  ],
};

const GetPrinterResponse$json = const {
  '1': 'GetPrinterResponse',
  '2': const [
    const {'1': 'success', '3': 1, '4': 1, '5': 8, '10': 'success'},
  ],
};

const SearchPrintersRequest$json = const {
  '1': 'SearchPrintersRequest',
  '2': const [
    const {'1': 'q', '3': 1, '4': 1, '5': 9, '10': 'q'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.PrinterType', '10': 'type'},
    const {'1': 'all_connection_statuses', '3': 3, '4': 1, '5': 8, '9': 0, '10': 'allConnectionStatuses'},
    const {'1': 'connection_status', '3': 4, '4': 1, '5': 14, '6': '.google.cloudprint.PrinterConnectionStatus', '9': 0, '10': 'connectionStatus'},
    const {'1': 'use_cdd', '3': 5, '4': 1, '5': 8, '10': 'useCdd'},
    const {'1': 'extra_fields', '3': 6, '4': 3, '5': 14, '6': '.google.cloudprint.ExtraPrinterField', '10': 'extraFields'},
  ],
  '8': const [
    const {'1': 'connection_status_filter'},
  ],
};

const CloudPrinter$json = const {
  '1': 'CloudPrinter',
  '2': const [
    const {'1': 'gcp_version', '3': 1, '4': 1, '5': 9, '10': 'gcpVersion'},
    const {'1': 'id', '3': 2, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'uuid', '3': 3, '4': 1, '5': 9, '10': 'uuid'},
    const {'1': 'type', '3': 4, '4': 1, '5': 14, '6': '.google.cloudprint.PrinterType', '10': 'type'},
    const {'1': 'name', '3': 5, '4': 1, '5': 9, '10': 'name'},
    const {'1': 'display_name', '3': 6, '4': 1, '5': 9, '10': 'displayName'},
    const {'1': 'default_display_name', '3': 7, '4': 1, '5': 9, '10': 'defaultDisplayName'},
    const {'1': 'description', '3': 8, '4': 1, '5': 9, '10': 'description'},
    const {'1': 'owner_id', '3': 9, '4': 1, '5': 9, '10': 'ownerId'},
    const {'1': 'owner_name', '3': 10, '4': 1, '5': 9, '10': 'ownerName'},
    const {'1': 'proxy', '3': 11, '4': 1, '5': 9, '10': 'proxy'},
    const {'1': 'status', '3': 12, '4': 1, '5': 14, '6': '.google.cloudprint.PrinterConnectionStatus', '10': 'status'},
    const {'1': 'tags', '3': 13, '4': 3, '5': 9, '10': 'tags'},
    const {'1': 'caps_hash', '3': 14, '4': 1, '5': 9, '10': 'capsHash'},
    const {'1': 'is_tos_accepted', '3': 15, '4': 1, '5': 8, '10': 'isTosAccepted'},
    const {'1': 'supported_content_types', '3': 16, '4': 1, '5': 9, '10': 'supportedContentTypes'},
    const {'1': 'local_settings', '3': 17, '4': 1, '5': 11, '6': '.google.cloudprint.LocalSettings', '10': 'localSettings'},
    const {'1': 'notification_channel', '3': 18, '4': 1, '5': 14, '6': '.google.cloudprint.NotificationChannel', '10': 'notificationChannel'},
    const {'1': 'manufacturer', '3': 19, '4': 1, '5': 9, '10': 'manufacturer'},
    const {'1': 'model', '3': 20, '4': 1, '5': 9, '10': 'model'},
    const {'1': 'support_url', '3': 21, '4': 1, '5': 9, '10': 'supportUrl'},
    const {'1': 'update_url', '3': 22, '4': 1, '5': 9, '10': 'updateUrl'},
    const {'1': 'setup_url', '3': 23, '4': 1, '5': 9, '10': 'setupUrl'},
    const {'1': 'certification_id', '3': 24, '4': 1, '5': 9, '10': 'certificationId'},
    const {'1': 'firmware', '3': 25, '4': 1, '5': 9, '10': 'firmware'},
    const {'1': 'access_time', '3': 97, '4': 1, '5': 9, '10': 'accessTime'},
    const {'1': 'update_time', '3': 98, '4': 1, '5': 9, '10': 'updateTime'},
    const {'1': 'create_time', '3': 99, '4': 1, '5': 9, '10': 'createTime'},
  ],
};

const SearchPrintersResponse$json = const {
  '1': 'SearchPrintersResponse',
  '2': const [
    const {'1': 'success', '3': 1, '4': 1, '5': 8, '10': 'success'},
    const {'1': 'xsrf_token', '3': 2, '4': 1, '5': 9, '10': 'xsrfToken'},
    const {'1': 'printers', '3': 3, '4': 3, '5': 11, '6': '.google.cloudprint.CloudPrinter', '10': 'printers'},
  ],
};

const LocalSettings$json = const {
  '1': 'LocalSettings',
  '2': const [
    const {'1': 'current', '3': 1, '4': 1, '5': 11, '6': '.google.cloudprint.LocalSettings.Settings', '10': 'current'},
    const {'1': 'pending', '3': 2, '4': 1, '5': 11, '6': '.google.cloudprint.LocalSettings.Settings', '10': 'pending'},
  ],
  '3': const [LocalSettings_Settings$json],
};

const LocalSettings_Settings$json = const {
  '1': 'Settings',
  '2': const [
    const {'1': 'local_discovery', '3': 1, '4': 1, '5': 8, '10': 'localDiscovery'},
    const {'1': 'access_token_enabled', '3': 2, '4': 1, '5': 8, '10': 'accessTokenEnabled'},
    const {'1': 'local_printing_enabled', '3': 3, '4': 1, '5': 8, '10': 'localPrintingEnabled'},
    const {'1': 'conversion_printing_enabled', '3': 4, '4': 1, '5': 8, '10': 'conversionPrintingEnabled'},
    const {'1': 'xmpp_timeout_value', '3': 5, '4': 1, '5': 5, '10': 'xmppTimeoutValue'},
  ],
};

const CloudJobTicket$json = const {
  '1': 'CloudJobTicket',
  '2': const [
    const {'1': 'version', '3': 1, '4': 1, '5': 9, '10': 'version'},
    const {'1': 'print', '3': 101, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection', '10': 'print'},
  ],
};

const CloudDeviceDescription$json = const {
  '1': 'CloudDeviceDescription',
  '2': const [
    const {'1': 'version', '3': 1, '4': 1, '5': 9, '10': 'version'},
    const {'1': 'printer', '3': 101, '4': 1, '5': 11, '6': '.google.cloudprint.PrinterDescriptionSection', '10': 'printer'},
  ],
};

const PrintJobState$json = const {
  '1': 'PrintJobState',
  '2': const [
    const {'1': 'version', '3': 1, '4': 1, '5': 9, '10': 'version'},
    const {'1': 'state', '3': 2, '4': 1, '5': 11, '6': '.google.cloudprint.JobState', '10': 'state'},
    const {'1': 'pages_printed', '3': 3, '4': 1, '5': 5, '10': 'pagesPrinted'},
    const {'1': 'delivery_attempts', '3': 4, '4': 1, '5': 5, '10': 'deliveryAttempts'},
  ],
};

const PrintJobStateDiff$json = const {
  '1': 'PrintJobStateDiff',
  '2': const [
    const {'1': 'state', '3': 1, '4': 1, '5': 11, '6': '.google.cloudprint.JobState', '10': 'state'},
    const {'1': 'pages_printed', '3': 2, '4': 1, '5': 5, '10': 'pagesPrinted'},
  ],
};

const CloudPrintServiceBase$json = const {
  '1': 'CloudPrint',
  '2': const [
    const {'1': 'SubmitJob', '2': '.google.cloudprint.SubmitJobRequest', '3': '.google.cloudprint.SubmitJobResponse', '4': const {}},
    const {'1': 'DeleteJob', '2': '.google.cloudprint.DeleteJobRequest', '3': '.google.cloudprint.DeleteJobResponse', '4': const {}},
    const {'1': 'ListJobs', '2': '.google.cloudprint.ListJobsRequest', '3': '.google.cloudprint.ListJobsResponse', '4': const {}},
    const {'1': 'GetPrinter', '2': '.google.cloudprint.GetPrinterRequest', '3': '.google.cloudprint.GetPrinterResponse', '4': const {}},
    const {'1': 'SearchPrinters', '2': '.google.cloudprint.SearchPrintersRequest', '3': '.google.cloudprint.SearchPrintersResponse', '4': const {}},
  ],
};

const CloudPrintServiceBase$messageJson = const {
  '.google.cloudprint.SubmitJobRequest': SubmitJobRequest$json,
  '.google.cloudprint.CloudJobTicket': CloudJobTicket$json,
  '.google.cloudprint.PrintTicketSection': $31.PrintTicketSection$json,
  '.google.cloudprint.PrintTicketSection.VendorTicketItem': $31.PrintTicketSection_VendorTicketItem$json,
  '.google.cloudprint.PrintTicketSection.ColorTicketItem': $31.PrintTicketSection_ColorTicketItem$json,
  '.google.cloudprint.PrintTicketSection.DuplexTicketItem': $31.PrintTicketSection_DuplexTicketItem$json,
  '.google.cloudprint.PrintTicketSection.PageOrientationTicketItem': $31.PrintTicketSection_PageOrientationTicketItem$json,
  '.google.cloudprint.PrintTicketSection.CopiesTicketItem': $31.PrintTicketSection_CopiesTicketItem$json,
  '.google.cloudprint.PrintTicketSection.MarginsTicketItem': $31.PrintTicketSection_MarginsTicketItem$json,
  '.google.cloudprint.PrintTicketSection.DpiTicketItem': $31.PrintTicketSection_DpiTicketItem$json,
  '.google.cloudprint.PrintTicketSection.FitToPageTicketItem': $31.PrintTicketSection_FitToPageTicketItem$json,
  '.google.cloudprint.PrintTicketSection.PageRangeTicketItem': $31.PrintTicketSection_PageRangeTicketItem$json,
  '.google.cloudprint.PageRange.Interval': $30.PageRange_Interval$json,
  '.google.cloudprint.PrintTicketSection.MediaSizeTicketItem': $31.PrintTicketSection_MediaSizeTicketItem$json,
  '.google.cloudprint.PrintTicketSection.CollateTicketItem': $31.PrintTicketSection_CollateTicketItem$json,
  '.google.cloudprint.PrintTicketSection.ReverseOrderTicketItem': $31.PrintTicketSection_ReverseOrderTicketItem$json,
  '.google.cloudprint.SubmitJobResponse': SubmitJobResponse$json,
  '.google.cloudprint.DeleteJobRequest': DeleteJobRequest$json,
  '.google.cloudprint.DeleteJobResponse': DeleteJobResponse$json,
  '.google.cloudprint.ListJobsRequest': ListJobsRequest$json,
  '.google.cloudprint.ListJobsResponse': ListJobsResponse$json,
  '.google.cloudprint.GetPrinterRequest': GetPrinterRequest$json,
  '.google.cloudprint.GetPrinterResponse': GetPrinterResponse$json,
  '.google.cloudprint.SearchPrintersRequest': SearchPrintersRequest$json,
  '.google.cloudprint.SearchPrintersResponse': SearchPrintersResponse$json,
  '.google.cloudprint.CloudPrinter': CloudPrinter$json,
  '.google.cloudprint.LocalSettings': LocalSettings$json,
  '.google.cloudprint.LocalSettings.Settings': LocalSettings_Settings$json,
};

