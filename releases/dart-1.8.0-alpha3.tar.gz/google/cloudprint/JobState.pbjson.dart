///
//  Generated code. Do not modify.
//  source: google/cloudprint/JobState.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const JobState$json = const {
  '1': 'JobState',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.JobState.Type', '10': 'type'},
    const {'1': 'user_action_cause', '3': 2, '4': 1, '5': 11, '6': '.google.cloudprint.JobState.UserActionCause', '10': 'userActionCause'},
    const {'1': 'device_state_cause', '3': 3, '4': 1, '5': 11, '6': '.google.cloudprint.JobState.DeviceStateCause', '10': 'deviceStateCause'},
    const {'1': 'device_action_cause', '3': 4, '4': 1, '5': 11, '6': '.google.cloudprint.JobState.DeviceActionCause', '10': 'deviceActionCause'},
    const {'1': 'service_action_cause', '3': 5, '4': 1, '5': 11, '6': '.google.cloudprint.JobState.ServiceActionCause', '10': 'serviceActionCause'},
  ],
  '3': const [JobState_UserActionCause$json, JobState_DeviceStateCause$json, JobState_DeviceActionCause$json, JobState_ServiceActionCause$json],
  '4': const [JobState_Type$json],
};

const JobState_UserActionCause$json = const {
  '1': 'UserActionCause',
  '2': const [
    const {'1': 'action_code', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.JobState.UserActionCause.ActionCode', '10': 'actionCode'},
  ],
  '4': const [JobState_UserActionCause_ActionCode$json],
};

const JobState_UserActionCause_ActionCode$json = const {
  '1': 'ActionCode',
  '2': const [
    const {'1': 'CANCELLED', '2': 0},
    const {'1': 'PAUSED', '2': 1},
    const {'1': 'OTHER', '2': 100},
  ],
};

const JobState_DeviceStateCause$json = const {
  '1': 'DeviceStateCause',
  '2': const [
    const {'1': 'error_code', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.JobState.DeviceStateCause.ErrorCode', '10': 'errorCode'},
  ],
  '4': const [JobState_DeviceStateCause_ErrorCode$json],
};

const JobState_DeviceStateCause_ErrorCode$json = const {
  '1': 'ErrorCode',
  '2': const [
    const {'1': 'INPUT_TRAY', '2': 0},
    const {'1': 'MARKER', '2': 1},
    const {'1': 'MEDIA_PATH', '2': 2},
    const {'1': 'MEDIA_SIZE', '2': 3},
    const {'1': 'MEDIA_TYPE', '2': 4},
    const {'1': 'OTHER', '2': 100},
  ],
};

const JobState_DeviceActionCause$json = const {
  '1': 'DeviceActionCause',
  '2': const [
    const {'1': 'error_code', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.JobState.DeviceActionCause.ErrorCode', '10': 'errorCode'},
  ],
  '4': const [JobState_DeviceActionCause_ErrorCode$json],
};

const JobState_DeviceActionCause_ErrorCode$json = const {
  '1': 'ErrorCode',
  '2': const [
    const {'1': 'DOWNLOAD_FAILURE', '2': 0},
    const {'1': 'INVALID_TICKET', '2': 1},
    const {'1': 'PRINT_FAILURE', '2': 2},
    const {'1': 'OTHER', '2': 100},
  ],
};

const JobState_ServiceActionCause$json = const {
  '1': 'ServiceActionCause',
  '2': const [
    const {'1': 'error_code', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.JobState.ServiceActionCause.ErrorCode', '10': 'errorCode'},
  ],
  '4': const [JobState_ServiceActionCause_ErrorCode$json],
};

const JobState_ServiceActionCause_ErrorCode$json = const {
  '1': 'ErrorCode',
  '2': const [
    const {'1': 'COMMUNICATION_WITH_DEVICE_ERROR', '2': 0},
    const {'1': 'CONVERSION_ERROR', '2': 1},
    const {'1': 'CONVERSION_FILE_TOO_BIG', '2': 2},
    const {'1': 'CONVERSION_UNSUPPORTED_CONTENT_TYPE', '2': 3},
    const {'1': 'DELIVERY_FAILURE', '2': 11},
    const {'1': 'EXPIRATION', '2': 14},
    const {'1': 'FETCH_DOCUMENT_FORBIDDEN', '2': 4},
    const {'1': 'FETCH_DOCUMENT_NOT_FOUND', '2': 5},
    const {'1': 'GOOGLE_DRIVE_QUOTA', '2': 15},
    const {'1': 'INCONSISTENT_JOB', '2': 6},
    const {'1': 'INCONSISTENT_PRINTER', '2': 13},
    const {'1': 'PRINTER_DELETED', '2': 12},
    const {'1': 'REMOTE_JOB_NO_LONGER_EXISTS', '2': 7},
    const {'1': 'REMOTE_JOB_ERROR', '2': 8},
    const {'1': 'REMOTE_JOB_TIMEOUT', '2': 9},
    const {'1': 'REMOTE_JOB_ABORTED', '2': 10},
    const {'1': 'OTHER', '2': 100},
  ],
};

const JobState_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'DRAFT', '2': 0},
    const {'1': 'HELD', '2': 1},
    const {'1': 'QUEUED', '2': 2},
    const {'1': 'IN_PROGRESS', '2': 3},
    const {'1': 'STOPPED', '2': 4},
    const {'1': 'DONE', '2': 5},
    const {'1': 'ABORTED', '2': 6},
  ],
};

const PrintJobUiState$json = const {
  '1': 'PrintJobUiState',
  '2': const [
    const {'1': 'summary', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.PrintJobUiState.Summary', '10': 'summary'},
    const {'1': 'progress', '3': 2, '4': 1, '5': 9, '10': 'progress'},
    const {'1': 'cause', '3': 3, '4': 1, '5': 9, '10': 'cause'},
  ],
  '4': const [PrintJobUiState_Summary$json],
};

const PrintJobUiState_Summary$json = const {
  '1': 'Summary',
  '2': const [
    const {'1': 'DRAFT', '2': 0},
    const {'1': 'QUEUED', '2': 1},
    const {'1': 'IN_PROGRESS', '2': 2},
    const {'1': 'PAUSED', '2': 3},
    const {'1': 'DONE', '2': 4},
    const {'1': 'CANCELLED', '2': 5},
    const {'1': 'ERROR', '2': 6},
    const {'1': 'EXPIRED', '2': 7},
  ],
};

