///
//  Generated code. Do not modify.
//  source: google/cloudprint/JobState.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class JobState_Type extends $pb.ProtobufEnum {
  static const JobState_Type DRAFT = JobState_Type._(0, 'DRAFT');
  static const JobState_Type HELD = JobState_Type._(1, 'HELD');
  static const JobState_Type QUEUED = JobState_Type._(2, 'QUEUED');
  static const JobState_Type IN_PROGRESS = JobState_Type._(3, 'IN_PROGRESS');
  static const JobState_Type STOPPED = JobState_Type._(4, 'STOPPED');
  static const JobState_Type DONE = JobState_Type._(5, 'DONE');
  static const JobState_Type ABORTED = JobState_Type._(6, 'ABORTED');

  static const $core.List<JobState_Type> values = <JobState_Type> [
    DRAFT,
    HELD,
    QUEUED,
    IN_PROGRESS,
    STOPPED,
    DONE,
    ABORTED,
  ];

  static final $core.Map<$core.int, JobState_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static JobState_Type valueOf($core.int value) => _byValue[value];

  const JobState_Type._($core.int v, $core.String n) : super(v, n);
}

class JobState_UserActionCause_ActionCode extends $pb.ProtobufEnum {
  static const JobState_UserActionCause_ActionCode CANCELLED = JobState_UserActionCause_ActionCode._(0, 'CANCELLED');
  static const JobState_UserActionCause_ActionCode PAUSED = JobState_UserActionCause_ActionCode._(1, 'PAUSED');
  static const JobState_UserActionCause_ActionCode OTHER = JobState_UserActionCause_ActionCode._(100, 'OTHER');

  static const $core.List<JobState_UserActionCause_ActionCode> values = <JobState_UserActionCause_ActionCode> [
    CANCELLED,
    PAUSED,
    OTHER,
  ];

  static final $core.Map<$core.int, JobState_UserActionCause_ActionCode> _byValue = $pb.ProtobufEnum.initByValue(values);
  static JobState_UserActionCause_ActionCode valueOf($core.int value) => _byValue[value];

  const JobState_UserActionCause_ActionCode._($core.int v, $core.String n) : super(v, n);
}

class JobState_DeviceStateCause_ErrorCode extends $pb.ProtobufEnum {
  static const JobState_DeviceStateCause_ErrorCode INPUT_TRAY = JobState_DeviceStateCause_ErrorCode._(0, 'INPUT_TRAY');
  static const JobState_DeviceStateCause_ErrorCode MARKER = JobState_DeviceStateCause_ErrorCode._(1, 'MARKER');
  static const JobState_DeviceStateCause_ErrorCode MEDIA_PATH = JobState_DeviceStateCause_ErrorCode._(2, 'MEDIA_PATH');
  static const JobState_DeviceStateCause_ErrorCode MEDIA_SIZE = JobState_DeviceStateCause_ErrorCode._(3, 'MEDIA_SIZE');
  static const JobState_DeviceStateCause_ErrorCode MEDIA_TYPE = JobState_DeviceStateCause_ErrorCode._(4, 'MEDIA_TYPE');
  static const JobState_DeviceStateCause_ErrorCode OTHER = JobState_DeviceStateCause_ErrorCode._(100, 'OTHER');

  static const $core.List<JobState_DeviceStateCause_ErrorCode> values = <JobState_DeviceStateCause_ErrorCode> [
    INPUT_TRAY,
    MARKER,
    MEDIA_PATH,
    MEDIA_SIZE,
    MEDIA_TYPE,
    OTHER,
  ];

  static final $core.Map<$core.int, JobState_DeviceStateCause_ErrorCode> _byValue = $pb.ProtobufEnum.initByValue(values);
  static JobState_DeviceStateCause_ErrorCode valueOf($core.int value) => _byValue[value];

  const JobState_DeviceStateCause_ErrorCode._($core.int v, $core.String n) : super(v, n);
}

class JobState_DeviceActionCause_ErrorCode extends $pb.ProtobufEnum {
  static const JobState_DeviceActionCause_ErrorCode DOWNLOAD_FAILURE = JobState_DeviceActionCause_ErrorCode._(0, 'DOWNLOAD_FAILURE');
  static const JobState_DeviceActionCause_ErrorCode INVALID_TICKET = JobState_DeviceActionCause_ErrorCode._(1, 'INVALID_TICKET');
  static const JobState_DeviceActionCause_ErrorCode PRINT_FAILURE = JobState_DeviceActionCause_ErrorCode._(2, 'PRINT_FAILURE');
  static const JobState_DeviceActionCause_ErrorCode OTHER = JobState_DeviceActionCause_ErrorCode._(100, 'OTHER');

  static const $core.List<JobState_DeviceActionCause_ErrorCode> values = <JobState_DeviceActionCause_ErrorCode> [
    DOWNLOAD_FAILURE,
    INVALID_TICKET,
    PRINT_FAILURE,
    OTHER,
  ];

  static final $core.Map<$core.int, JobState_DeviceActionCause_ErrorCode> _byValue = $pb.ProtobufEnum.initByValue(values);
  static JobState_DeviceActionCause_ErrorCode valueOf($core.int value) => _byValue[value];

  const JobState_DeviceActionCause_ErrorCode._($core.int v, $core.String n) : super(v, n);
}

class JobState_ServiceActionCause_ErrorCode extends $pb.ProtobufEnum {
  static const JobState_ServiceActionCause_ErrorCode COMMUNICATION_WITH_DEVICE_ERROR = JobState_ServiceActionCause_ErrorCode._(0, 'COMMUNICATION_WITH_DEVICE_ERROR');
  static const JobState_ServiceActionCause_ErrorCode CONVERSION_ERROR = JobState_ServiceActionCause_ErrorCode._(1, 'CONVERSION_ERROR');
  static const JobState_ServiceActionCause_ErrorCode CONVERSION_FILE_TOO_BIG = JobState_ServiceActionCause_ErrorCode._(2, 'CONVERSION_FILE_TOO_BIG');
  static const JobState_ServiceActionCause_ErrorCode CONVERSION_UNSUPPORTED_CONTENT_TYPE = JobState_ServiceActionCause_ErrorCode._(3, 'CONVERSION_UNSUPPORTED_CONTENT_TYPE');
  static const JobState_ServiceActionCause_ErrorCode DELIVERY_FAILURE = JobState_ServiceActionCause_ErrorCode._(11, 'DELIVERY_FAILURE');
  static const JobState_ServiceActionCause_ErrorCode EXPIRATION = JobState_ServiceActionCause_ErrorCode._(14, 'EXPIRATION');
  static const JobState_ServiceActionCause_ErrorCode FETCH_DOCUMENT_FORBIDDEN = JobState_ServiceActionCause_ErrorCode._(4, 'FETCH_DOCUMENT_FORBIDDEN');
  static const JobState_ServiceActionCause_ErrorCode FETCH_DOCUMENT_NOT_FOUND = JobState_ServiceActionCause_ErrorCode._(5, 'FETCH_DOCUMENT_NOT_FOUND');
  static const JobState_ServiceActionCause_ErrorCode GOOGLE_DRIVE_QUOTA = JobState_ServiceActionCause_ErrorCode._(15, 'GOOGLE_DRIVE_QUOTA');
  static const JobState_ServiceActionCause_ErrorCode INCONSISTENT_JOB = JobState_ServiceActionCause_ErrorCode._(6, 'INCONSISTENT_JOB');
  static const JobState_ServiceActionCause_ErrorCode INCONSISTENT_PRINTER = JobState_ServiceActionCause_ErrorCode._(13, 'INCONSISTENT_PRINTER');
  static const JobState_ServiceActionCause_ErrorCode PRINTER_DELETED = JobState_ServiceActionCause_ErrorCode._(12, 'PRINTER_DELETED');
  static const JobState_ServiceActionCause_ErrorCode REMOTE_JOB_NO_LONGER_EXISTS = JobState_ServiceActionCause_ErrorCode._(7, 'REMOTE_JOB_NO_LONGER_EXISTS');
  static const JobState_ServiceActionCause_ErrorCode REMOTE_JOB_ERROR = JobState_ServiceActionCause_ErrorCode._(8, 'REMOTE_JOB_ERROR');
  static const JobState_ServiceActionCause_ErrorCode REMOTE_JOB_TIMEOUT = JobState_ServiceActionCause_ErrorCode._(9, 'REMOTE_JOB_TIMEOUT');
  static const JobState_ServiceActionCause_ErrorCode REMOTE_JOB_ABORTED = JobState_ServiceActionCause_ErrorCode._(10, 'REMOTE_JOB_ABORTED');
  static const JobState_ServiceActionCause_ErrorCode OTHER = JobState_ServiceActionCause_ErrorCode._(100, 'OTHER');

  static const $core.List<JobState_ServiceActionCause_ErrorCode> values = <JobState_ServiceActionCause_ErrorCode> [
    COMMUNICATION_WITH_DEVICE_ERROR,
    CONVERSION_ERROR,
    CONVERSION_FILE_TOO_BIG,
    CONVERSION_UNSUPPORTED_CONTENT_TYPE,
    DELIVERY_FAILURE,
    EXPIRATION,
    FETCH_DOCUMENT_FORBIDDEN,
    FETCH_DOCUMENT_NOT_FOUND,
    GOOGLE_DRIVE_QUOTA,
    INCONSISTENT_JOB,
    INCONSISTENT_PRINTER,
    PRINTER_DELETED,
    REMOTE_JOB_NO_LONGER_EXISTS,
    REMOTE_JOB_ERROR,
    REMOTE_JOB_TIMEOUT,
    REMOTE_JOB_ABORTED,
    OTHER,
  ];

  static final $core.Map<$core.int, JobState_ServiceActionCause_ErrorCode> _byValue = $pb.ProtobufEnum.initByValue(values);
  static JobState_ServiceActionCause_ErrorCode valueOf($core.int value) => _byValue[value];

  const JobState_ServiceActionCause_ErrorCode._($core.int v, $core.String n) : super(v, n);
}

class PrintJobUiState_Summary extends $pb.ProtobufEnum {
  static const PrintJobUiState_Summary DRAFT = PrintJobUiState_Summary._(0, 'DRAFT');
  static const PrintJobUiState_Summary QUEUED = PrintJobUiState_Summary._(1, 'QUEUED');
  static const PrintJobUiState_Summary IN_PROGRESS = PrintJobUiState_Summary._(2, 'IN_PROGRESS');
  static const PrintJobUiState_Summary PAUSED = PrintJobUiState_Summary._(3, 'PAUSED');
  static const PrintJobUiState_Summary DONE = PrintJobUiState_Summary._(4, 'DONE');
  static const PrintJobUiState_Summary CANCELLED = PrintJobUiState_Summary._(5, 'CANCELLED');
  static const PrintJobUiState_Summary ERROR = PrintJobUiState_Summary._(6, 'ERROR');
  static const PrintJobUiState_Summary EXPIRED = PrintJobUiState_Summary._(7, 'EXPIRED');

  static const $core.List<PrintJobUiState_Summary> values = <PrintJobUiState_Summary> [
    DRAFT,
    QUEUED,
    IN_PROGRESS,
    PAUSED,
    DONE,
    CANCELLED,
    ERROR,
    EXPIRED,
  ];

  static final $core.Map<$core.int, PrintJobUiState_Summary> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PrintJobUiState_Summary valueOf($core.int value) => _byValue[value];

  const PrintJobUiState_Summary._($core.int v, $core.String n) : super(v, n);
}

