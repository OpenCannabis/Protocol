///
//  Generated code. Do not modify.
//  source: google/cloudprint/GoogleCloudPrint.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class PrinterConnectionStatus extends $pb.ProtobufEnum {
  static const PrinterConnectionStatus UNKNOWN = PrinterConnectionStatus._(0, 'UNKNOWN');
  static const PrinterConnectionStatus DORMANT = PrinterConnectionStatus._(1, 'DORMANT');
  static const PrinterConnectionStatus OFFLINE = PrinterConnectionStatus._(2, 'OFFLINE');
  static const PrinterConnectionStatus ONLINE = PrinterConnectionStatus._(3, 'ONLINE');

  static const $core.List<PrinterConnectionStatus> values = <PrinterConnectionStatus> [
    UNKNOWN,
    DORMANT,
    OFFLINE,
    ONLINE,
  ];

  static final $core.Map<$core.int, PrinterConnectionStatus> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PrinterConnectionStatus valueOf($core.int value) => _byValue[value];

  const PrinterConnectionStatus._($core.int v, $core.String n) : super(v, n);
}

class ExtraPrinterField extends $pb.ProtobufEnum {
  static const ExtraPrinterField UNKNOWN_EXTRA_FIELDS = ExtraPrinterField._(0, 'UNKNOWN_EXTRA_FIELDS');
  static const ExtraPrinterField CONNECTION_STATUS = ExtraPrinterField._(1, 'CONNECTION_STATUS');
  static const ExtraPrinterField SEMANTIC_STATE = ExtraPrinterField._(2, 'SEMANTIC_STATE');
  static const ExtraPrinterField UI_STATE = ExtraPrinterField._(3, 'UI_STATE');
  static const ExtraPrinterField QUEUED_JOBS_COUNT = ExtraPrinterField._(4, 'QUEUED_JOBS_COUNT');

  static const $core.List<ExtraPrinterField> values = <ExtraPrinterField> [
    UNKNOWN_EXTRA_FIELDS,
    CONNECTION_STATUS,
    SEMANTIC_STATE,
    UI_STATE,
    QUEUED_JOBS_COUNT,
  ];

  static final $core.Map<$core.int, ExtraPrinterField> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ExtraPrinterField valueOf($core.int value) => _byValue[value];

  const ExtraPrinterField._($core.int v, $core.String n) : super(v, n);
}

class ListJobsRequest_JobListSortOrder extends $pb.ProtobufEnum {
  static const ListJobsRequest_JobListSortOrder CREATE_TIME_DESC = ListJobsRequest_JobListSortOrder._(0, 'CREATE_TIME_DESC');
  static const ListJobsRequest_JobListSortOrder CREATE_TIME = ListJobsRequest_JobListSortOrder._(1, 'CREATE_TIME');
  static const ListJobsRequest_JobListSortOrder STATUS = ListJobsRequest_JobListSortOrder._(2, 'STATUS');
  static const ListJobsRequest_JobListSortOrder STATUS_DESC = ListJobsRequest_JobListSortOrder._(3, 'STATUS_DESC');
  static const ListJobsRequest_JobListSortOrder TITLE = ListJobsRequest_JobListSortOrder._(4, 'TITLE');
  static const ListJobsRequest_JobListSortOrder TITLE_DESC = ListJobsRequest_JobListSortOrder._(5, 'TITLE_DESC');

  static const $core.List<ListJobsRequest_JobListSortOrder> values = <ListJobsRequest_JobListSortOrder> [
    CREATE_TIME_DESC,
    CREATE_TIME,
    STATUS,
    STATUS_DESC,
    TITLE,
    TITLE_DESC,
  ];

  static final $core.Map<$core.int, ListJobsRequest_JobListSortOrder> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ListJobsRequest_JobListSortOrder valueOf($core.int value) => _byValue[value];

  const ListJobsRequest_JobListSortOrder._($core.int v, $core.String n) : super(v, n);
}

