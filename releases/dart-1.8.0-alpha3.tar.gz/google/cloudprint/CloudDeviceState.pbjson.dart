///
//  Generated code. Do not modify.
//  source: google/cloudprint/CloudDeviceState.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const CloudDeviceState$json = const {
  '1': 'CloudDeviceState',
  '2': const [
    const {'1': 'version', '3': 1, '4': 1, '5': 9, '10': 'version'},
    const {'1': 'cloud_connection_state', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.CloudDeviceState.CloudConnectionStateType', '10': 'cloudConnectionState'},
    const {'1': 'printer', '3': 3, '4': 1, '5': 11, '6': '.google.cloudprint.PrinterStateSection', '10': 'printer'},
  ],
  '4': const [CloudDeviceState_StateType$json, CloudDeviceState_CloudConnectionStateType$json],
};

const CloudDeviceState_StateType$json = const {
  '1': 'StateType',
  '2': const [
    const {'1': 'IDLE', '2': 0},
    const {'1': 'PROCESSING', '2': 1},
    const {'1': 'STOPPED', '2': 2},
  ],
};

const CloudDeviceState_CloudConnectionStateType$json = const {
  '1': 'CloudConnectionStateType',
  '2': const [
    const {'1': 'UNKNOWN', '2': 0},
    const {'1': 'NOT_CONFIGURED', '2': 1},
    const {'1': 'ONLINE', '2': 2},
    const {'1': 'OFFLINE', '2': 3},
  ],
};

const CloudDeviceUiState$json = const {
  '1': 'CloudDeviceUiState',
  '2': const [
    const {'1': 'summary', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.CloudDeviceUiState.Summary', '10': 'summary'},
    const {'1': 'severity', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.CloudDeviceUiState.Severity', '10': 'severity'},
    const {'1': 'num_issues', '3': 3, '4': 1, '5': 5, '10': 'numIssues'},
    const {'1': 'caption', '3': 4, '4': 1, '5': 9, '10': 'caption'},
    const {'1': 'printer', '3': 5, '4': 1, '5': 11, '6': '.google.cloudprint.PrinterUiStateSection', '10': 'printer'},
  ],
  '4': const [CloudDeviceUiState_Summary$json, CloudDeviceUiState_Severity$json],
};

const CloudDeviceUiState_Summary$json = const {
  '1': 'Summary',
  '2': const [
    const {'1': 'IDLE', '2': 0},
    const {'1': 'PROCESSING', '2': 1},
    const {'1': 'STOPPED', '2': 2},
    const {'1': 'OFFLINE', '2': 3},
  ],
};

const CloudDeviceUiState_Severity$json = const {
  '1': 'Severity',
  '2': const [
    const {'1': 'NONE', '2': 0},
    const {'1': 'LOW', '2': 1},
    const {'1': 'MEDIUM', '2': 2},
    const {'1': 'HIGH', '2': 3},
  ],
};

const PrinterUiStateSection$json = const {
  '1': 'PrinterUiStateSection',
  '2': const [
    const {'1': 'vendor_item', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.PrinterUiStateSection.Item', '10': 'vendorItem'},
    const {'1': 'input_tray_item', '3': 2, '4': 3, '5': 11, '6': '.google.cloudprint.PrinterUiStateSection.Item', '10': 'inputTrayItem'},
    const {'1': 'output_bin_item', '3': 3, '4': 3, '5': 11, '6': '.google.cloudprint.PrinterUiStateSection.Item', '10': 'outputBinItem'},
    const {'1': 'marker_item', '3': 4, '4': 3, '5': 11, '6': '.google.cloudprint.PrinterUiStateSection.Item', '10': 'markerItem'},
    const {'1': 'cover_item', '3': 5, '4': 3, '5': 11, '6': '.google.cloudprint.PrinterUiStateSection.Item', '10': 'coverItem'},
    const {'1': 'media_path_item', '3': 6, '4': 3, '5': 11, '6': '.google.cloudprint.PrinterUiStateSection.Item', '10': 'mediaPathItem'},
  ],
  '3': const [PrinterUiStateSection_Item$json],
};

const PrinterUiStateSection_Item$json = const {
  '1': 'Item',
  '2': const [
    const {'1': 'severity', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.CloudDeviceUiState.Severity', '10': 'severity'},
    const {'1': 'message', '3': 2, '4': 1, '5': 9, '10': 'message'},
    const {'1': 'vendor_message', '3': 3, '4': 1, '5': 9, '10': 'vendorMessage'},
    const {'1': 'level_percent', '3': 4, '4': 1, '5': 5, '10': 'levelPercent'},
    const {'1': 'color', '3': 5, '4': 1, '5': 14, '6': '.google.cloudprint.Marker.Color.Type', '10': 'color'},
  ],
};

const PrinterStateSection$json = const {
  '1': 'PrinterStateSection',
  '2': const [
    const {'1': 'state', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.CloudDeviceState.StateType', '10': 'state'},
    const {'1': 'input_tray_state', '3': 2, '4': 1, '5': 11, '6': '.google.cloudprint.InputTrayState', '10': 'inputTrayState'},
    const {'1': 'output_bin_state', '3': 3, '4': 1, '5': 11, '6': '.google.cloudprint.OutputBinState', '10': 'outputBinState'},
    const {'1': 'marker_state', '3': 4, '4': 1, '5': 11, '6': '.google.cloudprint.MarkerState', '10': 'markerState'},
    const {'1': 'cover_state', '3': 5, '4': 1, '5': 11, '6': '.google.cloudprint.CoverState', '10': 'coverState'},
    const {'1': 'media_path_state', '3': 6, '4': 1, '5': 11, '6': '.google.cloudprint.MediaPathState', '10': 'mediaPathState'},
    const {'1': 'vendor_state', '3': 101, '4': 1, '5': 11, '6': '.google.cloudprint.VendorState', '10': 'vendorState'},
  ],
};

const InputTrayState$json = const {
  '1': 'InputTrayState',
  '2': const [
    const {'1': 'item', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.InputTrayState.Item', '10': 'item'},
  ],
  '3': const [InputTrayState_Item$json],
};

const InputTrayState_Item$json = const {
  '1': 'Item',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'state', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.InputTrayState.Item.StateType', '10': 'state'},
    const {'1': 'level_percent', '3': 3, '4': 1, '5': 5, '10': 'levelPercent'},
    const {'1': 'vendor_message', '3': 101, '4': 1, '5': 9, '10': 'vendorMessage'},
  ],
  '4': const [InputTrayState_Item_StateType$json],
};

const InputTrayState_Item_StateType$json = const {
  '1': 'StateType',
  '2': const [
    const {'1': 'OK', '2': 0},
    const {'1': 'EMPTY', '2': 1},
    const {'1': 'OPEN', '2': 2},
    const {'1': 'OFF', '2': 3},
    const {'1': 'FAILURE', '2': 4},
  ],
};

const OutputBinState$json = const {
  '1': 'OutputBinState',
  '2': const [
    const {'1': 'item', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.OutputBinState.Item', '10': 'item'},
  ],
  '3': const [OutputBinState_Item$json],
};

const OutputBinState_Item$json = const {
  '1': 'Item',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'state', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.OutputBinState.Item.StateType', '10': 'state'},
    const {'1': 'level_percent', '3': 3, '4': 1, '5': 5, '10': 'levelPercent'},
    const {'1': 'vendor_message', '3': 101, '4': 1, '5': 9, '10': 'vendorMessage'},
  ],
  '4': const [OutputBinState_Item_StateType$json],
};

const OutputBinState_Item_StateType$json = const {
  '1': 'StateType',
  '2': const [
    const {'1': 'OK', '2': 0},
    const {'1': 'FULL', '2': 1},
    const {'1': 'OPEN', '2': 2},
    const {'1': 'OFF', '2': 3},
    const {'1': 'FAILURE', '2': 4},
  ],
};

const MarkerState$json = const {
  '1': 'MarkerState',
  '2': const [
    const {'1': 'item', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.MarkerState.Item', '10': 'item'},
  ],
  '3': const [MarkerState_Item$json],
};

const MarkerState_Item$json = const {
  '1': 'Item',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'state', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.MarkerState.Item.StateType', '10': 'state'},
    const {'1': 'level_percent', '3': 3, '4': 1, '5': 5, '10': 'levelPercent'},
    const {'1': 'level_pages', '3': 4, '4': 1, '5': 5, '10': 'levelPages'},
    const {'1': 'vendor_message', '3': 101, '4': 1, '5': 9, '10': 'vendorMessage'},
  ],
  '4': const [MarkerState_Item_StateType$json],
};

const MarkerState_Item_StateType$json = const {
  '1': 'StateType',
  '2': const [
    const {'1': 'OK', '2': 0},
    const {'1': 'EXHAUSTED', '2': 1},
    const {'1': 'REMOVED', '2': 2},
    const {'1': 'FAILURE', '2': 3},
  ],
};

const CoverState$json = const {
  '1': 'CoverState',
  '2': const [
    const {'1': 'item', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.CoverState.Item', '10': 'item'},
  ],
  '3': const [CoverState_Item$json],
};

const CoverState_Item$json = const {
  '1': 'Item',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'state', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.CoverState.Item.StateType', '10': 'state'},
    const {'1': 'vendor_message', '3': 101, '4': 1, '5': 9, '10': 'vendorMessage'},
  ],
  '4': const [CoverState_Item_StateType$json],
};

const CoverState_Item_StateType$json = const {
  '1': 'StateType',
  '2': const [
    const {'1': 'OK', '2': 0},
    const {'1': 'OPEN', '2': 1},
    const {'1': 'FAILURE', '2': 2},
  ],
};

const MediaPathState$json = const {
  '1': 'MediaPathState',
  '2': const [
    const {'1': 'item', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.MediaPathState.Item', '10': 'item'},
  ],
  '3': const [MediaPathState_Item$json],
};

const MediaPathState_Item$json = const {
  '1': 'Item',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'state', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.MediaPathState.Item.StateType', '10': 'state'},
    const {'1': 'vendor_message', '3': 101, '4': 1, '5': 9, '10': 'vendorMessage'},
  ],
  '4': const [MediaPathState_Item_StateType$json],
};

const MediaPathState_Item_StateType$json = const {
  '1': 'StateType',
  '2': const [
    const {'1': 'OK', '2': 0},
    const {'1': 'MEDIA_JAM', '2': 1},
    const {'1': 'FAILURE', '2': 2},
  ],
};

const VendorState$json = const {
  '1': 'VendorState',
  '2': const [
    const {'1': 'item', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.VendorState.Item', '10': 'item'},
  ],
  '3': const [VendorState_Item$json],
};

const VendorState_Item$json = const {
  '1': 'Item',
  '2': const [
    const {'1': 'state', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.VendorState.Item.StateType', '10': 'state'},
    const {'1': 'description', '3': 2, '4': 1, '5': 9, '10': 'description'},
    const {'1': 'description_localized', '3': 3, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'descriptionLocalized'},
  ],
  '4': const [VendorState_Item_StateType$json],
};

const VendorState_Item_StateType$json = const {
  '1': 'StateType',
  '2': const [
    const {'1': 'ERROR', '2': 0},
    const {'1': 'WARNING', '2': 1},
    const {'1': 'INFO', '2': 2},
  ],
};

