///
//  Generated code. Do not modify.
//  source: google/cloudprint/CloudDeviceState.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Common.pb.dart' as $30;

import 'CloudDeviceState.pbenum.dart';
import 'Common.pbenum.dart' as $30;

export 'CloudDeviceState.pbenum.dart';

class CloudDeviceState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CloudDeviceState', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'version')
    ..e<CloudDeviceState_CloudConnectionStateType>(2, 'cloudConnectionState', $pb.PbFieldType.OE, CloudDeviceState_CloudConnectionStateType.UNKNOWN, CloudDeviceState_CloudConnectionStateType.valueOf, CloudDeviceState_CloudConnectionStateType.values)
    ..a<PrinterStateSection>(3, 'printer', $pb.PbFieldType.OM, PrinterStateSection.getDefault, PrinterStateSection.create)
    ..hasRequiredFields = false
  ;

  CloudDeviceState() : super();
  CloudDeviceState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CloudDeviceState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CloudDeviceState clone() => CloudDeviceState()..mergeFromMessage(this);
  CloudDeviceState copyWith(void Function(CloudDeviceState) updates) => super.copyWith((message) => updates(message as CloudDeviceState));
  $pb.BuilderInfo get info_ => _i;
  static CloudDeviceState create() => CloudDeviceState();
  CloudDeviceState createEmptyInstance() => create();
  static $pb.PbList<CloudDeviceState> createRepeated() => $pb.PbList<CloudDeviceState>();
  static CloudDeviceState getDefault() => _defaultInstance ??= create()..freeze();
  static CloudDeviceState _defaultInstance;

  $core.String get version => $_getS(0, '');
  set version($core.String v) { $_setString(0, v); }
  $core.bool hasVersion() => $_has(0);
  void clearVersion() => clearField(1);

  CloudDeviceState_CloudConnectionStateType get cloudConnectionState => $_getN(1);
  set cloudConnectionState(CloudDeviceState_CloudConnectionStateType v) { setField(2, v); }
  $core.bool hasCloudConnectionState() => $_has(1);
  void clearCloudConnectionState() => clearField(2);

  PrinterStateSection get printer => $_getN(2);
  set printer(PrinterStateSection v) { setField(3, v); }
  $core.bool hasPrinter() => $_has(2);
  void clearPrinter() => clearField(3);
}

class CloudDeviceUiState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CloudDeviceUiState', package: const $pb.PackageName('google.cloudprint'))
    ..e<CloudDeviceUiState_Summary>(1, 'summary', $pb.PbFieldType.OE, CloudDeviceUiState_Summary.IDLE, CloudDeviceUiState_Summary.valueOf, CloudDeviceUiState_Summary.values)
    ..e<CloudDeviceUiState_Severity>(2, 'severity', $pb.PbFieldType.OE, CloudDeviceUiState_Severity.NONE, CloudDeviceUiState_Severity.valueOf, CloudDeviceUiState_Severity.values)
    ..a<$core.int>(3, 'numIssues', $pb.PbFieldType.O3)
    ..aOS(4, 'caption')
    ..a<PrinterUiStateSection>(5, 'printer', $pb.PbFieldType.OM, PrinterUiStateSection.getDefault, PrinterUiStateSection.create)
    ..hasRequiredFields = false
  ;

  CloudDeviceUiState() : super();
  CloudDeviceUiState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CloudDeviceUiState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CloudDeviceUiState clone() => CloudDeviceUiState()..mergeFromMessage(this);
  CloudDeviceUiState copyWith(void Function(CloudDeviceUiState) updates) => super.copyWith((message) => updates(message as CloudDeviceUiState));
  $pb.BuilderInfo get info_ => _i;
  static CloudDeviceUiState create() => CloudDeviceUiState();
  CloudDeviceUiState createEmptyInstance() => create();
  static $pb.PbList<CloudDeviceUiState> createRepeated() => $pb.PbList<CloudDeviceUiState>();
  static CloudDeviceUiState getDefault() => _defaultInstance ??= create()..freeze();
  static CloudDeviceUiState _defaultInstance;

  CloudDeviceUiState_Summary get summary => $_getN(0);
  set summary(CloudDeviceUiState_Summary v) { setField(1, v); }
  $core.bool hasSummary() => $_has(0);
  void clearSummary() => clearField(1);

  CloudDeviceUiState_Severity get severity => $_getN(1);
  set severity(CloudDeviceUiState_Severity v) { setField(2, v); }
  $core.bool hasSeverity() => $_has(1);
  void clearSeverity() => clearField(2);

  $core.int get numIssues => $_get(2, 0);
  set numIssues($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasNumIssues() => $_has(2);
  void clearNumIssues() => clearField(3);

  $core.String get caption => $_getS(3, '');
  set caption($core.String v) { $_setString(3, v); }
  $core.bool hasCaption() => $_has(3);
  void clearCaption() => clearField(4);

  PrinterUiStateSection get printer => $_getN(4);
  set printer(PrinterUiStateSection v) { setField(5, v); }
  $core.bool hasPrinter() => $_has(4);
  void clearPrinter() => clearField(5);
}

class PrinterUiStateSection_Item extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrinterUiStateSection.Item', package: const $pb.PackageName('google.cloudprint'))
    ..e<CloudDeviceUiState_Severity>(1, 'severity', $pb.PbFieldType.OE, CloudDeviceUiState_Severity.NONE, CloudDeviceUiState_Severity.valueOf, CloudDeviceUiState_Severity.values)
    ..aOS(2, 'message')
    ..aOS(3, 'vendorMessage')
    ..a<$core.int>(4, 'levelPercent', $pb.PbFieldType.O3)
    ..e<$30.Marker_Color_Type>(5, 'color', $pb.PbFieldType.OE, $30.Marker_Color_Type.CUSTOM, $30.Marker_Color_Type.valueOf, $30.Marker_Color_Type.values)
    ..hasRequiredFields = false
  ;

  PrinterUiStateSection_Item() : super();
  PrinterUiStateSection_Item.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrinterUiStateSection_Item.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrinterUiStateSection_Item clone() => PrinterUiStateSection_Item()..mergeFromMessage(this);
  PrinterUiStateSection_Item copyWith(void Function(PrinterUiStateSection_Item) updates) => super.copyWith((message) => updates(message as PrinterUiStateSection_Item));
  $pb.BuilderInfo get info_ => _i;
  static PrinterUiStateSection_Item create() => PrinterUiStateSection_Item();
  PrinterUiStateSection_Item createEmptyInstance() => create();
  static $pb.PbList<PrinterUiStateSection_Item> createRepeated() => $pb.PbList<PrinterUiStateSection_Item>();
  static PrinterUiStateSection_Item getDefault() => _defaultInstance ??= create()..freeze();
  static PrinterUiStateSection_Item _defaultInstance;

  CloudDeviceUiState_Severity get severity => $_getN(0);
  set severity(CloudDeviceUiState_Severity v) { setField(1, v); }
  $core.bool hasSeverity() => $_has(0);
  void clearSeverity() => clearField(1);

  $core.String get message => $_getS(1, '');
  set message($core.String v) { $_setString(1, v); }
  $core.bool hasMessage() => $_has(1);
  void clearMessage() => clearField(2);

  $core.String get vendorMessage => $_getS(2, '');
  set vendorMessage($core.String v) { $_setString(2, v); }
  $core.bool hasVendorMessage() => $_has(2);
  void clearVendorMessage() => clearField(3);

  $core.int get levelPercent => $_get(3, 0);
  set levelPercent($core.int v) { $_setSignedInt32(3, v); }
  $core.bool hasLevelPercent() => $_has(3);
  void clearLevelPercent() => clearField(4);

  $30.Marker_Color_Type get color => $_getN(4);
  set color($30.Marker_Color_Type v) { setField(5, v); }
  $core.bool hasColor() => $_has(4);
  void clearColor() => clearField(5);
}

class PrinterUiStateSection extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrinterUiStateSection', package: const $pb.PackageName('google.cloudprint'))
    ..pc<PrinterUiStateSection_Item>(1, 'vendorItem', $pb.PbFieldType.PM,PrinterUiStateSection_Item.create)
    ..pc<PrinterUiStateSection_Item>(2, 'inputTrayItem', $pb.PbFieldType.PM,PrinterUiStateSection_Item.create)
    ..pc<PrinterUiStateSection_Item>(3, 'outputBinItem', $pb.PbFieldType.PM,PrinterUiStateSection_Item.create)
    ..pc<PrinterUiStateSection_Item>(4, 'markerItem', $pb.PbFieldType.PM,PrinterUiStateSection_Item.create)
    ..pc<PrinterUiStateSection_Item>(5, 'coverItem', $pb.PbFieldType.PM,PrinterUiStateSection_Item.create)
    ..pc<PrinterUiStateSection_Item>(6, 'mediaPathItem', $pb.PbFieldType.PM,PrinterUiStateSection_Item.create)
    ..hasRequiredFields = false
  ;

  PrinterUiStateSection() : super();
  PrinterUiStateSection.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrinterUiStateSection.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrinterUiStateSection clone() => PrinterUiStateSection()..mergeFromMessage(this);
  PrinterUiStateSection copyWith(void Function(PrinterUiStateSection) updates) => super.copyWith((message) => updates(message as PrinterUiStateSection));
  $pb.BuilderInfo get info_ => _i;
  static PrinterUiStateSection create() => PrinterUiStateSection();
  PrinterUiStateSection createEmptyInstance() => create();
  static $pb.PbList<PrinterUiStateSection> createRepeated() => $pb.PbList<PrinterUiStateSection>();
  static PrinterUiStateSection getDefault() => _defaultInstance ??= create()..freeze();
  static PrinterUiStateSection _defaultInstance;

  $core.List<PrinterUiStateSection_Item> get vendorItem => $_getList(0);

  $core.List<PrinterUiStateSection_Item> get inputTrayItem => $_getList(1);

  $core.List<PrinterUiStateSection_Item> get outputBinItem => $_getList(2);

  $core.List<PrinterUiStateSection_Item> get markerItem => $_getList(3);

  $core.List<PrinterUiStateSection_Item> get coverItem => $_getList(4);

  $core.List<PrinterUiStateSection_Item> get mediaPathItem => $_getList(5);
}

class PrinterStateSection extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrinterStateSection', package: const $pb.PackageName('google.cloudprint'))
    ..e<CloudDeviceState_StateType>(1, 'state', $pb.PbFieldType.OE, CloudDeviceState_StateType.IDLE, CloudDeviceState_StateType.valueOf, CloudDeviceState_StateType.values)
    ..a<InputTrayState>(2, 'inputTrayState', $pb.PbFieldType.OM, InputTrayState.getDefault, InputTrayState.create)
    ..a<OutputBinState>(3, 'outputBinState', $pb.PbFieldType.OM, OutputBinState.getDefault, OutputBinState.create)
    ..a<MarkerState>(4, 'markerState', $pb.PbFieldType.OM, MarkerState.getDefault, MarkerState.create)
    ..a<CoverState>(5, 'coverState', $pb.PbFieldType.OM, CoverState.getDefault, CoverState.create)
    ..a<MediaPathState>(6, 'mediaPathState', $pb.PbFieldType.OM, MediaPathState.getDefault, MediaPathState.create)
    ..a<VendorState>(101, 'vendorState', $pb.PbFieldType.OM, VendorState.getDefault, VendorState.create)
    ..hasRequiredFields = false
  ;

  PrinterStateSection() : super();
  PrinterStateSection.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrinterStateSection.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrinterStateSection clone() => PrinterStateSection()..mergeFromMessage(this);
  PrinterStateSection copyWith(void Function(PrinterStateSection) updates) => super.copyWith((message) => updates(message as PrinterStateSection));
  $pb.BuilderInfo get info_ => _i;
  static PrinterStateSection create() => PrinterStateSection();
  PrinterStateSection createEmptyInstance() => create();
  static $pb.PbList<PrinterStateSection> createRepeated() => $pb.PbList<PrinterStateSection>();
  static PrinterStateSection getDefault() => _defaultInstance ??= create()..freeze();
  static PrinterStateSection _defaultInstance;

  CloudDeviceState_StateType get state => $_getN(0);
  set state(CloudDeviceState_StateType v) { setField(1, v); }
  $core.bool hasState() => $_has(0);
  void clearState() => clearField(1);

  InputTrayState get inputTrayState => $_getN(1);
  set inputTrayState(InputTrayState v) { setField(2, v); }
  $core.bool hasInputTrayState() => $_has(1);
  void clearInputTrayState() => clearField(2);

  OutputBinState get outputBinState => $_getN(2);
  set outputBinState(OutputBinState v) { setField(3, v); }
  $core.bool hasOutputBinState() => $_has(2);
  void clearOutputBinState() => clearField(3);

  MarkerState get markerState => $_getN(3);
  set markerState(MarkerState v) { setField(4, v); }
  $core.bool hasMarkerState() => $_has(3);
  void clearMarkerState() => clearField(4);

  CoverState get coverState => $_getN(4);
  set coverState(CoverState v) { setField(5, v); }
  $core.bool hasCoverState() => $_has(4);
  void clearCoverState() => clearField(5);

  MediaPathState get mediaPathState => $_getN(5);
  set mediaPathState(MediaPathState v) { setField(6, v); }
  $core.bool hasMediaPathState() => $_has(5);
  void clearMediaPathState() => clearField(6);

  VendorState get vendorState => $_getN(6);
  set vendorState(VendorState v) { setField(101, v); }
  $core.bool hasVendorState() => $_has(6);
  void clearVendorState() => clearField(101);
}

class InputTrayState_Item extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InputTrayState.Item', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<InputTrayState_Item_StateType>(2, 'state', $pb.PbFieldType.OE, InputTrayState_Item_StateType.OK, InputTrayState_Item_StateType.valueOf, InputTrayState_Item_StateType.values)
    ..a<$core.int>(3, 'levelPercent', $pb.PbFieldType.O3)
    ..aOS(101, 'vendorMessage')
    ..hasRequiredFields = false
  ;

  InputTrayState_Item() : super();
  InputTrayState_Item.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InputTrayState_Item.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InputTrayState_Item clone() => InputTrayState_Item()..mergeFromMessage(this);
  InputTrayState_Item copyWith(void Function(InputTrayState_Item) updates) => super.copyWith((message) => updates(message as InputTrayState_Item));
  $pb.BuilderInfo get info_ => _i;
  static InputTrayState_Item create() => InputTrayState_Item();
  InputTrayState_Item createEmptyInstance() => create();
  static $pb.PbList<InputTrayState_Item> createRepeated() => $pb.PbList<InputTrayState_Item>();
  static InputTrayState_Item getDefault() => _defaultInstance ??= create()..freeze();
  static InputTrayState_Item _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  InputTrayState_Item_StateType get state => $_getN(1);
  set state(InputTrayState_Item_StateType v) { setField(2, v); }
  $core.bool hasState() => $_has(1);
  void clearState() => clearField(2);

  $core.int get levelPercent => $_get(2, 0);
  set levelPercent($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasLevelPercent() => $_has(2);
  void clearLevelPercent() => clearField(3);

  $core.String get vendorMessage => $_getS(3, '');
  set vendorMessage($core.String v) { $_setString(3, v); }
  $core.bool hasVendorMessage() => $_has(3);
  void clearVendorMessage() => clearField(101);
}

class InputTrayState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InputTrayState', package: const $pb.PackageName('google.cloudprint'))
    ..pc<InputTrayState_Item>(1, 'item', $pb.PbFieldType.PM,InputTrayState_Item.create)
    ..hasRequiredFields = false
  ;

  InputTrayState() : super();
  InputTrayState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InputTrayState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InputTrayState clone() => InputTrayState()..mergeFromMessage(this);
  InputTrayState copyWith(void Function(InputTrayState) updates) => super.copyWith((message) => updates(message as InputTrayState));
  $pb.BuilderInfo get info_ => _i;
  static InputTrayState create() => InputTrayState();
  InputTrayState createEmptyInstance() => create();
  static $pb.PbList<InputTrayState> createRepeated() => $pb.PbList<InputTrayState>();
  static InputTrayState getDefault() => _defaultInstance ??= create()..freeze();
  static InputTrayState _defaultInstance;

  $core.List<InputTrayState_Item> get item => $_getList(0);
}

class OutputBinState_Item extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('OutputBinState.Item', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<OutputBinState_Item_StateType>(2, 'state', $pb.PbFieldType.OE, OutputBinState_Item_StateType.OK, OutputBinState_Item_StateType.valueOf, OutputBinState_Item_StateType.values)
    ..a<$core.int>(3, 'levelPercent', $pb.PbFieldType.O3)
    ..aOS(101, 'vendorMessage')
    ..hasRequiredFields = false
  ;

  OutputBinState_Item() : super();
  OutputBinState_Item.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  OutputBinState_Item.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  OutputBinState_Item clone() => OutputBinState_Item()..mergeFromMessage(this);
  OutputBinState_Item copyWith(void Function(OutputBinState_Item) updates) => super.copyWith((message) => updates(message as OutputBinState_Item));
  $pb.BuilderInfo get info_ => _i;
  static OutputBinState_Item create() => OutputBinState_Item();
  OutputBinState_Item createEmptyInstance() => create();
  static $pb.PbList<OutputBinState_Item> createRepeated() => $pb.PbList<OutputBinState_Item>();
  static OutputBinState_Item getDefault() => _defaultInstance ??= create()..freeze();
  static OutputBinState_Item _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  OutputBinState_Item_StateType get state => $_getN(1);
  set state(OutputBinState_Item_StateType v) { setField(2, v); }
  $core.bool hasState() => $_has(1);
  void clearState() => clearField(2);

  $core.int get levelPercent => $_get(2, 0);
  set levelPercent($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasLevelPercent() => $_has(2);
  void clearLevelPercent() => clearField(3);

  $core.String get vendorMessage => $_getS(3, '');
  set vendorMessage($core.String v) { $_setString(3, v); }
  $core.bool hasVendorMessage() => $_has(3);
  void clearVendorMessage() => clearField(101);
}

class OutputBinState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('OutputBinState', package: const $pb.PackageName('google.cloudprint'))
    ..pc<OutputBinState_Item>(1, 'item', $pb.PbFieldType.PM,OutputBinState_Item.create)
    ..hasRequiredFields = false
  ;

  OutputBinState() : super();
  OutputBinState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  OutputBinState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  OutputBinState clone() => OutputBinState()..mergeFromMessage(this);
  OutputBinState copyWith(void Function(OutputBinState) updates) => super.copyWith((message) => updates(message as OutputBinState));
  $pb.BuilderInfo get info_ => _i;
  static OutputBinState create() => OutputBinState();
  OutputBinState createEmptyInstance() => create();
  static $pb.PbList<OutputBinState> createRepeated() => $pb.PbList<OutputBinState>();
  static OutputBinState getDefault() => _defaultInstance ??= create()..freeze();
  static OutputBinState _defaultInstance;

  $core.List<OutputBinState_Item> get item => $_getList(0);
}

class MarkerState_Item extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MarkerState.Item', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<MarkerState_Item_StateType>(2, 'state', $pb.PbFieldType.OE, MarkerState_Item_StateType.OK, MarkerState_Item_StateType.valueOf, MarkerState_Item_StateType.values)
    ..a<$core.int>(3, 'levelPercent', $pb.PbFieldType.O3)
    ..a<$core.int>(4, 'levelPages', $pb.PbFieldType.O3)
    ..aOS(101, 'vendorMessage')
    ..hasRequiredFields = false
  ;

  MarkerState_Item() : super();
  MarkerState_Item.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MarkerState_Item.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MarkerState_Item clone() => MarkerState_Item()..mergeFromMessage(this);
  MarkerState_Item copyWith(void Function(MarkerState_Item) updates) => super.copyWith((message) => updates(message as MarkerState_Item));
  $pb.BuilderInfo get info_ => _i;
  static MarkerState_Item create() => MarkerState_Item();
  MarkerState_Item createEmptyInstance() => create();
  static $pb.PbList<MarkerState_Item> createRepeated() => $pb.PbList<MarkerState_Item>();
  static MarkerState_Item getDefault() => _defaultInstance ??= create()..freeze();
  static MarkerState_Item _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  MarkerState_Item_StateType get state => $_getN(1);
  set state(MarkerState_Item_StateType v) { setField(2, v); }
  $core.bool hasState() => $_has(1);
  void clearState() => clearField(2);

  $core.int get levelPercent => $_get(2, 0);
  set levelPercent($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasLevelPercent() => $_has(2);
  void clearLevelPercent() => clearField(3);

  $core.int get levelPages => $_get(3, 0);
  set levelPages($core.int v) { $_setSignedInt32(3, v); }
  $core.bool hasLevelPages() => $_has(3);
  void clearLevelPages() => clearField(4);

  $core.String get vendorMessage => $_getS(4, '');
  set vendorMessage($core.String v) { $_setString(4, v); }
  $core.bool hasVendorMessage() => $_has(4);
  void clearVendorMessage() => clearField(101);
}

class MarkerState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MarkerState', package: const $pb.PackageName('google.cloudprint'))
    ..pc<MarkerState_Item>(1, 'item', $pb.PbFieldType.PM,MarkerState_Item.create)
    ..hasRequiredFields = false
  ;

  MarkerState() : super();
  MarkerState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MarkerState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MarkerState clone() => MarkerState()..mergeFromMessage(this);
  MarkerState copyWith(void Function(MarkerState) updates) => super.copyWith((message) => updates(message as MarkerState));
  $pb.BuilderInfo get info_ => _i;
  static MarkerState create() => MarkerState();
  MarkerState createEmptyInstance() => create();
  static $pb.PbList<MarkerState> createRepeated() => $pb.PbList<MarkerState>();
  static MarkerState getDefault() => _defaultInstance ??= create()..freeze();
  static MarkerState _defaultInstance;

  $core.List<MarkerState_Item> get item => $_getList(0);
}

class CoverState_Item extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CoverState.Item', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<CoverState_Item_StateType>(2, 'state', $pb.PbFieldType.OE, CoverState_Item_StateType.OK, CoverState_Item_StateType.valueOf, CoverState_Item_StateType.values)
    ..aOS(101, 'vendorMessage')
    ..hasRequiredFields = false
  ;

  CoverState_Item() : super();
  CoverState_Item.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CoverState_Item.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CoverState_Item clone() => CoverState_Item()..mergeFromMessage(this);
  CoverState_Item copyWith(void Function(CoverState_Item) updates) => super.copyWith((message) => updates(message as CoverState_Item));
  $pb.BuilderInfo get info_ => _i;
  static CoverState_Item create() => CoverState_Item();
  CoverState_Item createEmptyInstance() => create();
  static $pb.PbList<CoverState_Item> createRepeated() => $pb.PbList<CoverState_Item>();
  static CoverState_Item getDefault() => _defaultInstance ??= create()..freeze();
  static CoverState_Item _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  CoverState_Item_StateType get state => $_getN(1);
  set state(CoverState_Item_StateType v) { setField(2, v); }
  $core.bool hasState() => $_has(1);
  void clearState() => clearField(2);

  $core.String get vendorMessage => $_getS(2, '');
  set vendorMessage($core.String v) { $_setString(2, v); }
  $core.bool hasVendorMessage() => $_has(2);
  void clearVendorMessage() => clearField(101);
}

class CoverState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CoverState', package: const $pb.PackageName('google.cloudprint'))
    ..pc<CoverState_Item>(1, 'item', $pb.PbFieldType.PM,CoverState_Item.create)
    ..hasRequiredFields = false
  ;

  CoverState() : super();
  CoverState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CoverState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CoverState clone() => CoverState()..mergeFromMessage(this);
  CoverState copyWith(void Function(CoverState) updates) => super.copyWith((message) => updates(message as CoverState));
  $pb.BuilderInfo get info_ => _i;
  static CoverState create() => CoverState();
  CoverState createEmptyInstance() => create();
  static $pb.PbList<CoverState> createRepeated() => $pb.PbList<CoverState>();
  static CoverState getDefault() => _defaultInstance ??= create()..freeze();
  static CoverState _defaultInstance;

  $core.List<CoverState_Item> get item => $_getList(0);
}

class MediaPathState_Item extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaPathState.Item', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<MediaPathState_Item_StateType>(2, 'state', $pb.PbFieldType.OE, MediaPathState_Item_StateType.OK, MediaPathState_Item_StateType.valueOf, MediaPathState_Item_StateType.values)
    ..aOS(101, 'vendorMessage')
    ..hasRequiredFields = false
  ;

  MediaPathState_Item() : super();
  MediaPathState_Item.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaPathState_Item.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaPathState_Item clone() => MediaPathState_Item()..mergeFromMessage(this);
  MediaPathState_Item copyWith(void Function(MediaPathState_Item) updates) => super.copyWith((message) => updates(message as MediaPathState_Item));
  $pb.BuilderInfo get info_ => _i;
  static MediaPathState_Item create() => MediaPathState_Item();
  MediaPathState_Item createEmptyInstance() => create();
  static $pb.PbList<MediaPathState_Item> createRepeated() => $pb.PbList<MediaPathState_Item>();
  static MediaPathState_Item getDefault() => _defaultInstance ??= create()..freeze();
  static MediaPathState_Item _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  MediaPathState_Item_StateType get state => $_getN(1);
  set state(MediaPathState_Item_StateType v) { setField(2, v); }
  $core.bool hasState() => $_has(1);
  void clearState() => clearField(2);

  $core.String get vendorMessage => $_getS(2, '');
  set vendorMessage($core.String v) { $_setString(2, v); }
  $core.bool hasVendorMessage() => $_has(2);
  void clearVendorMessage() => clearField(101);
}

class MediaPathState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaPathState', package: const $pb.PackageName('google.cloudprint'))
    ..pc<MediaPathState_Item>(1, 'item', $pb.PbFieldType.PM,MediaPathState_Item.create)
    ..hasRequiredFields = false
  ;

  MediaPathState() : super();
  MediaPathState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaPathState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaPathState clone() => MediaPathState()..mergeFromMessage(this);
  MediaPathState copyWith(void Function(MediaPathState) updates) => super.copyWith((message) => updates(message as MediaPathState));
  $pb.BuilderInfo get info_ => _i;
  static MediaPathState create() => MediaPathState();
  MediaPathState createEmptyInstance() => create();
  static $pb.PbList<MediaPathState> createRepeated() => $pb.PbList<MediaPathState>();
  static MediaPathState getDefault() => _defaultInstance ??= create()..freeze();
  static MediaPathState _defaultInstance;

  $core.List<MediaPathState_Item> get item => $_getList(0);
}

class VendorState_Item extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('VendorState.Item', package: const $pb.PackageName('google.cloudprint'))
    ..e<VendorState_Item_StateType>(1, 'state', $pb.PbFieldType.OE, VendorState_Item_StateType.ERROR, VendorState_Item_StateType.valueOf, VendorState_Item_StateType.values)
    ..aOS(2, 'description')
    ..pc<$30.LocalizedString>(3, 'descriptionLocalized', $pb.PbFieldType.PM,$30.LocalizedString.create)
    ..hasRequiredFields = false
  ;

  VendorState_Item() : super();
  VendorState_Item.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  VendorState_Item.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  VendorState_Item clone() => VendorState_Item()..mergeFromMessage(this);
  VendorState_Item copyWith(void Function(VendorState_Item) updates) => super.copyWith((message) => updates(message as VendorState_Item));
  $pb.BuilderInfo get info_ => _i;
  static VendorState_Item create() => VendorState_Item();
  VendorState_Item createEmptyInstance() => create();
  static $pb.PbList<VendorState_Item> createRepeated() => $pb.PbList<VendorState_Item>();
  static VendorState_Item getDefault() => _defaultInstance ??= create()..freeze();
  static VendorState_Item _defaultInstance;

  VendorState_Item_StateType get state => $_getN(0);
  set state(VendorState_Item_StateType v) { setField(1, v); }
  $core.bool hasState() => $_has(0);
  void clearState() => clearField(1);

  $core.String get description => $_getS(1, '');
  set description($core.String v) { $_setString(1, v); }
  $core.bool hasDescription() => $_has(1);
  void clearDescription() => clearField(2);

  $core.List<$30.LocalizedString> get descriptionLocalized => $_getList(2);
}

class VendorState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('VendorState', package: const $pb.PackageName('google.cloudprint'))
    ..pc<VendorState_Item>(1, 'item', $pb.PbFieldType.PM,VendorState_Item.create)
    ..hasRequiredFields = false
  ;

  VendorState() : super();
  VendorState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  VendorState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  VendorState clone() => VendorState()..mergeFromMessage(this);
  VendorState copyWith(void Function(VendorState) updates) => super.copyWith((message) => updates(message as VendorState));
  $pb.BuilderInfo get info_ => _i;
  static VendorState create() => VendorState();
  VendorState createEmptyInstance() => create();
  static $pb.PbList<VendorState> createRepeated() => $pb.PbList<VendorState>();
  static VendorState getDefault() => _defaultInstance ??= create()..freeze();
  static VendorState _defaultInstance;

  $core.List<VendorState_Item> get item => $_getList(0);
}

