///
//  Generated code. Do not modify.
//  source: google/cloudprint/GoogleCloudPrint.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:async' as $async;
import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'PrintTicket.pb.dart' as $31;
import 'PrinterDescription.pb.dart' as $32;
import 'JobState.pb.dart' as $33;

import 'GoogleCloudPrint.pbenum.dart';
import 'Common.pbenum.dart' as $30;

export 'GoogleCloudPrint.pbenum.dart';

class SubmitJobRequest extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SubmitJobRequest', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'printerid')
    ..aOS(2, 'title')
    ..a<CloudJobTicket>(3, 'ticket', $pb.PbFieldType.OM, CloudJobTicket.getDefault, CloudJobTicket.create)
    ..aOS(4, 'content')
    ..aOS(5, 'contentType')
    ..pPS(6, 'tag')
    ..hasRequiredFields = false
  ;

  SubmitJobRequest() : super();
  SubmitJobRequest.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SubmitJobRequest.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SubmitJobRequest clone() => SubmitJobRequest()..mergeFromMessage(this);
  SubmitJobRequest copyWith(void Function(SubmitJobRequest) updates) => super.copyWith((message) => updates(message as SubmitJobRequest));
  $pb.BuilderInfo get info_ => _i;
  static SubmitJobRequest create() => SubmitJobRequest();
  SubmitJobRequest createEmptyInstance() => create();
  static $pb.PbList<SubmitJobRequest> createRepeated() => $pb.PbList<SubmitJobRequest>();
  static SubmitJobRequest getDefault() => _defaultInstance ??= create()..freeze();
  static SubmitJobRequest _defaultInstance;

  $core.String get printerid => $_getS(0, '');
  set printerid($core.String v) { $_setString(0, v); }
  $core.bool hasPrinterid() => $_has(0);
  void clearPrinterid() => clearField(1);

  $core.String get title => $_getS(1, '');
  set title($core.String v) { $_setString(1, v); }
  $core.bool hasTitle() => $_has(1);
  void clearTitle() => clearField(2);

  CloudJobTicket get ticket => $_getN(2);
  set ticket(CloudJobTicket v) { setField(3, v); }
  $core.bool hasTicket() => $_has(2);
  void clearTicket() => clearField(3);

  $core.String get content => $_getS(3, '');
  set content($core.String v) { $_setString(3, v); }
  $core.bool hasContent() => $_has(3);
  void clearContent() => clearField(4);

  $core.String get contentType => $_getS(4, '');
  set contentType($core.String v) { $_setString(4, v); }
  $core.bool hasContentType() => $_has(4);
  void clearContentType() => clearField(5);

  $core.List<$core.String> get tag => $_getList(5);
}

class SubmitJobResponse extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SubmitJobResponse', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'success')
    ..aOS(2, 'message')
    ..a<$core.int>(3, 'errorCode', $pb.PbFieldType.OU3)
    ..a<SubmitJobRequest>(4, 'request', $pb.PbFieldType.OM, SubmitJobRequest.getDefault, SubmitJobRequest.create)
    ..hasRequiredFields = false
  ;

  SubmitJobResponse() : super();
  SubmitJobResponse.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SubmitJobResponse.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SubmitJobResponse clone() => SubmitJobResponse()..mergeFromMessage(this);
  SubmitJobResponse copyWith(void Function(SubmitJobResponse) updates) => super.copyWith((message) => updates(message as SubmitJobResponse));
  $pb.BuilderInfo get info_ => _i;
  static SubmitJobResponse create() => SubmitJobResponse();
  SubmitJobResponse createEmptyInstance() => create();
  static $pb.PbList<SubmitJobResponse> createRepeated() => $pb.PbList<SubmitJobResponse>();
  static SubmitJobResponse getDefault() => _defaultInstance ??= create()..freeze();
  static SubmitJobResponse _defaultInstance;

  $core.bool get success => $_get(0, false);
  set success($core.bool v) { $_setBool(0, v); }
  $core.bool hasSuccess() => $_has(0);
  void clearSuccess() => clearField(1);

  $core.String get message => $_getS(1, '');
  set message($core.String v) { $_setString(1, v); }
  $core.bool hasMessage() => $_has(1);
  void clearMessage() => clearField(2);

  $core.int get errorCode => $_get(2, 0);
  set errorCode($core.int v) { $_setUnsignedInt32(2, v); }
  $core.bool hasErrorCode() => $_has(2);
  void clearErrorCode() => clearField(3);

  SubmitJobRequest get request => $_getN(3);
  set request(SubmitJobRequest v) { setField(4, v); }
  $core.bool hasRequest() => $_has(3);
  void clearRequest() => clearField(4);
}

class DeleteJobRequest extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DeleteJobRequest', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'jobid')
    ..hasRequiredFields = false
  ;

  DeleteJobRequest() : super();
  DeleteJobRequest.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DeleteJobRequest.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DeleteJobRequest clone() => DeleteJobRequest()..mergeFromMessage(this);
  DeleteJobRequest copyWith(void Function(DeleteJobRequest) updates) => super.copyWith((message) => updates(message as DeleteJobRequest));
  $pb.BuilderInfo get info_ => _i;
  static DeleteJobRequest create() => DeleteJobRequest();
  DeleteJobRequest createEmptyInstance() => create();
  static $pb.PbList<DeleteJobRequest> createRepeated() => $pb.PbList<DeleteJobRequest>();
  static DeleteJobRequest getDefault() => _defaultInstance ??= create()..freeze();
  static DeleteJobRequest _defaultInstance;

  $core.String get jobid => $_getS(0, '');
  set jobid($core.String v) { $_setString(0, v); }
  $core.bool hasJobid() => $_has(0);
  void clearJobid() => clearField(1);
}

class DeleteJobResponse extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DeleteJobResponse', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'success')
    ..aOS(2, 'message')
    ..a<$core.int>(3, 'errorCode', $pb.PbFieldType.OU3)
    ..a<DeleteJobRequest>(4, 'request', $pb.PbFieldType.OM, DeleteJobRequest.getDefault, DeleteJobRequest.create)
    ..hasRequiredFields = false
  ;

  DeleteJobResponse() : super();
  DeleteJobResponse.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DeleteJobResponse.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DeleteJobResponse clone() => DeleteJobResponse()..mergeFromMessage(this);
  DeleteJobResponse copyWith(void Function(DeleteJobResponse) updates) => super.copyWith((message) => updates(message as DeleteJobResponse));
  $pb.BuilderInfo get info_ => _i;
  static DeleteJobResponse create() => DeleteJobResponse();
  DeleteJobResponse createEmptyInstance() => create();
  static $pb.PbList<DeleteJobResponse> createRepeated() => $pb.PbList<DeleteJobResponse>();
  static DeleteJobResponse getDefault() => _defaultInstance ??= create()..freeze();
  static DeleteJobResponse _defaultInstance;

  $core.bool get success => $_get(0, false);
  set success($core.bool v) { $_setBool(0, v); }
  $core.bool hasSuccess() => $_has(0);
  void clearSuccess() => clearField(1);

  $core.String get message => $_getS(1, '');
  set message($core.String v) { $_setString(1, v); }
  $core.bool hasMessage() => $_has(1);
  void clearMessage() => clearField(2);

  $core.int get errorCode => $_get(2, 0);
  set errorCode($core.int v) { $_setUnsignedInt32(2, v); }
  $core.bool hasErrorCode() => $_has(2);
  void clearErrorCode() => clearField(3);

  DeleteJobRequest get request => $_getN(3);
  set request(DeleteJobRequest v) { setField(4, v); }
  $core.bool hasRequest() => $_has(3);
  void clearRequest() => clearField(4);
}

class ListJobsRequest extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ListJobsRequest', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'printerid')
    ..aOS(2, 'owner')
    ..aOS(3, 'status')
    ..aOS(4, 'q')
    ..a<$core.int>(5, 'offset', $pb.PbFieldType.OU3)
    ..a<$core.int>(6, 'limit', $pb.PbFieldType.OU3)
    ..e<ListJobsRequest_JobListSortOrder>(7, 'sortorder', $pb.PbFieldType.OE, ListJobsRequest_JobListSortOrder.CREATE_TIME_DESC, ListJobsRequest_JobListSortOrder.valueOf, ListJobsRequest_JobListSortOrder.values)
    ..hasRequiredFields = false
  ;

  ListJobsRequest() : super();
  ListJobsRequest.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ListJobsRequest.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ListJobsRequest clone() => ListJobsRequest()..mergeFromMessage(this);
  ListJobsRequest copyWith(void Function(ListJobsRequest) updates) => super.copyWith((message) => updates(message as ListJobsRequest));
  $pb.BuilderInfo get info_ => _i;
  static ListJobsRequest create() => ListJobsRequest();
  ListJobsRequest createEmptyInstance() => create();
  static $pb.PbList<ListJobsRequest> createRepeated() => $pb.PbList<ListJobsRequest>();
  static ListJobsRequest getDefault() => _defaultInstance ??= create()..freeze();
  static ListJobsRequest _defaultInstance;

  $core.String get printerid => $_getS(0, '');
  set printerid($core.String v) { $_setString(0, v); }
  $core.bool hasPrinterid() => $_has(0);
  void clearPrinterid() => clearField(1);

  $core.String get owner => $_getS(1, '');
  set owner($core.String v) { $_setString(1, v); }
  $core.bool hasOwner() => $_has(1);
  void clearOwner() => clearField(2);

  $core.String get status => $_getS(2, '');
  set status($core.String v) { $_setString(2, v); }
  $core.bool hasStatus() => $_has(2);
  void clearStatus() => clearField(3);

  $core.String get q => $_getS(3, '');
  set q($core.String v) { $_setString(3, v); }
  $core.bool hasQ() => $_has(3);
  void clearQ() => clearField(4);

  $core.int get offset => $_get(4, 0);
  set offset($core.int v) { $_setUnsignedInt32(4, v); }
  $core.bool hasOffset() => $_has(4);
  void clearOffset() => clearField(5);

  $core.int get limit => $_get(5, 0);
  set limit($core.int v) { $_setUnsignedInt32(5, v); }
  $core.bool hasLimit() => $_has(5);
  void clearLimit() => clearField(6);

  ListJobsRequest_JobListSortOrder get sortorder => $_getN(6);
  set sortorder(ListJobsRequest_JobListSortOrder v) { setField(7, v); }
  $core.bool hasSortorder() => $_has(6);
  void clearSortorder() => clearField(7);
}

class ListJobsResponse extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ListJobsResponse', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'success')
    ..hasRequiredFields = false
  ;

  ListJobsResponse() : super();
  ListJobsResponse.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ListJobsResponse.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ListJobsResponse clone() => ListJobsResponse()..mergeFromMessage(this);
  ListJobsResponse copyWith(void Function(ListJobsResponse) updates) => super.copyWith((message) => updates(message as ListJobsResponse));
  $pb.BuilderInfo get info_ => _i;
  static ListJobsResponse create() => ListJobsResponse();
  ListJobsResponse createEmptyInstance() => create();
  static $pb.PbList<ListJobsResponse> createRepeated() => $pb.PbList<ListJobsResponse>();
  static ListJobsResponse getDefault() => _defaultInstance ??= create()..freeze();
  static ListJobsResponse _defaultInstance;

  $core.bool get success => $_get(0, false);
  set success($core.bool v) { $_setBool(0, v); }
  $core.bool hasSuccess() => $_has(0);
  void clearSuccess() => clearField(1);
}

class GetPrinterRequest extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('GetPrinterRequest', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'printerid')
    ..aOS(2, 'client')
    ..aOS(3, 'extraFields')
    ..hasRequiredFields = false
  ;

  GetPrinterRequest() : super();
  GetPrinterRequest.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  GetPrinterRequest.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  GetPrinterRequest clone() => GetPrinterRequest()..mergeFromMessage(this);
  GetPrinterRequest copyWith(void Function(GetPrinterRequest) updates) => super.copyWith((message) => updates(message as GetPrinterRequest));
  $pb.BuilderInfo get info_ => _i;
  static GetPrinterRequest create() => GetPrinterRequest();
  GetPrinterRequest createEmptyInstance() => create();
  static $pb.PbList<GetPrinterRequest> createRepeated() => $pb.PbList<GetPrinterRequest>();
  static GetPrinterRequest getDefault() => _defaultInstance ??= create()..freeze();
  static GetPrinterRequest _defaultInstance;

  $core.String get printerid => $_getS(0, '');
  set printerid($core.String v) { $_setString(0, v); }
  $core.bool hasPrinterid() => $_has(0);
  void clearPrinterid() => clearField(1);

  $core.String get client => $_getS(1, '');
  set client($core.String v) { $_setString(1, v); }
  $core.bool hasClient() => $_has(1);
  void clearClient() => clearField(2);

  $core.String get extraFields => $_getS(2, '');
  set extraFields($core.String v) { $_setString(2, v); }
  $core.bool hasExtraFields() => $_has(2);
  void clearExtraFields() => clearField(3);
}

class GetPrinterResponse extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('GetPrinterResponse', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'success')
    ..hasRequiredFields = false
  ;

  GetPrinterResponse() : super();
  GetPrinterResponse.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  GetPrinterResponse.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  GetPrinterResponse clone() => GetPrinterResponse()..mergeFromMessage(this);
  GetPrinterResponse copyWith(void Function(GetPrinterResponse) updates) => super.copyWith((message) => updates(message as GetPrinterResponse));
  $pb.BuilderInfo get info_ => _i;
  static GetPrinterResponse create() => GetPrinterResponse();
  GetPrinterResponse createEmptyInstance() => create();
  static $pb.PbList<GetPrinterResponse> createRepeated() => $pb.PbList<GetPrinterResponse>();
  static GetPrinterResponse getDefault() => _defaultInstance ??= create()..freeze();
  static GetPrinterResponse _defaultInstance;

  $core.bool get success => $_get(0, false);
  set success($core.bool v) { $_setBool(0, v); }
  $core.bool hasSuccess() => $_has(0);
  void clearSuccess() => clearField(1);
}

enum SearchPrintersRequest_ConnectionStatusFilter {
  allConnectionStatuses, 
  connectionStatus, 
  notSet
}

class SearchPrintersRequest extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, SearchPrintersRequest_ConnectionStatusFilter> _SearchPrintersRequest_ConnectionStatusFilterByTag = {
    3 : SearchPrintersRequest_ConnectionStatusFilter.allConnectionStatuses,
    4 : SearchPrintersRequest_ConnectionStatusFilter.connectionStatus,
    0 : SearchPrintersRequest_ConnectionStatusFilter.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SearchPrintersRequest', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'q')
    ..e<$30.PrinterType>(2, 'type', $pb.PbFieldType.OE, $30.PrinterType.NO_PRINTER_TYPE_FILTER, $30.PrinterType.valueOf, $30.PrinterType.values)
    ..aOB(3, 'allConnectionStatuses')
    ..e<PrinterConnectionStatus>(4, 'connectionStatus', $pb.PbFieldType.OE, PrinterConnectionStatus.UNKNOWN, PrinterConnectionStatus.valueOf, PrinterConnectionStatus.values)
    ..aOB(5, 'useCdd')
    ..pc<ExtraPrinterField>(6, 'extraFields', $pb.PbFieldType.PE, null, ExtraPrinterField.valueOf, ExtraPrinterField.values)
    ..oo(0, [3, 4])
    ..hasRequiredFields = false
  ;

  SearchPrintersRequest() : super();
  SearchPrintersRequest.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SearchPrintersRequest.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SearchPrintersRequest clone() => SearchPrintersRequest()..mergeFromMessage(this);
  SearchPrintersRequest copyWith(void Function(SearchPrintersRequest) updates) => super.copyWith((message) => updates(message as SearchPrintersRequest));
  $pb.BuilderInfo get info_ => _i;
  static SearchPrintersRequest create() => SearchPrintersRequest();
  SearchPrintersRequest createEmptyInstance() => create();
  static $pb.PbList<SearchPrintersRequest> createRepeated() => $pb.PbList<SearchPrintersRequest>();
  static SearchPrintersRequest getDefault() => _defaultInstance ??= create()..freeze();
  static SearchPrintersRequest _defaultInstance;

  SearchPrintersRequest_ConnectionStatusFilter whichConnectionStatusFilter() => _SearchPrintersRequest_ConnectionStatusFilterByTag[$_whichOneof(0)];
  void clearConnectionStatusFilter() => clearField($_whichOneof(0));

  $core.String get q => $_getS(0, '');
  set q($core.String v) { $_setString(0, v); }
  $core.bool hasQ() => $_has(0);
  void clearQ() => clearField(1);

  $30.PrinterType get type => $_getN(1);
  set type($30.PrinterType v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $core.bool get allConnectionStatuses => $_get(2, false);
  set allConnectionStatuses($core.bool v) { $_setBool(2, v); }
  $core.bool hasAllConnectionStatuses() => $_has(2);
  void clearAllConnectionStatuses() => clearField(3);

  PrinterConnectionStatus get connectionStatus => $_getN(3);
  set connectionStatus(PrinterConnectionStatus v) { setField(4, v); }
  $core.bool hasConnectionStatus() => $_has(3);
  void clearConnectionStatus() => clearField(4);

  $core.bool get useCdd => $_get(4, false);
  set useCdd($core.bool v) { $_setBool(4, v); }
  $core.bool hasUseCdd() => $_has(4);
  void clearUseCdd() => clearField(5);

  $core.List<ExtraPrinterField> get extraFields => $_getList(5);
}

class CloudPrinter extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CloudPrinter', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'gcpVersion')
    ..aOS(2, 'id')
    ..aOS(3, 'uuid')
    ..e<$30.PrinterType>(4, 'type', $pb.PbFieldType.OE, $30.PrinterType.NO_PRINTER_TYPE_FILTER, $30.PrinterType.valueOf, $30.PrinterType.values)
    ..aOS(5, 'name')
    ..aOS(6, 'displayName')
    ..aOS(7, 'defaultDisplayName')
    ..aOS(8, 'description')
    ..aOS(9, 'ownerId')
    ..aOS(10, 'ownerName')
    ..aOS(11, 'proxy')
    ..e<PrinterConnectionStatus>(12, 'status', $pb.PbFieldType.OE, PrinterConnectionStatus.UNKNOWN, PrinterConnectionStatus.valueOf, PrinterConnectionStatus.values)
    ..pPS(13, 'tags')
    ..aOS(14, 'capsHash')
    ..aOB(15, 'isTosAccepted')
    ..aOS(16, 'supportedContentTypes')
    ..a<LocalSettings>(17, 'localSettings', $pb.PbFieldType.OM, LocalSettings.getDefault, LocalSettings.create)
    ..e<$30.NotificationChannel>(18, 'notificationChannel', $pb.PbFieldType.OE, $30.NotificationChannel.UNRECOGNIZED_CHANNEL, $30.NotificationChannel.valueOf, $30.NotificationChannel.values)
    ..aOS(19, 'manufacturer')
    ..aOS(20, 'model')
    ..aOS(21, 'supportUrl')
    ..aOS(22, 'updateUrl')
    ..aOS(23, 'setupUrl')
    ..aOS(24, 'certificationId')
    ..aOS(25, 'firmware')
    ..aOS(97, 'accessTime')
    ..aOS(98, 'updateTime')
    ..aOS(99, 'createTime')
    ..hasRequiredFields = false
  ;

  CloudPrinter() : super();
  CloudPrinter.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CloudPrinter.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CloudPrinter clone() => CloudPrinter()..mergeFromMessage(this);
  CloudPrinter copyWith(void Function(CloudPrinter) updates) => super.copyWith((message) => updates(message as CloudPrinter));
  $pb.BuilderInfo get info_ => _i;
  static CloudPrinter create() => CloudPrinter();
  CloudPrinter createEmptyInstance() => create();
  static $pb.PbList<CloudPrinter> createRepeated() => $pb.PbList<CloudPrinter>();
  static CloudPrinter getDefault() => _defaultInstance ??= create()..freeze();
  static CloudPrinter _defaultInstance;

  $core.String get gcpVersion => $_getS(0, '');
  set gcpVersion($core.String v) { $_setString(0, v); }
  $core.bool hasGcpVersion() => $_has(0);
  void clearGcpVersion() => clearField(1);

  $core.String get id => $_getS(1, '');
  set id($core.String v) { $_setString(1, v); }
  $core.bool hasId() => $_has(1);
  void clearId() => clearField(2);

  $core.String get uuid => $_getS(2, '');
  set uuid($core.String v) { $_setString(2, v); }
  $core.bool hasUuid() => $_has(2);
  void clearUuid() => clearField(3);

  $30.PrinterType get type => $_getN(3);
  set type($30.PrinterType v) { setField(4, v); }
  $core.bool hasType() => $_has(3);
  void clearType() => clearField(4);

  $core.String get name => $_getS(4, '');
  set name($core.String v) { $_setString(4, v); }
  $core.bool hasName() => $_has(4);
  void clearName() => clearField(5);

  $core.String get displayName => $_getS(5, '');
  set displayName($core.String v) { $_setString(5, v); }
  $core.bool hasDisplayName() => $_has(5);
  void clearDisplayName() => clearField(6);

  $core.String get defaultDisplayName => $_getS(6, '');
  set defaultDisplayName($core.String v) { $_setString(6, v); }
  $core.bool hasDefaultDisplayName() => $_has(6);
  void clearDefaultDisplayName() => clearField(7);

  $core.String get description => $_getS(7, '');
  set description($core.String v) { $_setString(7, v); }
  $core.bool hasDescription() => $_has(7);
  void clearDescription() => clearField(8);

  $core.String get ownerId => $_getS(8, '');
  set ownerId($core.String v) { $_setString(8, v); }
  $core.bool hasOwnerId() => $_has(8);
  void clearOwnerId() => clearField(9);

  $core.String get ownerName => $_getS(9, '');
  set ownerName($core.String v) { $_setString(9, v); }
  $core.bool hasOwnerName() => $_has(9);
  void clearOwnerName() => clearField(10);

  $core.String get proxy => $_getS(10, '');
  set proxy($core.String v) { $_setString(10, v); }
  $core.bool hasProxy() => $_has(10);
  void clearProxy() => clearField(11);

  PrinterConnectionStatus get status => $_getN(11);
  set status(PrinterConnectionStatus v) { setField(12, v); }
  $core.bool hasStatus() => $_has(11);
  void clearStatus() => clearField(12);

  $core.List<$core.String> get tags => $_getList(12);

  $core.String get capsHash => $_getS(13, '');
  set capsHash($core.String v) { $_setString(13, v); }
  $core.bool hasCapsHash() => $_has(13);
  void clearCapsHash() => clearField(14);

  $core.bool get isTosAccepted => $_get(14, false);
  set isTosAccepted($core.bool v) { $_setBool(14, v); }
  $core.bool hasIsTosAccepted() => $_has(14);
  void clearIsTosAccepted() => clearField(15);

  $core.String get supportedContentTypes => $_getS(15, '');
  set supportedContentTypes($core.String v) { $_setString(15, v); }
  $core.bool hasSupportedContentTypes() => $_has(15);
  void clearSupportedContentTypes() => clearField(16);

  LocalSettings get localSettings => $_getN(16);
  set localSettings(LocalSettings v) { setField(17, v); }
  $core.bool hasLocalSettings() => $_has(16);
  void clearLocalSettings() => clearField(17);

  $30.NotificationChannel get notificationChannel => $_getN(17);
  set notificationChannel($30.NotificationChannel v) { setField(18, v); }
  $core.bool hasNotificationChannel() => $_has(17);
  void clearNotificationChannel() => clearField(18);

  $core.String get manufacturer => $_getS(18, '');
  set manufacturer($core.String v) { $_setString(18, v); }
  $core.bool hasManufacturer() => $_has(18);
  void clearManufacturer() => clearField(19);

  $core.String get model => $_getS(19, '');
  set model($core.String v) { $_setString(19, v); }
  $core.bool hasModel() => $_has(19);
  void clearModel() => clearField(20);

  $core.String get supportUrl => $_getS(20, '');
  set supportUrl($core.String v) { $_setString(20, v); }
  $core.bool hasSupportUrl() => $_has(20);
  void clearSupportUrl() => clearField(21);

  $core.String get updateUrl => $_getS(21, '');
  set updateUrl($core.String v) { $_setString(21, v); }
  $core.bool hasUpdateUrl() => $_has(21);
  void clearUpdateUrl() => clearField(22);

  $core.String get setupUrl => $_getS(22, '');
  set setupUrl($core.String v) { $_setString(22, v); }
  $core.bool hasSetupUrl() => $_has(22);
  void clearSetupUrl() => clearField(23);

  $core.String get certificationId => $_getS(23, '');
  set certificationId($core.String v) { $_setString(23, v); }
  $core.bool hasCertificationId() => $_has(23);
  void clearCertificationId() => clearField(24);

  $core.String get firmware => $_getS(24, '');
  set firmware($core.String v) { $_setString(24, v); }
  $core.bool hasFirmware() => $_has(24);
  void clearFirmware() => clearField(25);

  $core.String get accessTime => $_getS(25, '');
  set accessTime($core.String v) { $_setString(25, v); }
  $core.bool hasAccessTime() => $_has(25);
  void clearAccessTime() => clearField(97);

  $core.String get updateTime => $_getS(26, '');
  set updateTime($core.String v) { $_setString(26, v); }
  $core.bool hasUpdateTime() => $_has(26);
  void clearUpdateTime() => clearField(98);

  $core.String get createTime => $_getS(27, '');
  set createTime($core.String v) { $_setString(27, v); }
  $core.bool hasCreateTime() => $_has(27);
  void clearCreateTime() => clearField(99);
}

class SearchPrintersResponse extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SearchPrintersResponse', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'success')
    ..aOS(2, 'xsrfToken')
    ..pc<CloudPrinter>(3, 'printers', $pb.PbFieldType.PM,CloudPrinter.create)
    ..hasRequiredFields = false
  ;

  SearchPrintersResponse() : super();
  SearchPrintersResponse.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SearchPrintersResponse.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SearchPrintersResponse clone() => SearchPrintersResponse()..mergeFromMessage(this);
  SearchPrintersResponse copyWith(void Function(SearchPrintersResponse) updates) => super.copyWith((message) => updates(message as SearchPrintersResponse));
  $pb.BuilderInfo get info_ => _i;
  static SearchPrintersResponse create() => SearchPrintersResponse();
  SearchPrintersResponse createEmptyInstance() => create();
  static $pb.PbList<SearchPrintersResponse> createRepeated() => $pb.PbList<SearchPrintersResponse>();
  static SearchPrintersResponse getDefault() => _defaultInstance ??= create()..freeze();
  static SearchPrintersResponse _defaultInstance;

  $core.bool get success => $_get(0, false);
  set success($core.bool v) { $_setBool(0, v); }
  $core.bool hasSuccess() => $_has(0);
  void clearSuccess() => clearField(1);

  $core.String get xsrfToken => $_getS(1, '');
  set xsrfToken($core.String v) { $_setString(1, v); }
  $core.bool hasXsrfToken() => $_has(1);
  void clearXsrfToken() => clearField(2);

  $core.List<CloudPrinter> get printers => $_getList(2);
}

class LocalSettings_Settings extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('LocalSettings.Settings', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'localDiscovery')
    ..aOB(2, 'accessTokenEnabled')
    ..aOB(3, 'localPrintingEnabled')
    ..aOB(4, 'conversionPrintingEnabled')
    ..a<$core.int>(5, 'xmppTimeoutValue', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  LocalSettings_Settings() : super();
  LocalSettings_Settings.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  LocalSettings_Settings.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  LocalSettings_Settings clone() => LocalSettings_Settings()..mergeFromMessage(this);
  LocalSettings_Settings copyWith(void Function(LocalSettings_Settings) updates) => super.copyWith((message) => updates(message as LocalSettings_Settings));
  $pb.BuilderInfo get info_ => _i;
  static LocalSettings_Settings create() => LocalSettings_Settings();
  LocalSettings_Settings createEmptyInstance() => create();
  static $pb.PbList<LocalSettings_Settings> createRepeated() => $pb.PbList<LocalSettings_Settings>();
  static LocalSettings_Settings getDefault() => _defaultInstance ??= create()..freeze();
  static LocalSettings_Settings _defaultInstance;

  $core.bool get localDiscovery => $_get(0, false);
  set localDiscovery($core.bool v) { $_setBool(0, v); }
  $core.bool hasLocalDiscovery() => $_has(0);
  void clearLocalDiscovery() => clearField(1);

  $core.bool get accessTokenEnabled => $_get(1, false);
  set accessTokenEnabled($core.bool v) { $_setBool(1, v); }
  $core.bool hasAccessTokenEnabled() => $_has(1);
  void clearAccessTokenEnabled() => clearField(2);

  $core.bool get localPrintingEnabled => $_get(2, false);
  set localPrintingEnabled($core.bool v) { $_setBool(2, v); }
  $core.bool hasLocalPrintingEnabled() => $_has(2);
  void clearLocalPrintingEnabled() => clearField(3);

  $core.bool get conversionPrintingEnabled => $_get(3, false);
  set conversionPrintingEnabled($core.bool v) { $_setBool(3, v); }
  $core.bool hasConversionPrintingEnabled() => $_has(3);
  void clearConversionPrintingEnabled() => clearField(4);

  $core.int get xmppTimeoutValue => $_get(4, 0);
  set xmppTimeoutValue($core.int v) { $_setSignedInt32(4, v); }
  $core.bool hasXmppTimeoutValue() => $_has(4);
  void clearXmppTimeoutValue() => clearField(5);
}

class LocalSettings extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('LocalSettings', package: const $pb.PackageName('google.cloudprint'))
    ..a<LocalSettings_Settings>(1, 'current', $pb.PbFieldType.OM, LocalSettings_Settings.getDefault, LocalSettings_Settings.create)
    ..a<LocalSettings_Settings>(2, 'pending', $pb.PbFieldType.OM, LocalSettings_Settings.getDefault, LocalSettings_Settings.create)
    ..hasRequiredFields = false
  ;

  LocalSettings() : super();
  LocalSettings.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  LocalSettings.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  LocalSettings clone() => LocalSettings()..mergeFromMessage(this);
  LocalSettings copyWith(void Function(LocalSettings) updates) => super.copyWith((message) => updates(message as LocalSettings));
  $pb.BuilderInfo get info_ => _i;
  static LocalSettings create() => LocalSettings();
  LocalSettings createEmptyInstance() => create();
  static $pb.PbList<LocalSettings> createRepeated() => $pb.PbList<LocalSettings>();
  static LocalSettings getDefault() => _defaultInstance ??= create()..freeze();
  static LocalSettings _defaultInstance;

  LocalSettings_Settings get current => $_getN(0);
  set current(LocalSettings_Settings v) { setField(1, v); }
  $core.bool hasCurrent() => $_has(0);
  void clearCurrent() => clearField(1);

  LocalSettings_Settings get pending => $_getN(1);
  set pending(LocalSettings_Settings v) { setField(2, v); }
  $core.bool hasPending() => $_has(1);
  void clearPending() => clearField(2);
}

class CloudJobTicket extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CloudJobTicket', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'version')
    ..a<$31.PrintTicketSection>(101, 'print', $pb.PbFieldType.OM, $31.PrintTicketSection.getDefault, $31.PrintTicketSection.create)
    ..hasRequiredFields = false
  ;

  CloudJobTicket() : super();
  CloudJobTicket.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CloudJobTicket.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CloudJobTicket clone() => CloudJobTicket()..mergeFromMessage(this);
  CloudJobTicket copyWith(void Function(CloudJobTicket) updates) => super.copyWith((message) => updates(message as CloudJobTicket));
  $pb.BuilderInfo get info_ => _i;
  static CloudJobTicket create() => CloudJobTicket();
  CloudJobTicket createEmptyInstance() => create();
  static $pb.PbList<CloudJobTicket> createRepeated() => $pb.PbList<CloudJobTicket>();
  static CloudJobTicket getDefault() => _defaultInstance ??= create()..freeze();
  static CloudJobTicket _defaultInstance;

  $core.String get version => $_getS(0, '');
  set version($core.String v) { $_setString(0, v); }
  $core.bool hasVersion() => $_has(0);
  void clearVersion() => clearField(1);

  $31.PrintTicketSection get print => $_getN(1);
  set print($31.PrintTicketSection v) { setField(101, v); }
  $core.bool hasPrint() => $_has(1);
  void clearPrint() => clearField(101);
}

class CloudDeviceDescription extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CloudDeviceDescription', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'version')
    ..a<$32.PrinterDescriptionSection>(101, 'printer', $pb.PbFieldType.OM, $32.PrinterDescriptionSection.getDefault, $32.PrinterDescriptionSection.create)
    ..hasRequiredFields = false
  ;

  CloudDeviceDescription() : super();
  CloudDeviceDescription.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CloudDeviceDescription.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CloudDeviceDescription clone() => CloudDeviceDescription()..mergeFromMessage(this);
  CloudDeviceDescription copyWith(void Function(CloudDeviceDescription) updates) => super.copyWith((message) => updates(message as CloudDeviceDescription));
  $pb.BuilderInfo get info_ => _i;
  static CloudDeviceDescription create() => CloudDeviceDescription();
  CloudDeviceDescription createEmptyInstance() => create();
  static $pb.PbList<CloudDeviceDescription> createRepeated() => $pb.PbList<CloudDeviceDescription>();
  static CloudDeviceDescription getDefault() => _defaultInstance ??= create()..freeze();
  static CloudDeviceDescription _defaultInstance;

  $core.String get version => $_getS(0, '');
  set version($core.String v) { $_setString(0, v); }
  $core.bool hasVersion() => $_has(0);
  void clearVersion() => clearField(1);

  $32.PrinterDescriptionSection get printer => $_getN(1);
  set printer($32.PrinterDescriptionSection v) { setField(101, v); }
  $core.bool hasPrinter() => $_has(1);
  void clearPrinter() => clearField(101);
}

class PrintJobState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintJobState', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'version')
    ..a<$33.JobState>(2, 'state', $pb.PbFieldType.OM, $33.JobState.getDefault, $33.JobState.create)
    ..a<$core.int>(3, 'pagesPrinted', $pb.PbFieldType.O3)
    ..a<$core.int>(4, 'deliveryAttempts', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  PrintJobState() : super();
  PrintJobState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintJobState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintJobState clone() => PrintJobState()..mergeFromMessage(this);
  PrintJobState copyWith(void Function(PrintJobState) updates) => super.copyWith((message) => updates(message as PrintJobState));
  $pb.BuilderInfo get info_ => _i;
  static PrintJobState create() => PrintJobState();
  PrintJobState createEmptyInstance() => create();
  static $pb.PbList<PrintJobState> createRepeated() => $pb.PbList<PrintJobState>();
  static PrintJobState getDefault() => _defaultInstance ??= create()..freeze();
  static PrintJobState _defaultInstance;

  $core.String get version => $_getS(0, '');
  set version($core.String v) { $_setString(0, v); }
  $core.bool hasVersion() => $_has(0);
  void clearVersion() => clearField(1);

  $33.JobState get state => $_getN(1);
  set state($33.JobState v) { setField(2, v); }
  $core.bool hasState() => $_has(1);
  void clearState() => clearField(2);

  $core.int get pagesPrinted => $_get(2, 0);
  set pagesPrinted($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasPagesPrinted() => $_has(2);
  void clearPagesPrinted() => clearField(3);

  $core.int get deliveryAttempts => $_get(3, 0);
  set deliveryAttempts($core.int v) { $_setSignedInt32(3, v); }
  $core.bool hasDeliveryAttempts() => $_has(3);
  void clearDeliveryAttempts() => clearField(4);
}

class PrintJobStateDiff extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintJobStateDiff', package: const $pb.PackageName('google.cloudprint'))
    ..a<$33.JobState>(1, 'state', $pb.PbFieldType.OM, $33.JobState.getDefault, $33.JobState.create)
    ..a<$core.int>(2, 'pagesPrinted', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  PrintJobStateDiff() : super();
  PrintJobStateDiff.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintJobStateDiff.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintJobStateDiff clone() => PrintJobStateDiff()..mergeFromMessage(this);
  PrintJobStateDiff copyWith(void Function(PrintJobStateDiff) updates) => super.copyWith((message) => updates(message as PrintJobStateDiff));
  $pb.BuilderInfo get info_ => _i;
  static PrintJobStateDiff create() => PrintJobStateDiff();
  PrintJobStateDiff createEmptyInstance() => create();
  static $pb.PbList<PrintJobStateDiff> createRepeated() => $pb.PbList<PrintJobStateDiff>();
  static PrintJobStateDiff getDefault() => _defaultInstance ??= create()..freeze();
  static PrintJobStateDiff _defaultInstance;

  $33.JobState get state => $_getN(0);
  set state($33.JobState v) { setField(1, v); }
  $core.bool hasState() => $_has(0);
  void clearState() => clearField(1);

  $core.int get pagesPrinted => $_get(1, 0);
  set pagesPrinted($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasPagesPrinted() => $_has(1);
  void clearPagesPrinted() => clearField(2);
}

class CloudPrintApi {
  $pb.RpcClient _client;
  CloudPrintApi(this._client);

  $async.Future<SubmitJobResponse> submitJob($pb.ClientContext ctx, SubmitJobRequest request) {
    var emptyResponse = SubmitJobResponse();
    return _client.invoke<SubmitJobResponse>(ctx, 'CloudPrint', 'SubmitJob', request, emptyResponse);
  }
  $async.Future<DeleteJobResponse> deleteJob($pb.ClientContext ctx, DeleteJobRequest request) {
    var emptyResponse = DeleteJobResponse();
    return _client.invoke<DeleteJobResponse>(ctx, 'CloudPrint', 'DeleteJob', request, emptyResponse);
  }
  $async.Future<ListJobsResponse> listJobs($pb.ClientContext ctx, ListJobsRequest request) {
    var emptyResponse = ListJobsResponse();
    return _client.invoke<ListJobsResponse>(ctx, 'CloudPrint', 'ListJobs', request, emptyResponse);
  }
  $async.Future<GetPrinterResponse> getPrinter($pb.ClientContext ctx, GetPrinterRequest request) {
    var emptyResponse = GetPrinterResponse();
    return _client.invoke<GetPrinterResponse>(ctx, 'CloudPrint', 'GetPrinter', request, emptyResponse);
  }
  $async.Future<SearchPrintersResponse> searchPrinters($pb.ClientContext ctx, SearchPrintersRequest request) {
    var emptyResponse = SearchPrintersResponse();
    return _client.invoke<SearchPrintersResponse>(ctx, 'CloudPrint', 'SearchPrinters', request, emptyResponse);
  }
}

