///
//  Generated code. Do not modify.
//  source: google/cloudprint/Common.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const PrinterType$json = const {
  '1': 'PrinterType',
  '2': const [
    const {'1': 'NO_PRINTER_TYPE_FILTER', '2': 0},
    const {'1': 'GOOGLE', '2': 1},
    const {'1': 'HP', '2': 2},
    const {'1': 'DRIVE', '2': 3},
    const {'1': 'FEDEX', '2': 4},
    const {'1': 'ANDROID_CHROME_SNAPSHOT', '2': 5},
    const {'1': 'IOS_CHROME_SNAPSHOT', '2': 6},
  ],
};

const NotificationChannel$json = const {
  '1': 'NotificationChannel',
  '2': const [
    const {'1': 'UNRECOGNIZED_CHANNEL', '2': 0},
    const {'1': 'XMPP_CHANNEL', '2': 1},
  ],
};

const Marker$json = const {
  '1': 'Marker',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.Marker.Type', '10': 'type'},
    const {'1': 'color', '3': 3, '4': 1, '5': 11, '6': '.google.cloudprint.Marker.Color', '10': 'color'},
    const {'1': 'custom_display_name', '3': 4, '4': 1, '5': 9, '10': 'customDisplayName'},
    const {'1': 'custom_display_name_localized', '3': 5, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'customDisplayNameLocalized'},
  ],
  '3': const [Marker_Color$json],
  '4': const [Marker_Type$json],
};

const Marker_Color$json = const {
  '1': 'Color',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.Marker.Color.Type', '10': 'type'},
    const {'1': 'custom_display_name', '3': 2, '4': 1, '5': 9, '10': 'customDisplayName'},
    const {'1': 'custom_display_name_localized', '3': 3, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'customDisplayNameLocalized'},
  ],
  '4': const [Marker_Color_Type$json],
};

const Marker_Color_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'CUSTOM', '2': 0},
    const {'1': 'BLACK', '2': 1},
    const {'1': 'COLOR', '2': 2},
    const {'1': 'CYAN', '2': 3},
    const {'1': 'MAGENTA', '2': 4},
    const {'1': 'YELLOW', '2': 5},
    const {'1': 'LIGHT_CYAN', '2': 6},
    const {'1': 'LIGHT_MAGENTA', '2': 7},
    const {'1': 'GRAY', '2': 8},
    const {'1': 'LIGHT_GRAY', '2': 9},
    const {'1': 'PIGMENT_BLACK', '2': 10},
    const {'1': 'MATTE_BLACK', '2': 11},
    const {'1': 'PHOTO_CYAN', '2': 12},
    const {'1': 'PHOTO_MAGENTA', '2': 13},
    const {'1': 'PHOTO_YELLOW', '2': 14},
    const {'1': 'PHOTO_GRAY', '2': 15},
    const {'1': 'RED', '2': 16},
    const {'1': 'GREEN', '2': 17},
    const {'1': 'BLUE', '2': 18},
  ],
};

const Marker_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'CUSTOM', '2': 0},
    const {'1': 'TONER', '2': 1},
    const {'1': 'INK', '2': 2},
    const {'1': 'STAPLES', '2': 3},
  ],
};

const Cover$json = const {
  '1': 'Cover',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.Cover.Type', '10': 'type'},
    const {'1': 'index', '3': 3, '4': 1, '5': 3, '10': 'index'},
    const {'1': 'custom_display_name', '3': 4, '4': 1, '5': 9, '10': 'customDisplayName'},
    const {'1': 'custom_display_name_localized', '3': 5, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'customDisplayNameLocalized'},
  ],
  '4': const [Cover_Type$json],
};

const Cover_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'CUSTOM', '2': 0},
    const {'1': 'DOOR', '2': 1},
    const {'1': 'COVER', '2': 2},
  ],
};

const MediaPath$json = const {
  '1': 'MediaPath',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
  ],
};

const VendorCapability$json = const {
  '1': 'VendorCapability',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'display_name', '3': 2, '4': 1, '5': 9, '10': 'displayName'},
    const {'1': 'type', '3': 3, '4': 1, '5': 14, '6': '.google.cloudprint.VendorCapability.Type', '10': 'type'},
    const {'1': 'range_cap', '3': 4, '4': 1, '5': 11, '6': '.google.cloudprint.RangeCapability', '10': 'rangeCap'},
    const {'1': 'select_cap', '3': 5, '4': 1, '5': 11, '6': '.google.cloudprint.SelectCapability', '10': 'selectCap'},
    const {'1': 'typed_value_cap', '3': 6, '4': 1, '5': 11, '6': '.google.cloudprint.TypedValueCapability', '10': 'typedValueCap'},
    const {'1': 'display_name_localized', '3': 7, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'displayNameLocalized'},
  ],
  '4': const [VendorCapability_Type$json],
};

const VendorCapability_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'RANGE', '2': 0},
    const {'1': 'SELECT', '2': 1},
    const {'1': 'TYPED_VALUE', '2': 2},
  ],
};

const RangeCapability$json = const {
  '1': 'RangeCapability',
  '2': const [
    const {'1': 'value_type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.RangeCapability.ValueType', '10': 'valueType'},
    const {'1': 'default', '3': 2, '4': 1, '5': 9, '10': 'default'},
    const {'1': 'min', '3': 3, '4': 1, '5': 9, '10': 'min'},
    const {'1': 'max', '3': 4, '4': 1, '5': 9, '10': 'max'},
  ],
  '4': const [RangeCapability_ValueType$json],
};

const RangeCapability_ValueType$json = const {
  '1': 'ValueType',
  '2': const [
    const {'1': 'FLOAT', '2': 0},
    const {'1': 'INTEGER', '2': 1},
  ],
};

const SelectCapability$json = const {
  '1': 'SelectCapability',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.SelectCapability.Option', '10': 'option'},
  ],
  '3': const [SelectCapability_Option$json],
};

const SelectCapability_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'value', '3': 1, '4': 1, '5': 9, '10': 'value'},
    const {'1': 'display_name', '3': 2, '4': 1, '5': 9, '10': 'displayName'},
    const {'1': 'is_default', '3': 3, '4': 1, '5': 8, '10': 'isDefault'},
    const {'1': 'display_name_localized', '3': 4, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'displayNameLocalized'},
  ],
};

const TypedValueCapability$json = const {
  '1': 'TypedValueCapability',
  '2': const [
    const {'1': 'value_type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.TypedValueCapability.ValueType', '10': 'valueType'},
    const {'1': 'default', '3': 2, '4': 1, '5': 9, '10': 'default'},
  ],
  '4': const [TypedValueCapability_ValueType$json],
};

const TypedValueCapability_ValueType$json = const {
  '1': 'ValueType',
  '2': const [
    const {'1': 'BOOLEAN', '2': 0},
    const {'1': 'FLOAT', '2': 1},
    const {'1': 'INTEGER', '2': 2},
    const {'1': 'STRING', '2': 3},
  ],
};

const Color$json = const {
  '1': 'Color',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.Color.Option', '10': 'option'},
  ],
  '3': const [Color_Option$json],
  '4': const [Color_Type$json],
};

const Color_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.Color.Type', '10': 'type'},
    const {'1': 'custom_display_name', '3': 3, '4': 1, '5': 9, '10': 'customDisplayName'},
    const {'1': 'is_default', '3': 4, '4': 1, '5': 8, '10': 'isDefault'},
    const {'1': 'custom_display_name_localized', '3': 5, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'customDisplayNameLocalized'},
  ],
};

const Color_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'STANDARD_COLOR', '2': 0},
    const {'1': 'STANDARD_MONOCHROME', '2': 1},
    const {'1': 'CUSTOM_COLOR', '2': 2},
    const {'1': 'CUSTOM_MONOCHROME', '2': 3},
    const {'1': 'AUTO', '2': 4},
  ],
};

const Duplex$json = const {
  '1': 'Duplex',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.Duplex.Option', '10': 'option'},
  ],
  '3': const [Duplex_Option$json],
  '4': const [Duplex_Type$json],
};

const Duplex_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.Duplex.Type', '10': 'type'},
    const {'1': 'is_default', '3': 2, '4': 1, '5': 8, '10': 'isDefault'},
  ],
};

const Duplex_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'NO_DUPLEX', '2': 0},
    const {'1': 'LONG_EDGE', '2': 1},
    const {'1': 'SHORT_EDGE', '2': 2},
  ],
};

const PageOrientation$json = const {
  '1': 'PageOrientation',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.PageOrientation.Option', '10': 'option'},
  ],
  '3': const [PageOrientation_Option$json],
  '4': const [PageOrientation_Type$json],
};

const PageOrientation_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.PageOrientation.Type', '10': 'type'},
    const {'1': 'is_default', '3': 2, '4': 1, '5': 8, '10': 'isDefault'},
  ],
};

const PageOrientation_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'PORTRAIT', '2': 0},
    const {'1': 'LANDSCAPE', '2': 1},
    const {'1': 'AUTO', '2': 2},
  ],
};

const Copies$json = const {
  '1': 'Copies',
  '2': const [
    const {'1': 'default', '3': 1, '4': 1, '5': 5, '10': 'default'},
    const {'1': 'max', '3': 2, '4': 1, '5': 5, '10': 'max'},
  ],
};

const Margins$json = const {
  '1': 'Margins',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.Margins.Option', '10': 'option'},
  ],
  '3': const [Margins_Option$json],
  '4': const [Margins_Type$json],
};

const Margins_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.Margins.Type', '10': 'type'},
    const {'1': 'top_microns', '3': 2, '4': 1, '5': 5, '10': 'topMicrons'},
    const {'1': 'right_microns', '3': 3, '4': 1, '5': 5, '10': 'rightMicrons'},
    const {'1': 'bottom_microns', '3': 4, '4': 1, '5': 5, '10': 'bottomMicrons'},
    const {'1': 'left_microns', '3': 5, '4': 1, '5': 5, '10': 'leftMicrons'},
    const {'1': 'is_default', '3': 6, '4': 1, '5': 8, '10': 'isDefault'},
  ],
};

const Margins_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'BORDERLESS', '2': 0},
    const {'1': 'STANDARD', '2': 1},
    const {'1': 'CUSTOM', '2': 2},
  ],
};

const Dpi$json = const {
  '1': 'Dpi',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.Dpi.Option', '10': 'option'},
    const {'1': 'min_horizontal_dpi', '3': 2, '4': 1, '5': 5, '10': 'minHorizontalDpi'},
    const {'1': 'max_horizontal_dpi', '3': 3, '4': 1, '5': 5, '10': 'maxHorizontalDpi'},
    const {'1': 'min_vertical_dpi', '3': 4, '4': 1, '5': 5, '10': 'minVerticalDpi'},
    const {'1': 'max_vertical_dpi', '3': 5, '4': 1, '5': 5, '10': 'maxVerticalDpi'},
  ],
  '3': const [Dpi_Option$json],
};

const Dpi_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'horizontal_dpi', '3': 1, '4': 1, '5': 5, '10': 'horizontalDpi'},
    const {'1': 'vertical_dpi', '3': 2, '4': 1, '5': 5, '10': 'verticalDpi'},
    const {'1': 'is_default', '3': 3, '4': 1, '5': 8, '10': 'isDefault'},
    const {'1': 'custom_display_name', '3': 4, '4': 1, '5': 9, '10': 'customDisplayName'},
    const {'1': 'vendor_id', '3': 5, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'custom_display_name_localized', '3': 6, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'customDisplayNameLocalized'},
  ],
};

const FitToPage$json = const {
  '1': 'FitToPage',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.FitToPage.Option', '10': 'option'},
  ],
  '3': const [FitToPage_Option$json],
  '4': const [FitToPage_Type$json],
};

const FitToPage_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.FitToPage.Type', '10': 'type'},
    const {'1': 'is_default', '3': 2, '4': 1, '5': 8, '10': 'isDefault'},
  ],
};

const FitToPage_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'NO_FITTING', '2': 0},
    const {'1': 'FIT_TO_PAGE', '2': 1},
    const {'1': 'GROW_TO_PAGE', '2': 2},
    const {'1': 'SHRINK_TO_PAGE', '2': 3},
    const {'1': 'FILL_PAGE', '2': 4},
  ],
};

const PageRange$json = const {
  '1': 'PageRange',
  '2': const [
    const {'1': 'default', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.PageRange.Interval', '10': 'default'},
  ],
  '3': const [PageRange_Interval$json],
};

const PageRange_Interval$json = const {
  '1': 'Interval',
  '2': const [
    const {'1': 'start', '3': 1, '4': 1, '5': 5, '10': 'start'},
    const {'1': 'end', '3': 2, '4': 1, '5': 5, '10': 'end'},
  ],
};

const MediaSize$json = const {
  '1': 'MediaSize',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.MediaSize.Option', '10': 'option'},
    const {'1': 'max_width_microns', '3': 2, '4': 1, '5': 5, '10': 'maxWidthMicrons'},
    const {'1': 'max_height_microns', '3': 3, '4': 1, '5': 5, '10': 'maxHeightMicrons'},
    const {'1': 'min_width_microns', '3': 4, '4': 1, '5': 5, '10': 'minWidthMicrons'},
    const {'1': 'min_height_microns', '3': 5, '4': 1, '5': 5, '10': 'minHeightMicrons'},
  ],
  '3': const [MediaSize_Option$json],
  '4': const [MediaSize_Name$json],
};

const MediaSize_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.MediaSize.Name', '10': 'name'},
    const {'1': 'width_microns', '3': 2, '4': 1, '5': 5, '10': 'widthMicrons'},
    const {'1': 'height_microns', '3': 3, '4': 1, '5': 5, '10': 'heightMicrons'},
    const {'1': 'is_continuous_feed', '3': 4, '4': 1, '5': 8, '10': 'isContinuousFeed'},
    const {'1': 'is_default', '3': 5, '4': 1, '5': 8, '10': 'isDefault'},
    const {'1': 'custom_display_name', '3': 6, '4': 1, '5': 9, '10': 'customDisplayName'},
    const {'1': 'vendor_id', '3': 7, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'custom_display_name_localized', '3': 8, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'customDisplayNameLocalized'},
  ],
};

const MediaSize_Name$json = const {
  '1': 'Name',
  '2': const [
    const {'1': 'CUSTOM', '2': 0},
    const {'1': 'NA_INDEX_3X5', '2': 100},
    const {'1': 'NA_PERSONAL', '2': 101},
    const {'1': 'NA_MONARCH', '2': 102},
    const {'1': 'NA_NUMBER_9', '2': 103},
    const {'1': 'NA_INDEX_4X6', '2': 104},
    const {'1': 'NA_NUMBER_10', '2': 105},
    const {'1': 'NA_A2', '2': 106},
    const {'1': 'NA_NUMBER_11', '2': 107},
    const {'1': 'NA_NUMBER_12', '2': 108},
    const {'1': 'NA_5X7', '2': 109},
    const {'1': 'NA_INDEX_5X8', '2': 110},
    const {'1': 'NA_NUMBER_14', '2': 111},
    const {'1': 'NA_INVOICE', '2': 112},
    const {'1': 'NA_INDEX_4X6_EXT', '2': 113},
    const {'1': 'NA_6X9', '2': 114},
    const {'1': 'NA_C5', '2': 115},
    const {'1': 'NA_7X9', '2': 116},
    const {'1': 'NA_EXECUTIVE', '2': 117},
    const {'1': 'NA_GOVT_LETTER', '2': 118},
    const {'1': 'NA_GOVT_LEGAL', '2': 119},
    const {'1': 'NA_QUARTO', '2': 120},
    const {'1': 'NA_LETTER', '2': 121},
    const {'1': 'NA_FANFOLD_EUR', '2': 122},
    const {'1': 'NA_LETTER_PLUS', '2': 123},
    const {'1': 'NA_FOOLSCAP', '2': 124},
    const {'1': 'NA_LEGAL', '2': 125},
    const {'1': 'NA_SUPER_A', '2': 126},
    const {'1': 'NA_9X11', '2': 127},
    const {'1': 'NA_ARCH_A', '2': 128},
    const {'1': 'NA_LETTER_EXTRA', '2': 129},
    const {'1': 'NA_LEGAL_EXTRA', '2': 130},
    const {'1': 'NA_10X11', '2': 131},
    const {'1': 'NA_10X13', '2': 132},
    const {'1': 'NA_10X14', '2': 133},
    const {'1': 'NA_10X15', '2': 134},
    const {'1': 'NA_11X12', '2': 135},
    const {'1': 'NA_EDP', '2': 136},
    const {'1': 'NA_FANFOLD_US', '2': 137},
    const {'1': 'NA_11X15', '2': 138},
    const {'1': 'NA_LEDGER', '2': 139},
    const {'1': 'NA_EUR_EDP', '2': 140},
    const {'1': 'NA_ARCH_B', '2': 141},
    const {'1': 'NA_12X19', '2': 142},
    const {'1': 'NA_B_PLUS', '2': 143},
    const {'1': 'NA_SUPER_B', '2': 144},
    const {'1': 'NA_C', '2': 145},
    const {'1': 'NA_ARCH_C', '2': 146},
    const {'1': 'NA_D', '2': 147},
    const {'1': 'NA_ARCH_D', '2': 148},
    const {'1': 'NA_ASME_F', '2': 149},
    const {'1': 'NA_WIDE_FORMAT', '2': 150},
    const {'1': 'NA_E', '2': 151},
    const {'1': 'NA_ARCH_E', '2': 152},
    const {'1': 'NA_F', '2': 153},
    const {'1': 'ROC_16K', '2': 200},
    const {'1': 'ROC_8K', '2': 201},
    const {'1': 'PRC_32K', '2': 202},
    const {'1': 'PRC_1', '2': 203},
    const {'1': 'PRC_2', '2': 204},
    const {'1': 'PRC_4', '2': 205},
    const {'1': 'PRC_5', '2': 206},
    const {'1': 'PRC_8', '2': 207},
    const {'1': 'PRC_6', '2': 208},
    const {'1': 'PRC_3', '2': 209},
    const {'1': 'PRC_16K', '2': 210},
    const {'1': 'PRC_7', '2': 211},
    const {'1': 'OM_JUURO_KU_KAI', '2': 212},
    const {'1': 'OM_PA_KAI', '2': 213},
    const {'1': 'OM_DAI_PA_KAI', '2': 214},
    const {'1': 'PRC_10', '2': 215},
    const {'1': 'ISO_A10', '2': 301},
    const {'1': 'ISO_A9', '2': 302},
    const {'1': 'ISO_A8', '2': 303},
    const {'1': 'ISO_A7', '2': 304},
    const {'1': 'ISO_A6', '2': 305},
    const {'1': 'ISO_A5', '2': 306},
    const {'1': 'ISO_A5_EXTRA', '2': 307},
    const {'1': 'ISO_A4', '2': 308},
    const {'1': 'ISO_A4_TAB', '2': 309},
    const {'1': 'ISO_A4_EXTRA', '2': 310},
    const {'1': 'ISO_A3', '2': 311},
    const {'1': 'ISO_A4X3', '2': 312},
    const {'1': 'ISO_A4X4', '2': 313},
    const {'1': 'ISO_A4X5', '2': 314},
    const {'1': 'ISO_A4X6', '2': 315},
    const {'1': 'ISO_A4X7', '2': 316},
    const {'1': 'ISO_A4X8', '2': 317},
    const {'1': 'ISO_A4X9', '2': 318},
    const {'1': 'ISO_A3_EXTRA', '2': 319},
    const {'1': 'ISO_A2', '2': 320},
    const {'1': 'ISO_A3X3', '2': 321},
    const {'1': 'ISO_A3X4', '2': 322},
    const {'1': 'ISO_A3X5', '2': 323},
    const {'1': 'ISO_A3X6', '2': 324},
    const {'1': 'ISO_A3X7', '2': 325},
    const {'1': 'ISO_A1', '2': 326},
    const {'1': 'ISO_A2X3', '2': 327},
    const {'1': 'ISO_A2X4', '2': 328},
    const {'1': 'ISO_A2X5', '2': 329},
    const {'1': 'ISO_A0', '2': 330},
    const {'1': 'ISO_A1X3', '2': 331},
    const {'1': 'ISO_A1X4', '2': 332},
    const {'1': 'ISO_2A0', '2': 333},
    const {'1': 'ISO_A0X3', '2': 334},
    const {'1': 'ISO_B10', '2': 335},
    const {'1': 'ISO_B9', '2': 336},
    const {'1': 'ISO_B8', '2': 337},
    const {'1': 'ISO_B7', '2': 338},
    const {'1': 'ISO_B6', '2': 339},
    const {'1': 'ISO_B6C4', '2': 340},
    const {'1': 'ISO_B5', '2': 341},
    const {'1': 'ISO_B5_EXTRA', '2': 342},
    const {'1': 'ISO_B4', '2': 343},
    const {'1': 'ISO_B3', '2': 344},
    const {'1': 'ISO_B2', '2': 345},
    const {'1': 'ISO_B1', '2': 346},
    const {'1': 'ISO_B0', '2': 347},
    const {'1': 'ISO_C10', '2': 348},
    const {'1': 'ISO_C9', '2': 349},
    const {'1': 'ISO_C8', '2': 350},
    const {'1': 'ISO_C7', '2': 351},
    const {'1': 'ISO_C7C6', '2': 352},
    const {'1': 'ISO_C6', '2': 353},
    const {'1': 'ISO_C6C5', '2': 354},
    const {'1': 'ISO_C5', '2': 355},
    const {'1': 'ISO_C4', '2': 356},
    const {'1': 'ISO_C3', '2': 357},
    const {'1': 'ISO_C2', '2': 358},
    const {'1': 'ISO_C1', '2': 359},
    const {'1': 'ISO_C0', '2': 360},
    const {'1': 'ISO_DL', '2': 361},
    const {'1': 'ISO_RA2', '2': 362},
    const {'1': 'ISO_SRA2', '2': 363},
    const {'1': 'ISO_RA1', '2': 364},
    const {'1': 'ISO_SRA1', '2': 365},
    const {'1': 'ISO_RA0', '2': 366},
    const {'1': 'ISO_SRA0', '2': 367},
    const {'1': 'JIS_B10', '2': 400},
    const {'1': 'JIS_B9', '2': 401},
    const {'1': 'JIS_B8', '2': 402},
    const {'1': 'JIS_B7', '2': 403},
    const {'1': 'JIS_B6', '2': 404},
    const {'1': 'JIS_B5', '2': 405},
    const {'1': 'JIS_B4', '2': 406},
    const {'1': 'JIS_B3', '2': 407},
    const {'1': 'JIS_B2', '2': 408},
    const {'1': 'JIS_B1', '2': 409},
    const {'1': 'JIS_B0', '2': 410},
    const {'1': 'JIS_EXEC', '2': 411},
    const {'1': 'JPN_CHOU4', '2': 412},
    const {'1': 'JPN_HAGAKI', '2': 413},
    const {'1': 'JPN_YOU4', '2': 414},
    const {'1': 'JPN_CHOU2', '2': 415},
    const {'1': 'JPN_CHOU3', '2': 416},
    const {'1': 'JPN_OUFUKU', '2': 417},
    const {'1': 'JPN_KAHU', '2': 418},
    const {'1': 'JPN_KAKU2', '2': 419},
    const {'1': 'OM_SMALL_PHOTO', '2': 500},
    const {'1': 'OM_ITALIAN', '2': 501},
    const {'1': 'OM_POSTFIX', '2': 502},
    const {'1': 'OM_LARGE_PHOTO', '2': 503},
    const {'1': 'OM_FOLIO', '2': 504},
    const {'1': 'OM_FOLIO_SP', '2': 505},
    const {'1': 'OM_INVITE', '2': 506},
  ],
};

const Collate$json = const {
  '1': 'Collate',
  '2': const [
    const {'1': 'default', '3': 1, '4': 1, '5': 8, '10': 'default'},
  ],
};

const ReverseOrder$json = const {
  '1': 'ReverseOrder',
  '2': const [
    const {'1': 'default', '3': 1, '4': 1, '5': 8, '10': 'default'},
  ],
};

const LocalizedString$json = const {
  '1': 'LocalizedString',
  '2': const [
    const {'1': 'locale', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.LocalizedString.Locale', '10': 'locale'},
    const {'1': 'value', '3': 2, '4': 1, '5': 9, '10': 'value'},
  ],
  '4': const [LocalizedString_Locale$json],
};

const LocalizedString_Locale$json = const {
  '1': 'Locale',
  '2': const [
    const {'1': 'AF', '2': 0},
    const {'1': 'AM', '2': 1},
    const {'1': 'AR', '2': 2},
    const {'1': 'AR_XB', '2': 3},
    const {'1': 'BG', '2': 4},
    const {'1': 'BN', '2': 5},
    const {'1': 'CA', '2': 6},
    const {'1': 'CS', '2': 7},
    const {'1': 'CY', '2': 8},
    const {'1': 'DA', '2': 9},
    const {'1': 'DE', '2': 10},
    const {'1': 'DE_AT', '2': 11},
    const {'1': 'DE_CH', '2': 12},
    const {'1': 'EL', '2': 13},
    const {'1': 'EN', '2': 14},
    const {'1': 'EN_GB', '2': 15},
    const {'1': 'EN_IE', '2': 16},
    const {'1': 'EN_IN', '2': 17},
    const {'1': 'EN_SG', '2': 18},
    const {'1': 'EN_XA', '2': 19},
    const {'1': 'EN_XC', '2': 20},
    const {'1': 'EN_ZA', '2': 21},
    const {'1': 'ES', '2': 22},
    const {'1': 'ES_419', '2': 23},
    const {'1': 'ES_AR', '2': 24},
    const {'1': 'ES_BO', '2': 25},
    const {'1': 'ES_CL', '2': 26},
    const {'1': 'ES_CO', '2': 27},
    const {'1': 'ES_CR', '2': 28},
    const {'1': 'ES_DO', '2': 29},
    const {'1': 'ES_EC', '2': 30},
    const {'1': 'ES_GT', '2': 31},
    const {'1': 'ES_HN', '2': 32},
    const {'1': 'ES_MX', '2': 33},
    const {'1': 'ES_NI', '2': 34},
    const {'1': 'ES_PA', '2': 35},
    const {'1': 'ES_PE', '2': 36},
    const {'1': 'ES_PR', '2': 37},
    const {'1': 'ES_PY', '2': 38},
    const {'1': 'ES_SV', '2': 39},
    const {'1': 'ES_US', '2': 40},
    const {'1': 'ES_UY', '2': 41},
    const {'1': 'ES_VE', '2': 42},
    const {'1': 'ET', '2': 43},
    const {'1': 'EU', '2': 44},
    const {'1': 'FA', '2': 45},
    const {'1': 'FI', '2': 46},
    const {'1': 'FR', '2': 47},
    const {'1': 'FR_CA', '2': 48},
    const {'1': 'FR_CH', '2': 49},
    const {'1': 'GL', '2': 50},
    const {'1': 'GU', '2': 51},
    const {'1': 'HE', '2': 52},
    const {'1': 'HI', '2': 53},
    const {'1': 'HR', '2': 54},
    const {'1': 'HU', '2': 55},
    const {'1': 'HY', '2': 56},
    const {'1': 'ID', '2': 57},
    const {'1': 'IN', '2': 58},
    const {'1': 'IT', '2': 59},
    const {'1': 'JA', '2': 60},
    const {'1': 'KA', '2': 61},
    const {'1': 'KM', '2': 62},
    const {'1': 'KN', '2': 63},
    const {'1': 'KO', '2': 64},
    const {'1': 'LN', '2': 65},
    const {'1': 'LO', '2': 66},
    const {'1': 'LT', '2': 67},
    const {'1': 'LV', '2': 68},
    const {'1': 'ML', '2': 69},
    const {'1': 'MO', '2': 70},
    const {'1': 'MR', '2': 71},
    const {'1': 'MS', '2': 72},
    const {'1': 'NB', '2': 73},
    const {'1': 'NE', '2': 74},
    const {'1': 'NL', '2': 75},
    const {'1': 'NO', '2': 76},
    const {'1': 'PL', '2': 77},
    const {'1': 'PT', '2': 78},
    const {'1': 'PT_BR', '2': 79},
    const {'1': 'PT_PT', '2': 80},
    const {'1': 'RM', '2': 81},
    const {'1': 'RO', '2': 82},
    const {'1': 'RU', '2': 83},
    const {'1': 'SK', '2': 84},
    const {'1': 'SL', '2': 85},
    const {'1': 'SR', '2': 86},
    const {'1': 'SR_LATN', '2': 87},
    const {'1': 'SV', '2': 88},
    const {'1': 'SW', '2': 89},
    const {'1': 'TA', '2': 90},
    const {'1': 'TE', '2': 91},
    const {'1': 'TH', '2': 92},
    const {'1': 'TL', '2': 93},
    const {'1': 'TR', '2': 94},
    const {'1': 'UK', '2': 95},
    const {'1': 'UR', '2': 96},
    const {'1': 'VI', '2': 97},
    const {'1': 'ZH', '2': 98},
    const {'1': 'ZH_CN', '2': 99},
    const {'1': 'ZH_HK', '2': 100},
    const {'1': 'ZH_TW', '2': 101},
    const {'1': 'ZU', '2': 102},
  ],
};

const SupportedContentType$json = const {
  '1': 'SupportedContentType',
  '2': const [
    const {'1': 'content_type', '3': 1, '4': 1, '5': 9, '10': 'contentType'},
    const {'1': 'min_version', '3': 2, '4': 1, '5': 9, '10': 'minVersion'},
    const {'1': 'max_version', '3': 3, '4': 1, '5': 9, '10': 'maxVersion'},
  ],
};

const PrintingSpeed$json = const {
  '1': 'PrintingSpeed',
  '2': const [
    const {'1': 'option', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.PrintingSpeed.Option', '10': 'option'},
  ],
  '3': const [PrintingSpeed_Option$json],
};

const PrintingSpeed_Option$json = const {
  '1': 'Option',
  '2': const [
    const {'1': 'speed_ppm', '3': 1, '4': 1, '5': 2, '10': 'speedPpm'},
    const {'1': 'color_type', '3': 2, '4': 3, '5': 14, '6': '.google.cloudprint.Color.Type', '10': 'colorType'},
    const {'1': 'media_size_name', '3': 3, '4': 3, '5': 14, '6': '.google.cloudprint.MediaSize.Name', '10': 'mediaSizeName'},
  ],
};

const PwgRasterConfig$json = const {
  '1': 'PwgRasterConfig',
  '2': const [
    const {'1': 'document_resolution_supported', '3': 2, '4': 3, '5': 11, '6': '.google.cloudprint.PwgRasterConfig.Resolution', '10': 'documentResolutionSupported'},
    const {'1': 'document_type_supported', '3': 3, '4': 3, '5': 14, '6': '.google.cloudprint.PwgRasterConfig.PwgDocumentTypeSupported', '10': 'documentTypeSupported'},
    const {'1': 'document_sheet_back', '3': 4, '4': 1, '5': 14, '6': '.google.cloudprint.PwgRasterConfig.DocumentSheetBack', '10': 'documentSheetBack'},
    const {'1': 'reverse_order_streaming', '3': 5, '4': 1, '5': 8, '10': 'reverseOrderStreaming'},
    const {'1': 'rotate_all_pages', '3': 6, '4': 1, '5': 8, '10': 'rotateAllPages'},
    const {'1': 'transformation', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.PwgRasterConfig.Transformation', '10': 'transformation'},
  ],
  '3': const [PwgRasterConfig_Resolution$json, PwgRasterConfig_Transformation$json],
  '4': const [PwgRasterConfig_DocumentSheetBack$json, PwgRasterConfig_PwgDocumentTypeSupported$json],
};

const PwgRasterConfig_Resolution$json = const {
  '1': 'Resolution',
  '2': const [
    const {'1': 'cross_feed_dir', '3': 1, '4': 1, '5': 5, '10': 'crossFeedDir'},
    const {'1': 'feed_dir', '3': 2, '4': 1, '5': 5, '10': 'feedDir'},
  ],
};

const PwgRasterConfig_Transformation$json = const {
  '1': 'Transformation',
  '2': const [
    const {'1': 'operation', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.PwgRasterConfig.Transformation.Operation', '10': 'operation'},
    const {'1': 'operand', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.PwgRasterConfig.Transformation.Operand', '10': 'operand'},
    const {'1': 'duplex_type', '3': 3, '4': 3, '5': 14, '6': '.google.cloudprint.Duplex.Type', '10': 'duplexType'},
  ],
  '4': const [PwgRasterConfig_Transformation_Operation$json, PwgRasterConfig_Transformation_Operand$json],
  '7': const {'3': true},
};

const PwgRasterConfig_Transformation_Operation$json = const {
  '1': 'Operation',
  '2': const [
    const {'1': 'ROTATE_180', '2': 0},
    const {'1': 'FLIP_ON_LONG_EDGE', '2': 1},
    const {'1': 'FLIP_ON_SHORT_EDGE', '2': 2},
  ],
};

const PwgRasterConfig_Transformation_Operand$json = const {
  '1': 'Operand',
  '2': const [
    const {'1': 'ALL_PAGES', '2': 0},
    const {'1': 'ONLY_DUPLEXED_EVEN_PAGES', '2': 1},
    const {'1': 'ONLY_DUPLEXED_ODD_PAGES', '2': 2},
    const {'1': 'EVEN_PAGES', '2': 3},
    const {'1': 'ODD_PAGES', '2': 4},
  ],
};

const PwgRasterConfig_DocumentSheetBack$json = const {
  '1': 'DocumentSheetBack',
  '2': const [
    const {'1': 'NORMAL', '2': 0},
    const {'1': 'ROTATED', '2': 1},
    const {'1': 'MANUAL_TUMBLE', '2': 2},
    const {'1': 'FLIPPED', '2': 3},
  ],
};

const PwgRasterConfig_PwgDocumentTypeSupported$json = const {
  '1': 'PwgDocumentTypeSupported',
  '2': const [
    const {'1': 'UNSPECIFIED_PWG_DOCUMENT_TYPE', '2': 0},
    const {'1': 'BLACK_1', '2': 1},
    const {'1': 'SGRAY_1', '2': 2},
    const {'1': 'ADOBE_RGB_8', '2': 3},
    const {'1': 'BLACK_8', '2': 4},
    const {'1': 'CMYK_8', '2': 5},
    const {'1': 'DEVICE1_8', '2': 6},
    const {'1': 'DEVICE2_8', '2': 7},
    const {'1': 'DEVICE3_8', '2': 8},
    const {'1': 'DEVICE4_8', '2': 9},
    const {'1': 'DEVICE5_8', '2': 10},
    const {'1': 'DEVICE6_8', '2': 11},
    const {'1': 'DEVICE7_8', '2': 12},
    const {'1': 'DEVICE8_8', '2': 13},
    const {'1': 'DEVICE9_8', '2': 14},
    const {'1': 'DEVICE10_8', '2': 15},
    const {'1': 'DEVICE11_8', '2': 16},
    const {'1': 'DEVICE12_8', '2': 17},
    const {'1': 'DEVICE13_8', '2': 18},
    const {'1': 'DEVICE14_8', '2': 19},
    const {'1': 'DEVICE15_8', '2': 20},
    const {'1': 'RGB_8', '2': 21},
    const {'1': 'SGRAY_8', '2': 22},
    const {'1': 'SRGB_8', '2': 23},
    const {'1': 'ADOBE_RGB_16', '2': 24},
    const {'1': 'BLACK_16', '2': 25},
    const {'1': 'CMYK_16', '2': 26},
    const {'1': 'DEVICE1_16', '2': 27},
    const {'1': 'DEVICE2_16', '2': 28},
    const {'1': 'DEVICE3_16', '2': 29},
    const {'1': 'DEVICE4_16', '2': 30},
    const {'1': 'DEVICE5_16', '2': 31},
    const {'1': 'DEVICE6_16', '2': 32},
    const {'1': 'DEVICE7_16', '2': 33},
    const {'1': 'DEVICE8_16', '2': 34},
    const {'1': 'DEVICE9_16', '2': 35},
    const {'1': 'DEVICE10_16', '2': 36},
    const {'1': 'DEVICE11_16', '2': 37},
    const {'1': 'DEVICE12_16', '2': 38},
    const {'1': 'DEVICE13_16', '2': 39},
    const {'1': 'DEVICE14_16', '2': 40},
    const {'1': 'DEVICE15_16', '2': 41},
    const {'1': 'RGB_16', '2': 42},
    const {'1': 'SGRAY_16', '2': 43},
    const {'1': 'SRGB_16', '2': 44},
  ],
};

const InputTrayUnit$json = const {
  '1': 'InputTrayUnit',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.InputTrayUnit.Type', '10': 'type'},
    const {'1': 'index', '3': 3, '4': 1, '5': 3, '10': 'index'},
    const {'1': 'custom_display_name', '3': 4, '4': 1, '5': 9, '10': 'customDisplayName'},
    const {'1': 'custom_display_name_localized', '3': 5, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'customDisplayNameLocalized'},
  ],
  '4': const [InputTrayUnit_Type$json],
};

const InputTrayUnit_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'CUSTOM', '2': 0},
    const {'1': 'INPUT_TRAY', '2': 1},
    const {'1': 'BYPASS_TRAY', '2': 2},
    const {'1': 'MANUAL_FEED_TRAY', '2': 3},
    const {'1': 'LCT', '2': 4},
    const {'1': 'ENVELOPE_TRAY', '2': 5},
    const {'1': 'ROLL', '2': 6},
  ],
};

const OutputBinUnit$json = const {
  '1': 'OutputBinUnit',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.OutputBinUnit.Type', '10': 'type'},
    const {'1': 'index', '3': 3, '4': 1, '5': 3, '10': 'index'},
    const {'1': 'custom_display_name', '3': 4, '4': 1, '5': 9, '10': 'customDisplayName'},
    const {'1': 'custom_display_name_localized', '3': 5, '4': 3, '5': 11, '6': '.google.cloudprint.LocalizedString', '10': 'customDisplayNameLocalized'},
  ],
  '4': const [OutputBinUnit_Type$json],
};

const OutputBinUnit_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'CUSTOM', '2': 0},
    const {'1': 'OUTPUT_BIN', '2': 1},
    const {'1': 'MAILBOX', '2': 2},
    const {'1': 'STACKER', '2': 3},
  ],
};

