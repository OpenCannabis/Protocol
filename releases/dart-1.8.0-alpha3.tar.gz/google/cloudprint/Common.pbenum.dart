///
//  Generated code. Do not modify.
//  source: google/cloudprint/Common.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class PrinterType extends $pb.ProtobufEnum {
  static const PrinterType NO_PRINTER_TYPE_FILTER = PrinterType._(0, 'NO_PRINTER_TYPE_FILTER');
  static const PrinterType GOOGLE = PrinterType._(1, 'GOOGLE');
  static const PrinterType HP = PrinterType._(2, 'HP');
  static const PrinterType DRIVE = PrinterType._(3, 'DRIVE');
  static const PrinterType FEDEX = PrinterType._(4, 'FEDEX');
  static const PrinterType ANDROID_CHROME_SNAPSHOT = PrinterType._(5, 'ANDROID_CHROME_SNAPSHOT');
  static const PrinterType IOS_CHROME_SNAPSHOT = PrinterType._(6, 'IOS_CHROME_SNAPSHOT');

  static const $core.List<PrinterType> values = <PrinterType> [
    NO_PRINTER_TYPE_FILTER,
    GOOGLE,
    HP,
    DRIVE,
    FEDEX,
    ANDROID_CHROME_SNAPSHOT,
    IOS_CHROME_SNAPSHOT,
  ];

  static final $core.Map<$core.int, PrinterType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PrinterType valueOf($core.int value) => _byValue[value];

  const PrinterType._($core.int v, $core.String n) : super(v, n);
}

class NotificationChannel extends $pb.ProtobufEnum {
  static const NotificationChannel UNRECOGNIZED_CHANNEL = NotificationChannel._(0, 'UNRECOGNIZED_CHANNEL');
  static const NotificationChannel XMPP_CHANNEL = NotificationChannel._(1, 'XMPP_CHANNEL');

  static const $core.List<NotificationChannel> values = <NotificationChannel> [
    UNRECOGNIZED_CHANNEL,
    XMPP_CHANNEL,
  ];

  static final $core.Map<$core.int, NotificationChannel> _byValue = $pb.ProtobufEnum.initByValue(values);
  static NotificationChannel valueOf($core.int value) => _byValue[value];

  const NotificationChannel._($core.int v, $core.String n) : super(v, n);
}

class Marker_Type extends $pb.ProtobufEnum {
  static const Marker_Type CUSTOM = Marker_Type._(0, 'CUSTOM');
  static const Marker_Type TONER = Marker_Type._(1, 'TONER');
  static const Marker_Type INK = Marker_Type._(2, 'INK');
  static const Marker_Type STAPLES = Marker_Type._(3, 'STAPLES');

  static const $core.List<Marker_Type> values = <Marker_Type> [
    CUSTOM,
    TONER,
    INK,
    STAPLES,
  ];

  static final $core.Map<$core.int, Marker_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Marker_Type valueOf($core.int value) => _byValue[value];

  const Marker_Type._($core.int v, $core.String n) : super(v, n);
}

class Marker_Color_Type extends $pb.ProtobufEnum {
  static const Marker_Color_Type CUSTOM = Marker_Color_Type._(0, 'CUSTOM');
  static const Marker_Color_Type BLACK = Marker_Color_Type._(1, 'BLACK');
  static const Marker_Color_Type COLOR = Marker_Color_Type._(2, 'COLOR');
  static const Marker_Color_Type CYAN = Marker_Color_Type._(3, 'CYAN');
  static const Marker_Color_Type MAGENTA = Marker_Color_Type._(4, 'MAGENTA');
  static const Marker_Color_Type YELLOW = Marker_Color_Type._(5, 'YELLOW');
  static const Marker_Color_Type LIGHT_CYAN = Marker_Color_Type._(6, 'LIGHT_CYAN');
  static const Marker_Color_Type LIGHT_MAGENTA = Marker_Color_Type._(7, 'LIGHT_MAGENTA');
  static const Marker_Color_Type GRAY = Marker_Color_Type._(8, 'GRAY');
  static const Marker_Color_Type LIGHT_GRAY = Marker_Color_Type._(9, 'LIGHT_GRAY');
  static const Marker_Color_Type PIGMENT_BLACK = Marker_Color_Type._(10, 'PIGMENT_BLACK');
  static const Marker_Color_Type MATTE_BLACK = Marker_Color_Type._(11, 'MATTE_BLACK');
  static const Marker_Color_Type PHOTO_CYAN = Marker_Color_Type._(12, 'PHOTO_CYAN');
  static const Marker_Color_Type PHOTO_MAGENTA = Marker_Color_Type._(13, 'PHOTO_MAGENTA');
  static const Marker_Color_Type PHOTO_YELLOW = Marker_Color_Type._(14, 'PHOTO_YELLOW');
  static const Marker_Color_Type PHOTO_GRAY = Marker_Color_Type._(15, 'PHOTO_GRAY');
  static const Marker_Color_Type RED = Marker_Color_Type._(16, 'RED');
  static const Marker_Color_Type GREEN = Marker_Color_Type._(17, 'GREEN');
  static const Marker_Color_Type BLUE = Marker_Color_Type._(18, 'BLUE');

  static const $core.List<Marker_Color_Type> values = <Marker_Color_Type> [
    CUSTOM,
    BLACK,
    COLOR,
    CYAN,
    MAGENTA,
    YELLOW,
    LIGHT_CYAN,
    LIGHT_MAGENTA,
    GRAY,
    LIGHT_GRAY,
    PIGMENT_BLACK,
    MATTE_BLACK,
    PHOTO_CYAN,
    PHOTO_MAGENTA,
    PHOTO_YELLOW,
    PHOTO_GRAY,
    RED,
    GREEN,
    BLUE,
  ];

  static final $core.Map<$core.int, Marker_Color_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Marker_Color_Type valueOf($core.int value) => _byValue[value];

  const Marker_Color_Type._($core.int v, $core.String n) : super(v, n);
}

class Cover_Type extends $pb.ProtobufEnum {
  static const Cover_Type CUSTOM = Cover_Type._(0, 'CUSTOM');
  static const Cover_Type DOOR = Cover_Type._(1, 'DOOR');
  static const Cover_Type COVER = Cover_Type._(2, 'COVER');

  static const $core.List<Cover_Type> values = <Cover_Type> [
    CUSTOM,
    DOOR,
    COVER,
  ];

  static final $core.Map<$core.int, Cover_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Cover_Type valueOf($core.int value) => _byValue[value];

  const Cover_Type._($core.int v, $core.String n) : super(v, n);
}

class VendorCapability_Type extends $pb.ProtobufEnum {
  static const VendorCapability_Type RANGE = VendorCapability_Type._(0, 'RANGE');
  static const VendorCapability_Type SELECT = VendorCapability_Type._(1, 'SELECT');
  static const VendorCapability_Type TYPED_VALUE = VendorCapability_Type._(2, 'TYPED_VALUE');

  static const $core.List<VendorCapability_Type> values = <VendorCapability_Type> [
    RANGE,
    SELECT,
    TYPED_VALUE,
  ];

  static final $core.Map<$core.int, VendorCapability_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static VendorCapability_Type valueOf($core.int value) => _byValue[value];

  const VendorCapability_Type._($core.int v, $core.String n) : super(v, n);
}

class RangeCapability_ValueType extends $pb.ProtobufEnum {
  static const RangeCapability_ValueType FLOAT = RangeCapability_ValueType._(0, 'FLOAT');
  static const RangeCapability_ValueType INTEGER = RangeCapability_ValueType._(1, 'INTEGER');

  static const $core.List<RangeCapability_ValueType> values = <RangeCapability_ValueType> [
    FLOAT,
    INTEGER,
  ];

  static final $core.Map<$core.int, RangeCapability_ValueType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static RangeCapability_ValueType valueOf($core.int value) => _byValue[value];

  const RangeCapability_ValueType._($core.int v, $core.String n) : super(v, n);
}

class TypedValueCapability_ValueType extends $pb.ProtobufEnum {
  static const TypedValueCapability_ValueType BOOLEAN = TypedValueCapability_ValueType._(0, 'BOOLEAN');
  static const TypedValueCapability_ValueType FLOAT = TypedValueCapability_ValueType._(1, 'FLOAT');
  static const TypedValueCapability_ValueType INTEGER = TypedValueCapability_ValueType._(2, 'INTEGER');
  static const TypedValueCapability_ValueType STRING = TypedValueCapability_ValueType._(3, 'STRING');

  static const $core.List<TypedValueCapability_ValueType> values = <TypedValueCapability_ValueType> [
    BOOLEAN,
    FLOAT,
    INTEGER,
    STRING,
  ];

  static final $core.Map<$core.int, TypedValueCapability_ValueType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static TypedValueCapability_ValueType valueOf($core.int value) => _byValue[value];

  const TypedValueCapability_ValueType._($core.int v, $core.String n) : super(v, n);
}

class Color_Type extends $pb.ProtobufEnum {
  static const Color_Type STANDARD_COLOR = Color_Type._(0, 'STANDARD_COLOR');
  static const Color_Type STANDARD_MONOCHROME = Color_Type._(1, 'STANDARD_MONOCHROME');
  static const Color_Type CUSTOM_COLOR = Color_Type._(2, 'CUSTOM_COLOR');
  static const Color_Type CUSTOM_MONOCHROME = Color_Type._(3, 'CUSTOM_MONOCHROME');
  static const Color_Type AUTO = Color_Type._(4, 'AUTO');

  static const $core.List<Color_Type> values = <Color_Type> [
    STANDARD_COLOR,
    STANDARD_MONOCHROME,
    CUSTOM_COLOR,
    CUSTOM_MONOCHROME,
    AUTO,
  ];

  static final $core.Map<$core.int, Color_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Color_Type valueOf($core.int value) => _byValue[value];

  const Color_Type._($core.int v, $core.String n) : super(v, n);
}

class Duplex_Type extends $pb.ProtobufEnum {
  static const Duplex_Type NO_DUPLEX = Duplex_Type._(0, 'NO_DUPLEX');
  static const Duplex_Type LONG_EDGE = Duplex_Type._(1, 'LONG_EDGE');
  static const Duplex_Type SHORT_EDGE = Duplex_Type._(2, 'SHORT_EDGE');

  static const $core.List<Duplex_Type> values = <Duplex_Type> [
    NO_DUPLEX,
    LONG_EDGE,
    SHORT_EDGE,
  ];

  static final $core.Map<$core.int, Duplex_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Duplex_Type valueOf($core.int value) => _byValue[value];

  const Duplex_Type._($core.int v, $core.String n) : super(v, n);
}

class PageOrientation_Type extends $pb.ProtobufEnum {
  static const PageOrientation_Type PORTRAIT = PageOrientation_Type._(0, 'PORTRAIT');
  static const PageOrientation_Type LANDSCAPE = PageOrientation_Type._(1, 'LANDSCAPE');
  static const PageOrientation_Type AUTO = PageOrientation_Type._(2, 'AUTO');

  static const $core.List<PageOrientation_Type> values = <PageOrientation_Type> [
    PORTRAIT,
    LANDSCAPE,
    AUTO,
  ];

  static final $core.Map<$core.int, PageOrientation_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PageOrientation_Type valueOf($core.int value) => _byValue[value];

  const PageOrientation_Type._($core.int v, $core.String n) : super(v, n);
}

class Margins_Type extends $pb.ProtobufEnum {
  static const Margins_Type BORDERLESS = Margins_Type._(0, 'BORDERLESS');
  static const Margins_Type STANDARD = Margins_Type._(1, 'STANDARD');
  static const Margins_Type CUSTOM = Margins_Type._(2, 'CUSTOM');

  static const $core.List<Margins_Type> values = <Margins_Type> [
    BORDERLESS,
    STANDARD,
    CUSTOM,
  ];

  static final $core.Map<$core.int, Margins_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Margins_Type valueOf($core.int value) => _byValue[value];

  const Margins_Type._($core.int v, $core.String n) : super(v, n);
}

class FitToPage_Type extends $pb.ProtobufEnum {
  static const FitToPage_Type NO_FITTING = FitToPage_Type._(0, 'NO_FITTING');
  static const FitToPage_Type FIT_TO_PAGE = FitToPage_Type._(1, 'FIT_TO_PAGE');
  static const FitToPage_Type GROW_TO_PAGE = FitToPage_Type._(2, 'GROW_TO_PAGE');
  static const FitToPage_Type SHRINK_TO_PAGE = FitToPage_Type._(3, 'SHRINK_TO_PAGE');
  static const FitToPage_Type FILL_PAGE = FitToPage_Type._(4, 'FILL_PAGE');

  static const $core.List<FitToPage_Type> values = <FitToPage_Type> [
    NO_FITTING,
    FIT_TO_PAGE,
    GROW_TO_PAGE,
    SHRINK_TO_PAGE,
    FILL_PAGE,
  ];

  static final $core.Map<$core.int, FitToPage_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static FitToPage_Type valueOf($core.int value) => _byValue[value];

  const FitToPage_Type._($core.int v, $core.String n) : super(v, n);
}

class MediaSize_Name extends $pb.ProtobufEnum {
  static const MediaSize_Name CUSTOM = MediaSize_Name._(0, 'CUSTOM');
  static const MediaSize_Name NA_INDEX_3X5 = MediaSize_Name._(100, 'NA_INDEX_3X5');
  static const MediaSize_Name NA_PERSONAL = MediaSize_Name._(101, 'NA_PERSONAL');
  static const MediaSize_Name NA_MONARCH = MediaSize_Name._(102, 'NA_MONARCH');
  static const MediaSize_Name NA_NUMBER_9 = MediaSize_Name._(103, 'NA_NUMBER_9');
  static const MediaSize_Name NA_INDEX_4X6 = MediaSize_Name._(104, 'NA_INDEX_4X6');
  static const MediaSize_Name NA_NUMBER_10 = MediaSize_Name._(105, 'NA_NUMBER_10');
  static const MediaSize_Name NA_A2 = MediaSize_Name._(106, 'NA_A2');
  static const MediaSize_Name NA_NUMBER_11 = MediaSize_Name._(107, 'NA_NUMBER_11');
  static const MediaSize_Name NA_NUMBER_12 = MediaSize_Name._(108, 'NA_NUMBER_12');
  static const MediaSize_Name NA_5X7 = MediaSize_Name._(109, 'NA_5X7');
  static const MediaSize_Name NA_INDEX_5X8 = MediaSize_Name._(110, 'NA_INDEX_5X8');
  static const MediaSize_Name NA_NUMBER_14 = MediaSize_Name._(111, 'NA_NUMBER_14');
  static const MediaSize_Name NA_INVOICE = MediaSize_Name._(112, 'NA_INVOICE');
  static const MediaSize_Name NA_INDEX_4X6_EXT = MediaSize_Name._(113, 'NA_INDEX_4X6_EXT');
  static const MediaSize_Name NA_6X9 = MediaSize_Name._(114, 'NA_6X9');
  static const MediaSize_Name NA_C5 = MediaSize_Name._(115, 'NA_C5');
  static const MediaSize_Name NA_7X9 = MediaSize_Name._(116, 'NA_7X9');
  static const MediaSize_Name NA_EXECUTIVE = MediaSize_Name._(117, 'NA_EXECUTIVE');
  static const MediaSize_Name NA_GOVT_LETTER = MediaSize_Name._(118, 'NA_GOVT_LETTER');
  static const MediaSize_Name NA_GOVT_LEGAL = MediaSize_Name._(119, 'NA_GOVT_LEGAL');
  static const MediaSize_Name NA_QUARTO = MediaSize_Name._(120, 'NA_QUARTO');
  static const MediaSize_Name NA_LETTER = MediaSize_Name._(121, 'NA_LETTER');
  static const MediaSize_Name NA_FANFOLD_EUR = MediaSize_Name._(122, 'NA_FANFOLD_EUR');
  static const MediaSize_Name NA_LETTER_PLUS = MediaSize_Name._(123, 'NA_LETTER_PLUS');
  static const MediaSize_Name NA_FOOLSCAP = MediaSize_Name._(124, 'NA_FOOLSCAP');
  static const MediaSize_Name NA_LEGAL = MediaSize_Name._(125, 'NA_LEGAL');
  static const MediaSize_Name NA_SUPER_A = MediaSize_Name._(126, 'NA_SUPER_A');
  static const MediaSize_Name NA_9X11 = MediaSize_Name._(127, 'NA_9X11');
  static const MediaSize_Name NA_ARCH_A = MediaSize_Name._(128, 'NA_ARCH_A');
  static const MediaSize_Name NA_LETTER_EXTRA = MediaSize_Name._(129, 'NA_LETTER_EXTRA');
  static const MediaSize_Name NA_LEGAL_EXTRA = MediaSize_Name._(130, 'NA_LEGAL_EXTRA');
  static const MediaSize_Name NA_10X11 = MediaSize_Name._(131, 'NA_10X11');
  static const MediaSize_Name NA_10X13 = MediaSize_Name._(132, 'NA_10X13');
  static const MediaSize_Name NA_10X14 = MediaSize_Name._(133, 'NA_10X14');
  static const MediaSize_Name NA_10X15 = MediaSize_Name._(134, 'NA_10X15');
  static const MediaSize_Name NA_11X12 = MediaSize_Name._(135, 'NA_11X12');
  static const MediaSize_Name NA_EDP = MediaSize_Name._(136, 'NA_EDP');
  static const MediaSize_Name NA_FANFOLD_US = MediaSize_Name._(137, 'NA_FANFOLD_US');
  static const MediaSize_Name NA_11X15 = MediaSize_Name._(138, 'NA_11X15');
  static const MediaSize_Name NA_LEDGER = MediaSize_Name._(139, 'NA_LEDGER');
  static const MediaSize_Name NA_EUR_EDP = MediaSize_Name._(140, 'NA_EUR_EDP');
  static const MediaSize_Name NA_ARCH_B = MediaSize_Name._(141, 'NA_ARCH_B');
  static const MediaSize_Name NA_12X19 = MediaSize_Name._(142, 'NA_12X19');
  static const MediaSize_Name NA_B_PLUS = MediaSize_Name._(143, 'NA_B_PLUS');
  static const MediaSize_Name NA_SUPER_B = MediaSize_Name._(144, 'NA_SUPER_B');
  static const MediaSize_Name NA_C = MediaSize_Name._(145, 'NA_C');
  static const MediaSize_Name NA_ARCH_C = MediaSize_Name._(146, 'NA_ARCH_C');
  static const MediaSize_Name NA_D = MediaSize_Name._(147, 'NA_D');
  static const MediaSize_Name NA_ARCH_D = MediaSize_Name._(148, 'NA_ARCH_D');
  static const MediaSize_Name NA_ASME_F = MediaSize_Name._(149, 'NA_ASME_F');
  static const MediaSize_Name NA_WIDE_FORMAT = MediaSize_Name._(150, 'NA_WIDE_FORMAT');
  static const MediaSize_Name NA_E = MediaSize_Name._(151, 'NA_E');
  static const MediaSize_Name NA_ARCH_E = MediaSize_Name._(152, 'NA_ARCH_E');
  static const MediaSize_Name NA_F = MediaSize_Name._(153, 'NA_F');
  static const MediaSize_Name ROC_16K = MediaSize_Name._(200, 'ROC_16K');
  static const MediaSize_Name ROC_8K = MediaSize_Name._(201, 'ROC_8K');
  static const MediaSize_Name PRC_32K = MediaSize_Name._(202, 'PRC_32K');
  static const MediaSize_Name PRC_1 = MediaSize_Name._(203, 'PRC_1');
  static const MediaSize_Name PRC_2 = MediaSize_Name._(204, 'PRC_2');
  static const MediaSize_Name PRC_4 = MediaSize_Name._(205, 'PRC_4');
  static const MediaSize_Name PRC_5 = MediaSize_Name._(206, 'PRC_5');
  static const MediaSize_Name PRC_8 = MediaSize_Name._(207, 'PRC_8');
  static const MediaSize_Name PRC_6 = MediaSize_Name._(208, 'PRC_6');
  static const MediaSize_Name PRC_3 = MediaSize_Name._(209, 'PRC_3');
  static const MediaSize_Name PRC_16K = MediaSize_Name._(210, 'PRC_16K');
  static const MediaSize_Name PRC_7 = MediaSize_Name._(211, 'PRC_7');
  static const MediaSize_Name OM_JUURO_KU_KAI = MediaSize_Name._(212, 'OM_JUURO_KU_KAI');
  static const MediaSize_Name OM_PA_KAI = MediaSize_Name._(213, 'OM_PA_KAI');
  static const MediaSize_Name OM_DAI_PA_KAI = MediaSize_Name._(214, 'OM_DAI_PA_KAI');
  static const MediaSize_Name PRC_10 = MediaSize_Name._(215, 'PRC_10');
  static const MediaSize_Name ISO_A10 = MediaSize_Name._(301, 'ISO_A10');
  static const MediaSize_Name ISO_A9 = MediaSize_Name._(302, 'ISO_A9');
  static const MediaSize_Name ISO_A8 = MediaSize_Name._(303, 'ISO_A8');
  static const MediaSize_Name ISO_A7 = MediaSize_Name._(304, 'ISO_A7');
  static const MediaSize_Name ISO_A6 = MediaSize_Name._(305, 'ISO_A6');
  static const MediaSize_Name ISO_A5 = MediaSize_Name._(306, 'ISO_A5');
  static const MediaSize_Name ISO_A5_EXTRA = MediaSize_Name._(307, 'ISO_A5_EXTRA');
  static const MediaSize_Name ISO_A4 = MediaSize_Name._(308, 'ISO_A4');
  static const MediaSize_Name ISO_A4_TAB = MediaSize_Name._(309, 'ISO_A4_TAB');
  static const MediaSize_Name ISO_A4_EXTRA = MediaSize_Name._(310, 'ISO_A4_EXTRA');
  static const MediaSize_Name ISO_A3 = MediaSize_Name._(311, 'ISO_A3');
  static const MediaSize_Name ISO_A4X3 = MediaSize_Name._(312, 'ISO_A4X3');
  static const MediaSize_Name ISO_A4X4 = MediaSize_Name._(313, 'ISO_A4X4');
  static const MediaSize_Name ISO_A4X5 = MediaSize_Name._(314, 'ISO_A4X5');
  static const MediaSize_Name ISO_A4X6 = MediaSize_Name._(315, 'ISO_A4X6');
  static const MediaSize_Name ISO_A4X7 = MediaSize_Name._(316, 'ISO_A4X7');
  static const MediaSize_Name ISO_A4X8 = MediaSize_Name._(317, 'ISO_A4X8');
  static const MediaSize_Name ISO_A4X9 = MediaSize_Name._(318, 'ISO_A4X9');
  static const MediaSize_Name ISO_A3_EXTRA = MediaSize_Name._(319, 'ISO_A3_EXTRA');
  static const MediaSize_Name ISO_A2 = MediaSize_Name._(320, 'ISO_A2');
  static const MediaSize_Name ISO_A3X3 = MediaSize_Name._(321, 'ISO_A3X3');
  static const MediaSize_Name ISO_A3X4 = MediaSize_Name._(322, 'ISO_A3X4');
  static const MediaSize_Name ISO_A3X5 = MediaSize_Name._(323, 'ISO_A3X5');
  static const MediaSize_Name ISO_A3X6 = MediaSize_Name._(324, 'ISO_A3X6');
  static const MediaSize_Name ISO_A3X7 = MediaSize_Name._(325, 'ISO_A3X7');
  static const MediaSize_Name ISO_A1 = MediaSize_Name._(326, 'ISO_A1');
  static const MediaSize_Name ISO_A2X3 = MediaSize_Name._(327, 'ISO_A2X3');
  static const MediaSize_Name ISO_A2X4 = MediaSize_Name._(328, 'ISO_A2X4');
  static const MediaSize_Name ISO_A2X5 = MediaSize_Name._(329, 'ISO_A2X5');
  static const MediaSize_Name ISO_A0 = MediaSize_Name._(330, 'ISO_A0');
  static const MediaSize_Name ISO_A1X3 = MediaSize_Name._(331, 'ISO_A1X3');
  static const MediaSize_Name ISO_A1X4 = MediaSize_Name._(332, 'ISO_A1X4');
  static const MediaSize_Name ISO_2A0 = MediaSize_Name._(333, 'ISO_2A0');
  static const MediaSize_Name ISO_A0X3 = MediaSize_Name._(334, 'ISO_A0X3');
  static const MediaSize_Name ISO_B10 = MediaSize_Name._(335, 'ISO_B10');
  static const MediaSize_Name ISO_B9 = MediaSize_Name._(336, 'ISO_B9');
  static const MediaSize_Name ISO_B8 = MediaSize_Name._(337, 'ISO_B8');
  static const MediaSize_Name ISO_B7 = MediaSize_Name._(338, 'ISO_B7');
  static const MediaSize_Name ISO_B6 = MediaSize_Name._(339, 'ISO_B6');
  static const MediaSize_Name ISO_B6C4 = MediaSize_Name._(340, 'ISO_B6C4');
  static const MediaSize_Name ISO_B5 = MediaSize_Name._(341, 'ISO_B5');
  static const MediaSize_Name ISO_B5_EXTRA = MediaSize_Name._(342, 'ISO_B5_EXTRA');
  static const MediaSize_Name ISO_B4 = MediaSize_Name._(343, 'ISO_B4');
  static const MediaSize_Name ISO_B3 = MediaSize_Name._(344, 'ISO_B3');
  static const MediaSize_Name ISO_B2 = MediaSize_Name._(345, 'ISO_B2');
  static const MediaSize_Name ISO_B1 = MediaSize_Name._(346, 'ISO_B1');
  static const MediaSize_Name ISO_B0 = MediaSize_Name._(347, 'ISO_B0');
  static const MediaSize_Name ISO_C10 = MediaSize_Name._(348, 'ISO_C10');
  static const MediaSize_Name ISO_C9 = MediaSize_Name._(349, 'ISO_C9');
  static const MediaSize_Name ISO_C8 = MediaSize_Name._(350, 'ISO_C8');
  static const MediaSize_Name ISO_C7 = MediaSize_Name._(351, 'ISO_C7');
  static const MediaSize_Name ISO_C7C6 = MediaSize_Name._(352, 'ISO_C7C6');
  static const MediaSize_Name ISO_C6 = MediaSize_Name._(353, 'ISO_C6');
  static const MediaSize_Name ISO_C6C5 = MediaSize_Name._(354, 'ISO_C6C5');
  static const MediaSize_Name ISO_C5 = MediaSize_Name._(355, 'ISO_C5');
  static const MediaSize_Name ISO_C4 = MediaSize_Name._(356, 'ISO_C4');
  static const MediaSize_Name ISO_C3 = MediaSize_Name._(357, 'ISO_C3');
  static const MediaSize_Name ISO_C2 = MediaSize_Name._(358, 'ISO_C2');
  static const MediaSize_Name ISO_C1 = MediaSize_Name._(359, 'ISO_C1');
  static const MediaSize_Name ISO_C0 = MediaSize_Name._(360, 'ISO_C0');
  static const MediaSize_Name ISO_DL = MediaSize_Name._(361, 'ISO_DL');
  static const MediaSize_Name ISO_RA2 = MediaSize_Name._(362, 'ISO_RA2');
  static const MediaSize_Name ISO_SRA2 = MediaSize_Name._(363, 'ISO_SRA2');
  static const MediaSize_Name ISO_RA1 = MediaSize_Name._(364, 'ISO_RA1');
  static const MediaSize_Name ISO_SRA1 = MediaSize_Name._(365, 'ISO_SRA1');
  static const MediaSize_Name ISO_RA0 = MediaSize_Name._(366, 'ISO_RA0');
  static const MediaSize_Name ISO_SRA0 = MediaSize_Name._(367, 'ISO_SRA0');
  static const MediaSize_Name JIS_B10 = MediaSize_Name._(400, 'JIS_B10');
  static const MediaSize_Name JIS_B9 = MediaSize_Name._(401, 'JIS_B9');
  static const MediaSize_Name JIS_B8 = MediaSize_Name._(402, 'JIS_B8');
  static const MediaSize_Name JIS_B7 = MediaSize_Name._(403, 'JIS_B7');
  static const MediaSize_Name JIS_B6 = MediaSize_Name._(404, 'JIS_B6');
  static const MediaSize_Name JIS_B5 = MediaSize_Name._(405, 'JIS_B5');
  static const MediaSize_Name JIS_B4 = MediaSize_Name._(406, 'JIS_B4');
  static const MediaSize_Name JIS_B3 = MediaSize_Name._(407, 'JIS_B3');
  static const MediaSize_Name JIS_B2 = MediaSize_Name._(408, 'JIS_B2');
  static const MediaSize_Name JIS_B1 = MediaSize_Name._(409, 'JIS_B1');
  static const MediaSize_Name JIS_B0 = MediaSize_Name._(410, 'JIS_B0');
  static const MediaSize_Name JIS_EXEC = MediaSize_Name._(411, 'JIS_EXEC');
  static const MediaSize_Name JPN_CHOU4 = MediaSize_Name._(412, 'JPN_CHOU4');
  static const MediaSize_Name JPN_HAGAKI = MediaSize_Name._(413, 'JPN_HAGAKI');
  static const MediaSize_Name JPN_YOU4 = MediaSize_Name._(414, 'JPN_YOU4');
  static const MediaSize_Name JPN_CHOU2 = MediaSize_Name._(415, 'JPN_CHOU2');
  static const MediaSize_Name JPN_CHOU3 = MediaSize_Name._(416, 'JPN_CHOU3');
  static const MediaSize_Name JPN_OUFUKU = MediaSize_Name._(417, 'JPN_OUFUKU');
  static const MediaSize_Name JPN_KAHU = MediaSize_Name._(418, 'JPN_KAHU');
  static const MediaSize_Name JPN_KAKU2 = MediaSize_Name._(419, 'JPN_KAKU2');
  static const MediaSize_Name OM_SMALL_PHOTO = MediaSize_Name._(500, 'OM_SMALL_PHOTO');
  static const MediaSize_Name OM_ITALIAN = MediaSize_Name._(501, 'OM_ITALIAN');
  static const MediaSize_Name OM_POSTFIX = MediaSize_Name._(502, 'OM_POSTFIX');
  static const MediaSize_Name OM_LARGE_PHOTO = MediaSize_Name._(503, 'OM_LARGE_PHOTO');
  static const MediaSize_Name OM_FOLIO = MediaSize_Name._(504, 'OM_FOLIO');
  static const MediaSize_Name OM_FOLIO_SP = MediaSize_Name._(505, 'OM_FOLIO_SP');
  static const MediaSize_Name OM_INVITE = MediaSize_Name._(506, 'OM_INVITE');

  static const $core.List<MediaSize_Name> values = <MediaSize_Name> [
    CUSTOM,
    NA_INDEX_3X5,
    NA_PERSONAL,
    NA_MONARCH,
    NA_NUMBER_9,
    NA_INDEX_4X6,
    NA_NUMBER_10,
    NA_A2,
    NA_NUMBER_11,
    NA_NUMBER_12,
    NA_5X7,
    NA_INDEX_5X8,
    NA_NUMBER_14,
    NA_INVOICE,
    NA_INDEX_4X6_EXT,
    NA_6X9,
    NA_C5,
    NA_7X9,
    NA_EXECUTIVE,
    NA_GOVT_LETTER,
    NA_GOVT_LEGAL,
    NA_QUARTO,
    NA_LETTER,
    NA_FANFOLD_EUR,
    NA_LETTER_PLUS,
    NA_FOOLSCAP,
    NA_LEGAL,
    NA_SUPER_A,
    NA_9X11,
    NA_ARCH_A,
    NA_LETTER_EXTRA,
    NA_LEGAL_EXTRA,
    NA_10X11,
    NA_10X13,
    NA_10X14,
    NA_10X15,
    NA_11X12,
    NA_EDP,
    NA_FANFOLD_US,
    NA_11X15,
    NA_LEDGER,
    NA_EUR_EDP,
    NA_ARCH_B,
    NA_12X19,
    NA_B_PLUS,
    NA_SUPER_B,
    NA_C,
    NA_ARCH_C,
    NA_D,
    NA_ARCH_D,
    NA_ASME_F,
    NA_WIDE_FORMAT,
    NA_E,
    NA_ARCH_E,
    NA_F,
    ROC_16K,
    ROC_8K,
    PRC_32K,
    PRC_1,
    PRC_2,
    PRC_4,
    PRC_5,
    PRC_8,
    PRC_6,
    PRC_3,
    PRC_16K,
    PRC_7,
    OM_JUURO_KU_KAI,
    OM_PA_KAI,
    OM_DAI_PA_KAI,
    PRC_10,
    ISO_A10,
    ISO_A9,
    ISO_A8,
    ISO_A7,
    ISO_A6,
    ISO_A5,
    ISO_A5_EXTRA,
    ISO_A4,
    ISO_A4_TAB,
    ISO_A4_EXTRA,
    ISO_A3,
    ISO_A4X3,
    ISO_A4X4,
    ISO_A4X5,
    ISO_A4X6,
    ISO_A4X7,
    ISO_A4X8,
    ISO_A4X9,
    ISO_A3_EXTRA,
    ISO_A2,
    ISO_A3X3,
    ISO_A3X4,
    ISO_A3X5,
    ISO_A3X6,
    ISO_A3X7,
    ISO_A1,
    ISO_A2X3,
    ISO_A2X4,
    ISO_A2X5,
    ISO_A0,
    ISO_A1X3,
    ISO_A1X4,
    ISO_2A0,
    ISO_A0X3,
    ISO_B10,
    ISO_B9,
    ISO_B8,
    ISO_B7,
    ISO_B6,
    ISO_B6C4,
    ISO_B5,
    ISO_B5_EXTRA,
    ISO_B4,
    ISO_B3,
    ISO_B2,
    ISO_B1,
    ISO_B0,
    ISO_C10,
    ISO_C9,
    ISO_C8,
    ISO_C7,
    ISO_C7C6,
    ISO_C6,
    ISO_C6C5,
    ISO_C5,
    ISO_C4,
    ISO_C3,
    ISO_C2,
    ISO_C1,
    ISO_C0,
    ISO_DL,
    ISO_RA2,
    ISO_SRA2,
    ISO_RA1,
    ISO_SRA1,
    ISO_RA0,
    ISO_SRA0,
    JIS_B10,
    JIS_B9,
    JIS_B8,
    JIS_B7,
    JIS_B6,
    JIS_B5,
    JIS_B4,
    JIS_B3,
    JIS_B2,
    JIS_B1,
    JIS_B0,
    JIS_EXEC,
    JPN_CHOU4,
    JPN_HAGAKI,
    JPN_YOU4,
    JPN_CHOU2,
    JPN_CHOU3,
    JPN_OUFUKU,
    JPN_KAHU,
    JPN_KAKU2,
    OM_SMALL_PHOTO,
    OM_ITALIAN,
    OM_POSTFIX,
    OM_LARGE_PHOTO,
    OM_FOLIO,
    OM_FOLIO_SP,
    OM_INVITE,
  ];

  static final $core.Map<$core.int, MediaSize_Name> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaSize_Name valueOf($core.int value) => _byValue[value];

  const MediaSize_Name._($core.int v, $core.String n) : super(v, n);
}

class LocalizedString_Locale extends $pb.ProtobufEnum {
  static const LocalizedString_Locale AF = LocalizedString_Locale._(0, 'AF');
  static const LocalizedString_Locale AM = LocalizedString_Locale._(1, 'AM');
  static const LocalizedString_Locale AR = LocalizedString_Locale._(2, 'AR');
  static const LocalizedString_Locale AR_XB = LocalizedString_Locale._(3, 'AR_XB');
  static const LocalizedString_Locale BG = LocalizedString_Locale._(4, 'BG');
  static const LocalizedString_Locale BN = LocalizedString_Locale._(5, 'BN');
  static const LocalizedString_Locale CA = LocalizedString_Locale._(6, 'CA');
  static const LocalizedString_Locale CS = LocalizedString_Locale._(7, 'CS');
  static const LocalizedString_Locale CY = LocalizedString_Locale._(8, 'CY');
  static const LocalizedString_Locale DA = LocalizedString_Locale._(9, 'DA');
  static const LocalizedString_Locale DE = LocalizedString_Locale._(10, 'DE');
  static const LocalizedString_Locale DE_AT = LocalizedString_Locale._(11, 'DE_AT');
  static const LocalizedString_Locale DE_CH = LocalizedString_Locale._(12, 'DE_CH');
  static const LocalizedString_Locale EL = LocalizedString_Locale._(13, 'EL');
  static const LocalizedString_Locale EN = LocalizedString_Locale._(14, 'EN');
  static const LocalizedString_Locale EN_GB = LocalizedString_Locale._(15, 'EN_GB');
  static const LocalizedString_Locale EN_IE = LocalizedString_Locale._(16, 'EN_IE');
  static const LocalizedString_Locale EN_IN = LocalizedString_Locale._(17, 'EN_IN');
  static const LocalizedString_Locale EN_SG = LocalizedString_Locale._(18, 'EN_SG');
  static const LocalizedString_Locale EN_XA = LocalizedString_Locale._(19, 'EN_XA');
  static const LocalizedString_Locale EN_XC = LocalizedString_Locale._(20, 'EN_XC');
  static const LocalizedString_Locale EN_ZA = LocalizedString_Locale._(21, 'EN_ZA');
  static const LocalizedString_Locale ES = LocalizedString_Locale._(22, 'ES');
  static const LocalizedString_Locale ES_419 = LocalizedString_Locale._(23, 'ES_419');
  static const LocalizedString_Locale ES_AR = LocalizedString_Locale._(24, 'ES_AR');
  static const LocalizedString_Locale ES_BO = LocalizedString_Locale._(25, 'ES_BO');
  static const LocalizedString_Locale ES_CL = LocalizedString_Locale._(26, 'ES_CL');
  static const LocalizedString_Locale ES_CO = LocalizedString_Locale._(27, 'ES_CO');
  static const LocalizedString_Locale ES_CR = LocalizedString_Locale._(28, 'ES_CR');
  static const LocalizedString_Locale ES_DO = LocalizedString_Locale._(29, 'ES_DO');
  static const LocalizedString_Locale ES_EC = LocalizedString_Locale._(30, 'ES_EC');
  static const LocalizedString_Locale ES_GT = LocalizedString_Locale._(31, 'ES_GT');
  static const LocalizedString_Locale ES_HN = LocalizedString_Locale._(32, 'ES_HN');
  static const LocalizedString_Locale ES_MX = LocalizedString_Locale._(33, 'ES_MX');
  static const LocalizedString_Locale ES_NI = LocalizedString_Locale._(34, 'ES_NI');
  static const LocalizedString_Locale ES_PA = LocalizedString_Locale._(35, 'ES_PA');
  static const LocalizedString_Locale ES_PE = LocalizedString_Locale._(36, 'ES_PE');
  static const LocalizedString_Locale ES_PR = LocalizedString_Locale._(37, 'ES_PR');
  static const LocalizedString_Locale ES_PY = LocalizedString_Locale._(38, 'ES_PY');
  static const LocalizedString_Locale ES_SV = LocalizedString_Locale._(39, 'ES_SV');
  static const LocalizedString_Locale ES_US = LocalizedString_Locale._(40, 'ES_US');
  static const LocalizedString_Locale ES_UY = LocalizedString_Locale._(41, 'ES_UY');
  static const LocalizedString_Locale ES_VE = LocalizedString_Locale._(42, 'ES_VE');
  static const LocalizedString_Locale ET = LocalizedString_Locale._(43, 'ET');
  static const LocalizedString_Locale EU = LocalizedString_Locale._(44, 'EU');
  static const LocalizedString_Locale FA = LocalizedString_Locale._(45, 'FA');
  static const LocalizedString_Locale FI = LocalizedString_Locale._(46, 'FI');
  static const LocalizedString_Locale FR = LocalizedString_Locale._(47, 'FR');
  static const LocalizedString_Locale FR_CA = LocalizedString_Locale._(48, 'FR_CA');
  static const LocalizedString_Locale FR_CH = LocalizedString_Locale._(49, 'FR_CH');
  static const LocalizedString_Locale GL = LocalizedString_Locale._(50, 'GL');
  static const LocalizedString_Locale GU = LocalizedString_Locale._(51, 'GU');
  static const LocalizedString_Locale HE = LocalizedString_Locale._(52, 'HE');
  static const LocalizedString_Locale HI = LocalizedString_Locale._(53, 'HI');
  static const LocalizedString_Locale HR = LocalizedString_Locale._(54, 'HR');
  static const LocalizedString_Locale HU = LocalizedString_Locale._(55, 'HU');
  static const LocalizedString_Locale HY = LocalizedString_Locale._(56, 'HY');
  static const LocalizedString_Locale ID = LocalizedString_Locale._(57, 'ID');
  static const LocalizedString_Locale IN = LocalizedString_Locale._(58, 'IN');
  static const LocalizedString_Locale IT = LocalizedString_Locale._(59, 'IT');
  static const LocalizedString_Locale JA = LocalizedString_Locale._(60, 'JA');
  static const LocalizedString_Locale KA = LocalizedString_Locale._(61, 'KA');
  static const LocalizedString_Locale KM = LocalizedString_Locale._(62, 'KM');
  static const LocalizedString_Locale KN = LocalizedString_Locale._(63, 'KN');
  static const LocalizedString_Locale KO = LocalizedString_Locale._(64, 'KO');
  static const LocalizedString_Locale LN = LocalizedString_Locale._(65, 'LN');
  static const LocalizedString_Locale LO = LocalizedString_Locale._(66, 'LO');
  static const LocalizedString_Locale LT = LocalizedString_Locale._(67, 'LT');
  static const LocalizedString_Locale LV = LocalizedString_Locale._(68, 'LV');
  static const LocalizedString_Locale ML = LocalizedString_Locale._(69, 'ML');
  static const LocalizedString_Locale MO = LocalizedString_Locale._(70, 'MO');
  static const LocalizedString_Locale MR = LocalizedString_Locale._(71, 'MR');
  static const LocalizedString_Locale MS = LocalizedString_Locale._(72, 'MS');
  static const LocalizedString_Locale NB = LocalizedString_Locale._(73, 'NB');
  static const LocalizedString_Locale NE = LocalizedString_Locale._(74, 'NE');
  static const LocalizedString_Locale NL = LocalizedString_Locale._(75, 'NL');
  static const LocalizedString_Locale NO = LocalizedString_Locale._(76, 'NO');
  static const LocalizedString_Locale PL = LocalizedString_Locale._(77, 'PL');
  static const LocalizedString_Locale PT = LocalizedString_Locale._(78, 'PT');
  static const LocalizedString_Locale PT_BR = LocalizedString_Locale._(79, 'PT_BR');
  static const LocalizedString_Locale PT_PT = LocalizedString_Locale._(80, 'PT_PT');
  static const LocalizedString_Locale RM = LocalizedString_Locale._(81, 'RM');
  static const LocalizedString_Locale RO = LocalizedString_Locale._(82, 'RO');
  static const LocalizedString_Locale RU = LocalizedString_Locale._(83, 'RU');
  static const LocalizedString_Locale SK = LocalizedString_Locale._(84, 'SK');
  static const LocalizedString_Locale SL = LocalizedString_Locale._(85, 'SL');
  static const LocalizedString_Locale SR = LocalizedString_Locale._(86, 'SR');
  static const LocalizedString_Locale SR_LATN = LocalizedString_Locale._(87, 'SR_LATN');
  static const LocalizedString_Locale SV = LocalizedString_Locale._(88, 'SV');
  static const LocalizedString_Locale SW = LocalizedString_Locale._(89, 'SW');
  static const LocalizedString_Locale TA = LocalizedString_Locale._(90, 'TA');
  static const LocalizedString_Locale TE = LocalizedString_Locale._(91, 'TE');
  static const LocalizedString_Locale TH = LocalizedString_Locale._(92, 'TH');
  static const LocalizedString_Locale TL = LocalizedString_Locale._(93, 'TL');
  static const LocalizedString_Locale TR = LocalizedString_Locale._(94, 'TR');
  static const LocalizedString_Locale UK = LocalizedString_Locale._(95, 'UK');
  static const LocalizedString_Locale UR = LocalizedString_Locale._(96, 'UR');
  static const LocalizedString_Locale VI = LocalizedString_Locale._(97, 'VI');
  static const LocalizedString_Locale ZH = LocalizedString_Locale._(98, 'ZH');
  static const LocalizedString_Locale ZH_CN = LocalizedString_Locale._(99, 'ZH_CN');
  static const LocalizedString_Locale ZH_HK = LocalizedString_Locale._(100, 'ZH_HK');
  static const LocalizedString_Locale ZH_TW = LocalizedString_Locale._(101, 'ZH_TW');
  static const LocalizedString_Locale ZU = LocalizedString_Locale._(102, 'ZU');

  static const $core.List<LocalizedString_Locale> values = <LocalizedString_Locale> [
    AF,
    AM,
    AR,
    AR_XB,
    BG,
    BN,
    CA,
    CS,
    CY,
    DA,
    DE,
    DE_AT,
    DE_CH,
    EL,
    EN,
    EN_GB,
    EN_IE,
    EN_IN,
    EN_SG,
    EN_XA,
    EN_XC,
    EN_ZA,
    ES,
    ES_419,
    ES_AR,
    ES_BO,
    ES_CL,
    ES_CO,
    ES_CR,
    ES_DO,
    ES_EC,
    ES_GT,
    ES_HN,
    ES_MX,
    ES_NI,
    ES_PA,
    ES_PE,
    ES_PR,
    ES_PY,
    ES_SV,
    ES_US,
    ES_UY,
    ES_VE,
    ET,
    EU,
    FA,
    FI,
    FR,
    FR_CA,
    FR_CH,
    GL,
    GU,
    HE,
    HI,
    HR,
    HU,
    HY,
    ID,
    IN,
    IT,
    JA,
    KA,
    KM,
    KN,
    KO,
    LN,
    LO,
    LT,
    LV,
    ML,
    MO,
    MR,
    MS,
    NB,
    NE,
    NL,
    NO,
    PL,
    PT,
    PT_BR,
    PT_PT,
    RM,
    RO,
    RU,
    SK,
    SL,
    SR,
    SR_LATN,
    SV,
    SW,
    TA,
    TE,
    TH,
    TL,
    TR,
    UK,
    UR,
    VI,
    ZH,
    ZH_CN,
    ZH_HK,
    ZH_TW,
    ZU,
  ];

  static final $core.Map<$core.int, LocalizedString_Locale> _byValue = $pb.ProtobufEnum.initByValue(values);
  static LocalizedString_Locale valueOf($core.int value) => _byValue[value];

  const LocalizedString_Locale._($core.int v, $core.String n) : super(v, n);
}

class PwgRasterConfig_DocumentSheetBack extends $pb.ProtobufEnum {
  static const PwgRasterConfig_DocumentSheetBack NORMAL = PwgRasterConfig_DocumentSheetBack._(0, 'NORMAL');
  static const PwgRasterConfig_DocumentSheetBack ROTATED = PwgRasterConfig_DocumentSheetBack._(1, 'ROTATED');
  static const PwgRasterConfig_DocumentSheetBack MANUAL_TUMBLE = PwgRasterConfig_DocumentSheetBack._(2, 'MANUAL_TUMBLE');
  static const PwgRasterConfig_DocumentSheetBack FLIPPED = PwgRasterConfig_DocumentSheetBack._(3, 'FLIPPED');

  static const $core.List<PwgRasterConfig_DocumentSheetBack> values = <PwgRasterConfig_DocumentSheetBack> [
    NORMAL,
    ROTATED,
    MANUAL_TUMBLE,
    FLIPPED,
  ];

  static final $core.Map<$core.int, PwgRasterConfig_DocumentSheetBack> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PwgRasterConfig_DocumentSheetBack valueOf($core.int value) => _byValue[value];

  const PwgRasterConfig_DocumentSheetBack._($core.int v, $core.String n) : super(v, n);
}

class PwgRasterConfig_PwgDocumentTypeSupported extends $pb.ProtobufEnum {
  static const PwgRasterConfig_PwgDocumentTypeSupported UNSPECIFIED_PWG_DOCUMENT_TYPE = PwgRasterConfig_PwgDocumentTypeSupported._(0, 'UNSPECIFIED_PWG_DOCUMENT_TYPE');
  static const PwgRasterConfig_PwgDocumentTypeSupported BLACK_1 = PwgRasterConfig_PwgDocumentTypeSupported._(1, 'BLACK_1');
  static const PwgRasterConfig_PwgDocumentTypeSupported SGRAY_1 = PwgRasterConfig_PwgDocumentTypeSupported._(2, 'SGRAY_1');
  static const PwgRasterConfig_PwgDocumentTypeSupported ADOBE_RGB_8 = PwgRasterConfig_PwgDocumentTypeSupported._(3, 'ADOBE_RGB_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported BLACK_8 = PwgRasterConfig_PwgDocumentTypeSupported._(4, 'BLACK_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported CMYK_8 = PwgRasterConfig_PwgDocumentTypeSupported._(5, 'CMYK_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE1_8 = PwgRasterConfig_PwgDocumentTypeSupported._(6, 'DEVICE1_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE2_8 = PwgRasterConfig_PwgDocumentTypeSupported._(7, 'DEVICE2_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE3_8 = PwgRasterConfig_PwgDocumentTypeSupported._(8, 'DEVICE3_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE4_8 = PwgRasterConfig_PwgDocumentTypeSupported._(9, 'DEVICE4_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE5_8 = PwgRasterConfig_PwgDocumentTypeSupported._(10, 'DEVICE5_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE6_8 = PwgRasterConfig_PwgDocumentTypeSupported._(11, 'DEVICE6_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE7_8 = PwgRasterConfig_PwgDocumentTypeSupported._(12, 'DEVICE7_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE8_8 = PwgRasterConfig_PwgDocumentTypeSupported._(13, 'DEVICE8_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE9_8 = PwgRasterConfig_PwgDocumentTypeSupported._(14, 'DEVICE9_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE10_8 = PwgRasterConfig_PwgDocumentTypeSupported._(15, 'DEVICE10_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE11_8 = PwgRasterConfig_PwgDocumentTypeSupported._(16, 'DEVICE11_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE12_8 = PwgRasterConfig_PwgDocumentTypeSupported._(17, 'DEVICE12_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE13_8 = PwgRasterConfig_PwgDocumentTypeSupported._(18, 'DEVICE13_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE14_8 = PwgRasterConfig_PwgDocumentTypeSupported._(19, 'DEVICE14_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE15_8 = PwgRasterConfig_PwgDocumentTypeSupported._(20, 'DEVICE15_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported RGB_8 = PwgRasterConfig_PwgDocumentTypeSupported._(21, 'RGB_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported SGRAY_8 = PwgRasterConfig_PwgDocumentTypeSupported._(22, 'SGRAY_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported SRGB_8 = PwgRasterConfig_PwgDocumentTypeSupported._(23, 'SRGB_8');
  static const PwgRasterConfig_PwgDocumentTypeSupported ADOBE_RGB_16 = PwgRasterConfig_PwgDocumentTypeSupported._(24, 'ADOBE_RGB_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported BLACK_16 = PwgRasterConfig_PwgDocumentTypeSupported._(25, 'BLACK_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported CMYK_16 = PwgRasterConfig_PwgDocumentTypeSupported._(26, 'CMYK_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE1_16 = PwgRasterConfig_PwgDocumentTypeSupported._(27, 'DEVICE1_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE2_16 = PwgRasterConfig_PwgDocumentTypeSupported._(28, 'DEVICE2_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE3_16 = PwgRasterConfig_PwgDocumentTypeSupported._(29, 'DEVICE3_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE4_16 = PwgRasterConfig_PwgDocumentTypeSupported._(30, 'DEVICE4_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE5_16 = PwgRasterConfig_PwgDocumentTypeSupported._(31, 'DEVICE5_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE6_16 = PwgRasterConfig_PwgDocumentTypeSupported._(32, 'DEVICE6_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE7_16 = PwgRasterConfig_PwgDocumentTypeSupported._(33, 'DEVICE7_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE8_16 = PwgRasterConfig_PwgDocumentTypeSupported._(34, 'DEVICE8_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE9_16 = PwgRasterConfig_PwgDocumentTypeSupported._(35, 'DEVICE9_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE10_16 = PwgRasterConfig_PwgDocumentTypeSupported._(36, 'DEVICE10_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE11_16 = PwgRasterConfig_PwgDocumentTypeSupported._(37, 'DEVICE11_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE12_16 = PwgRasterConfig_PwgDocumentTypeSupported._(38, 'DEVICE12_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE13_16 = PwgRasterConfig_PwgDocumentTypeSupported._(39, 'DEVICE13_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE14_16 = PwgRasterConfig_PwgDocumentTypeSupported._(40, 'DEVICE14_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported DEVICE15_16 = PwgRasterConfig_PwgDocumentTypeSupported._(41, 'DEVICE15_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported RGB_16 = PwgRasterConfig_PwgDocumentTypeSupported._(42, 'RGB_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported SGRAY_16 = PwgRasterConfig_PwgDocumentTypeSupported._(43, 'SGRAY_16');
  static const PwgRasterConfig_PwgDocumentTypeSupported SRGB_16 = PwgRasterConfig_PwgDocumentTypeSupported._(44, 'SRGB_16');

  static const $core.List<PwgRasterConfig_PwgDocumentTypeSupported> values = <PwgRasterConfig_PwgDocumentTypeSupported> [
    UNSPECIFIED_PWG_DOCUMENT_TYPE,
    BLACK_1,
    SGRAY_1,
    ADOBE_RGB_8,
    BLACK_8,
    CMYK_8,
    DEVICE1_8,
    DEVICE2_8,
    DEVICE3_8,
    DEVICE4_8,
    DEVICE5_8,
    DEVICE6_8,
    DEVICE7_8,
    DEVICE8_8,
    DEVICE9_8,
    DEVICE10_8,
    DEVICE11_8,
    DEVICE12_8,
    DEVICE13_8,
    DEVICE14_8,
    DEVICE15_8,
    RGB_8,
    SGRAY_8,
    SRGB_8,
    ADOBE_RGB_16,
    BLACK_16,
    CMYK_16,
    DEVICE1_16,
    DEVICE2_16,
    DEVICE3_16,
    DEVICE4_16,
    DEVICE5_16,
    DEVICE6_16,
    DEVICE7_16,
    DEVICE8_16,
    DEVICE9_16,
    DEVICE10_16,
    DEVICE11_16,
    DEVICE12_16,
    DEVICE13_16,
    DEVICE14_16,
    DEVICE15_16,
    RGB_16,
    SGRAY_16,
    SRGB_16,
  ];

  static final $core.Map<$core.int, PwgRasterConfig_PwgDocumentTypeSupported> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PwgRasterConfig_PwgDocumentTypeSupported valueOf($core.int value) => _byValue[value];

  const PwgRasterConfig_PwgDocumentTypeSupported._($core.int v, $core.String n) : super(v, n);
}

class PwgRasterConfig_Transformation_Operation extends $pb.ProtobufEnum {
  static const PwgRasterConfig_Transformation_Operation ROTATE_180 = PwgRasterConfig_Transformation_Operation._(0, 'ROTATE_180');
  static const PwgRasterConfig_Transformation_Operation FLIP_ON_LONG_EDGE = PwgRasterConfig_Transformation_Operation._(1, 'FLIP_ON_LONG_EDGE');
  static const PwgRasterConfig_Transformation_Operation FLIP_ON_SHORT_EDGE = PwgRasterConfig_Transformation_Operation._(2, 'FLIP_ON_SHORT_EDGE');

  static const $core.List<PwgRasterConfig_Transformation_Operation> values = <PwgRasterConfig_Transformation_Operation> [
    ROTATE_180,
    FLIP_ON_LONG_EDGE,
    FLIP_ON_SHORT_EDGE,
  ];

  static final $core.Map<$core.int, PwgRasterConfig_Transformation_Operation> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PwgRasterConfig_Transformation_Operation valueOf($core.int value) => _byValue[value];

  const PwgRasterConfig_Transformation_Operation._($core.int v, $core.String n) : super(v, n);
}

class PwgRasterConfig_Transformation_Operand extends $pb.ProtobufEnum {
  static const PwgRasterConfig_Transformation_Operand ALL_PAGES = PwgRasterConfig_Transformation_Operand._(0, 'ALL_PAGES');
  static const PwgRasterConfig_Transformation_Operand ONLY_DUPLEXED_EVEN_PAGES = PwgRasterConfig_Transformation_Operand._(1, 'ONLY_DUPLEXED_EVEN_PAGES');
  static const PwgRasterConfig_Transformation_Operand ONLY_DUPLEXED_ODD_PAGES = PwgRasterConfig_Transformation_Operand._(2, 'ONLY_DUPLEXED_ODD_PAGES');
  static const PwgRasterConfig_Transformation_Operand EVEN_PAGES = PwgRasterConfig_Transformation_Operand._(3, 'EVEN_PAGES');
  static const PwgRasterConfig_Transformation_Operand ODD_PAGES = PwgRasterConfig_Transformation_Operand._(4, 'ODD_PAGES');

  static const $core.List<PwgRasterConfig_Transformation_Operand> values = <PwgRasterConfig_Transformation_Operand> [
    ALL_PAGES,
    ONLY_DUPLEXED_EVEN_PAGES,
    ONLY_DUPLEXED_ODD_PAGES,
    EVEN_PAGES,
    ODD_PAGES,
  ];

  static final $core.Map<$core.int, PwgRasterConfig_Transformation_Operand> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PwgRasterConfig_Transformation_Operand valueOf($core.int value) => _byValue[value];

  const PwgRasterConfig_Transformation_Operand._($core.int v, $core.String n) : super(v, n);
}

class InputTrayUnit_Type extends $pb.ProtobufEnum {
  static const InputTrayUnit_Type CUSTOM = InputTrayUnit_Type._(0, 'CUSTOM');
  static const InputTrayUnit_Type INPUT_TRAY = InputTrayUnit_Type._(1, 'INPUT_TRAY');
  static const InputTrayUnit_Type BYPASS_TRAY = InputTrayUnit_Type._(2, 'BYPASS_TRAY');
  static const InputTrayUnit_Type MANUAL_FEED_TRAY = InputTrayUnit_Type._(3, 'MANUAL_FEED_TRAY');
  static const InputTrayUnit_Type LCT = InputTrayUnit_Type._(4, 'LCT');
  static const InputTrayUnit_Type ENVELOPE_TRAY = InputTrayUnit_Type._(5, 'ENVELOPE_TRAY');
  static const InputTrayUnit_Type ROLL = InputTrayUnit_Type._(6, 'ROLL');

  static const $core.List<InputTrayUnit_Type> values = <InputTrayUnit_Type> [
    CUSTOM,
    INPUT_TRAY,
    BYPASS_TRAY,
    MANUAL_FEED_TRAY,
    LCT,
    ENVELOPE_TRAY,
    ROLL,
  ];

  static final $core.Map<$core.int, InputTrayUnit_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static InputTrayUnit_Type valueOf($core.int value) => _byValue[value];

  const InputTrayUnit_Type._($core.int v, $core.String n) : super(v, n);
}

class OutputBinUnit_Type extends $pb.ProtobufEnum {
  static const OutputBinUnit_Type CUSTOM = OutputBinUnit_Type._(0, 'CUSTOM');
  static const OutputBinUnit_Type OUTPUT_BIN = OutputBinUnit_Type._(1, 'OUTPUT_BIN');
  static const OutputBinUnit_Type MAILBOX = OutputBinUnit_Type._(2, 'MAILBOX');
  static const OutputBinUnit_Type STACKER = OutputBinUnit_Type._(3, 'STACKER');

  static const $core.List<OutputBinUnit_Type> values = <OutputBinUnit_Type> [
    CUSTOM,
    OUTPUT_BIN,
    MAILBOX,
    STACKER,
  ];

  static final $core.Map<$core.int, OutputBinUnit_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static OutputBinUnit_Type valueOf($core.int value) => _byValue[value];

  const OutputBinUnit_Type._($core.int v, $core.String n) : super(v, n);
}

