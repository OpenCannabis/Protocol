///
//  Generated code. Do not modify.
//  source: google/cloudprint/CloudDeviceState.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class CloudDeviceState_StateType extends $pb.ProtobufEnum {
  static const CloudDeviceState_StateType IDLE = CloudDeviceState_StateType._(0, 'IDLE');
  static const CloudDeviceState_StateType PROCESSING = CloudDeviceState_StateType._(1, 'PROCESSING');
  static const CloudDeviceState_StateType STOPPED = CloudDeviceState_StateType._(2, 'STOPPED');

  static const $core.List<CloudDeviceState_StateType> values = <CloudDeviceState_StateType> [
    IDLE,
    PROCESSING,
    STOPPED,
  ];

  static final $core.Map<$core.int, CloudDeviceState_StateType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CloudDeviceState_StateType valueOf($core.int value) => _byValue[value];

  const CloudDeviceState_StateType._($core.int v, $core.String n) : super(v, n);
}

class CloudDeviceState_CloudConnectionStateType extends $pb.ProtobufEnum {
  static const CloudDeviceState_CloudConnectionStateType UNKNOWN = CloudDeviceState_CloudConnectionStateType._(0, 'UNKNOWN');
  static const CloudDeviceState_CloudConnectionStateType NOT_CONFIGURED = CloudDeviceState_CloudConnectionStateType._(1, 'NOT_CONFIGURED');
  static const CloudDeviceState_CloudConnectionStateType ONLINE = CloudDeviceState_CloudConnectionStateType._(2, 'ONLINE');
  static const CloudDeviceState_CloudConnectionStateType OFFLINE = CloudDeviceState_CloudConnectionStateType._(3, 'OFFLINE');

  static const $core.List<CloudDeviceState_CloudConnectionStateType> values = <CloudDeviceState_CloudConnectionStateType> [
    UNKNOWN,
    NOT_CONFIGURED,
    ONLINE,
    OFFLINE,
  ];

  static final $core.Map<$core.int, CloudDeviceState_CloudConnectionStateType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CloudDeviceState_CloudConnectionStateType valueOf($core.int value) => _byValue[value];

  const CloudDeviceState_CloudConnectionStateType._($core.int v, $core.String n) : super(v, n);
}

class CloudDeviceUiState_Summary extends $pb.ProtobufEnum {
  static const CloudDeviceUiState_Summary IDLE = CloudDeviceUiState_Summary._(0, 'IDLE');
  static const CloudDeviceUiState_Summary PROCESSING = CloudDeviceUiState_Summary._(1, 'PROCESSING');
  static const CloudDeviceUiState_Summary STOPPED = CloudDeviceUiState_Summary._(2, 'STOPPED');
  static const CloudDeviceUiState_Summary OFFLINE = CloudDeviceUiState_Summary._(3, 'OFFLINE');

  static const $core.List<CloudDeviceUiState_Summary> values = <CloudDeviceUiState_Summary> [
    IDLE,
    PROCESSING,
    STOPPED,
    OFFLINE,
  ];

  static final $core.Map<$core.int, CloudDeviceUiState_Summary> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CloudDeviceUiState_Summary valueOf($core.int value) => _byValue[value];

  const CloudDeviceUiState_Summary._($core.int v, $core.String n) : super(v, n);
}

class CloudDeviceUiState_Severity extends $pb.ProtobufEnum {
  static const CloudDeviceUiState_Severity NONE = CloudDeviceUiState_Severity._(0, 'NONE');
  static const CloudDeviceUiState_Severity LOW = CloudDeviceUiState_Severity._(1, 'LOW');
  static const CloudDeviceUiState_Severity MEDIUM = CloudDeviceUiState_Severity._(2, 'MEDIUM');
  static const CloudDeviceUiState_Severity HIGH = CloudDeviceUiState_Severity._(3, 'HIGH');

  static const $core.List<CloudDeviceUiState_Severity> values = <CloudDeviceUiState_Severity> [
    NONE,
    LOW,
    MEDIUM,
    HIGH,
  ];

  static final $core.Map<$core.int, CloudDeviceUiState_Severity> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CloudDeviceUiState_Severity valueOf($core.int value) => _byValue[value];

  const CloudDeviceUiState_Severity._($core.int v, $core.String n) : super(v, n);
}

class InputTrayState_Item_StateType extends $pb.ProtobufEnum {
  static const InputTrayState_Item_StateType OK = InputTrayState_Item_StateType._(0, 'OK');
  static const InputTrayState_Item_StateType EMPTY = InputTrayState_Item_StateType._(1, 'EMPTY');
  static const InputTrayState_Item_StateType OPEN = InputTrayState_Item_StateType._(2, 'OPEN');
  static const InputTrayState_Item_StateType OFF = InputTrayState_Item_StateType._(3, 'OFF');
  static const InputTrayState_Item_StateType FAILURE = InputTrayState_Item_StateType._(4, 'FAILURE');

  static const $core.List<InputTrayState_Item_StateType> values = <InputTrayState_Item_StateType> [
    OK,
    EMPTY,
    OPEN,
    OFF,
    FAILURE,
  ];

  static final $core.Map<$core.int, InputTrayState_Item_StateType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static InputTrayState_Item_StateType valueOf($core.int value) => _byValue[value];

  const InputTrayState_Item_StateType._($core.int v, $core.String n) : super(v, n);
}

class OutputBinState_Item_StateType extends $pb.ProtobufEnum {
  static const OutputBinState_Item_StateType OK = OutputBinState_Item_StateType._(0, 'OK');
  static const OutputBinState_Item_StateType FULL = OutputBinState_Item_StateType._(1, 'FULL');
  static const OutputBinState_Item_StateType OPEN = OutputBinState_Item_StateType._(2, 'OPEN');
  static const OutputBinState_Item_StateType OFF = OutputBinState_Item_StateType._(3, 'OFF');
  static const OutputBinState_Item_StateType FAILURE = OutputBinState_Item_StateType._(4, 'FAILURE');

  static const $core.List<OutputBinState_Item_StateType> values = <OutputBinState_Item_StateType> [
    OK,
    FULL,
    OPEN,
    OFF,
    FAILURE,
  ];

  static final $core.Map<$core.int, OutputBinState_Item_StateType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static OutputBinState_Item_StateType valueOf($core.int value) => _byValue[value];

  const OutputBinState_Item_StateType._($core.int v, $core.String n) : super(v, n);
}

class MarkerState_Item_StateType extends $pb.ProtobufEnum {
  static const MarkerState_Item_StateType OK = MarkerState_Item_StateType._(0, 'OK');
  static const MarkerState_Item_StateType EXHAUSTED = MarkerState_Item_StateType._(1, 'EXHAUSTED');
  static const MarkerState_Item_StateType REMOVED = MarkerState_Item_StateType._(2, 'REMOVED');
  static const MarkerState_Item_StateType FAILURE = MarkerState_Item_StateType._(3, 'FAILURE');

  static const $core.List<MarkerState_Item_StateType> values = <MarkerState_Item_StateType> [
    OK,
    EXHAUSTED,
    REMOVED,
    FAILURE,
  ];

  static final $core.Map<$core.int, MarkerState_Item_StateType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MarkerState_Item_StateType valueOf($core.int value) => _byValue[value];

  const MarkerState_Item_StateType._($core.int v, $core.String n) : super(v, n);
}

class CoverState_Item_StateType extends $pb.ProtobufEnum {
  static const CoverState_Item_StateType OK = CoverState_Item_StateType._(0, 'OK');
  static const CoverState_Item_StateType OPEN = CoverState_Item_StateType._(1, 'OPEN');
  static const CoverState_Item_StateType FAILURE = CoverState_Item_StateType._(2, 'FAILURE');

  static const $core.List<CoverState_Item_StateType> values = <CoverState_Item_StateType> [
    OK,
    OPEN,
    FAILURE,
  ];

  static final $core.Map<$core.int, CoverState_Item_StateType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CoverState_Item_StateType valueOf($core.int value) => _byValue[value];

  const CoverState_Item_StateType._($core.int v, $core.String n) : super(v, n);
}

class MediaPathState_Item_StateType extends $pb.ProtobufEnum {
  static const MediaPathState_Item_StateType OK = MediaPathState_Item_StateType._(0, 'OK');
  static const MediaPathState_Item_StateType MEDIA_JAM = MediaPathState_Item_StateType._(1, 'MEDIA_JAM');
  static const MediaPathState_Item_StateType FAILURE = MediaPathState_Item_StateType._(2, 'FAILURE');

  static const $core.List<MediaPathState_Item_StateType> values = <MediaPathState_Item_StateType> [
    OK,
    MEDIA_JAM,
    FAILURE,
  ];

  static final $core.Map<$core.int, MediaPathState_Item_StateType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MediaPathState_Item_StateType valueOf($core.int value) => _byValue[value];

  const MediaPathState_Item_StateType._($core.int v, $core.String n) : super(v, n);
}

class VendorState_Item_StateType extends $pb.ProtobufEnum {
  static const VendorState_Item_StateType ERROR = VendorState_Item_StateType._(0, 'ERROR');
  static const VendorState_Item_StateType WARNING = VendorState_Item_StateType._(1, 'WARNING');
  static const VendorState_Item_StateType INFO = VendorState_Item_StateType._(2, 'INFO');

  static const $core.List<VendorState_Item_StateType> values = <VendorState_Item_StateType> [
    ERROR,
    WARNING,
    INFO,
  ];

  static final $core.Map<$core.int, VendorState_Item_StateType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static VendorState_Item_StateType valueOf($core.int value) => _byValue[value];

  const VendorState_Item_StateType._($core.int v, $core.String n) : super(v, n);
}

