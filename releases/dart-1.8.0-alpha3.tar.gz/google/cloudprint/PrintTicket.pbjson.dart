///
//  Generated code. Do not modify.
//  source: google/cloudprint/PrintTicket.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const PrintTicketSection$json = const {
  '1': 'PrintTicketSection',
  '2': const [
    const {'1': 'vendor_ticket_item', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.PrintTicketSection.VendorTicketItem', '10': 'vendorTicketItem'},
    const {'1': 'color', '3': 2, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.ColorTicketItem', '10': 'color'},
    const {'1': 'duplex', '3': 3, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.DuplexTicketItem', '10': 'duplex'},
    const {'1': 'page_orientation', '3': 4, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.PageOrientationTicketItem', '10': 'pageOrientation'},
    const {'1': 'copies', '3': 5, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.CopiesTicketItem', '10': 'copies'},
    const {'1': 'margins', '3': 6, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.MarginsTicketItem', '10': 'margins'},
    const {'1': 'dpi', '3': 7, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.DpiTicketItem', '10': 'dpi'},
    const {'1': 'fit_to_page', '3': 8, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.FitToPageTicketItem', '10': 'fitToPage'},
    const {'1': 'page_range', '3': 9, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.PageRangeTicketItem', '10': 'pageRange'},
    const {'1': 'media_size', '3': 10, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.MediaSizeTicketItem', '10': 'mediaSize'},
    const {'1': 'collate', '3': 11, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.CollateTicketItem', '10': 'collate'},
    const {'1': 'reverse_order', '3': 12, '4': 1, '5': 11, '6': '.google.cloudprint.PrintTicketSection.ReverseOrderTicketItem', '10': 'reverseOrder'},
  ],
  '3': const [PrintTicketSection_VendorTicketItem$json, PrintTicketSection_ColorTicketItem$json, PrintTicketSection_DuplexTicketItem$json, PrintTicketSection_PageOrientationTicketItem$json, PrintTicketSection_CopiesTicketItem$json, PrintTicketSection_MarginsTicketItem$json, PrintTicketSection_DpiTicketItem$json, PrintTicketSection_FitToPageTicketItem$json, PrintTicketSection_PageRangeTicketItem$json, PrintTicketSection_MediaSizeTicketItem$json, PrintTicketSection_CollateTicketItem$json, PrintTicketSection_ReverseOrderTicketItem$json],
};

const PrintTicketSection_VendorTicketItem$json = const {
  '1': 'VendorTicketItem',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'value', '3': 2, '4': 1, '5': 9, '10': 'value'},
  ],
};

const PrintTicketSection_ColorTicketItem$json = const {
  '1': 'ColorTicketItem',
  '2': const [
    const {'1': 'vendor_id', '3': 1, '4': 1, '5': 9, '10': 'vendorId'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.google.cloudprint.Color.Type', '10': 'type'},
  ],
};

const PrintTicketSection_DuplexTicketItem$json = const {
  '1': 'DuplexTicketItem',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.Duplex.Type', '10': 'type'},
  ],
};

const PrintTicketSection_PageOrientationTicketItem$json = const {
  '1': 'PageOrientationTicketItem',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.PageOrientation.Type', '10': 'type'},
  ],
};

const PrintTicketSection_CopiesTicketItem$json = const {
  '1': 'CopiesTicketItem',
  '2': const [
    const {'1': 'copies', '3': 1, '4': 1, '5': 5, '10': 'copies'},
  ],
};

const PrintTicketSection_MarginsTicketItem$json = const {
  '1': 'MarginsTicketItem',
  '2': const [
    const {'1': 'top_microns', '3': 1, '4': 1, '5': 5, '10': 'topMicrons'},
    const {'1': 'right_microns', '3': 2, '4': 1, '5': 5, '10': 'rightMicrons'},
    const {'1': 'bottom_microns', '3': 3, '4': 1, '5': 5, '10': 'bottomMicrons'},
    const {'1': 'left_microns', '3': 4, '4': 1, '5': 5, '10': 'leftMicrons'},
  ],
};

const PrintTicketSection_DpiTicketItem$json = const {
  '1': 'DpiTicketItem',
  '2': const [
    const {'1': 'horizontal_dpi', '3': 1, '4': 1, '5': 5, '10': 'horizontalDpi'},
    const {'1': 'vertical_dpi', '3': 2, '4': 1, '5': 5, '10': 'verticalDpi'},
    const {'1': 'vendor_id', '3': 3, '4': 1, '5': 9, '10': 'vendorId'},
  ],
};

const PrintTicketSection_FitToPageTicketItem$json = const {
  '1': 'FitToPageTicketItem',
  '2': const [
    const {'1': 'type', '3': 1, '4': 1, '5': 14, '6': '.google.cloudprint.FitToPage.Type', '10': 'type'},
  ],
};

const PrintTicketSection_PageRangeTicketItem$json = const {
  '1': 'PageRangeTicketItem',
  '2': const [
    const {'1': 'interval', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.PageRange.Interval', '10': 'interval'},
  ],
};

const PrintTicketSection_MediaSizeTicketItem$json = const {
  '1': 'MediaSizeTicketItem',
  '2': const [
    const {'1': 'width_microns', '3': 1, '4': 1, '5': 5, '10': 'widthMicrons'},
    const {'1': 'height_microns', '3': 2, '4': 1, '5': 5, '10': 'heightMicrons'},
    const {'1': 'is_continuous_feed', '3': 3, '4': 1, '5': 8, '10': 'isContinuousFeed'},
    const {'1': 'vendor_id', '3': 4, '4': 1, '5': 9, '10': 'vendorId'},
  ],
};

const PrintTicketSection_CollateTicketItem$json = const {
  '1': 'CollateTicketItem',
  '2': const [
    const {'1': 'collate', '3': 1, '4': 1, '5': 8, '10': 'collate'},
  ],
};

const PrintTicketSection_ReverseOrderTicketItem$json = const {
  '1': 'ReverseOrderTicketItem',
  '2': const [
    const {'1': 'reverse_order', '3': 1, '4': 1, '5': 8, '10': 'reverseOrder'},
  ],
};

