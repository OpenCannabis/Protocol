///
//  Generated code. Do not modify.
//  source: google/cloudprint/PrinterDescription.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const PrinterDescriptionSection$json = const {
  '1': 'PrinterDescriptionSection',
  '2': const [
    const {'1': 'supported_content_type', '3': 1, '4': 3, '5': 11, '6': '.google.cloudprint.SupportedContentType', '10': 'supportedContentType'},
    const {'1': 'printing_speed', '3': 2, '4': 1, '5': 11, '6': '.google.cloudprint.PrintingSpeed', '10': 'printingSpeed'},
    const {'1': 'pwg_raster_config', '3': 3, '4': 1, '5': 11, '6': '.google.cloudprint.PwgRasterConfig', '10': 'pwgRasterConfig'},
    const {'1': 'input_tray_unit', '3': 4, '4': 3, '5': 11, '6': '.google.cloudprint.InputTrayUnit', '10': 'inputTrayUnit'},
    const {'1': 'output_bin_unit', '3': 5, '4': 3, '5': 11, '6': '.google.cloudprint.OutputBinUnit', '10': 'outputBinUnit'},
    const {'1': 'marker', '3': 6, '4': 3, '5': 11, '6': '.google.cloudprint.Marker', '10': 'marker'},
    const {'1': 'cover', '3': 7, '4': 3, '5': 11, '6': '.google.cloudprint.Cover', '10': 'cover'},
    const {'1': 'media_path', '3': 8, '4': 3, '5': 11, '6': '.google.cloudprint.MediaPath', '10': 'mediaPath'},
    const {'1': 'vendor_capability', '3': 101, '4': 3, '5': 11, '6': '.google.cloudprint.VendorCapability', '10': 'vendorCapability'},
    const {'1': 'color', '3': 102, '4': 1, '5': 11, '6': '.google.cloudprint.Color', '10': 'color'},
    const {'1': 'duplex', '3': 103, '4': 1, '5': 11, '6': '.google.cloudprint.Duplex', '10': 'duplex'},
    const {'1': 'page_orientation', '3': 104, '4': 1, '5': 11, '6': '.google.cloudprint.PageOrientation', '10': 'pageOrientation'},
    const {'1': 'copies', '3': 105, '4': 1, '5': 11, '6': '.google.cloudprint.Copies', '10': 'copies'},
    const {'1': 'margins', '3': 106, '4': 1, '5': 11, '6': '.google.cloudprint.Margins', '10': 'margins'},
    const {'1': 'dpi', '3': 107, '4': 1, '5': 11, '6': '.google.cloudprint.Dpi', '10': 'dpi'},
    const {'1': 'fit_to_page', '3': 108, '4': 1, '5': 11, '6': '.google.cloudprint.FitToPage', '10': 'fitToPage'},
    const {'1': 'page_range', '3': 109, '4': 1, '5': 11, '6': '.google.cloudprint.PageRange', '10': 'pageRange'},
    const {'1': 'media_size', '3': 110, '4': 1, '5': 11, '6': '.google.cloudprint.MediaSize', '10': 'mediaSize'},
    const {'1': 'collate', '3': 111, '4': 1, '5': 11, '6': '.google.cloudprint.Collate', '10': 'collate'},
    const {'1': 'reverse_order', '3': 112, '4': 1, '5': 11, '6': '.google.cloudprint.ReverseOrder', '10': 'reverseOrder'},
  ],
};

