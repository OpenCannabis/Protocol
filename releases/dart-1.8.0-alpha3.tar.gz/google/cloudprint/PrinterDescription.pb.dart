///
//  Generated code. Do not modify.
//  source: google/cloudprint/PrinterDescription.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Common.pb.dart' as $30;

class PrinterDescriptionSection extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrinterDescriptionSection', package: const $pb.PackageName('google.cloudprint'))
    ..pc<$30.SupportedContentType>(1, 'supportedContentType', $pb.PbFieldType.PM,$30.SupportedContentType.create)
    ..a<$30.PrintingSpeed>(2, 'printingSpeed', $pb.PbFieldType.OM, $30.PrintingSpeed.getDefault, $30.PrintingSpeed.create)
    ..a<$30.PwgRasterConfig>(3, 'pwgRasterConfig', $pb.PbFieldType.OM, $30.PwgRasterConfig.getDefault, $30.PwgRasterConfig.create)
    ..pc<$30.InputTrayUnit>(4, 'inputTrayUnit', $pb.PbFieldType.PM,$30.InputTrayUnit.create)
    ..pc<$30.OutputBinUnit>(5, 'outputBinUnit', $pb.PbFieldType.PM,$30.OutputBinUnit.create)
    ..pc<$30.Marker>(6, 'marker', $pb.PbFieldType.PM,$30.Marker.create)
    ..pc<$30.Cover>(7, 'cover', $pb.PbFieldType.PM,$30.Cover.create)
    ..pc<$30.MediaPath>(8, 'mediaPath', $pb.PbFieldType.PM,$30.MediaPath.create)
    ..pc<$30.VendorCapability>(101, 'vendorCapability', $pb.PbFieldType.PM,$30.VendorCapability.create)
    ..a<$30.Color>(102, 'color', $pb.PbFieldType.OM, $30.Color.getDefault, $30.Color.create)
    ..a<$30.Duplex>(103, 'duplex', $pb.PbFieldType.OM, $30.Duplex.getDefault, $30.Duplex.create)
    ..a<$30.PageOrientation>(104, 'pageOrientation', $pb.PbFieldType.OM, $30.PageOrientation.getDefault, $30.PageOrientation.create)
    ..a<$30.Copies>(105, 'copies', $pb.PbFieldType.OM, $30.Copies.getDefault, $30.Copies.create)
    ..a<$30.Margins>(106, 'margins', $pb.PbFieldType.OM, $30.Margins.getDefault, $30.Margins.create)
    ..a<$30.Dpi>(107, 'dpi', $pb.PbFieldType.OM, $30.Dpi.getDefault, $30.Dpi.create)
    ..a<$30.FitToPage>(108, 'fitToPage', $pb.PbFieldType.OM, $30.FitToPage.getDefault, $30.FitToPage.create)
    ..a<$30.PageRange>(109, 'pageRange', $pb.PbFieldType.OM, $30.PageRange.getDefault, $30.PageRange.create)
    ..a<$30.MediaSize>(110, 'mediaSize', $pb.PbFieldType.OM, $30.MediaSize.getDefault, $30.MediaSize.create)
    ..a<$30.Collate>(111, 'collate', $pb.PbFieldType.OM, $30.Collate.getDefault, $30.Collate.create)
    ..a<$30.ReverseOrder>(112, 'reverseOrder', $pb.PbFieldType.OM, $30.ReverseOrder.getDefault, $30.ReverseOrder.create)
    ..hasRequiredFields = false
  ;

  PrinterDescriptionSection() : super();
  PrinterDescriptionSection.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrinterDescriptionSection.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrinterDescriptionSection clone() => PrinterDescriptionSection()..mergeFromMessage(this);
  PrinterDescriptionSection copyWith(void Function(PrinterDescriptionSection) updates) => super.copyWith((message) => updates(message as PrinterDescriptionSection));
  $pb.BuilderInfo get info_ => _i;
  static PrinterDescriptionSection create() => PrinterDescriptionSection();
  PrinterDescriptionSection createEmptyInstance() => create();
  static $pb.PbList<PrinterDescriptionSection> createRepeated() => $pb.PbList<PrinterDescriptionSection>();
  static PrinterDescriptionSection getDefault() => _defaultInstance ??= create()..freeze();
  static PrinterDescriptionSection _defaultInstance;

  $core.List<$30.SupportedContentType> get supportedContentType => $_getList(0);

  $30.PrintingSpeed get printingSpeed => $_getN(1);
  set printingSpeed($30.PrintingSpeed v) { setField(2, v); }
  $core.bool hasPrintingSpeed() => $_has(1);
  void clearPrintingSpeed() => clearField(2);

  $30.PwgRasterConfig get pwgRasterConfig => $_getN(2);
  set pwgRasterConfig($30.PwgRasterConfig v) { setField(3, v); }
  $core.bool hasPwgRasterConfig() => $_has(2);
  void clearPwgRasterConfig() => clearField(3);

  $core.List<$30.InputTrayUnit> get inputTrayUnit => $_getList(3);

  $core.List<$30.OutputBinUnit> get outputBinUnit => $_getList(4);

  $core.List<$30.Marker> get marker => $_getList(5);

  $core.List<$30.Cover> get cover => $_getList(6);

  $core.List<$30.MediaPath> get mediaPath => $_getList(7);

  $core.List<$30.VendorCapability> get vendorCapability => $_getList(8);

  $30.Color get color => $_getN(9);
  set color($30.Color v) { setField(102, v); }
  $core.bool hasColor() => $_has(9);
  void clearColor() => clearField(102);

  $30.Duplex get duplex => $_getN(10);
  set duplex($30.Duplex v) { setField(103, v); }
  $core.bool hasDuplex() => $_has(10);
  void clearDuplex() => clearField(103);

  $30.PageOrientation get pageOrientation => $_getN(11);
  set pageOrientation($30.PageOrientation v) { setField(104, v); }
  $core.bool hasPageOrientation() => $_has(11);
  void clearPageOrientation() => clearField(104);

  $30.Copies get copies => $_getN(12);
  set copies($30.Copies v) { setField(105, v); }
  $core.bool hasCopies() => $_has(12);
  void clearCopies() => clearField(105);

  $30.Margins get margins => $_getN(13);
  set margins($30.Margins v) { setField(106, v); }
  $core.bool hasMargins() => $_has(13);
  void clearMargins() => clearField(106);

  $30.Dpi get dpi => $_getN(14);
  set dpi($30.Dpi v) { setField(107, v); }
  $core.bool hasDpi() => $_has(14);
  void clearDpi() => clearField(107);

  $30.FitToPage get fitToPage => $_getN(15);
  set fitToPage($30.FitToPage v) { setField(108, v); }
  $core.bool hasFitToPage() => $_has(15);
  void clearFitToPage() => clearField(108);

  $30.PageRange get pageRange => $_getN(16);
  set pageRange($30.PageRange v) { setField(109, v); }
  $core.bool hasPageRange() => $_has(16);
  void clearPageRange() => clearField(109);

  $30.MediaSize get mediaSize => $_getN(17);
  set mediaSize($30.MediaSize v) { setField(110, v); }
  $core.bool hasMediaSize() => $_has(17);
  void clearMediaSize() => clearField(110);

  $30.Collate get collate => $_getN(18);
  set collate($30.Collate v) { setField(111, v); }
  $core.bool hasCollate() => $_has(18);
  void clearCollate() => clearField(111);

  $30.ReverseOrder get reverseOrder => $_getN(19);
  set reverseOrder($30.ReverseOrder v) { setField(112, v); }
  $core.bool hasReverseOrder() => $_has(19);
  void clearReverseOrder() => clearField(112);
}

