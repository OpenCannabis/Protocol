///
//  Generated code. Do not modify.
//  source: google/cloudprint/GoogleCloudPrint.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:async' as $async;

import 'package:protobuf/protobuf.dart' as $pb;

import 'dart:core' as $core show String, Map, ArgumentError, dynamic;
import 'GoogleCloudPrint.pb.dart';
import 'GoogleCloudPrint.pbjson.dart';

export 'GoogleCloudPrint.pb.dart';

abstract class CloudPrintServiceBase extends $pb.GeneratedService {
  $async.Future<SubmitJobResponse> submitJob($pb.ServerContext ctx, SubmitJobRequest request);
  $async.Future<DeleteJobResponse> deleteJob($pb.ServerContext ctx, DeleteJobRequest request);
  $async.Future<ListJobsResponse> listJobs($pb.ServerContext ctx, ListJobsRequest request);
  $async.Future<GetPrinterResponse> getPrinter($pb.ServerContext ctx, GetPrinterRequest request);
  $async.Future<SearchPrintersResponse> searchPrinters($pb.ServerContext ctx, SearchPrintersRequest request);

  $pb.GeneratedMessage createRequest($core.String method) {
    switch (method) {
      case 'SubmitJob': return SubmitJobRequest();
      case 'DeleteJob': return DeleteJobRequest();
      case 'ListJobs': return ListJobsRequest();
      case 'GetPrinter': return GetPrinterRequest();
      case 'SearchPrinters': return SearchPrintersRequest();
      default: throw $core.ArgumentError('Unknown method: $method');
    }
  }

  $async.Future<$pb.GeneratedMessage> handleCall($pb.ServerContext ctx, $core.String method, $pb.GeneratedMessage request) {
    switch (method) {
      case 'SubmitJob': return this.submitJob(ctx, request);
      case 'DeleteJob': return this.deleteJob(ctx, request);
      case 'ListJobs': return this.listJobs(ctx, request);
      case 'GetPrinter': return this.getPrinter(ctx, request);
      case 'SearchPrinters': return this.searchPrinters(ctx, request);
      default: throw $core.ArgumentError('Unknown method: $method');
    }
  }

  $core.Map<$core.String, $core.dynamic> get $json => CloudPrintServiceBase$json;
  $core.Map<$core.String, $core.Map<$core.String, $core.dynamic>> get $messageJson => CloudPrintServiceBase$messageJson;
}

