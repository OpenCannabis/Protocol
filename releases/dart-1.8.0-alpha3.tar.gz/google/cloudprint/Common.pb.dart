///
//  Generated code. Do not modify.
//  source: google/cloudprint/Common.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart' as $pb;

import 'Common.pbenum.dart';

export 'Common.pbenum.dart';

class Marker_Color extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Marker.Color', package: const $pb.PackageName('google.cloudprint'))
    ..e<Marker_Color_Type>(1, 'type', $pb.PbFieldType.OE, Marker_Color_Type.CUSTOM, Marker_Color_Type.valueOf, Marker_Color_Type.values)
    ..aOS(2, 'customDisplayName')
    ..pc<LocalizedString>(3, 'customDisplayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  Marker_Color() : super();
  Marker_Color.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Marker_Color.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Marker_Color clone() => Marker_Color()..mergeFromMessage(this);
  Marker_Color copyWith(void Function(Marker_Color) updates) => super.copyWith((message) => updates(message as Marker_Color));
  $pb.BuilderInfo get info_ => _i;
  static Marker_Color create() => Marker_Color();
  Marker_Color createEmptyInstance() => create();
  static $pb.PbList<Marker_Color> createRepeated() => $pb.PbList<Marker_Color>();
  static Marker_Color getDefault() => _defaultInstance ??= create()..freeze();
  static Marker_Color _defaultInstance;

  Marker_Color_Type get type => $_getN(0);
  set type(Marker_Color_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.String get customDisplayName => $_getS(1, '');
  set customDisplayName($core.String v) { $_setString(1, v); }
  $core.bool hasCustomDisplayName() => $_has(1);
  void clearCustomDisplayName() => clearField(2);

  $core.List<LocalizedString> get customDisplayNameLocalized => $_getList(2);
}

class Marker extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Marker', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<Marker_Type>(2, 'type', $pb.PbFieldType.OE, Marker_Type.CUSTOM, Marker_Type.valueOf, Marker_Type.values)
    ..a<Marker_Color>(3, 'color', $pb.PbFieldType.OM, Marker_Color.getDefault, Marker_Color.create)
    ..aOS(4, 'customDisplayName')
    ..pc<LocalizedString>(5, 'customDisplayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  Marker() : super();
  Marker.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Marker.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Marker clone() => Marker()..mergeFromMessage(this);
  Marker copyWith(void Function(Marker) updates) => super.copyWith((message) => updates(message as Marker));
  $pb.BuilderInfo get info_ => _i;
  static Marker create() => Marker();
  Marker createEmptyInstance() => create();
  static $pb.PbList<Marker> createRepeated() => $pb.PbList<Marker>();
  static Marker getDefault() => _defaultInstance ??= create()..freeze();
  static Marker _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  Marker_Type get type => $_getN(1);
  set type(Marker_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  Marker_Color get color => $_getN(2);
  set color(Marker_Color v) { setField(3, v); }
  $core.bool hasColor() => $_has(2);
  void clearColor() => clearField(3);

  $core.String get customDisplayName => $_getS(3, '');
  set customDisplayName($core.String v) { $_setString(3, v); }
  $core.bool hasCustomDisplayName() => $_has(3);
  void clearCustomDisplayName() => clearField(4);

  $core.List<LocalizedString> get customDisplayNameLocalized => $_getList(4);
}

class Cover extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Cover', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<Cover_Type>(2, 'type', $pb.PbFieldType.OE, Cover_Type.CUSTOM, Cover_Type.valueOf, Cover_Type.values)
    ..aInt64(3, 'index')
    ..aOS(4, 'customDisplayName')
    ..pc<LocalizedString>(5, 'customDisplayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  Cover() : super();
  Cover.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Cover.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Cover clone() => Cover()..mergeFromMessage(this);
  Cover copyWith(void Function(Cover) updates) => super.copyWith((message) => updates(message as Cover));
  $pb.BuilderInfo get info_ => _i;
  static Cover create() => Cover();
  Cover createEmptyInstance() => create();
  static $pb.PbList<Cover> createRepeated() => $pb.PbList<Cover>();
  static Cover getDefault() => _defaultInstance ??= create()..freeze();
  static Cover _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  Cover_Type get type => $_getN(1);
  set type(Cover_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  Int64 get index => $_getI64(2);
  set index(Int64 v) { $_setInt64(2, v); }
  $core.bool hasIndex() => $_has(2);
  void clearIndex() => clearField(3);

  $core.String get customDisplayName => $_getS(3, '');
  set customDisplayName($core.String v) { $_setString(3, v); }
  $core.bool hasCustomDisplayName() => $_has(3);
  void clearCustomDisplayName() => clearField(4);

  $core.List<LocalizedString> get customDisplayNameLocalized => $_getList(4);
}

class MediaPath extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaPath', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..hasRequiredFields = false
  ;

  MediaPath() : super();
  MediaPath.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaPath.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaPath clone() => MediaPath()..mergeFromMessage(this);
  MediaPath copyWith(void Function(MediaPath) updates) => super.copyWith((message) => updates(message as MediaPath));
  $pb.BuilderInfo get info_ => _i;
  static MediaPath create() => MediaPath();
  MediaPath createEmptyInstance() => create();
  static $pb.PbList<MediaPath> createRepeated() => $pb.PbList<MediaPath>();
  static MediaPath getDefault() => _defaultInstance ??= create()..freeze();
  static MediaPath _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);
}

class VendorCapability extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('VendorCapability', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'id')
    ..aOS(2, 'displayName')
    ..e<VendorCapability_Type>(3, 'type', $pb.PbFieldType.OE, VendorCapability_Type.RANGE, VendorCapability_Type.valueOf, VendorCapability_Type.values)
    ..a<RangeCapability>(4, 'rangeCap', $pb.PbFieldType.OM, RangeCapability.getDefault, RangeCapability.create)
    ..a<SelectCapability>(5, 'selectCap', $pb.PbFieldType.OM, SelectCapability.getDefault, SelectCapability.create)
    ..a<TypedValueCapability>(6, 'typedValueCap', $pb.PbFieldType.OM, TypedValueCapability.getDefault, TypedValueCapability.create)
    ..pc<LocalizedString>(7, 'displayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  VendorCapability() : super();
  VendorCapability.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  VendorCapability.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  VendorCapability clone() => VendorCapability()..mergeFromMessage(this);
  VendorCapability copyWith(void Function(VendorCapability) updates) => super.copyWith((message) => updates(message as VendorCapability));
  $pb.BuilderInfo get info_ => _i;
  static VendorCapability create() => VendorCapability();
  VendorCapability createEmptyInstance() => create();
  static $pb.PbList<VendorCapability> createRepeated() => $pb.PbList<VendorCapability>();
  static VendorCapability getDefault() => _defaultInstance ??= create()..freeze();
  static VendorCapability _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $core.String get displayName => $_getS(1, '');
  set displayName($core.String v) { $_setString(1, v); }
  $core.bool hasDisplayName() => $_has(1);
  void clearDisplayName() => clearField(2);

  VendorCapability_Type get type => $_getN(2);
  set type(VendorCapability_Type v) { setField(3, v); }
  $core.bool hasType() => $_has(2);
  void clearType() => clearField(3);

  RangeCapability get rangeCap => $_getN(3);
  set rangeCap(RangeCapability v) { setField(4, v); }
  $core.bool hasRangeCap() => $_has(3);
  void clearRangeCap() => clearField(4);

  SelectCapability get selectCap => $_getN(4);
  set selectCap(SelectCapability v) { setField(5, v); }
  $core.bool hasSelectCap() => $_has(4);
  void clearSelectCap() => clearField(5);

  TypedValueCapability get typedValueCap => $_getN(5);
  set typedValueCap(TypedValueCapability v) { setField(6, v); }
  $core.bool hasTypedValueCap() => $_has(5);
  void clearTypedValueCap() => clearField(6);

  $core.List<LocalizedString> get displayNameLocalized => $_getList(6);
}

class RangeCapability extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('RangeCapability', package: const $pb.PackageName('google.cloudprint'))
    ..e<RangeCapability_ValueType>(1, 'valueType', $pb.PbFieldType.OE, RangeCapability_ValueType.FLOAT, RangeCapability_ValueType.valueOf, RangeCapability_ValueType.values)
    ..aOS(2, 'default_2')
    ..aOS(3, 'min')
    ..aOS(4, 'max')
    ..hasRequiredFields = false
  ;

  RangeCapability() : super();
  RangeCapability.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  RangeCapability.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  RangeCapability clone() => RangeCapability()..mergeFromMessage(this);
  RangeCapability copyWith(void Function(RangeCapability) updates) => super.copyWith((message) => updates(message as RangeCapability));
  $pb.BuilderInfo get info_ => _i;
  static RangeCapability create() => RangeCapability();
  RangeCapability createEmptyInstance() => create();
  static $pb.PbList<RangeCapability> createRepeated() => $pb.PbList<RangeCapability>();
  static RangeCapability getDefault() => _defaultInstance ??= create()..freeze();
  static RangeCapability _defaultInstance;

  RangeCapability_ValueType get valueType => $_getN(0);
  set valueType(RangeCapability_ValueType v) { setField(1, v); }
  $core.bool hasValueType() => $_has(0);
  void clearValueType() => clearField(1);

  $core.String get default_2 => $_getS(1, '');
  set default_2($core.String v) { $_setString(1, v); }
  $core.bool hasDefault_2() => $_has(1);
  void clearDefault_2() => clearField(2);

  $core.String get min => $_getS(2, '');
  set min($core.String v) { $_setString(2, v); }
  $core.bool hasMin() => $_has(2);
  void clearMin() => clearField(3);

  $core.String get max => $_getS(3, '');
  set max($core.String v) { $_setString(3, v); }
  $core.bool hasMax() => $_has(3);
  void clearMax() => clearField(4);
}

class SelectCapability_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SelectCapability.Option', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'value')
    ..aOS(2, 'displayName')
    ..aOB(3, 'isDefault')
    ..pc<LocalizedString>(4, 'displayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  SelectCapability_Option() : super();
  SelectCapability_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SelectCapability_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SelectCapability_Option clone() => SelectCapability_Option()..mergeFromMessage(this);
  SelectCapability_Option copyWith(void Function(SelectCapability_Option) updates) => super.copyWith((message) => updates(message as SelectCapability_Option));
  $pb.BuilderInfo get info_ => _i;
  static SelectCapability_Option create() => SelectCapability_Option();
  SelectCapability_Option createEmptyInstance() => create();
  static $pb.PbList<SelectCapability_Option> createRepeated() => $pb.PbList<SelectCapability_Option>();
  static SelectCapability_Option getDefault() => _defaultInstance ??= create()..freeze();
  static SelectCapability_Option _defaultInstance;

  $core.String get value => $_getS(0, '');
  set value($core.String v) { $_setString(0, v); }
  $core.bool hasValue() => $_has(0);
  void clearValue() => clearField(1);

  $core.String get displayName => $_getS(1, '');
  set displayName($core.String v) { $_setString(1, v); }
  $core.bool hasDisplayName() => $_has(1);
  void clearDisplayName() => clearField(2);

  $core.bool get isDefault => $_get(2, false);
  set isDefault($core.bool v) { $_setBool(2, v); }
  $core.bool hasIsDefault() => $_has(2);
  void clearIsDefault() => clearField(3);

  $core.List<LocalizedString> get displayNameLocalized => $_getList(3);
}

class SelectCapability extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SelectCapability', package: const $pb.PackageName('google.cloudprint'))
    ..pc<SelectCapability_Option>(1, 'option', $pb.PbFieldType.PM,SelectCapability_Option.create)
    ..hasRequiredFields = false
  ;

  SelectCapability() : super();
  SelectCapability.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SelectCapability.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SelectCapability clone() => SelectCapability()..mergeFromMessage(this);
  SelectCapability copyWith(void Function(SelectCapability) updates) => super.copyWith((message) => updates(message as SelectCapability));
  $pb.BuilderInfo get info_ => _i;
  static SelectCapability create() => SelectCapability();
  SelectCapability createEmptyInstance() => create();
  static $pb.PbList<SelectCapability> createRepeated() => $pb.PbList<SelectCapability>();
  static SelectCapability getDefault() => _defaultInstance ??= create()..freeze();
  static SelectCapability _defaultInstance;

  $core.List<SelectCapability_Option> get option => $_getList(0);
}

class TypedValueCapability extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TypedValueCapability', package: const $pb.PackageName('google.cloudprint'))
    ..e<TypedValueCapability_ValueType>(1, 'valueType', $pb.PbFieldType.OE, TypedValueCapability_ValueType.BOOLEAN, TypedValueCapability_ValueType.valueOf, TypedValueCapability_ValueType.values)
    ..aOS(2, 'default_2')
    ..hasRequiredFields = false
  ;

  TypedValueCapability() : super();
  TypedValueCapability.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TypedValueCapability.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TypedValueCapability clone() => TypedValueCapability()..mergeFromMessage(this);
  TypedValueCapability copyWith(void Function(TypedValueCapability) updates) => super.copyWith((message) => updates(message as TypedValueCapability));
  $pb.BuilderInfo get info_ => _i;
  static TypedValueCapability create() => TypedValueCapability();
  TypedValueCapability createEmptyInstance() => create();
  static $pb.PbList<TypedValueCapability> createRepeated() => $pb.PbList<TypedValueCapability>();
  static TypedValueCapability getDefault() => _defaultInstance ??= create()..freeze();
  static TypedValueCapability _defaultInstance;

  TypedValueCapability_ValueType get valueType => $_getN(0);
  set valueType(TypedValueCapability_ValueType v) { setField(1, v); }
  $core.bool hasValueType() => $_has(0);
  void clearValueType() => clearField(1);

  $core.String get default_2 => $_getS(1, '');
  set default_2($core.String v) { $_setString(1, v); }
  $core.bool hasDefault_2() => $_has(1);
  void clearDefault_2() => clearField(2);
}

class Color_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Color.Option', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<Color_Type>(2, 'type', $pb.PbFieldType.OE, Color_Type.STANDARD_COLOR, Color_Type.valueOf, Color_Type.values)
    ..aOS(3, 'customDisplayName')
    ..aOB(4, 'isDefault')
    ..pc<LocalizedString>(5, 'customDisplayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  Color_Option() : super();
  Color_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Color_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Color_Option clone() => Color_Option()..mergeFromMessage(this);
  Color_Option copyWith(void Function(Color_Option) updates) => super.copyWith((message) => updates(message as Color_Option));
  $pb.BuilderInfo get info_ => _i;
  static Color_Option create() => Color_Option();
  Color_Option createEmptyInstance() => create();
  static $pb.PbList<Color_Option> createRepeated() => $pb.PbList<Color_Option>();
  static Color_Option getDefault() => _defaultInstance ??= create()..freeze();
  static Color_Option _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  Color_Type get type => $_getN(1);
  set type(Color_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $core.String get customDisplayName => $_getS(2, '');
  set customDisplayName($core.String v) { $_setString(2, v); }
  $core.bool hasCustomDisplayName() => $_has(2);
  void clearCustomDisplayName() => clearField(3);

  $core.bool get isDefault => $_get(3, false);
  set isDefault($core.bool v) { $_setBool(3, v); }
  $core.bool hasIsDefault() => $_has(3);
  void clearIsDefault() => clearField(4);

  $core.List<LocalizedString> get customDisplayNameLocalized => $_getList(4);
}

class Color extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Color', package: const $pb.PackageName('google.cloudprint'))
    ..pc<Color_Option>(1, 'option', $pb.PbFieldType.PM,Color_Option.create)
    ..hasRequiredFields = false
  ;

  Color() : super();
  Color.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Color.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Color clone() => Color()..mergeFromMessage(this);
  Color copyWith(void Function(Color) updates) => super.copyWith((message) => updates(message as Color));
  $pb.BuilderInfo get info_ => _i;
  static Color create() => Color();
  Color createEmptyInstance() => create();
  static $pb.PbList<Color> createRepeated() => $pb.PbList<Color>();
  static Color getDefault() => _defaultInstance ??= create()..freeze();
  static Color _defaultInstance;

  $core.List<Color_Option> get option => $_getList(0);
}

class Duplex_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Duplex.Option', package: const $pb.PackageName('google.cloudprint'))
    ..e<Duplex_Type>(1, 'type', $pb.PbFieldType.OE, Duplex_Type.NO_DUPLEX, Duplex_Type.valueOf, Duplex_Type.values)
    ..aOB(2, 'isDefault')
    ..hasRequiredFields = false
  ;

  Duplex_Option() : super();
  Duplex_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Duplex_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Duplex_Option clone() => Duplex_Option()..mergeFromMessage(this);
  Duplex_Option copyWith(void Function(Duplex_Option) updates) => super.copyWith((message) => updates(message as Duplex_Option));
  $pb.BuilderInfo get info_ => _i;
  static Duplex_Option create() => Duplex_Option();
  Duplex_Option createEmptyInstance() => create();
  static $pb.PbList<Duplex_Option> createRepeated() => $pb.PbList<Duplex_Option>();
  static Duplex_Option getDefault() => _defaultInstance ??= create()..freeze();
  static Duplex_Option _defaultInstance;

  Duplex_Type get type => $_getN(0);
  set type(Duplex_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.bool get isDefault => $_get(1, false);
  set isDefault($core.bool v) { $_setBool(1, v); }
  $core.bool hasIsDefault() => $_has(1);
  void clearIsDefault() => clearField(2);
}

class Duplex extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Duplex', package: const $pb.PackageName('google.cloudprint'))
    ..pc<Duplex_Option>(1, 'option', $pb.PbFieldType.PM,Duplex_Option.create)
    ..hasRequiredFields = false
  ;

  Duplex() : super();
  Duplex.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Duplex.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Duplex clone() => Duplex()..mergeFromMessage(this);
  Duplex copyWith(void Function(Duplex) updates) => super.copyWith((message) => updates(message as Duplex));
  $pb.BuilderInfo get info_ => _i;
  static Duplex create() => Duplex();
  Duplex createEmptyInstance() => create();
  static $pb.PbList<Duplex> createRepeated() => $pb.PbList<Duplex>();
  static Duplex getDefault() => _defaultInstance ??= create()..freeze();
  static Duplex _defaultInstance;

  $core.List<Duplex_Option> get option => $_getList(0);
}

class PageOrientation_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PageOrientation.Option', package: const $pb.PackageName('google.cloudprint'))
    ..e<PageOrientation_Type>(1, 'type', $pb.PbFieldType.OE, PageOrientation_Type.PORTRAIT, PageOrientation_Type.valueOf, PageOrientation_Type.values)
    ..aOB(2, 'isDefault')
    ..hasRequiredFields = false
  ;

  PageOrientation_Option() : super();
  PageOrientation_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PageOrientation_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PageOrientation_Option clone() => PageOrientation_Option()..mergeFromMessage(this);
  PageOrientation_Option copyWith(void Function(PageOrientation_Option) updates) => super.copyWith((message) => updates(message as PageOrientation_Option));
  $pb.BuilderInfo get info_ => _i;
  static PageOrientation_Option create() => PageOrientation_Option();
  PageOrientation_Option createEmptyInstance() => create();
  static $pb.PbList<PageOrientation_Option> createRepeated() => $pb.PbList<PageOrientation_Option>();
  static PageOrientation_Option getDefault() => _defaultInstance ??= create()..freeze();
  static PageOrientation_Option _defaultInstance;

  PageOrientation_Type get type => $_getN(0);
  set type(PageOrientation_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.bool get isDefault => $_get(1, false);
  set isDefault($core.bool v) { $_setBool(1, v); }
  $core.bool hasIsDefault() => $_has(1);
  void clearIsDefault() => clearField(2);
}

class PageOrientation extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PageOrientation', package: const $pb.PackageName('google.cloudprint'))
    ..pc<PageOrientation_Option>(1, 'option', $pb.PbFieldType.PM,PageOrientation_Option.create)
    ..hasRequiredFields = false
  ;

  PageOrientation() : super();
  PageOrientation.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PageOrientation.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PageOrientation clone() => PageOrientation()..mergeFromMessage(this);
  PageOrientation copyWith(void Function(PageOrientation) updates) => super.copyWith((message) => updates(message as PageOrientation));
  $pb.BuilderInfo get info_ => _i;
  static PageOrientation create() => PageOrientation();
  PageOrientation createEmptyInstance() => create();
  static $pb.PbList<PageOrientation> createRepeated() => $pb.PbList<PageOrientation>();
  static PageOrientation getDefault() => _defaultInstance ??= create()..freeze();
  static PageOrientation _defaultInstance;

  $core.List<PageOrientation_Option> get option => $_getList(0);
}

class Copies extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Copies', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.int>(1, 'default_1', $pb.PbFieldType.O3)
    ..a<$core.int>(2, 'max', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  Copies() : super();
  Copies.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Copies.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Copies clone() => Copies()..mergeFromMessage(this);
  Copies copyWith(void Function(Copies) updates) => super.copyWith((message) => updates(message as Copies));
  $pb.BuilderInfo get info_ => _i;
  static Copies create() => Copies();
  Copies createEmptyInstance() => create();
  static $pb.PbList<Copies> createRepeated() => $pb.PbList<Copies>();
  static Copies getDefault() => _defaultInstance ??= create()..freeze();
  static Copies _defaultInstance;

  $core.int get default_1 => $_get(0, 0);
  set default_1($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasDefault_1() => $_has(0);
  void clearDefault_1() => clearField(1);

  $core.int get max => $_get(1, 0);
  set max($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasMax() => $_has(1);
  void clearMax() => clearField(2);
}

class Margins_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Margins.Option', package: const $pb.PackageName('google.cloudprint'))
    ..e<Margins_Type>(1, 'type', $pb.PbFieldType.OE, Margins_Type.BORDERLESS, Margins_Type.valueOf, Margins_Type.values)
    ..a<$core.int>(2, 'topMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(3, 'rightMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(4, 'bottomMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(5, 'leftMicrons', $pb.PbFieldType.O3)
    ..aOB(6, 'isDefault')
    ..hasRequiredFields = false
  ;

  Margins_Option() : super();
  Margins_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Margins_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Margins_Option clone() => Margins_Option()..mergeFromMessage(this);
  Margins_Option copyWith(void Function(Margins_Option) updates) => super.copyWith((message) => updates(message as Margins_Option));
  $pb.BuilderInfo get info_ => _i;
  static Margins_Option create() => Margins_Option();
  Margins_Option createEmptyInstance() => create();
  static $pb.PbList<Margins_Option> createRepeated() => $pb.PbList<Margins_Option>();
  static Margins_Option getDefault() => _defaultInstance ??= create()..freeze();
  static Margins_Option _defaultInstance;

  Margins_Type get type => $_getN(0);
  set type(Margins_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.int get topMicrons => $_get(1, 0);
  set topMicrons($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasTopMicrons() => $_has(1);
  void clearTopMicrons() => clearField(2);

  $core.int get rightMicrons => $_get(2, 0);
  set rightMicrons($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasRightMicrons() => $_has(2);
  void clearRightMicrons() => clearField(3);

  $core.int get bottomMicrons => $_get(3, 0);
  set bottomMicrons($core.int v) { $_setSignedInt32(3, v); }
  $core.bool hasBottomMicrons() => $_has(3);
  void clearBottomMicrons() => clearField(4);

  $core.int get leftMicrons => $_get(4, 0);
  set leftMicrons($core.int v) { $_setSignedInt32(4, v); }
  $core.bool hasLeftMicrons() => $_has(4);
  void clearLeftMicrons() => clearField(5);

  $core.bool get isDefault => $_get(5, false);
  set isDefault($core.bool v) { $_setBool(5, v); }
  $core.bool hasIsDefault() => $_has(5);
  void clearIsDefault() => clearField(6);
}

class Margins extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Margins', package: const $pb.PackageName('google.cloudprint'))
    ..pc<Margins_Option>(1, 'option', $pb.PbFieldType.PM,Margins_Option.create)
    ..hasRequiredFields = false
  ;

  Margins() : super();
  Margins.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Margins.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Margins clone() => Margins()..mergeFromMessage(this);
  Margins copyWith(void Function(Margins) updates) => super.copyWith((message) => updates(message as Margins));
  $pb.BuilderInfo get info_ => _i;
  static Margins create() => Margins();
  Margins createEmptyInstance() => create();
  static $pb.PbList<Margins> createRepeated() => $pb.PbList<Margins>();
  static Margins getDefault() => _defaultInstance ??= create()..freeze();
  static Margins _defaultInstance;

  $core.List<Margins_Option> get option => $_getList(0);
}

class Dpi_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Dpi.Option', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.int>(1, 'horizontalDpi', $pb.PbFieldType.O3)
    ..a<$core.int>(2, 'verticalDpi', $pb.PbFieldType.O3)
    ..aOB(3, 'isDefault')
    ..aOS(4, 'customDisplayName')
    ..aOS(5, 'vendorId')
    ..pc<LocalizedString>(6, 'customDisplayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  Dpi_Option() : super();
  Dpi_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Dpi_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Dpi_Option clone() => Dpi_Option()..mergeFromMessage(this);
  Dpi_Option copyWith(void Function(Dpi_Option) updates) => super.copyWith((message) => updates(message as Dpi_Option));
  $pb.BuilderInfo get info_ => _i;
  static Dpi_Option create() => Dpi_Option();
  Dpi_Option createEmptyInstance() => create();
  static $pb.PbList<Dpi_Option> createRepeated() => $pb.PbList<Dpi_Option>();
  static Dpi_Option getDefault() => _defaultInstance ??= create()..freeze();
  static Dpi_Option _defaultInstance;

  $core.int get horizontalDpi => $_get(0, 0);
  set horizontalDpi($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasHorizontalDpi() => $_has(0);
  void clearHorizontalDpi() => clearField(1);

  $core.int get verticalDpi => $_get(1, 0);
  set verticalDpi($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasVerticalDpi() => $_has(1);
  void clearVerticalDpi() => clearField(2);

  $core.bool get isDefault => $_get(2, false);
  set isDefault($core.bool v) { $_setBool(2, v); }
  $core.bool hasIsDefault() => $_has(2);
  void clearIsDefault() => clearField(3);

  $core.String get customDisplayName => $_getS(3, '');
  set customDisplayName($core.String v) { $_setString(3, v); }
  $core.bool hasCustomDisplayName() => $_has(3);
  void clearCustomDisplayName() => clearField(4);

  $core.String get vendorId => $_getS(4, '');
  set vendorId($core.String v) { $_setString(4, v); }
  $core.bool hasVendorId() => $_has(4);
  void clearVendorId() => clearField(5);

  $core.List<LocalizedString> get customDisplayNameLocalized => $_getList(5);
}

class Dpi extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Dpi', package: const $pb.PackageName('google.cloudprint'))
    ..pc<Dpi_Option>(1, 'option', $pb.PbFieldType.PM,Dpi_Option.create)
    ..a<$core.int>(2, 'minHorizontalDpi', $pb.PbFieldType.O3)
    ..a<$core.int>(3, 'maxHorizontalDpi', $pb.PbFieldType.O3)
    ..a<$core.int>(4, 'minVerticalDpi', $pb.PbFieldType.O3)
    ..a<$core.int>(5, 'maxVerticalDpi', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  Dpi() : super();
  Dpi.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Dpi.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Dpi clone() => Dpi()..mergeFromMessage(this);
  Dpi copyWith(void Function(Dpi) updates) => super.copyWith((message) => updates(message as Dpi));
  $pb.BuilderInfo get info_ => _i;
  static Dpi create() => Dpi();
  Dpi createEmptyInstance() => create();
  static $pb.PbList<Dpi> createRepeated() => $pb.PbList<Dpi>();
  static Dpi getDefault() => _defaultInstance ??= create()..freeze();
  static Dpi _defaultInstance;

  $core.List<Dpi_Option> get option => $_getList(0);

  $core.int get minHorizontalDpi => $_get(1, 0);
  set minHorizontalDpi($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasMinHorizontalDpi() => $_has(1);
  void clearMinHorizontalDpi() => clearField(2);

  $core.int get maxHorizontalDpi => $_get(2, 0);
  set maxHorizontalDpi($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasMaxHorizontalDpi() => $_has(2);
  void clearMaxHorizontalDpi() => clearField(3);

  $core.int get minVerticalDpi => $_get(3, 0);
  set minVerticalDpi($core.int v) { $_setSignedInt32(3, v); }
  $core.bool hasMinVerticalDpi() => $_has(3);
  void clearMinVerticalDpi() => clearField(4);

  $core.int get maxVerticalDpi => $_get(4, 0);
  set maxVerticalDpi($core.int v) { $_setSignedInt32(4, v); }
  $core.bool hasMaxVerticalDpi() => $_has(4);
  void clearMaxVerticalDpi() => clearField(5);
}

class FitToPage_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('FitToPage.Option', package: const $pb.PackageName('google.cloudprint'))
    ..e<FitToPage_Type>(1, 'type', $pb.PbFieldType.OE, FitToPage_Type.NO_FITTING, FitToPage_Type.valueOf, FitToPage_Type.values)
    ..aOB(2, 'isDefault')
    ..hasRequiredFields = false
  ;

  FitToPage_Option() : super();
  FitToPage_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  FitToPage_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  FitToPage_Option clone() => FitToPage_Option()..mergeFromMessage(this);
  FitToPage_Option copyWith(void Function(FitToPage_Option) updates) => super.copyWith((message) => updates(message as FitToPage_Option));
  $pb.BuilderInfo get info_ => _i;
  static FitToPage_Option create() => FitToPage_Option();
  FitToPage_Option createEmptyInstance() => create();
  static $pb.PbList<FitToPage_Option> createRepeated() => $pb.PbList<FitToPage_Option>();
  static FitToPage_Option getDefault() => _defaultInstance ??= create()..freeze();
  static FitToPage_Option _defaultInstance;

  FitToPage_Type get type => $_getN(0);
  set type(FitToPage_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.bool get isDefault => $_get(1, false);
  set isDefault($core.bool v) { $_setBool(1, v); }
  $core.bool hasIsDefault() => $_has(1);
  void clearIsDefault() => clearField(2);
}

class FitToPage extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('FitToPage', package: const $pb.PackageName('google.cloudprint'))
    ..pc<FitToPage_Option>(1, 'option', $pb.PbFieldType.PM,FitToPage_Option.create)
    ..hasRequiredFields = false
  ;

  FitToPage() : super();
  FitToPage.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  FitToPage.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  FitToPage clone() => FitToPage()..mergeFromMessage(this);
  FitToPage copyWith(void Function(FitToPage) updates) => super.copyWith((message) => updates(message as FitToPage));
  $pb.BuilderInfo get info_ => _i;
  static FitToPage create() => FitToPage();
  FitToPage createEmptyInstance() => create();
  static $pb.PbList<FitToPage> createRepeated() => $pb.PbList<FitToPage>();
  static FitToPage getDefault() => _defaultInstance ??= create()..freeze();
  static FitToPage _defaultInstance;

  $core.List<FitToPage_Option> get option => $_getList(0);
}

class PageRange_Interval extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PageRange.Interval', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.int>(1, 'start', $pb.PbFieldType.O3)
    ..a<$core.int>(2, 'end', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  PageRange_Interval() : super();
  PageRange_Interval.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PageRange_Interval.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PageRange_Interval clone() => PageRange_Interval()..mergeFromMessage(this);
  PageRange_Interval copyWith(void Function(PageRange_Interval) updates) => super.copyWith((message) => updates(message as PageRange_Interval));
  $pb.BuilderInfo get info_ => _i;
  static PageRange_Interval create() => PageRange_Interval();
  PageRange_Interval createEmptyInstance() => create();
  static $pb.PbList<PageRange_Interval> createRepeated() => $pb.PbList<PageRange_Interval>();
  static PageRange_Interval getDefault() => _defaultInstance ??= create()..freeze();
  static PageRange_Interval _defaultInstance;

  $core.int get start => $_get(0, 0);
  set start($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasStart() => $_has(0);
  void clearStart() => clearField(1);

  $core.int get end => $_get(1, 0);
  set end($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasEnd() => $_has(1);
  void clearEnd() => clearField(2);
}

class PageRange extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PageRange', package: const $pb.PackageName('google.cloudprint'))
    ..pc<PageRange_Interval>(1, 'default_1', $pb.PbFieldType.PM,PageRange_Interval.create)
    ..hasRequiredFields = false
  ;

  PageRange() : super();
  PageRange.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PageRange.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PageRange clone() => PageRange()..mergeFromMessage(this);
  PageRange copyWith(void Function(PageRange) updates) => super.copyWith((message) => updates(message as PageRange));
  $pb.BuilderInfo get info_ => _i;
  static PageRange create() => PageRange();
  PageRange createEmptyInstance() => create();
  static $pb.PbList<PageRange> createRepeated() => $pb.PbList<PageRange>();
  static PageRange getDefault() => _defaultInstance ??= create()..freeze();
  static PageRange _defaultInstance;

  $core.List<PageRange_Interval> get default_1 => $_getList(0);
}

class MediaSize_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaSize.Option', package: const $pb.PackageName('google.cloudprint'))
    ..e<MediaSize_Name>(1, 'name', $pb.PbFieldType.OE, MediaSize_Name.CUSTOM, MediaSize_Name.valueOf, MediaSize_Name.values)
    ..a<$core.int>(2, 'widthMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(3, 'heightMicrons', $pb.PbFieldType.O3)
    ..aOB(4, 'isContinuousFeed')
    ..aOB(5, 'isDefault')
    ..aOS(6, 'customDisplayName')
    ..aOS(7, 'vendorId')
    ..pc<LocalizedString>(8, 'customDisplayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  MediaSize_Option() : super();
  MediaSize_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaSize_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaSize_Option clone() => MediaSize_Option()..mergeFromMessage(this);
  MediaSize_Option copyWith(void Function(MediaSize_Option) updates) => super.copyWith((message) => updates(message as MediaSize_Option));
  $pb.BuilderInfo get info_ => _i;
  static MediaSize_Option create() => MediaSize_Option();
  MediaSize_Option createEmptyInstance() => create();
  static $pb.PbList<MediaSize_Option> createRepeated() => $pb.PbList<MediaSize_Option>();
  static MediaSize_Option getDefault() => _defaultInstance ??= create()..freeze();
  static MediaSize_Option _defaultInstance;

  MediaSize_Name get name => $_getN(0);
  set name(MediaSize_Name v) { setField(1, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  $core.int get widthMicrons => $_get(1, 0);
  set widthMicrons($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasWidthMicrons() => $_has(1);
  void clearWidthMicrons() => clearField(2);

  $core.int get heightMicrons => $_get(2, 0);
  set heightMicrons($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasHeightMicrons() => $_has(2);
  void clearHeightMicrons() => clearField(3);

  $core.bool get isContinuousFeed => $_get(3, false);
  set isContinuousFeed($core.bool v) { $_setBool(3, v); }
  $core.bool hasIsContinuousFeed() => $_has(3);
  void clearIsContinuousFeed() => clearField(4);

  $core.bool get isDefault => $_get(4, false);
  set isDefault($core.bool v) { $_setBool(4, v); }
  $core.bool hasIsDefault() => $_has(4);
  void clearIsDefault() => clearField(5);

  $core.String get customDisplayName => $_getS(5, '');
  set customDisplayName($core.String v) { $_setString(5, v); }
  $core.bool hasCustomDisplayName() => $_has(5);
  void clearCustomDisplayName() => clearField(6);

  $core.String get vendorId => $_getS(6, '');
  set vendorId($core.String v) { $_setString(6, v); }
  $core.bool hasVendorId() => $_has(6);
  void clearVendorId() => clearField(7);

  $core.List<LocalizedString> get customDisplayNameLocalized => $_getList(7);
}

class MediaSize extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MediaSize', package: const $pb.PackageName('google.cloudprint'))
    ..pc<MediaSize_Option>(1, 'option', $pb.PbFieldType.PM,MediaSize_Option.create)
    ..a<$core.int>(2, 'maxWidthMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(3, 'maxHeightMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(4, 'minWidthMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(5, 'minHeightMicrons', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  MediaSize() : super();
  MediaSize.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MediaSize.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MediaSize clone() => MediaSize()..mergeFromMessage(this);
  MediaSize copyWith(void Function(MediaSize) updates) => super.copyWith((message) => updates(message as MediaSize));
  $pb.BuilderInfo get info_ => _i;
  static MediaSize create() => MediaSize();
  MediaSize createEmptyInstance() => create();
  static $pb.PbList<MediaSize> createRepeated() => $pb.PbList<MediaSize>();
  static MediaSize getDefault() => _defaultInstance ??= create()..freeze();
  static MediaSize _defaultInstance;

  $core.List<MediaSize_Option> get option => $_getList(0);

  $core.int get maxWidthMicrons => $_get(1, 0);
  set maxWidthMicrons($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasMaxWidthMicrons() => $_has(1);
  void clearMaxWidthMicrons() => clearField(2);

  $core.int get maxHeightMicrons => $_get(2, 0);
  set maxHeightMicrons($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasMaxHeightMicrons() => $_has(2);
  void clearMaxHeightMicrons() => clearField(3);

  $core.int get minWidthMicrons => $_get(3, 0);
  set minWidthMicrons($core.int v) { $_setSignedInt32(3, v); }
  $core.bool hasMinWidthMicrons() => $_has(3);
  void clearMinWidthMicrons() => clearField(4);

  $core.int get minHeightMicrons => $_get(4, 0);
  set minHeightMicrons($core.int v) { $_setSignedInt32(4, v); }
  $core.bool hasMinHeightMicrons() => $_has(4);
  void clearMinHeightMicrons() => clearField(5);
}

class Collate extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Collate', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'default_1')
    ..hasRequiredFields = false
  ;

  Collate() : super();
  Collate.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Collate.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Collate clone() => Collate()..mergeFromMessage(this);
  Collate copyWith(void Function(Collate) updates) => super.copyWith((message) => updates(message as Collate));
  $pb.BuilderInfo get info_ => _i;
  static Collate create() => Collate();
  Collate createEmptyInstance() => create();
  static $pb.PbList<Collate> createRepeated() => $pb.PbList<Collate>();
  static Collate getDefault() => _defaultInstance ??= create()..freeze();
  static Collate _defaultInstance;

  $core.bool get default_1 => $_get(0, false);
  set default_1($core.bool v) { $_setBool(0, v); }
  $core.bool hasDefault_1() => $_has(0);
  void clearDefault_1() => clearField(1);
}

class ReverseOrder extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ReverseOrder', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'default_1')
    ..hasRequiredFields = false
  ;

  ReverseOrder() : super();
  ReverseOrder.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ReverseOrder.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ReverseOrder clone() => ReverseOrder()..mergeFromMessage(this);
  ReverseOrder copyWith(void Function(ReverseOrder) updates) => super.copyWith((message) => updates(message as ReverseOrder));
  $pb.BuilderInfo get info_ => _i;
  static ReverseOrder create() => ReverseOrder();
  ReverseOrder createEmptyInstance() => create();
  static $pb.PbList<ReverseOrder> createRepeated() => $pb.PbList<ReverseOrder>();
  static ReverseOrder getDefault() => _defaultInstance ??= create()..freeze();
  static ReverseOrder _defaultInstance;

  $core.bool get default_1 => $_get(0, false);
  set default_1($core.bool v) { $_setBool(0, v); }
  $core.bool hasDefault_1() => $_has(0);
  void clearDefault_1() => clearField(1);
}

class LocalizedString extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('LocalizedString', package: const $pb.PackageName('google.cloudprint'))
    ..e<LocalizedString_Locale>(1, 'locale', $pb.PbFieldType.OE, LocalizedString_Locale.AF, LocalizedString_Locale.valueOf, LocalizedString_Locale.values)
    ..aOS(2, 'value')
    ..hasRequiredFields = false
  ;

  LocalizedString() : super();
  LocalizedString.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  LocalizedString.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  LocalizedString clone() => LocalizedString()..mergeFromMessage(this);
  LocalizedString copyWith(void Function(LocalizedString) updates) => super.copyWith((message) => updates(message as LocalizedString));
  $pb.BuilderInfo get info_ => _i;
  static LocalizedString create() => LocalizedString();
  LocalizedString createEmptyInstance() => create();
  static $pb.PbList<LocalizedString> createRepeated() => $pb.PbList<LocalizedString>();
  static LocalizedString getDefault() => _defaultInstance ??= create()..freeze();
  static LocalizedString _defaultInstance;

  LocalizedString_Locale get locale => $_getN(0);
  set locale(LocalizedString_Locale v) { setField(1, v); }
  $core.bool hasLocale() => $_has(0);
  void clearLocale() => clearField(1);

  $core.String get value => $_getS(1, '');
  set value($core.String v) { $_setString(1, v); }
  $core.bool hasValue() => $_has(1);
  void clearValue() => clearField(2);
}

class SupportedContentType extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SupportedContentType', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'contentType')
    ..aOS(2, 'minVersion')
    ..aOS(3, 'maxVersion')
    ..hasRequiredFields = false
  ;

  SupportedContentType() : super();
  SupportedContentType.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SupportedContentType.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SupportedContentType clone() => SupportedContentType()..mergeFromMessage(this);
  SupportedContentType copyWith(void Function(SupportedContentType) updates) => super.copyWith((message) => updates(message as SupportedContentType));
  $pb.BuilderInfo get info_ => _i;
  static SupportedContentType create() => SupportedContentType();
  SupportedContentType createEmptyInstance() => create();
  static $pb.PbList<SupportedContentType> createRepeated() => $pb.PbList<SupportedContentType>();
  static SupportedContentType getDefault() => _defaultInstance ??= create()..freeze();
  static SupportedContentType _defaultInstance;

  $core.String get contentType => $_getS(0, '');
  set contentType($core.String v) { $_setString(0, v); }
  $core.bool hasContentType() => $_has(0);
  void clearContentType() => clearField(1);

  $core.String get minVersion => $_getS(1, '');
  set minVersion($core.String v) { $_setString(1, v); }
  $core.bool hasMinVersion() => $_has(1);
  void clearMinVersion() => clearField(2);

  $core.String get maxVersion => $_getS(2, '');
  set maxVersion($core.String v) { $_setString(2, v); }
  $core.bool hasMaxVersion() => $_has(2);
  void clearMaxVersion() => clearField(3);
}

class PrintingSpeed_Option extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintingSpeed.Option', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.double>(1, 'speedPpm', $pb.PbFieldType.OF)
    ..pc<Color_Type>(2, 'colorType', $pb.PbFieldType.PE, null, Color_Type.valueOf, Color_Type.values)
    ..pc<MediaSize_Name>(3, 'mediaSizeName', $pb.PbFieldType.PE, null, MediaSize_Name.valueOf, MediaSize_Name.values)
    ..hasRequiredFields = false
  ;

  PrintingSpeed_Option() : super();
  PrintingSpeed_Option.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintingSpeed_Option.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintingSpeed_Option clone() => PrintingSpeed_Option()..mergeFromMessage(this);
  PrintingSpeed_Option copyWith(void Function(PrintingSpeed_Option) updates) => super.copyWith((message) => updates(message as PrintingSpeed_Option));
  $pb.BuilderInfo get info_ => _i;
  static PrintingSpeed_Option create() => PrintingSpeed_Option();
  PrintingSpeed_Option createEmptyInstance() => create();
  static $pb.PbList<PrintingSpeed_Option> createRepeated() => $pb.PbList<PrintingSpeed_Option>();
  static PrintingSpeed_Option getDefault() => _defaultInstance ??= create()..freeze();
  static PrintingSpeed_Option _defaultInstance;

  $core.double get speedPpm => $_getN(0);
  set speedPpm($core.double v) { $_setFloat(0, v); }
  $core.bool hasSpeedPpm() => $_has(0);
  void clearSpeedPpm() => clearField(1);

  $core.List<Color_Type> get colorType => $_getList(1);

  $core.List<MediaSize_Name> get mediaSizeName => $_getList(2);
}

class PrintingSpeed extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintingSpeed', package: const $pb.PackageName('google.cloudprint'))
    ..pc<PrintingSpeed_Option>(1, 'option', $pb.PbFieldType.PM,PrintingSpeed_Option.create)
    ..hasRequiredFields = false
  ;

  PrintingSpeed() : super();
  PrintingSpeed.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintingSpeed.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintingSpeed clone() => PrintingSpeed()..mergeFromMessage(this);
  PrintingSpeed copyWith(void Function(PrintingSpeed) updates) => super.copyWith((message) => updates(message as PrintingSpeed));
  $pb.BuilderInfo get info_ => _i;
  static PrintingSpeed create() => PrintingSpeed();
  PrintingSpeed createEmptyInstance() => create();
  static $pb.PbList<PrintingSpeed> createRepeated() => $pb.PbList<PrintingSpeed>();
  static PrintingSpeed getDefault() => _defaultInstance ??= create()..freeze();
  static PrintingSpeed _defaultInstance;

  $core.List<PrintingSpeed_Option> get option => $_getList(0);
}

class PwgRasterConfig_Resolution extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PwgRasterConfig.Resolution', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.int>(1, 'crossFeedDir', $pb.PbFieldType.O3)
    ..a<$core.int>(2, 'feedDir', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  PwgRasterConfig_Resolution() : super();
  PwgRasterConfig_Resolution.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PwgRasterConfig_Resolution.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PwgRasterConfig_Resolution clone() => PwgRasterConfig_Resolution()..mergeFromMessage(this);
  PwgRasterConfig_Resolution copyWith(void Function(PwgRasterConfig_Resolution) updates) => super.copyWith((message) => updates(message as PwgRasterConfig_Resolution));
  $pb.BuilderInfo get info_ => _i;
  static PwgRasterConfig_Resolution create() => PwgRasterConfig_Resolution();
  PwgRasterConfig_Resolution createEmptyInstance() => create();
  static $pb.PbList<PwgRasterConfig_Resolution> createRepeated() => $pb.PbList<PwgRasterConfig_Resolution>();
  static PwgRasterConfig_Resolution getDefault() => _defaultInstance ??= create()..freeze();
  static PwgRasterConfig_Resolution _defaultInstance;

  $core.int get crossFeedDir => $_get(0, 0);
  set crossFeedDir($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasCrossFeedDir() => $_has(0);
  void clearCrossFeedDir() => clearField(1);

  $core.int get feedDir => $_get(1, 0);
  set feedDir($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasFeedDir() => $_has(1);
  void clearFeedDir() => clearField(2);
}

class PwgRasterConfig_Transformation extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PwgRasterConfig.Transformation', package: const $pb.PackageName('google.cloudprint'))
    ..e<PwgRasterConfig_Transformation_Operation>(1, 'operation', $pb.PbFieldType.OE, PwgRasterConfig_Transformation_Operation.ROTATE_180, PwgRasterConfig_Transformation_Operation.valueOf, PwgRasterConfig_Transformation_Operation.values)
    ..e<PwgRasterConfig_Transformation_Operand>(2, 'operand', $pb.PbFieldType.OE, PwgRasterConfig_Transformation_Operand.ALL_PAGES, PwgRasterConfig_Transformation_Operand.valueOf, PwgRasterConfig_Transformation_Operand.values)
    ..pc<Duplex_Type>(3, 'duplexType', $pb.PbFieldType.PE, null, Duplex_Type.valueOf, Duplex_Type.values)
    ..hasRequiredFields = false
  ;

  PwgRasterConfig_Transformation() : super();
  PwgRasterConfig_Transformation.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PwgRasterConfig_Transformation.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PwgRasterConfig_Transformation clone() => PwgRasterConfig_Transformation()..mergeFromMessage(this);
  PwgRasterConfig_Transformation copyWith(void Function(PwgRasterConfig_Transformation) updates) => super.copyWith((message) => updates(message as PwgRasterConfig_Transformation));
  $pb.BuilderInfo get info_ => _i;
  static PwgRasterConfig_Transformation create() => PwgRasterConfig_Transformation();
  PwgRasterConfig_Transformation createEmptyInstance() => create();
  static $pb.PbList<PwgRasterConfig_Transformation> createRepeated() => $pb.PbList<PwgRasterConfig_Transformation>();
  static PwgRasterConfig_Transformation getDefault() => _defaultInstance ??= create()..freeze();
  static PwgRasterConfig_Transformation _defaultInstance;

  PwgRasterConfig_Transformation_Operation get operation => $_getN(0);
  set operation(PwgRasterConfig_Transformation_Operation v) { setField(1, v); }
  $core.bool hasOperation() => $_has(0);
  void clearOperation() => clearField(1);

  PwgRasterConfig_Transformation_Operand get operand => $_getN(1);
  set operand(PwgRasterConfig_Transformation_Operand v) { setField(2, v); }
  $core.bool hasOperand() => $_has(1);
  void clearOperand() => clearField(2);

  $core.List<Duplex_Type> get duplexType => $_getList(2);
}

class PwgRasterConfig extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PwgRasterConfig', package: const $pb.PackageName('google.cloudprint'))
    ..pc<PwgRasterConfig_Transformation>(1, 'transformation', $pb.PbFieldType.PM,PwgRasterConfig_Transformation.create)
    ..pc<PwgRasterConfig_Resolution>(2, 'documentResolutionSupported', $pb.PbFieldType.PM,PwgRasterConfig_Resolution.create)
    ..pc<PwgRasterConfig_PwgDocumentTypeSupported>(3, 'documentTypeSupported', $pb.PbFieldType.PE, null, PwgRasterConfig_PwgDocumentTypeSupported.valueOf, PwgRasterConfig_PwgDocumentTypeSupported.values)
    ..e<PwgRasterConfig_DocumentSheetBack>(4, 'documentSheetBack', $pb.PbFieldType.OE, PwgRasterConfig_DocumentSheetBack.NORMAL, PwgRasterConfig_DocumentSheetBack.valueOf, PwgRasterConfig_DocumentSheetBack.values)
    ..aOB(5, 'reverseOrderStreaming')
    ..aOB(6, 'rotateAllPages')
    ..hasRequiredFields = false
  ;

  PwgRasterConfig() : super();
  PwgRasterConfig.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PwgRasterConfig.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PwgRasterConfig clone() => PwgRasterConfig()..mergeFromMessage(this);
  PwgRasterConfig copyWith(void Function(PwgRasterConfig) updates) => super.copyWith((message) => updates(message as PwgRasterConfig));
  $pb.BuilderInfo get info_ => _i;
  static PwgRasterConfig create() => PwgRasterConfig();
  PwgRasterConfig createEmptyInstance() => create();
  static $pb.PbList<PwgRasterConfig> createRepeated() => $pb.PbList<PwgRasterConfig>();
  static PwgRasterConfig getDefault() => _defaultInstance ??= create()..freeze();
  static PwgRasterConfig _defaultInstance;

  $core.List<PwgRasterConfig_Transformation> get transformation => $_getList(0);

  $core.List<PwgRasterConfig_Resolution> get documentResolutionSupported => $_getList(1);

  $core.List<PwgRasterConfig_PwgDocumentTypeSupported> get documentTypeSupported => $_getList(2);

  PwgRasterConfig_DocumentSheetBack get documentSheetBack => $_getN(3);
  set documentSheetBack(PwgRasterConfig_DocumentSheetBack v) { setField(4, v); }
  $core.bool hasDocumentSheetBack() => $_has(3);
  void clearDocumentSheetBack() => clearField(4);

  $core.bool get reverseOrderStreaming => $_get(4, false);
  set reverseOrderStreaming($core.bool v) { $_setBool(4, v); }
  $core.bool hasReverseOrderStreaming() => $_has(4);
  void clearReverseOrderStreaming() => clearField(5);

  $core.bool get rotateAllPages => $_get(5, false);
  set rotateAllPages($core.bool v) { $_setBool(5, v); }
  $core.bool hasRotateAllPages() => $_has(5);
  void clearRotateAllPages() => clearField(6);
}

class InputTrayUnit extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InputTrayUnit', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<InputTrayUnit_Type>(2, 'type', $pb.PbFieldType.OE, InputTrayUnit_Type.CUSTOM, InputTrayUnit_Type.valueOf, InputTrayUnit_Type.values)
    ..aInt64(3, 'index')
    ..aOS(4, 'customDisplayName')
    ..pc<LocalizedString>(5, 'customDisplayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  InputTrayUnit() : super();
  InputTrayUnit.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InputTrayUnit.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InputTrayUnit clone() => InputTrayUnit()..mergeFromMessage(this);
  InputTrayUnit copyWith(void Function(InputTrayUnit) updates) => super.copyWith((message) => updates(message as InputTrayUnit));
  $pb.BuilderInfo get info_ => _i;
  static InputTrayUnit create() => InputTrayUnit();
  InputTrayUnit createEmptyInstance() => create();
  static $pb.PbList<InputTrayUnit> createRepeated() => $pb.PbList<InputTrayUnit>();
  static InputTrayUnit getDefault() => _defaultInstance ??= create()..freeze();
  static InputTrayUnit _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  InputTrayUnit_Type get type => $_getN(1);
  set type(InputTrayUnit_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  Int64 get index => $_getI64(2);
  set index(Int64 v) { $_setInt64(2, v); }
  $core.bool hasIndex() => $_has(2);
  void clearIndex() => clearField(3);

  $core.String get customDisplayName => $_getS(3, '');
  set customDisplayName($core.String v) { $_setString(3, v); }
  $core.bool hasCustomDisplayName() => $_has(3);
  void clearCustomDisplayName() => clearField(4);

  $core.List<LocalizedString> get customDisplayNameLocalized => $_getList(4);
}

class OutputBinUnit extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('OutputBinUnit', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<OutputBinUnit_Type>(2, 'type', $pb.PbFieldType.OE, OutputBinUnit_Type.CUSTOM, OutputBinUnit_Type.valueOf, OutputBinUnit_Type.values)
    ..aInt64(3, 'index')
    ..aOS(4, 'customDisplayName')
    ..pc<LocalizedString>(5, 'customDisplayNameLocalized', $pb.PbFieldType.PM,LocalizedString.create)
    ..hasRequiredFields = false
  ;

  OutputBinUnit() : super();
  OutputBinUnit.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  OutputBinUnit.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  OutputBinUnit clone() => OutputBinUnit()..mergeFromMessage(this);
  OutputBinUnit copyWith(void Function(OutputBinUnit) updates) => super.copyWith((message) => updates(message as OutputBinUnit));
  $pb.BuilderInfo get info_ => _i;
  static OutputBinUnit create() => OutputBinUnit();
  OutputBinUnit createEmptyInstance() => create();
  static $pb.PbList<OutputBinUnit> createRepeated() => $pb.PbList<OutputBinUnit>();
  static OutputBinUnit getDefault() => _defaultInstance ??= create()..freeze();
  static OutputBinUnit _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  OutputBinUnit_Type get type => $_getN(1);
  set type(OutputBinUnit_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  Int64 get index => $_getI64(2);
  set index(Int64 v) { $_setInt64(2, v); }
  $core.bool hasIndex() => $_has(2);
  void clearIndex() => clearField(3);

  $core.String get customDisplayName => $_getS(3, '');
  set customDisplayName($core.String v) { $_setString(3, v); }
  $core.bool hasCustomDisplayName() => $_has(3);
  void clearCustomDisplayName() => clearField(4);

  $core.List<LocalizedString> get customDisplayNameLocalized => $_getList(4);
}

