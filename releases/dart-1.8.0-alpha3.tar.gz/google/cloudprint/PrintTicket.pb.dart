///
//  Generated code. Do not modify.
//  source: google/cloudprint/PrintTicket.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Common.pb.dart' as $30;

import 'Common.pbenum.dart' as $30;

class PrintTicketSection_VendorTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.VendorTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'id')
    ..aOS(2, 'value')
    ..hasRequiredFields = false
  ;

  PrintTicketSection_VendorTicketItem() : super();
  PrintTicketSection_VendorTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_VendorTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_VendorTicketItem clone() => PrintTicketSection_VendorTicketItem()..mergeFromMessage(this);
  PrintTicketSection_VendorTicketItem copyWith(void Function(PrintTicketSection_VendorTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_VendorTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_VendorTicketItem create() => PrintTicketSection_VendorTicketItem();
  PrintTicketSection_VendorTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_VendorTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_VendorTicketItem>();
  static PrintTicketSection_VendorTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_VendorTicketItem _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $core.String get value => $_getS(1, '');
  set value($core.String v) { $_setString(1, v); }
  $core.bool hasValue() => $_has(1);
  void clearValue() => clearField(2);
}

class PrintTicketSection_ColorTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.ColorTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..aOS(1, 'vendorId')
    ..e<$30.Color_Type>(2, 'type', $pb.PbFieldType.OE, $30.Color_Type.STANDARD_COLOR, $30.Color_Type.valueOf, $30.Color_Type.values)
    ..hasRequiredFields = false
  ;

  PrintTicketSection_ColorTicketItem() : super();
  PrintTicketSection_ColorTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_ColorTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_ColorTicketItem clone() => PrintTicketSection_ColorTicketItem()..mergeFromMessage(this);
  PrintTicketSection_ColorTicketItem copyWith(void Function(PrintTicketSection_ColorTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_ColorTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_ColorTicketItem create() => PrintTicketSection_ColorTicketItem();
  PrintTicketSection_ColorTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_ColorTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_ColorTicketItem>();
  static PrintTicketSection_ColorTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_ColorTicketItem _defaultInstance;

  $core.String get vendorId => $_getS(0, '');
  set vendorId($core.String v) { $_setString(0, v); }
  $core.bool hasVendorId() => $_has(0);
  void clearVendorId() => clearField(1);

  $30.Color_Type get type => $_getN(1);
  set type($30.Color_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);
}

class PrintTicketSection_DuplexTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.DuplexTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..e<$30.Duplex_Type>(1, 'type', $pb.PbFieldType.OE, $30.Duplex_Type.NO_DUPLEX, $30.Duplex_Type.valueOf, $30.Duplex_Type.values)
    ..hasRequiredFields = false
  ;

  PrintTicketSection_DuplexTicketItem() : super();
  PrintTicketSection_DuplexTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_DuplexTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_DuplexTicketItem clone() => PrintTicketSection_DuplexTicketItem()..mergeFromMessage(this);
  PrintTicketSection_DuplexTicketItem copyWith(void Function(PrintTicketSection_DuplexTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_DuplexTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_DuplexTicketItem create() => PrintTicketSection_DuplexTicketItem();
  PrintTicketSection_DuplexTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_DuplexTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_DuplexTicketItem>();
  static PrintTicketSection_DuplexTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_DuplexTicketItem _defaultInstance;

  $30.Duplex_Type get type => $_getN(0);
  set type($30.Duplex_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);
}

class PrintTicketSection_PageOrientationTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.PageOrientationTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..e<$30.PageOrientation_Type>(1, 'type', $pb.PbFieldType.OE, $30.PageOrientation_Type.PORTRAIT, $30.PageOrientation_Type.valueOf, $30.PageOrientation_Type.values)
    ..hasRequiredFields = false
  ;

  PrintTicketSection_PageOrientationTicketItem() : super();
  PrintTicketSection_PageOrientationTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_PageOrientationTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_PageOrientationTicketItem clone() => PrintTicketSection_PageOrientationTicketItem()..mergeFromMessage(this);
  PrintTicketSection_PageOrientationTicketItem copyWith(void Function(PrintTicketSection_PageOrientationTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_PageOrientationTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_PageOrientationTicketItem create() => PrintTicketSection_PageOrientationTicketItem();
  PrintTicketSection_PageOrientationTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_PageOrientationTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_PageOrientationTicketItem>();
  static PrintTicketSection_PageOrientationTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_PageOrientationTicketItem _defaultInstance;

  $30.PageOrientation_Type get type => $_getN(0);
  set type($30.PageOrientation_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);
}

class PrintTicketSection_CopiesTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.CopiesTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.int>(1, 'copies', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  PrintTicketSection_CopiesTicketItem() : super();
  PrintTicketSection_CopiesTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_CopiesTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_CopiesTicketItem clone() => PrintTicketSection_CopiesTicketItem()..mergeFromMessage(this);
  PrintTicketSection_CopiesTicketItem copyWith(void Function(PrintTicketSection_CopiesTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_CopiesTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_CopiesTicketItem create() => PrintTicketSection_CopiesTicketItem();
  PrintTicketSection_CopiesTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_CopiesTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_CopiesTicketItem>();
  static PrintTicketSection_CopiesTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_CopiesTicketItem _defaultInstance;

  $core.int get copies => $_get(0, 0);
  set copies($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasCopies() => $_has(0);
  void clearCopies() => clearField(1);
}

class PrintTicketSection_MarginsTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.MarginsTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.int>(1, 'topMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(2, 'rightMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(3, 'bottomMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(4, 'leftMicrons', $pb.PbFieldType.O3)
    ..hasRequiredFields = false
  ;

  PrintTicketSection_MarginsTicketItem() : super();
  PrintTicketSection_MarginsTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_MarginsTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_MarginsTicketItem clone() => PrintTicketSection_MarginsTicketItem()..mergeFromMessage(this);
  PrintTicketSection_MarginsTicketItem copyWith(void Function(PrintTicketSection_MarginsTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_MarginsTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_MarginsTicketItem create() => PrintTicketSection_MarginsTicketItem();
  PrintTicketSection_MarginsTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_MarginsTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_MarginsTicketItem>();
  static PrintTicketSection_MarginsTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_MarginsTicketItem _defaultInstance;

  $core.int get topMicrons => $_get(0, 0);
  set topMicrons($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasTopMicrons() => $_has(0);
  void clearTopMicrons() => clearField(1);

  $core.int get rightMicrons => $_get(1, 0);
  set rightMicrons($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasRightMicrons() => $_has(1);
  void clearRightMicrons() => clearField(2);

  $core.int get bottomMicrons => $_get(2, 0);
  set bottomMicrons($core.int v) { $_setSignedInt32(2, v); }
  $core.bool hasBottomMicrons() => $_has(2);
  void clearBottomMicrons() => clearField(3);

  $core.int get leftMicrons => $_get(3, 0);
  set leftMicrons($core.int v) { $_setSignedInt32(3, v); }
  $core.bool hasLeftMicrons() => $_has(3);
  void clearLeftMicrons() => clearField(4);
}

class PrintTicketSection_DpiTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.DpiTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.int>(1, 'horizontalDpi', $pb.PbFieldType.O3)
    ..a<$core.int>(2, 'verticalDpi', $pb.PbFieldType.O3)
    ..aOS(3, 'vendorId')
    ..hasRequiredFields = false
  ;

  PrintTicketSection_DpiTicketItem() : super();
  PrintTicketSection_DpiTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_DpiTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_DpiTicketItem clone() => PrintTicketSection_DpiTicketItem()..mergeFromMessage(this);
  PrintTicketSection_DpiTicketItem copyWith(void Function(PrintTicketSection_DpiTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_DpiTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_DpiTicketItem create() => PrintTicketSection_DpiTicketItem();
  PrintTicketSection_DpiTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_DpiTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_DpiTicketItem>();
  static PrintTicketSection_DpiTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_DpiTicketItem _defaultInstance;

  $core.int get horizontalDpi => $_get(0, 0);
  set horizontalDpi($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasHorizontalDpi() => $_has(0);
  void clearHorizontalDpi() => clearField(1);

  $core.int get verticalDpi => $_get(1, 0);
  set verticalDpi($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasVerticalDpi() => $_has(1);
  void clearVerticalDpi() => clearField(2);

  $core.String get vendorId => $_getS(2, '');
  set vendorId($core.String v) { $_setString(2, v); }
  $core.bool hasVendorId() => $_has(2);
  void clearVendorId() => clearField(3);
}

class PrintTicketSection_FitToPageTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.FitToPageTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..e<$30.FitToPage_Type>(1, 'type', $pb.PbFieldType.OE, $30.FitToPage_Type.NO_FITTING, $30.FitToPage_Type.valueOf, $30.FitToPage_Type.values)
    ..hasRequiredFields = false
  ;

  PrintTicketSection_FitToPageTicketItem() : super();
  PrintTicketSection_FitToPageTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_FitToPageTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_FitToPageTicketItem clone() => PrintTicketSection_FitToPageTicketItem()..mergeFromMessage(this);
  PrintTicketSection_FitToPageTicketItem copyWith(void Function(PrintTicketSection_FitToPageTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_FitToPageTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_FitToPageTicketItem create() => PrintTicketSection_FitToPageTicketItem();
  PrintTicketSection_FitToPageTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_FitToPageTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_FitToPageTicketItem>();
  static PrintTicketSection_FitToPageTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_FitToPageTicketItem _defaultInstance;

  $30.FitToPage_Type get type => $_getN(0);
  set type($30.FitToPage_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);
}

class PrintTicketSection_PageRangeTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.PageRangeTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..pc<$30.PageRange_Interval>(1, 'interval', $pb.PbFieldType.PM,$30.PageRange_Interval.create)
    ..hasRequiredFields = false
  ;

  PrintTicketSection_PageRangeTicketItem() : super();
  PrintTicketSection_PageRangeTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_PageRangeTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_PageRangeTicketItem clone() => PrintTicketSection_PageRangeTicketItem()..mergeFromMessage(this);
  PrintTicketSection_PageRangeTicketItem copyWith(void Function(PrintTicketSection_PageRangeTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_PageRangeTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_PageRangeTicketItem create() => PrintTicketSection_PageRangeTicketItem();
  PrintTicketSection_PageRangeTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_PageRangeTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_PageRangeTicketItem>();
  static PrintTicketSection_PageRangeTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_PageRangeTicketItem _defaultInstance;

  $core.List<$30.PageRange_Interval> get interval => $_getList(0);
}

class PrintTicketSection_MediaSizeTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.MediaSizeTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..a<$core.int>(1, 'widthMicrons', $pb.PbFieldType.O3)
    ..a<$core.int>(2, 'heightMicrons', $pb.PbFieldType.O3)
    ..aOB(3, 'isContinuousFeed')
    ..aOS(4, 'vendorId')
    ..hasRequiredFields = false
  ;

  PrintTicketSection_MediaSizeTicketItem() : super();
  PrintTicketSection_MediaSizeTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_MediaSizeTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_MediaSizeTicketItem clone() => PrintTicketSection_MediaSizeTicketItem()..mergeFromMessage(this);
  PrintTicketSection_MediaSizeTicketItem copyWith(void Function(PrintTicketSection_MediaSizeTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_MediaSizeTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_MediaSizeTicketItem create() => PrintTicketSection_MediaSizeTicketItem();
  PrintTicketSection_MediaSizeTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_MediaSizeTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_MediaSizeTicketItem>();
  static PrintTicketSection_MediaSizeTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_MediaSizeTicketItem _defaultInstance;

  $core.int get widthMicrons => $_get(0, 0);
  set widthMicrons($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasWidthMicrons() => $_has(0);
  void clearWidthMicrons() => clearField(1);

  $core.int get heightMicrons => $_get(1, 0);
  set heightMicrons($core.int v) { $_setSignedInt32(1, v); }
  $core.bool hasHeightMicrons() => $_has(1);
  void clearHeightMicrons() => clearField(2);

  $core.bool get isContinuousFeed => $_get(2, false);
  set isContinuousFeed($core.bool v) { $_setBool(2, v); }
  $core.bool hasIsContinuousFeed() => $_has(2);
  void clearIsContinuousFeed() => clearField(3);

  $core.String get vendorId => $_getS(3, '');
  set vendorId($core.String v) { $_setString(3, v); }
  $core.bool hasVendorId() => $_has(3);
  void clearVendorId() => clearField(4);
}

class PrintTicketSection_CollateTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.CollateTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'collate')
    ..hasRequiredFields = false
  ;

  PrintTicketSection_CollateTicketItem() : super();
  PrintTicketSection_CollateTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_CollateTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_CollateTicketItem clone() => PrintTicketSection_CollateTicketItem()..mergeFromMessage(this);
  PrintTicketSection_CollateTicketItem copyWith(void Function(PrintTicketSection_CollateTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_CollateTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_CollateTicketItem create() => PrintTicketSection_CollateTicketItem();
  PrintTicketSection_CollateTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_CollateTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_CollateTicketItem>();
  static PrintTicketSection_CollateTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_CollateTicketItem _defaultInstance;

  $core.bool get collate => $_get(0, false);
  set collate($core.bool v) { $_setBool(0, v); }
  $core.bool hasCollate() => $_has(0);
  void clearCollate() => clearField(1);
}

class PrintTicketSection_ReverseOrderTicketItem extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection.ReverseOrderTicketItem', package: const $pb.PackageName('google.cloudprint'))
    ..aOB(1, 'reverseOrder')
    ..hasRequiredFields = false
  ;

  PrintTicketSection_ReverseOrderTicketItem() : super();
  PrintTicketSection_ReverseOrderTicketItem.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection_ReverseOrderTicketItem.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection_ReverseOrderTicketItem clone() => PrintTicketSection_ReverseOrderTicketItem()..mergeFromMessage(this);
  PrintTicketSection_ReverseOrderTicketItem copyWith(void Function(PrintTicketSection_ReverseOrderTicketItem) updates) => super.copyWith((message) => updates(message as PrintTicketSection_ReverseOrderTicketItem));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection_ReverseOrderTicketItem create() => PrintTicketSection_ReverseOrderTicketItem();
  PrintTicketSection_ReverseOrderTicketItem createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection_ReverseOrderTicketItem> createRepeated() => $pb.PbList<PrintTicketSection_ReverseOrderTicketItem>();
  static PrintTicketSection_ReverseOrderTicketItem getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection_ReverseOrderTicketItem _defaultInstance;

  $core.bool get reverseOrder => $_get(0, false);
  set reverseOrder($core.bool v) { $_setBool(0, v); }
  $core.bool hasReverseOrder() => $_has(0);
  void clearReverseOrder() => clearField(1);
}

class PrintTicketSection extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintTicketSection', package: const $pb.PackageName('google.cloudprint'))
    ..pc<PrintTicketSection_VendorTicketItem>(1, 'vendorTicketItem', $pb.PbFieldType.PM,PrintTicketSection_VendorTicketItem.create)
    ..a<PrintTicketSection_ColorTicketItem>(2, 'color', $pb.PbFieldType.OM, PrintTicketSection_ColorTicketItem.getDefault, PrintTicketSection_ColorTicketItem.create)
    ..a<PrintTicketSection_DuplexTicketItem>(3, 'duplex', $pb.PbFieldType.OM, PrintTicketSection_DuplexTicketItem.getDefault, PrintTicketSection_DuplexTicketItem.create)
    ..a<PrintTicketSection_PageOrientationTicketItem>(4, 'pageOrientation', $pb.PbFieldType.OM, PrintTicketSection_PageOrientationTicketItem.getDefault, PrintTicketSection_PageOrientationTicketItem.create)
    ..a<PrintTicketSection_CopiesTicketItem>(5, 'copies', $pb.PbFieldType.OM, PrintTicketSection_CopiesTicketItem.getDefault, PrintTicketSection_CopiesTicketItem.create)
    ..a<PrintTicketSection_MarginsTicketItem>(6, 'margins', $pb.PbFieldType.OM, PrintTicketSection_MarginsTicketItem.getDefault, PrintTicketSection_MarginsTicketItem.create)
    ..a<PrintTicketSection_DpiTicketItem>(7, 'dpi', $pb.PbFieldType.OM, PrintTicketSection_DpiTicketItem.getDefault, PrintTicketSection_DpiTicketItem.create)
    ..a<PrintTicketSection_FitToPageTicketItem>(8, 'fitToPage', $pb.PbFieldType.OM, PrintTicketSection_FitToPageTicketItem.getDefault, PrintTicketSection_FitToPageTicketItem.create)
    ..a<PrintTicketSection_PageRangeTicketItem>(9, 'pageRange', $pb.PbFieldType.OM, PrintTicketSection_PageRangeTicketItem.getDefault, PrintTicketSection_PageRangeTicketItem.create)
    ..a<PrintTicketSection_MediaSizeTicketItem>(10, 'mediaSize', $pb.PbFieldType.OM, PrintTicketSection_MediaSizeTicketItem.getDefault, PrintTicketSection_MediaSizeTicketItem.create)
    ..a<PrintTicketSection_CollateTicketItem>(11, 'collate', $pb.PbFieldType.OM, PrintTicketSection_CollateTicketItem.getDefault, PrintTicketSection_CollateTicketItem.create)
    ..a<PrintTicketSection_ReverseOrderTicketItem>(12, 'reverseOrder', $pb.PbFieldType.OM, PrintTicketSection_ReverseOrderTicketItem.getDefault, PrintTicketSection_ReverseOrderTicketItem.create)
    ..hasRequiredFields = false
  ;

  PrintTicketSection() : super();
  PrintTicketSection.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintTicketSection.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintTicketSection clone() => PrintTicketSection()..mergeFromMessage(this);
  PrintTicketSection copyWith(void Function(PrintTicketSection) updates) => super.copyWith((message) => updates(message as PrintTicketSection));
  $pb.BuilderInfo get info_ => _i;
  static PrintTicketSection create() => PrintTicketSection();
  PrintTicketSection createEmptyInstance() => create();
  static $pb.PbList<PrintTicketSection> createRepeated() => $pb.PbList<PrintTicketSection>();
  static PrintTicketSection getDefault() => _defaultInstance ??= create()..freeze();
  static PrintTicketSection _defaultInstance;

  $core.List<PrintTicketSection_VendorTicketItem> get vendorTicketItem => $_getList(0);

  PrintTicketSection_ColorTicketItem get color => $_getN(1);
  set color(PrintTicketSection_ColorTicketItem v) { setField(2, v); }
  $core.bool hasColor() => $_has(1);
  void clearColor() => clearField(2);

  PrintTicketSection_DuplexTicketItem get duplex => $_getN(2);
  set duplex(PrintTicketSection_DuplexTicketItem v) { setField(3, v); }
  $core.bool hasDuplex() => $_has(2);
  void clearDuplex() => clearField(3);

  PrintTicketSection_PageOrientationTicketItem get pageOrientation => $_getN(3);
  set pageOrientation(PrintTicketSection_PageOrientationTicketItem v) { setField(4, v); }
  $core.bool hasPageOrientation() => $_has(3);
  void clearPageOrientation() => clearField(4);

  PrintTicketSection_CopiesTicketItem get copies => $_getN(4);
  set copies(PrintTicketSection_CopiesTicketItem v) { setField(5, v); }
  $core.bool hasCopies() => $_has(4);
  void clearCopies() => clearField(5);

  PrintTicketSection_MarginsTicketItem get margins => $_getN(5);
  set margins(PrintTicketSection_MarginsTicketItem v) { setField(6, v); }
  $core.bool hasMargins() => $_has(5);
  void clearMargins() => clearField(6);

  PrintTicketSection_DpiTicketItem get dpi => $_getN(6);
  set dpi(PrintTicketSection_DpiTicketItem v) { setField(7, v); }
  $core.bool hasDpi() => $_has(6);
  void clearDpi() => clearField(7);

  PrintTicketSection_FitToPageTicketItem get fitToPage => $_getN(7);
  set fitToPage(PrintTicketSection_FitToPageTicketItem v) { setField(8, v); }
  $core.bool hasFitToPage() => $_has(7);
  void clearFitToPage() => clearField(8);

  PrintTicketSection_PageRangeTicketItem get pageRange => $_getN(8);
  set pageRange(PrintTicketSection_PageRangeTicketItem v) { setField(9, v); }
  $core.bool hasPageRange() => $_has(8);
  void clearPageRange() => clearField(9);

  PrintTicketSection_MediaSizeTicketItem get mediaSize => $_getN(9);
  set mediaSize(PrintTicketSection_MediaSizeTicketItem v) { setField(10, v); }
  $core.bool hasMediaSize() => $_has(9);
  void clearMediaSize() => clearField(10);

  PrintTicketSection_CollateTicketItem get collate => $_getN(10);
  set collate(PrintTicketSection_CollateTicketItem v) { setField(11, v); }
  $core.bool hasCollate() => $_has(10);
  void clearCollate() => clearField(11);

  PrintTicketSection_ReverseOrderTicketItem get reverseOrder => $_getN(11);
  set reverseOrder(PrintTicketSection_ReverseOrderTicketItem v) { setField(12, v); }
  $core.bool hasReverseOrder() => $_has(11);
  void clearReverseOrder() => clearField(12);
}

