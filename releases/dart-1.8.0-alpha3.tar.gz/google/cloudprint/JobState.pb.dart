///
//  Generated code. Do not modify.
//  source: google/cloudprint/JobState.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'JobState.pbenum.dart';

export 'JobState.pbenum.dart';

class JobState_UserActionCause extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('JobState.UserActionCause', package: const $pb.PackageName('google.cloudprint'))
    ..e<JobState_UserActionCause_ActionCode>(1, 'actionCode', $pb.PbFieldType.OE, JobState_UserActionCause_ActionCode.CANCELLED, JobState_UserActionCause_ActionCode.valueOf, JobState_UserActionCause_ActionCode.values)
    ..hasRequiredFields = false
  ;

  JobState_UserActionCause() : super();
  JobState_UserActionCause.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  JobState_UserActionCause.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  JobState_UserActionCause clone() => JobState_UserActionCause()..mergeFromMessage(this);
  JobState_UserActionCause copyWith(void Function(JobState_UserActionCause) updates) => super.copyWith((message) => updates(message as JobState_UserActionCause));
  $pb.BuilderInfo get info_ => _i;
  static JobState_UserActionCause create() => JobState_UserActionCause();
  JobState_UserActionCause createEmptyInstance() => create();
  static $pb.PbList<JobState_UserActionCause> createRepeated() => $pb.PbList<JobState_UserActionCause>();
  static JobState_UserActionCause getDefault() => _defaultInstance ??= create()..freeze();
  static JobState_UserActionCause _defaultInstance;

  JobState_UserActionCause_ActionCode get actionCode => $_getN(0);
  set actionCode(JobState_UserActionCause_ActionCode v) { setField(1, v); }
  $core.bool hasActionCode() => $_has(0);
  void clearActionCode() => clearField(1);
}

class JobState_DeviceStateCause extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('JobState.DeviceStateCause', package: const $pb.PackageName('google.cloudprint'))
    ..e<JobState_DeviceStateCause_ErrorCode>(1, 'errorCode', $pb.PbFieldType.OE, JobState_DeviceStateCause_ErrorCode.INPUT_TRAY, JobState_DeviceStateCause_ErrorCode.valueOf, JobState_DeviceStateCause_ErrorCode.values)
    ..hasRequiredFields = false
  ;

  JobState_DeviceStateCause() : super();
  JobState_DeviceStateCause.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  JobState_DeviceStateCause.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  JobState_DeviceStateCause clone() => JobState_DeviceStateCause()..mergeFromMessage(this);
  JobState_DeviceStateCause copyWith(void Function(JobState_DeviceStateCause) updates) => super.copyWith((message) => updates(message as JobState_DeviceStateCause));
  $pb.BuilderInfo get info_ => _i;
  static JobState_DeviceStateCause create() => JobState_DeviceStateCause();
  JobState_DeviceStateCause createEmptyInstance() => create();
  static $pb.PbList<JobState_DeviceStateCause> createRepeated() => $pb.PbList<JobState_DeviceStateCause>();
  static JobState_DeviceStateCause getDefault() => _defaultInstance ??= create()..freeze();
  static JobState_DeviceStateCause _defaultInstance;

  JobState_DeviceStateCause_ErrorCode get errorCode => $_getN(0);
  set errorCode(JobState_DeviceStateCause_ErrorCode v) { setField(1, v); }
  $core.bool hasErrorCode() => $_has(0);
  void clearErrorCode() => clearField(1);
}

class JobState_DeviceActionCause extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('JobState.DeviceActionCause', package: const $pb.PackageName('google.cloudprint'))
    ..e<JobState_DeviceActionCause_ErrorCode>(1, 'errorCode', $pb.PbFieldType.OE, JobState_DeviceActionCause_ErrorCode.DOWNLOAD_FAILURE, JobState_DeviceActionCause_ErrorCode.valueOf, JobState_DeviceActionCause_ErrorCode.values)
    ..hasRequiredFields = false
  ;

  JobState_DeviceActionCause() : super();
  JobState_DeviceActionCause.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  JobState_DeviceActionCause.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  JobState_DeviceActionCause clone() => JobState_DeviceActionCause()..mergeFromMessage(this);
  JobState_DeviceActionCause copyWith(void Function(JobState_DeviceActionCause) updates) => super.copyWith((message) => updates(message as JobState_DeviceActionCause));
  $pb.BuilderInfo get info_ => _i;
  static JobState_DeviceActionCause create() => JobState_DeviceActionCause();
  JobState_DeviceActionCause createEmptyInstance() => create();
  static $pb.PbList<JobState_DeviceActionCause> createRepeated() => $pb.PbList<JobState_DeviceActionCause>();
  static JobState_DeviceActionCause getDefault() => _defaultInstance ??= create()..freeze();
  static JobState_DeviceActionCause _defaultInstance;

  JobState_DeviceActionCause_ErrorCode get errorCode => $_getN(0);
  set errorCode(JobState_DeviceActionCause_ErrorCode v) { setField(1, v); }
  $core.bool hasErrorCode() => $_has(0);
  void clearErrorCode() => clearField(1);
}

class JobState_ServiceActionCause extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('JobState.ServiceActionCause', package: const $pb.PackageName('google.cloudprint'))
    ..e<JobState_ServiceActionCause_ErrorCode>(1, 'errorCode', $pb.PbFieldType.OE, JobState_ServiceActionCause_ErrorCode.COMMUNICATION_WITH_DEVICE_ERROR, JobState_ServiceActionCause_ErrorCode.valueOf, JobState_ServiceActionCause_ErrorCode.values)
    ..hasRequiredFields = false
  ;

  JobState_ServiceActionCause() : super();
  JobState_ServiceActionCause.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  JobState_ServiceActionCause.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  JobState_ServiceActionCause clone() => JobState_ServiceActionCause()..mergeFromMessage(this);
  JobState_ServiceActionCause copyWith(void Function(JobState_ServiceActionCause) updates) => super.copyWith((message) => updates(message as JobState_ServiceActionCause));
  $pb.BuilderInfo get info_ => _i;
  static JobState_ServiceActionCause create() => JobState_ServiceActionCause();
  JobState_ServiceActionCause createEmptyInstance() => create();
  static $pb.PbList<JobState_ServiceActionCause> createRepeated() => $pb.PbList<JobState_ServiceActionCause>();
  static JobState_ServiceActionCause getDefault() => _defaultInstance ??= create()..freeze();
  static JobState_ServiceActionCause _defaultInstance;

  JobState_ServiceActionCause_ErrorCode get errorCode => $_getN(0);
  set errorCode(JobState_ServiceActionCause_ErrorCode v) { setField(1, v); }
  $core.bool hasErrorCode() => $_has(0);
  void clearErrorCode() => clearField(1);
}

class JobState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('JobState', package: const $pb.PackageName('google.cloudprint'))
    ..e<JobState_Type>(1, 'type', $pb.PbFieldType.OE, JobState_Type.DRAFT, JobState_Type.valueOf, JobState_Type.values)
    ..a<JobState_UserActionCause>(2, 'userActionCause', $pb.PbFieldType.OM, JobState_UserActionCause.getDefault, JobState_UserActionCause.create)
    ..a<JobState_DeviceStateCause>(3, 'deviceStateCause', $pb.PbFieldType.OM, JobState_DeviceStateCause.getDefault, JobState_DeviceStateCause.create)
    ..a<JobState_DeviceActionCause>(4, 'deviceActionCause', $pb.PbFieldType.OM, JobState_DeviceActionCause.getDefault, JobState_DeviceActionCause.create)
    ..a<JobState_ServiceActionCause>(5, 'serviceActionCause', $pb.PbFieldType.OM, JobState_ServiceActionCause.getDefault, JobState_ServiceActionCause.create)
    ..hasRequiredFields = false
  ;

  JobState() : super();
  JobState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  JobState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  JobState clone() => JobState()..mergeFromMessage(this);
  JobState copyWith(void Function(JobState) updates) => super.copyWith((message) => updates(message as JobState));
  $pb.BuilderInfo get info_ => _i;
  static JobState create() => JobState();
  JobState createEmptyInstance() => create();
  static $pb.PbList<JobState> createRepeated() => $pb.PbList<JobState>();
  static JobState getDefault() => _defaultInstance ??= create()..freeze();
  static JobState _defaultInstance;

  JobState_Type get type => $_getN(0);
  set type(JobState_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  JobState_UserActionCause get userActionCause => $_getN(1);
  set userActionCause(JobState_UserActionCause v) { setField(2, v); }
  $core.bool hasUserActionCause() => $_has(1);
  void clearUserActionCause() => clearField(2);

  JobState_DeviceStateCause get deviceStateCause => $_getN(2);
  set deviceStateCause(JobState_DeviceStateCause v) { setField(3, v); }
  $core.bool hasDeviceStateCause() => $_has(2);
  void clearDeviceStateCause() => clearField(3);

  JobState_DeviceActionCause get deviceActionCause => $_getN(3);
  set deviceActionCause(JobState_DeviceActionCause v) { setField(4, v); }
  $core.bool hasDeviceActionCause() => $_has(3);
  void clearDeviceActionCause() => clearField(4);

  JobState_ServiceActionCause get serviceActionCause => $_getN(4);
  set serviceActionCause(JobState_ServiceActionCause v) { setField(5, v); }
  $core.bool hasServiceActionCause() => $_has(4);
  void clearServiceActionCause() => clearField(5);
}

class PrintJobUiState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PrintJobUiState', package: const $pb.PackageName('google.cloudprint'))
    ..e<PrintJobUiState_Summary>(1, 'summary', $pb.PbFieldType.OE, PrintJobUiState_Summary.DRAFT, PrintJobUiState_Summary.valueOf, PrintJobUiState_Summary.values)
    ..aOS(2, 'progress')
    ..aOS(3, 'cause')
    ..hasRequiredFields = false
  ;

  PrintJobUiState() : super();
  PrintJobUiState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PrintJobUiState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PrintJobUiState clone() => PrintJobUiState()..mergeFromMessage(this);
  PrintJobUiState copyWith(void Function(PrintJobUiState) updates) => super.copyWith((message) => updates(message as PrintJobUiState));
  $pb.BuilderInfo get info_ => _i;
  static PrintJobUiState create() => PrintJobUiState();
  PrintJobUiState createEmptyInstance() => create();
  static $pb.PbList<PrintJobUiState> createRepeated() => $pb.PbList<PrintJobUiState>();
  static PrintJobUiState getDefault() => _defaultInstance ??= create()..freeze();
  static PrintJobUiState _defaultInstance;

  PrintJobUiState_Summary get summary => $_getN(0);
  set summary(PrintJobUiState_Summary v) { setField(1, v); }
  $core.bool hasSummary() => $_has(0);
  void clearSummary() => clearField(1);

  $core.String get progress => $_getS(1, '');
  set progress($core.String v) { $_setString(1, v); }
  $core.bool hasProgress() => $_has(1);
  void clearProgress() => clearField(2);

  $core.String get cause => $_getS(2, '');
  set cause($core.String v) { $_setString(2, v); }
  $core.bool hasCause() => $_has(2);
  void clearCause() => clearField(3);
}

