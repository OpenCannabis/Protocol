///
//  Generated code. Do not modify.
//  source: inventory/InventoryProduct.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $16;
import '../temporal/Instant.pb.dart' as $0;
import '../commerce/Item.pb.dart' as $20;
import '../products/menu/Menu.pb.dart' as $66;

import '../structs/pricing/PricingDescriptor.pbenum.dart' as $17;
import 'InventoryProduct.pbenum.dart';

export 'InventoryProduct.pbenum.dart';

class InventoryKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InventoryKey', package: const $pb.PackageName('opencannabis.inventory'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..aOS(2, 'uuid')
    ..hasRequiredFields = false
  ;

  InventoryKey() : super();
  InventoryKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InventoryKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InventoryKey clone() => InventoryKey()..mergeFromMessage(this);
  InventoryKey copyWith(void Function(InventoryKey) updates) => super.copyWith((message) => updates(message as InventoryKey));
  $pb.BuilderInfo get info_ => _i;
  static InventoryKey create() => InventoryKey();
  InventoryKey createEmptyInstance() => create();
  static $pb.PbList<InventoryKey> createRepeated() => $pb.PbList<InventoryKey>();
  static InventoryKey getDefault() => _defaultInstance ??= create()..freeze();
  static InventoryKey _defaultInstance;

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $core.String get uuid => $_getS(1, '');
  set uuid($core.String v) { $_setString(1, v); }
  $core.bool hasUuid() => $_has(1);
  void clearUuid() => clearField(2);
}

class InventoryCoordinates extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InventoryCoordinates', package: const $pb.PackageName('opencannabis.inventory'))
    ..aOS(1, 'location')
    ..aOS(2, 'zone')
    ..aOS(3, 'rack')
    ..aOS(4, 'shelf')
    ..aOS(5, 'bin')
    ..aOS(6, 'batch')
    ..hasRequiredFields = false
  ;

  InventoryCoordinates() : super();
  InventoryCoordinates.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InventoryCoordinates.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InventoryCoordinates clone() => InventoryCoordinates()..mergeFromMessage(this);
  InventoryCoordinates copyWith(void Function(InventoryCoordinates) updates) => super.copyWith((message) => updates(message as InventoryCoordinates));
  $pb.BuilderInfo get info_ => _i;
  static InventoryCoordinates create() => InventoryCoordinates();
  InventoryCoordinates createEmptyInstance() => create();
  static $pb.PbList<InventoryCoordinates> createRepeated() => $pb.PbList<InventoryCoordinates>();
  static InventoryCoordinates getDefault() => _defaultInstance ??= create()..freeze();
  static InventoryCoordinates _defaultInstance;

  $core.String get location => $_getS(0, '');
  set location($core.String v) { $_setString(0, v); }
  $core.bool hasLocation() => $_has(0);
  void clearLocation() => clearField(1);

  $core.String get zone => $_getS(1, '');
  set zone($core.String v) { $_setString(1, v); }
  $core.bool hasZone() => $_has(1);
  void clearZone() => clearField(2);

  $core.String get rack => $_getS(2, '');
  set rack($core.String v) { $_setString(2, v); }
  $core.bool hasRack() => $_has(2);
  void clearRack() => clearField(3);

  $core.String get shelf => $_getS(3, '');
  set shelf($core.String v) { $_setString(3, v); }
  $core.bool hasShelf() => $_has(3);
  void clearShelf() => clearField(4);

  $core.String get bin => $_getS(4, '');
  set bin($core.String v) { $_setString(4, v); }
  $core.bool hasBin() => $_has(4);
  void clearBin() => clearField(5);

  $core.String get batch => $_getS(5, '');
  set batch($core.String v) { $_setString(5, v); }
  $core.bool hasBatch() => $_has(5);
  void clearBatch() => clearField(6);
}

enum InventoryAmount_Basis {
  unit, 
  weight, 
  notSet
}

class InventoryAmount extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, InventoryAmount_Basis> _InventoryAmount_BasisByTag = {
    2 : InventoryAmount_Basis.unit,
    3 : InventoryAmount_Basis.weight,
    0 : InventoryAmount_Basis.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InventoryAmount', package: const $pb.PackageName('opencannabis.inventory'))
    ..e<$17.PricingType>(1, 'type', $pb.PbFieldType.OE, $17.PricingType.UNIT, $17.PricingType.valueOf, $17.PricingType.values)
    ..aOB(2, 'unit')
    ..e<$17.PricingWeightTier>(3, 'weight', $pb.PbFieldType.OE, $17.PricingWeightTier.NO_WEIGHT, $17.PricingWeightTier.valueOf, $17.PricingWeightTier.values)
    ..a<Int64>(4, 'quantity', $pb.PbFieldType.OU6, Int64.ZERO)
    ..oo(0, [2, 3])
    ..hasRequiredFields = false
  ;

  InventoryAmount() : super();
  InventoryAmount.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InventoryAmount.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InventoryAmount clone() => InventoryAmount()..mergeFromMessage(this);
  InventoryAmount copyWith(void Function(InventoryAmount) updates) => super.copyWith((message) => updates(message as InventoryAmount));
  $pb.BuilderInfo get info_ => _i;
  static InventoryAmount create() => InventoryAmount();
  InventoryAmount createEmptyInstance() => create();
  static $pb.PbList<InventoryAmount> createRepeated() => $pb.PbList<InventoryAmount>();
  static InventoryAmount getDefault() => _defaultInstance ??= create()..freeze();
  static InventoryAmount _defaultInstance;

  InventoryAmount_Basis whichBasis() => _InventoryAmount_BasisByTag[$_whichOneof(0)];
  void clearBasis() => clearField($_whichOneof(0));

  $17.PricingType get type => $_getN(0);
  set type($17.PricingType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.bool get unit => $_get(1, false);
  set unit($core.bool v) { $_setBool(1, v); }
  $core.bool hasUnit() => $_has(1);
  void clearUnit() => clearField(2);

  $17.PricingWeightTier get weight => $_getN(2);
  set weight($17.PricingWeightTier v) { setField(3, v); }
  $core.bool hasWeight() => $_has(2);
  void clearWeight() => clearField(3);

  Int64 get quantity => $_getI64(3);
  set quantity(Int64 v) { $_setInt64(3, v); }
  $core.bool hasQuantity() => $_has(3);
  void clearQuantity() => clearField(4);
}

class InventoryState extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InventoryState', package: const $pb.PackageName('opencannabis.inventory'))
    ..e<InventoryState_Status>(1, 'status', $pb.PbFieldType.OE, InventoryState_Status.UNRECONCILED, InventoryState_Status.valueOf, InventoryState_Status.values)
    ..a<InventoryCoordinates>(2, 'coordinates', $pb.PbFieldType.OM, InventoryCoordinates.getDefault, InventoryCoordinates.create)
    ..aOB(3, 'fitForSale')
    ..a<InventoryAmount>(4, 'amount', $pb.PbFieldType.OM, InventoryAmount.getDefault, InventoryAmount.create)
    ..a<$0.Instant>(98, 'created', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(99, 'modified', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..hasRequiredFields = false
  ;

  InventoryState() : super();
  InventoryState.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InventoryState.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InventoryState clone() => InventoryState()..mergeFromMessage(this);
  InventoryState copyWith(void Function(InventoryState) updates) => super.copyWith((message) => updates(message as InventoryState));
  $pb.BuilderInfo get info_ => _i;
  static InventoryState create() => InventoryState();
  InventoryState createEmptyInstance() => create();
  static $pb.PbList<InventoryState> createRepeated() => $pb.PbList<InventoryState>();
  static InventoryState getDefault() => _defaultInstance ??= create()..freeze();
  static InventoryState _defaultInstance;

  InventoryState_Status get status => $_getN(0);
  set status(InventoryState_Status v) { setField(1, v); }
  $core.bool hasStatus() => $_has(0);
  void clearStatus() => clearField(1);

  InventoryCoordinates get coordinates => $_getN(1);
  set coordinates(InventoryCoordinates v) { setField(2, v); }
  $core.bool hasCoordinates() => $_has(1);
  void clearCoordinates() => clearField(2);

  $core.bool get fitForSale => $_get(2, false);
  set fitForSale($core.bool v) { $_setBool(2, v); }
  $core.bool hasFitForSale() => $_has(2);
  void clearFitForSale() => clearField(3);

  InventoryAmount get amount => $_getN(3);
  set amount(InventoryAmount v) { setField(4, v); }
  $core.bool hasAmount() => $_has(3);
  void clearAmount() => clearField(4);

  $0.Instant get created => $_getN(4);
  set created($0.Instant v) { setField(98, v); }
  $core.bool hasCreated() => $_has(4);
  void clearCreated() => clearField(98);

  $0.Instant get modified => $_getN(5);
  set modified($0.Instant v) { setField(99, v); }
  $core.bool hasModified() => $_has(5);
  void clearModified() => clearField(99);
}

class InventoryProduct extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InventoryProduct', package: const $pb.PackageName('opencannabis.inventory'))
    ..a<InventoryKey>(1, 'key', $pb.PbFieldType.OM, InventoryKey.getDefault, InventoryKey.create)
    ..pPS(2, 'sku')
    ..pc<$20.VariantSpec>(3, 'variant', $pb.PbFieldType.PM,$20.VariantSpec.create)
    ..a<InventoryState>(10, 'state', $pb.PbFieldType.OM, InventoryState.getDefault, InventoryState.create)
    ..pc<InventoryState>(11, 'history', $pb.PbFieldType.PM,InventoryState.create)
    ..a<$66.MenuProduct>(20, 'item', $pb.PbFieldType.OM, $66.MenuProduct.getDefault, $66.MenuProduct.create)
    ..hasRequiredFields = false
  ;

  InventoryProduct() : super();
  InventoryProduct.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InventoryProduct.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InventoryProduct clone() => InventoryProduct()..mergeFromMessage(this);
  InventoryProduct copyWith(void Function(InventoryProduct) updates) => super.copyWith((message) => updates(message as InventoryProduct));
  $pb.BuilderInfo get info_ => _i;
  static InventoryProduct create() => InventoryProduct();
  InventoryProduct createEmptyInstance() => create();
  static $pb.PbList<InventoryProduct> createRepeated() => $pb.PbList<InventoryProduct>();
  static InventoryProduct getDefault() => _defaultInstance ??= create()..freeze();
  static InventoryProduct _defaultInstance;

  InventoryKey get key => $_getN(0);
  set key(InventoryKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $core.List<$core.String> get sku => $_getList(1);

  $core.List<$20.VariantSpec> get variant => $_getList(2);

  InventoryState get state => $_getN(3);
  set state(InventoryState v) { setField(10, v); }
  $core.bool hasState() => $_has(3);
  void clearState() => clearField(10);

  $core.List<InventoryState> get history => $_getList(4);

  $66.MenuProduct get item => $_getN(5);
  set item($66.MenuProduct v) { setField(20, v); }
  $core.bool hasItem() => $_has(5);
  void clearItem() => clearField(20);
}

