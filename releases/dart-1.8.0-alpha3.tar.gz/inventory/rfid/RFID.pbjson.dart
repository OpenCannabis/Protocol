///
//  Generated code. Do not modify.
//  source: inventory/rfid/RFID.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ReaderVendor$json = const {
  '1': 'ReaderVendor',
  '2': const [
    const {'1': 'UNRECOGNIZED_VENDOR', '2': 0},
    const {'1': 'IMPINJ', '2': 25882},
    const {'1': 'ALIEN', '2': 2},
  ],
};

const ReaderModel$json = const {
  '1': 'ReaderModel',
  '2': const [
    const {'1': 'UNRECOGNIZED_READER', '2': 0},
    const {'1': 'SPEEDWAY_R120', '2': 1},
    const {'1': 'SPEEDWAY_R220', '2': 2},
    const {'1': 'SPEEDWAY_R420', '2': 2001002},
    const {'1': 'SPEEDWAY_XPORTAL', '2': 4},
    const {'1': 'ALIEN_ALRH450', '2': 5},
    const {'1': 'ALIEN_F800', '2': 6},
    const {'1': 'ALIEN_ALR9680', '2': 7},
  ],
};

const Reader$json = const {
  '1': 'Reader',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'name'},
    const {'1': 'mac', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'mac'},
    const {'1': 'ip', '3': 3, '4': 1, '5': 9, '8': const {}, '10': 'ip'},
    const {'1': 'vendor', '3': 4, '4': 1, '5': 14, '6': '.opencannabis.inventory.rfid.ReaderVendor', '8': const {}, '10': 'vendor'},
    const {'1': 'model', '3': 5, '4': 1, '5': 14, '6': '.opencannabis.inventory.rfid.ReaderModel', '8': const {}, '10': 'model'},
  ],
};

const Antenna$json = const {
  '1': 'Antenna',
  '2': const [
    const {'1': 'index', '3': 1, '4': 1, '5': 13, '8': const {}, '10': 'index'},
  ],
};

const Tag$json = const {
  '1': 'Tag',
  '2': const [
    const {'1': 'tid', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'tid'},
    const {'1': 'payload', '3': 2, '4': 1, '5': 12, '8': const {}, '10': 'payload'},
    const {'1': 'epc', '3': 10, '4': 1, '5': 9, '8': const {}, '9': 0, '10': 'epc'},
  ],
  '8': const [
    const {'1': 'content'},
  ],
};

