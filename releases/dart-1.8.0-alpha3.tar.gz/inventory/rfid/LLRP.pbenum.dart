///
//  Generated code. Do not modify.
//  source: inventory/rfid/LLRP.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class RegulatoryCapability extends $pb.ProtobufEnum {
  static const RegulatoryCapability UNSPECIFIED_REGULATORY_REGION = RegulatoryCapability._(0, 'UNSPECIFIED_REGULATORY_REGION');
  static const RegulatoryCapability US_FCC = RegulatoryCapability._(1, 'US_FCC');
  static const RegulatoryCapability ETSI_302_208 = RegulatoryCapability._(2, 'ETSI_302_208');
  static const RegulatoryCapability ETSI_300_220 = RegulatoryCapability._(3, 'ETSI_300_220');
  static const RegulatoryCapability AUSTRALIA_LIPD_1W = RegulatoryCapability._(4, 'AUSTRALIA_LIPD_1W');
  static const RegulatoryCapability AUSTRALIA_LIPD_4W = RegulatoryCapability._(5, 'AUSTRALIA_LIPD_4W');
  static const RegulatoryCapability JAPAN_ARIB_STD_T89 = RegulatoryCapability._(6, 'JAPAN_ARIB_STD_T89');
  static const RegulatoryCapability HONGKONG_OFTA_1049 = RegulatoryCapability._(7, 'HONGKONG_OFTA_1049');
  static const RegulatoryCapability TAIWAN_DGT_LP0002 = RegulatoryCapability._(8, 'TAIWAN_DGT_LP0002');
  static const RegulatoryCapability KOREA_MIC_ARTICLE_5_2 = RegulatoryCapability._(9, 'KOREA_MIC_ARTICLE_5_2');

  static const $core.List<RegulatoryCapability> values = <RegulatoryCapability> [
    UNSPECIFIED_REGULATORY_REGION,
    US_FCC,
    ETSI_302_208,
    ETSI_300_220,
    AUSTRALIA_LIPD_1W,
    AUSTRALIA_LIPD_4W,
    JAPAN_ARIB_STD_T89,
    HONGKONG_OFTA_1049,
    TAIWAN_DGT_LP0002,
    KOREA_MIC_ARTICLE_5_2,
  ];

  static final $core.Map<$core.int, RegulatoryCapability> _byValue = $pb.ProtobufEnum.initByValue(values);
  static RegulatoryCapability valueOf($core.int value) => _byValue[value];

  const RegulatoryCapability._($core.int v, $core.String n) : super(v, n);
}

class StartTriggerType extends $pb.ProtobufEnum {
  static const StartTriggerType NO_START_TRIGGER = StartTriggerType._(0, 'NO_START_TRIGGER');
  static const StartTriggerType IMMEDIATE = StartTriggerType._(1, 'IMMEDIATE');
  static const StartTriggerType PERIODIC = StartTriggerType._(2, 'PERIODIC');
  static const StartTriggerType GPIO_START = StartTriggerType._(3, 'GPIO_START');

  static const $core.List<StartTriggerType> values = <StartTriggerType> [
    NO_START_TRIGGER,
    IMMEDIATE,
    PERIODIC,
    GPIO_START,
  ];

  static final $core.Map<$core.int, StartTriggerType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static StartTriggerType valueOf($core.int value) => _byValue[value];

  const StartTriggerType._($core.int v, $core.String n) : super(v, n);
}

class StopTriggerType extends $pb.ProtobufEnum {
  static const StopTriggerType NO_STOP_TRIGGER = StopTriggerType._(0, 'NO_STOP_TRIGGER');
  static const StopTriggerType DURATION = StopTriggerType._(1, 'DURATION');
  static const StopTriggerType GPIO_STOP = StopTriggerType._(2, 'GPIO_STOP');

  static const $core.List<StopTriggerType> values = <StopTriggerType> [
    NO_STOP_TRIGGER,
    DURATION,
    GPIO_STOP,
  ];

  static final $core.Map<$core.int, StopTriggerType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static StopTriggerType valueOf($core.int value) => _byValue[value];

  const StopTriggerType._($core.int v, $core.String n) : super(v, n);
}

