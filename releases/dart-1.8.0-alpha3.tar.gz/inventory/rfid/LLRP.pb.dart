///
//  Generated code. Do not modify.
//  source: inventory/rfid/LLRP.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart' as $pb;

import 'RFID.pb.dart' as $73;
import '../../temporal/Instant.pb.dart' as $0;

import 'LLRP.pbenum.dart';

export 'LLRP.pbenum.dart';

class BoundaryConfig_StartTrigger extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('BoundaryConfig.StartTrigger', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..e<StartTriggerType>(1, 'type', $pb.PbFieldType.OE, StartTriggerType.NO_START_TRIGGER, StartTriggerType.valueOf, StartTriggerType.values)
    ..a<Int64>(2, 'schedule', $pb.PbFieldType.OU6, Int64.ZERO)
    ..hasRequiredFields = false
  ;

  BoundaryConfig_StartTrigger() : super();
  BoundaryConfig_StartTrigger.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BoundaryConfig_StartTrigger.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BoundaryConfig_StartTrigger clone() => BoundaryConfig_StartTrigger()..mergeFromMessage(this);
  BoundaryConfig_StartTrigger copyWith(void Function(BoundaryConfig_StartTrigger) updates) => super.copyWith((message) => updates(message as BoundaryConfig_StartTrigger));
  $pb.BuilderInfo get info_ => _i;
  static BoundaryConfig_StartTrigger create() => BoundaryConfig_StartTrigger();
  BoundaryConfig_StartTrigger createEmptyInstance() => create();
  static $pb.PbList<BoundaryConfig_StartTrigger> createRepeated() => $pb.PbList<BoundaryConfig_StartTrigger>();
  static BoundaryConfig_StartTrigger getDefault() => _defaultInstance ??= create()..freeze();
  static BoundaryConfig_StartTrigger _defaultInstance;

  StartTriggerType get type => $_getN(0);
  set type(StartTriggerType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  Int64 get schedule => $_getI64(1);
  set schedule(Int64 v) { $_setInt64(1, v); }
  $core.bool hasSchedule() => $_has(1);
  void clearSchedule() => clearField(2);
}

class BoundaryConfig_StopTrigger extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('BoundaryConfig.StopTrigger', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..e<StopTriggerType>(1, 'type', $pb.PbFieldType.OE, StopTriggerType.NO_STOP_TRIGGER, StopTriggerType.valueOf, StopTriggerType.values)
    ..a<Int64>(2, 'schedule', $pb.PbFieldType.OU6, Int64.ZERO)
    ..hasRequiredFields = false
  ;

  BoundaryConfig_StopTrigger() : super();
  BoundaryConfig_StopTrigger.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BoundaryConfig_StopTrigger.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BoundaryConfig_StopTrigger clone() => BoundaryConfig_StopTrigger()..mergeFromMessage(this);
  BoundaryConfig_StopTrigger copyWith(void Function(BoundaryConfig_StopTrigger) updates) => super.copyWith((message) => updates(message as BoundaryConfig_StopTrigger));
  $pb.BuilderInfo get info_ => _i;
  static BoundaryConfig_StopTrigger create() => BoundaryConfig_StopTrigger();
  BoundaryConfig_StopTrigger createEmptyInstance() => create();
  static $pb.PbList<BoundaryConfig_StopTrigger> createRepeated() => $pb.PbList<BoundaryConfig_StopTrigger>();
  static BoundaryConfig_StopTrigger getDefault() => _defaultInstance ??= create()..freeze();
  static BoundaryConfig_StopTrigger _defaultInstance;

  StopTriggerType get type => $_getN(0);
  set type(StopTriggerType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  Int64 get schedule => $_getI64(1);
  set schedule(Int64 v) { $_setInt64(1, v); }
  $core.bool hasSchedule() => $_has(1);
  void clearSchedule() => clearField(2);
}

class BoundaryConfig extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('BoundaryConfig', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..a<BoundaryConfig_StartTrigger>(1, 'start', $pb.PbFieldType.OM, BoundaryConfig_StartTrigger.getDefault, BoundaryConfig_StartTrigger.create)
    ..a<BoundaryConfig_StopTrigger>(2, 'stop', $pb.PbFieldType.OM, BoundaryConfig_StopTrigger.getDefault, BoundaryConfig_StopTrigger.create)
    ..hasRequiredFields = false
  ;

  BoundaryConfig() : super();
  BoundaryConfig.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  BoundaryConfig.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  BoundaryConfig clone() => BoundaryConfig()..mergeFromMessage(this);
  BoundaryConfig copyWith(void Function(BoundaryConfig) updates) => super.copyWith((message) => updates(message as BoundaryConfig));
  $pb.BuilderInfo get info_ => _i;
  static BoundaryConfig create() => BoundaryConfig();
  BoundaryConfig createEmptyInstance() => create();
  static $pb.PbList<BoundaryConfig> createRepeated() => $pb.PbList<BoundaryConfig>();
  static BoundaryConfig getDefault() => _defaultInstance ??= create()..freeze();
  static BoundaryConfig _defaultInstance;

  BoundaryConfig_StartTrigger get start => $_getN(0);
  set start(BoundaryConfig_StartTrigger v) { setField(1, v); }
  $core.bool hasStart() => $_has(0);
  void clearStart() => clearField(1);

  BoundaryConfig_StopTrigger get stop => $_getN(1);
  set stop(BoundaryConfig_StopTrigger v) { setField(2, v); }
  $core.bool hasStop() => $_has(1);
  void clearStop() => clearField(2);
}

class ReportingConfig extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ReportingConfig', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..hasRequiredFields = false
  ;

  ReportingConfig() : super();
  ReportingConfig.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ReportingConfig.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ReportingConfig clone() => ReportingConfig()..mergeFromMessage(this);
  ReportingConfig copyWith(void Function(ReportingConfig) updates) => super.copyWith((message) => updates(message as ReportingConfig));
  $pb.BuilderInfo get info_ => _i;
  static ReportingConfig create() => ReportingConfig();
  ReportingConfig createEmptyInstance() => create();
  static $pb.PbList<ReportingConfig> createRepeated() => $pb.PbList<ReportingConfig>();
  static ReportingConfig getDefault() => _defaultInstance ??= create()..freeze();
  static ReportingConfig _defaultInstance;
}

class ROSpec extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ROSpec', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..a<$core.int>(1, 'id', $pb.PbFieldType.OU3)
    ..a<$core.int>(2, 'priority', $pb.PbFieldType.OU3)
    ..a<BoundaryConfig>(3, 'boundary', $pb.PbFieldType.OM, BoundaryConfig.getDefault, BoundaryConfig.create)
    ..a<ReportingConfig>(4, 'reporting', $pb.PbFieldType.OM, ReportingConfig.getDefault, ReportingConfig.create)
    ..hasRequiredFields = false
  ;

  ROSpec() : super();
  ROSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ROSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ROSpec clone() => ROSpec()..mergeFromMessage(this);
  ROSpec copyWith(void Function(ROSpec) updates) => super.copyWith((message) => updates(message as ROSpec));
  $pb.BuilderInfo get info_ => _i;
  static ROSpec create() => ROSpec();
  ROSpec createEmptyInstance() => create();
  static $pb.PbList<ROSpec> createRepeated() => $pb.PbList<ROSpec>();
  static ROSpec getDefault() => _defaultInstance ??= create()..freeze();
  static ROSpec _defaultInstance;

  $core.int get id => $_get(0, 0);
  set id($core.int v) { $_setUnsignedInt32(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $core.int get priority => $_get(1, 0);
  set priority($core.int v) { $_setUnsignedInt32(1, v); }
  $core.bool hasPriority() => $_has(1);
  void clearPriority() => clearField(2);

  BoundaryConfig get boundary => $_getN(2);
  set boundary(BoundaryConfig v) { setField(3, v); }
  $core.bool hasBoundary() => $_has(2);
  void clearBoundary() => clearField(3);

  ReportingConfig get reporting => $_getN(3);
  set reporting(ReportingConfig v) { setField(4, v); }
  $core.bool hasReporting() => $_has(3);
  void clearReporting() => clearField(4);
}

class TagReportOrigin extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TagReportOrigin', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..a<$73.Reader>(1, 'reader', $pb.PbFieldType.OM, $73.Reader.getDefault, $73.Reader.create)
    ..aOS(2, 'partner')
    ..aOS(3, 'location')
    ..hasRequiredFields = false
  ;

  TagReportOrigin() : super();
  TagReportOrigin.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TagReportOrigin.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TagReportOrigin clone() => TagReportOrigin()..mergeFromMessage(this);
  TagReportOrigin copyWith(void Function(TagReportOrigin) updates) => super.copyWith((message) => updates(message as TagReportOrigin));
  $pb.BuilderInfo get info_ => _i;
  static TagReportOrigin create() => TagReportOrigin();
  TagReportOrigin createEmptyInstance() => create();
  static $pb.PbList<TagReportOrigin> createRepeated() => $pb.PbList<TagReportOrigin>();
  static TagReportOrigin getDefault() => _defaultInstance ??= create()..freeze();
  static TagReportOrigin _defaultInstance;

  $73.Reader get reader => $_getN(0);
  set reader($73.Reader v) { setField(1, v); }
  $core.bool hasReader() => $_has(0);
  void clearReader() => clearField(1);

  $core.String get partner => $_getS(1, '');
  set partner($core.String v) { $_setString(1, v); }
  $core.bool hasPartner() => $_has(1);
  void clearPartner() => clearField(2);

  $core.String get location => $_getS(2, '');
  set location($core.String v) { $_setString(2, v); }
  $core.bool hasLocation() => $_has(2);
  void clearLocation() => clearField(3);
}

class TagReport extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TagReport', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..a<$73.Antenna>(1, 'antenna', $pb.PbFieldType.OM, $73.Antenna.getDefault, $73.Antenna.create)
    ..a<$73.Tag>(2, 'tag', $pb.PbFieldType.OM, $73.Tag.getDefault, $73.Tag.create)
    ..a<$core.double>(3, 'rssi', $pb.PbFieldType.OD)
    ..a<$0.Instant>(4, 'firstSeen', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(5, 'lastSeen', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(6, 'received', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$core.int>(7, 'peers', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  TagReport() : super();
  TagReport.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TagReport.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TagReport clone() => TagReport()..mergeFromMessage(this);
  TagReport copyWith(void Function(TagReport) updates) => super.copyWith((message) => updates(message as TagReport));
  $pb.BuilderInfo get info_ => _i;
  static TagReport create() => TagReport();
  TagReport createEmptyInstance() => create();
  static $pb.PbList<TagReport> createRepeated() => $pb.PbList<TagReport>();
  static TagReport getDefault() => _defaultInstance ??= create()..freeze();
  static TagReport _defaultInstance;

  $73.Antenna get antenna => $_getN(0);
  set antenna($73.Antenna v) { setField(1, v); }
  $core.bool hasAntenna() => $_has(0);
  void clearAntenna() => clearField(1);

  $73.Tag get tag => $_getN(1);
  set tag($73.Tag v) { setField(2, v); }
  $core.bool hasTag() => $_has(1);
  void clearTag() => clearField(2);

  $core.double get rssi => $_getN(2);
  set rssi($core.double v) { $_setDouble(2, v); }
  $core.bool hasRssi() => $_has(2);
  void clearRssi() => clearField(3);

  $0.Instant get firstSeen => $_getN(3);
  set firstSeen($0.Instant v) { setField(4, v); }
  $core.bool hasFirstSeen() => $_has(3);
  void clearFirstSeen() => clearField(4);

  $0.Instant get lastSeen => $_getN(4);
  set lastSeen($0.Instant v) { setField(5, v); }
  $core.bool hasLastSeen() => $_has(4);
  void clearLastSeen() => clearField(5);

  $0.Instant get received => $_getN(5);
  set received($0.Instant v) { setField(6, v); }
  $core.bool hasReceived() => $_has(5);
  void clearReceived() => clearField(6);

  $core.int get peers => $_get(6, 0);
  set peers($core.int v) { $_setUnsignedInt32(6, v); }
  $core.bool hasPeers() => $_has(6);
  void clearPeers() => clearField(7);
}

class TagReportSet extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('TagReportSet', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..a<TagReportOrigin>(1, 'origin', $pb.PbFieldType.OM, TagReportOrigin.getDefault, TagReportOrigin.create)
    ..pc<TagReport>(2, 'report', $pb.PbFieldType.PM,TagReport.create)
    ..hasRequiredFields = false
  ;

  TagReportSet() : super();
  TagReportSet.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  TagReportSet.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  TagReportSet clone() => TagReportSet()..mergeFromMessage(this);
  TagReportSet copyWith(void Function(TagReportSet) updates) => super.copyWith((message) => updates(message as TagReportSet));
  $pb.BuilderInfo get info_ => _i;
  static TagReportSet create() => TagReportSet();
  TagReportSet createEmptyInstance() => create();
  static $pb.PbList<TagReportSet> createRepeated() => $pb.PbList<TagReportSet>();
  static TagReportSet getDefault() => _defaultInstance ??= create()..freeze();
  static TagReportSet _defaultInstance;

  TagReportOrigin get origin => $_getN(0);
  set origin(TagReportOrigin v) { setField(1, v); }
  $core.bool hasOrigin() => $_has(0);
  void clearOrigin() => clearField(1);

  $core.List<TagReport> get report => $_getList(1);
}

