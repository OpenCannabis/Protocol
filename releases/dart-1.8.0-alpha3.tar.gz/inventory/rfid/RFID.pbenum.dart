///
//  Generated code. Do not modify.
//  source: inventory/rfid/RFID.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class ReaderVendor extends $pb.ProtobufEnum {
  static const ReaderVendor UNRECOGNIZED_VENDOR = ReaderVendor._(0, 'UNRECOGNIZED_VENDOR');
  static const ReaderVendor IMPINJ = ReaderVendor._(25882, 'IMPINJ');
  static const ReaderVendor ALIEN = ReaderVendor._(2, 'ALIEN');

  static const $core.List<ReaderVendor> values = <ReaderVendor> [
    UNRECOGNIZED_VENDOR,
    IMPINJ,
    ALIEN,
  ];

  static final $core.Map<$core.int, ReaderVendor> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ReaderVendor valueOf($core.int value) => _byValue[value];

  const ReaderVendor._($core.int v, $core.String n) : super(v, n);
}

class ReaderModel extends $pb.ProtobufEnum {
  static const ReaderModel UNRECOGNIZED_READER = ReaderModel._(0, 'UNRECOGNIZED_READER');
  static const ReaderModel SPEEDWAY_R120 = ReaderModel._(1, 'SPEEDWAY_R120');
  static const ReaderModel SPEEDWAY_R220 = ReaderModel._(2, 'SPEEDWAY_R220');
  static const ReaderModel SPEEDWAY_R420 = ReaderModel._(2001002, 'SPEEDWAY_R420');
  static const ReaderModel SPEEDWAY_XPORTAL = ReaderModel._(4, 'SPEEDWAY_XPORTAL');
  static const ReaderModel ALIEN_ALRH450 = ReaderModel._(5, 'ALIEN_ALRH450');
  static const ReaderModel ALIEN_F800 = ReaderModel._(6, 'ALIEN_F800');
  static const ReaderModel ALIEN_ALR9680 = ReaderModel._(7, 'ALIEN_ALR9680');

  static const $core.List<ReaderModel> values = <ReaderModel> [
    UNRECOGNIZED_READER,
    SPEEDWAY_R120,
    SPEEDWAY_R220,
    SPEEDWAY_R420,
    SPEEDWAY_XPORTAL,
    ALIEN_ALRH450,
    ALIEN_F800,
    ALIEN_ALR9680,
  ];

  static final $core.Map<$core.int, ReaderModel> _byValue = $pb.ProtobufEnum.initByValue(values);
  static ReaderModel valueOf($core.int value) => _byValue[value];

  const ReaderModel._($core.int v, $core.String n) : super(v, n);
}

