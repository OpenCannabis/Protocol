///
//  Generated code. Do not modify.
//  source: inventory/rfid/RFID.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'RFID.pbenum.dart';

export 'RFID.pbenum.dart';

class Reader extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Reader', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..aOS(1, 'name')
    ..aOS(2, 'mac')
    ..aOS(3, 'ip')
    ..e<ReaderVendor>(4, 'vendor', $pb.PbFieldType.OE, ReaderVendor.UNRECOGNIZED_VENDOR, ReaderVendor.valueOf, ReaderVendor.values)
    ..e<ReaderModel>(5, 'model', $pb.PbFieldType.OE, ReaderModel.UNRECOGNIZED_READER, ReaderModel.valueOf, ReaderModel.values)
    ..hasRequiredFields = false
  ;

  Reader() : super();
  Reader.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Reader.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Reader clone() => Reader()..mergeFromMessage(this);
  Reader copyWith(void Function(Reader) updates) => super.copyWith((message) => updates(message as Reader));
  $pb.BuilderInfo get info_ => _i;
  static Reader create() => Reader();
  Reader createEmptyInstance() => create();
  static $pb.PbList<Reader> createRepeated() => $pb.PbList<Reader>();
  static Reader getDefault() => _defaultInstance ??= create()..freeze();
  static Reader _defaultInstance;

  $core.String get name => $_getS(0, '');
  set name($core.String v) { $_setString(0, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  $core.String get mac => $_getS(1, '');
  set mac($core.String v) { $_setString(1, v); }
  $core.bool hasMac() => $_has(1);
  void clearMac() => clearField(2);

  $core.String get ip => $_getS(2, '');
  set ip($core.String v) { $_setString(2, v); }
  $core.bool hasIp() => $_has(2);
  void clearIp() => clearField(3);

  ReaderVendor get vendor => $_getN(3);
  set vendor(ReaderVendor v) { setField(4, v); }
  $core.bool hasVendor() => $_has(3);
  void clearVendor() => clearField(4);

  ReaderModel get model => $_getN(4);
  set model(ReaderModel v) { setField(5, v); }
  $core.bool hasModel() => $_has(4);
  void clearModel() => clearField(5);
}

class Antenna extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Antenna', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..a<$core.int>(1, 'index', $pb.PbFieldType.OU3)
    ..hasRequiredFields = false
  ;

  Antenna() : super();
  Antenna.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Antenna.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Antenna clone() => Antenna()..mergeFromMessage(this);
  Antenna copyWith(void Function(Antenna) updates) => super.copyWith((message) => updates(message as Antenna));
  $pb.BuilderInfo get info_ => _i;
  static Antenna create() => Antenna();
  Antenna createEmptyInstance() => create();
  static $pb.PbList<Antenna> createRepeated() => $pb.PbList<Antenna>();
  static Antenna getDefault() => _defaultInstance ??= create()..freeze();
  static Antenna _defaultInstance;

  $core.int get index => $_get(0, 0);
  set index($core.int v) { $_setUnsignedInt32(0, v); }
  $core.bool hasIndex() => $_has(0);
  void clearIndex() => clearField(1);
}

enum Tag_Content {
  epc, 
  notSet
}

class Tag extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Tag_Content> _Tag_ContentByTag = {
    10 : Tag_Content.epc,
    0 : Tag_Content.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Tag', package: const $pb.PackageName('opencannabis.inventory.rfid'))
    ..aOS(1, 'tid')
    ..a<$core.List<$core.int>>(2, 'payload', $pb.PbFieldType.OY)
    ..aOS(10, 'epc')
    ..oo(0, [10])
    ..hasRequiredFields = false
  ;

  Tag() : super();
  Tag.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Tag.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Tag clone() => Tag()..mergeFromMessage(this);
  Tag copyWith(void Function(Tag) updates) => super.copyWith((message) => updates(message as Tag));
  $pb.BuilderInfo get info_ => _i;
  static Tag create() => Tag();
  Tag createEmptyInstance() => create();
  static $pb.PbList<Tag> createRepeated() => $pb.PbList<Tag>();
  static Tag getDefault() => _defaultInstance ??= create()..freeze();
  static Tag _defaultInstance;

  Tag_Content whichContent() => _Tag_ContentByTag[$_whichOneof(0)];
  void clearContent() => clearField($_whichOneof(0));

  $core.String get tid => $_getS(0, '');
  set tid($core.String v) { $_setString(0, v); }
  $core.bool hasTid() => $_has(0);
  void clearTid() => clearField(1);

  $core.List<$core.int> get payload => $_getN(1);
  set payload($core.List<$core.int> v) { $_setBytes(1, v); }
  $core.bool hasPayload() => $_has(1);
  void clearPayload() => clearField(2);

  $core.String get epc => $_getS(2, '');
  set epc($core.String v) { $_setString(2, v); }
  $core.bool hasEpc() => $_has(2);
  void clearEpc() => clearField(10);
}

