///
//  Generated code. Do not modify.
//  source: inventory/InventoryLocation.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const InventoryLocationType$json = const {
  '1': 'InventoryLocationType',
  '2': const [
    const {'1': 'RETAIL', '2': 0},
    const {'1': 'WAREHOUSE', '2': 1},
    const {'1': 'PRODUCTION', '2': 2},
  ],
};

const InventoryLocationKey$json = const {
  '1': 'InventoryLocationKey',
  '2': const [
    const {'1': 'uuid', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'uuid'},
    const {'1': 'partner', '3': 2, '4': 1, '5': 9, '10': 'partner'},
    const {'1': 'location', '3': 3, '4': 1, '5': 9, '10': 'location'},
  ],
};

const InventoryLocation$json = const {
  '1': 'InventoryLocation',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.inventory.InventoryLocationKey', '8': const {}, '10': 'key'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.inventory.InventoryLocationType', '10': 'type'},
    const {'1': 'name', '3': 3, '4': 1, '5': 9, '10': 'name'},
    const {'1': 'contact', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.contact.ContactInfo', '10': 'contact'},
  ],
};

const InventoryBinding$json = const {
  '1': 'InventoryBinding',
  '2': const [
    const {'1': 'held_by', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.inventory.InventoryLocationKey', '10': 'heldBy'},
    const {'1': 'item', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.inventory.InventoryProduct', '10': 'item'},
  ],
};

