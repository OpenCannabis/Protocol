///
//  Generated code. Do not modify.
//  source: inventory/InventoryProduct.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class InventoryState_Status extends $pb.ProtobufEnum {
  static const InventoryState_Status UNRECONCILED = InventoryState_Status._(0, 'UNRECONCILED');
  static const InventoryState_Status RECEIVING = InventoryState_Status._(1, 'RECEIVING');
  static const InventoryState_Status QUARANTINE = InventoryState_Status._(2, 'QUARANTINE');
  static const InventoryState_Status ON_HAND = InventoryState_Status._(3, 'ON_HAND');
  static const InventoryState_Status FOR_SALE = InventoryState_Status._(4, 'FOR_SALE');
  static const InventoryState_Status CLAIMED = InventoryState_Status._(5, 'CLAIMED');
  static const InventoryState_Status COMMITTED = InventoryState_Status._(6, 'COMMITTED');

  static const $core.List<InventoryState_Status> values = <InventoryState_Status> [
    UNRECONCILED,
    RECEIVING,
    QUARANTINE,
    ON_HAND,
    FOR_SALE,
    CLAIMED,
    COMMITTED,
  ];

  static final $core.Map<$core.int, InventoryState_Status> _byValue = $pb.ProtobufEnum.initByValue(values);
  static InventoryState_Status valueOf($core.int value) => _byValue[value];

  const InventoryState_Status._($core.int v, $core.String n) : super(v, n);
}

