///
//  Generated code. Do not modify.
//  source: inventory/InventoryLocation.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class InventoryLocationType extends $pb.ProtobufEnum {
  static const InventoryLocationType RETAIL = InventoryLocationType._(0, 'RETAIL');
  static const InventoryLocationType WAREHOUSE = InventoryLocationType._(1, 'WAREHOUSE');
  static const InventoryLocationType PRODUCTION = InventoryLocationType._(2, 'PRODUCTION');

  static const $core.List<InventoryLocationType> values = <InventoryLocationType> [
    RETAIL,
    WAREHOUSE,
    PRODUCTION,
  ];

  static final $core.Map<$core.int, InventoryLocationType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static InventoryLocationType valueOf($core.int value) => _byValue[value];

  const InventoryLocationType._($core.int v, $core.String n) : super(v, n);
}

