///
//  Generated code. Do not modify.
//  source: inventory/InventoryLocation.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../contact/ContactInfo.pb.dart' as $10;
import 'InventoryProduct.pb.dart' as $70;

import 'InventoryLocation.pbenum.dart';

export 'InventoryLocation.pbenum.dart';

class InventoryLocationKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InventoryLocationKey', package: const $pb.PackageName('opencannabis.inventory'))
    ..aOS(1, 'uuid')
    ..aOS(2, 'partner')
    ..aOS(3, 'location')
    ..hasRequiredFields = false
  ;

  InventoryLocationKey() : super();
  InventoryLocationKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InventoryLocationKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InventoryLocationKey clone() => InventoryLocationKey()..mergeFromMessage(this);
  InventoryLocationKey copyWith(void Function(InventoryLocationKey) updates) => super.copyWith((message) => updates(message as InventoryLocationKey));
  $pb.BuilderInfo get info_ => _i;
  static InventoryLocationKey create() => InventoryLocationKey();
  InventoryLocationKey createEmptyInstance() => create();
  static $pb.PbList<InventoryLocationKey> createRepeated() => $pb.PbList<InventoryLocationKey>();
  static InventoryLocationKey getDefault() => _defaultInstance ??= create()..freeze();
  static InventoryLocationKey _defaultInstance;

  $core.String get uuid => $_getS(0, '');
  set uuid($core.String v) { $_setString(0, v); }
  $core.bool hasUuid() => $_has(0);
  void clearUuid() => clearField(1);

  $core.String get partner => $_getS(1, '');
  set partner($core.String v) { $_setString(1, v); }
  $core.bool hasPartner() => $_has(1);
  void clearPartner() => clearField(2);

  $core.String get location => $_getS(2, '');
  set location($core.String v) { $_setString(2, v); }
  $core.bool hasLocation() => $_has(2);
  void clearLocation() => clearField(3);
}

class InventoryLocation extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InventoryLocation', package: const $pb.PackageName('opencannabis.inventory'))
    ..a<InventoryLocationKey>(1, 'key', $pb.PbFieldType.OM, InventoryLocationKey.getDefault, InventoryLocationKey.create)
    ..e<InventoryLocationType>(2, 'type', $pb.PbFieldType.OE, InventoryLocationType.RETAIL, InventoryLocationType.valueOf, InventoryLocationType.values)
    ..aOS(3, 'name')
    ..a<$10.ContactInfo>(4, 'contact', $pb.PbFieldType.OM, $10.ContactInfo.getDefault, $10.ContactInfo.create)
    ..hasRequiredFields = false
  ;

  InventoryLocation() : super();
  InventoryLocation.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InventoryLocation.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InventoryLocation clone() => InventoryLocation()..mergeFromMessage(this);
  InventoryLocation copyWith(void Function(InventoryLocation) updates) => super.copyWith((message) => updates(message as InventoryLocation));
  $pb.BuilderInfo get info_ => _i;
  static InventoryLocation create() => InventoryLocation();
  InventoryLocation createEmptyInstance() => create();
  static $pb.PbList<InventoryLocation> createRepeated() => $pb.PbList<InventoryLocation>();
  static InventoryLocation getDefault() => _defaultInstance ??= create()..freeze();
  static InventoryLocation _defaultInstance;

  InventoryLocationKey get key => $_getN(0);
  set key(InventoryLocationKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  InventoryLocationType get type => $_getN(1);
  set type(InventoryLocationType v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $core.String get name => $_getS(2, '');
  set name($core.String v) { $_setString(2, v); }
  $core.bool hasName() => $_has(2);
  void clearName() => clearField(3);

  $10.ContactInfo get contact => $_getN(3);
  set contact($10.ContactInfo v) { setField(4, v); }
  $core.bool hasContact() => $_has(3);
  void clearContact() => clearField(4);
}

class InventoryBinding extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('InventoryBinding', package: const $pb.PackageName('opencannabis.inventory'))
    ..a<InventoryLocationKey>(1, 'heldBy', $pb.PbFieldType.OM, InventoryLocationKey.getDefault, InventoryLocationKey.create)
    ..a<$70.InventoryProduct>(2, 'item', $pb.PbFieldType.OM, $70.InventoryProduct.getDefault, $70.InventoryProduct.create)
    ..hasRequiredFields = false
  ;

  InventoryBinding() : super();
  InventoryBinding.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  InventoryBinding.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  InventoryBinding clone() => InventoryBinding()..mergeFromMessage(this);
  InventoryBinding copyWith(void Function(InventoryBinding) updates) => super.copyWith((message) => updates(message as InventoryBinding));
  $pb.BuilderInfo get info_ => _i;
  static InventoryBinding create() => InventoryBinding();
  InventoryBinding createEmptyInstance() => create();
  static $pb.PbList<InventoryBinding> createRepeated() => $pb.PbList<InventoryBinding>();
  static InventoryBinding getDefault() => _defaultInstance ??= create()..freeze();
  static InventoryBinding _defaultInstance;

  InventoryLocationKey get heldBy => $_getN(0);
  set heldBy(InventoryLocationKey v) { setField(1, v); }
  $core.bool hasHeldBy() => $_has(0);
  void clearHeldBy() => clearField(1);

  $70.InventoryProduct get item => $_getN(1);
  set item($70.InventoryProduct v) { setField(2, v); }
  $core.bool hasItem() => $_has(1);
  void clearItem() => clearField(2);
}

