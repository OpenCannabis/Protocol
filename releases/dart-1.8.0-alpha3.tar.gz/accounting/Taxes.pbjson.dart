///
//  Generated code. Do not modify.
//  source: accounting/Taxes.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const TaxJurisdictionMode$json = const {
  '1': 'TaxJurisdictionMode',
  '2': const [
    const {'1': 'LOCAL', '2': 0},
    const {'1': 'PROVINCE', '2': 1},
    const {'1': 'FEDERAL', '2': 2},
  ],
};

const TaxBasis$json = const {
  '1': 'TaxBasis',
  '2': const [
    const {'1': 'ITEM', '2': 0},
    const {'1': 'ORDER_SUBTOTAL', '2': 1},
    const {'1': 'ORDER_TOTAL', '2': 2},
  ],
};

const LocalTax$json = const {
  '1': 'LocalTax',
  '2': const [
    const {'1': 'municipality', '3': 1, '4': 1, '5': 9, '10': 'municipality'},
    const {'1': 'province', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.geo.Province', '10': 'province'},
    const {'1': 'country', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.geo.Country', '10': 'country'},
  ],
};

const ProvincialTax$json = const {
  '1': 'ProvincialTax',
  '2': const [
    const {'1': 'province', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.geo.Province', '10': 'province'},
    const {'1': 'country', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.geo.Country', '10': 'country'},
  ],
};

const FederalTax$json = const {
  '1': 'FederalTax',
  '2': const [
    const {'1': 'country', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.geo.Country', '10': 'country'},
  ],
};

const TaxJurisdiction$json = const {
  '1': 'TaxJurisdiction',
  '2': const [
    const {'1': 'mode', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.taxes.TaxJurisdictionMode', '10': 'mode'},
    const {'1': 'local', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.taxes.LocalTax', '9': 0, '10': 'local'},
    const {'1': 'provincial', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.taxes.ProvincialTax', '9': 0, '10': 'provincial'},
    const {'1': 'federal', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.taxes.FederalTax', '9': 0, '10': 'federal'},
  ],
  '8': const [
    const {'1': 'jurisdiction'},
  ],
};

const TaxSpec$json = const {
  '1': 'TaxSpec',
  '2': const [
    const {'1': 'basis', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.taxes.TaxBasis', '10': 'basis'},
    const {'1': 'jurisdiction', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.taxes.TaxJurisdiction', '10': 'jurisdiction'},
    const {'1': 'transaction_label', '3': 3, '4': 1, '5': 9, '10': 'transactionLabel'},
    const {'1': 'percentage', '3': 4, '4': 1, '5': 1, '9': 0, '10': 'percentage'},
    const {'1': 'static_value', '3': 5, '4': 1, '5': 1, '9': 0, '10': 'staticValue'},
  ],
  '8': const [
    const {'1': 'rate'},
  ],
};

const Tax$json = const {
  '1': 'Tax',
  '2': const [
    const {'1': 'id', '3': 1, '4': 1, '5': 9, '10': 'id'},
    const {'1': 'spec', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.taxes.TaxSpec', '10': 'spec'},
    const {'1': 'name', '3': 3, '4': 1, '5': 9, '10': 'name'},
    const {'1': 'label', '3': 4, '4': 1, '5': 9, '10': 'label'},
    const {'1': 'description', '3': 5, '4': 1, '5': 9, '10': 'description'},
  ],
};

