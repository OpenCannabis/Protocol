///
//  Generated code. Do not modify.
//  source: regulatory/usa/ca/CAAgency.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const CaliforniaAgency$json = const {
  '1': 'CaliforniaAgency',
  '2': const [
    const {'1': 'UNKNOWN_AGENCY', '2': 0},
    const {'1': 'CDFA', '2': 1},
    const {'1': 'CBCC', '2': 2},
    const {'1': 'CDCA', '2': 3},
    const {'1': 'CDPH', '2': 4},
  ],
};

