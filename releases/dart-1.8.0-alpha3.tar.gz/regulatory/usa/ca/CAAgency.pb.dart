///
//  Generated code. Do not modify.
//  source: regulatory/usa/ca/CAAgency.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

export 'CAAgency.pbenum.dart';

