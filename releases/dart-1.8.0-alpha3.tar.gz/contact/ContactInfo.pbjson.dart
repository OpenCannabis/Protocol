///
//  Generated code. Do not modify.
//  source: contact/ContactInfo.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const ContactInfo$json = const {
  '1': 'ContactInfo',
  '2': const [
    const {'1': 'location', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.geo.Location', '8': const {}, '10': 'location'},
    const {'1': 'phone', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.contact.PhoneNumber', '8': const {}, '10': 'phone'},
    const {'1': 'email', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.contact.EmailAddress', '8': const {}, '10': 'email'},
    const {'1': 'website', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.contact.Website', '8': const {}, '10': 'website'},
  ],
};

const SocialInfo$json = const {
  '1': 'SocialInfo',
  '2': const [
    const {'1': 'profile', '3': 1, '4': 3, '5': 11, '6': '.opencannabis.contact.SocialInfo.SocialProfile', '10': 'profile'},
  ],
  '3': const [SocialInfo_SocialProfile$json],
  '4': const [SocialInfo_SocialProvider$json],
};

const SocialInfo_SocialProfile$json = const {
  '1': 'SocialProfile',
  '2': const [
    const {'1': 'known', '3': 10, '4': 1, '5': 14, '6': '.opencannabis.contact.SocialInfo.SocialProvider', '9': 0, '10': 'known'},
    const {'1': 'custom', '3': 11, '4': 1, '5': 9, '9': 0, '10': 'custom'},
    const {'1': 'username', '3': 1, '4': 1, '5': 9, '10': 'username'},
    const {'1': 'url', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.contact.Website', '10': 'url'},
  ],
  '8': const [
    const {'1': 'provider'},
  ],
};

const SocialInfo_SocialProvider$json = const {
  '1': 'SocialProvider',
  '2': const [
    const {'1': 'UNSPECIFIED_SOCIAL_PROVIDER', '2': 0},
    const {'1': 'FACEBOOK', '2': 1},
    const {'1': 'TWITTER', '2': 2},
    const {'1': 'INSTAGRAM', '2': 3},
    const {'1': 'YOUTUBE', '2': 4},
    const {'1': 'LEAFLY', '2': 5},
    const {'1': 'WEEDMAPS', '2': 6},
  ],
};

