///
//  Generated code. Do not modify.
//  source: contact/Website.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class Website extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Website', package: const $pb.PackageName('opencannabis.contact'))
    ..aOS(1, 'uri')
    ..aOS(2, 'title')
    ..a<$core.List<$core.int>>(3, 'icon', $pb.PbFieldType.OY)
    ..hasRequiredFields = false
  ;

  Website() : super();
  Website.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Website.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Website clone() => Website()..mergeFromMessage(this);
  Website copyWith(void Function(Website) updates) => super.copyWith((message) => updates(message as Website));
  $pb.BuilderInfo get info_ => _i;
  static Website create() => Website();
  Website createEmptyInstance() => create();
  static $pb.PbList<Website> createRepeated() => $pb.PbList<Website>();
  static Website getDefault() => _defaultInstance ??= create()..freeze();
  static Website _defaultInstance;

  $core.String get uri => $_getS(0, '');
  set uri($core.String v) { $_setString(0, v); }
  $core.bool hasUri() => $_has(0);
  void clearUri() => clearField(1);

  $core.String get title => $_getS(1, '');
  set title($core.String v) { $_setString(1, v); }
  $core.bool hasTitle() => $_has(1);
  void clearTitle() => clearField(2);

  $core.List<$core.int> get icon => $_getN(2);
  set icon($core.List<$core.int> v) { $_setBytes(2, v); }
  $core.bool hasIcon() => $_has(2);
  void clearIcon() => clearField(3);
}

