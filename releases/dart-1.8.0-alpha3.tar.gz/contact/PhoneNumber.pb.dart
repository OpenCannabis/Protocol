///
//  Generated code. Do not modify.
//  source: contact/PhoneNumber.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class PhoneNumber extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('PhoneNumber', package: const $pb.PackageName('opencannabis.contact'))
    ..aOS(1, 'e164')
    ..aOB(2, 'validated')
    ..aOS(3, 'display')
    ..aOB(4, 'textCapable')
    ..aOB(5, 'voiceCapable')
    ..hasRequiredFields = false
  ;

  PhoneNumber() : super();
  PhoneNumber.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  PhoneNumber.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  PhoneNumber clone() => PhoneNumber()..mergeFromMessage(this);
  PhoneNumber copyWith(void Function(PhoneNumber) updates) => super.copyWith((message) => updates(message as PhoneNumber));
  $pb.BuilderInfo get info_ => _i;
  static PhoneNumber create() => PhoneNumber();
  PhoneNumber createEmptyInstance() => create();
  static $pb.PbList<PhoneNumber> createRepeated() => $pb.PbList<PhoneNumber>();
  static PhoneNumber getDefault() => _defaultInstance ??= create()..freeze();
  static PhoneNumber _defaultInstance;

  $core.String get e164 => $_getS(0, '');
  set e164($core.String v) { $_setString(0, v); }
  $core.bool hasE164() => $_has(0);
  void clearE164() => clearField(1);

  $core.bool get validated => $_get(1, false);
  set validated($core.bool v) { $_setBool(1, v); }
  $core.bool hasValidated() => $_has(1);
  void clearValidated() => clearField(2);

  $core.String get display => $_getS(2, '');
  set display($core.String v) { $_setString(2, v); }
  $core.bool hasDisplay() => $_has(2);
  void clearDisplay() => clearField(3);

  $core.bool get textCapable => $_get(3, false);
  set textCapable($core.bool v) { $_setBool(3, v); }
  $core.bool hasTextCapable() => $_has(3);
  void clearTextCapable() => clearField(4);

  $core.bool get voiceCapable => $_get(4, false);
  set voiceCapable($core.bool v) { $_setBool(4, v); }
  $core.bool hasVoiceCapable() => $_has(4);
  void clearVoiceCapable() => clearField(5);
}

