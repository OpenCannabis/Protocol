///
//  Generated code. Do not modify.
//  source: contact/Website.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Website$json = const {
  '1': 'Website',
  '2': const [
    const {'1': 'uri', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'uri'},
    const {'1': 'title', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'title'},
    const {'1': 'icon', '3': 3, '4': 1, '5': 12, '8': const {}, '10': 'icon'},
  ],
};

