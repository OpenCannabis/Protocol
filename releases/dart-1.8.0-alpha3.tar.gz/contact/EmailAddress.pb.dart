///
//  Generated code. Do not modify.
//  source: contact/EmailAddress.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

class EmailAddress extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('EmailAddress', package: const $pb.PackageName('opencannabis.contact'))
    ..aOS(1, 'address')
    ..aOB(2, 'validated')
    ..aOS(3, 'name')
    ..hasRequiredFields = false
  ;

  EmailAddress() : super();
  EmailAddress.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  EmailAddress.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  EmailAddress clone() => EmailAddress()..mergeFromMessage(this);
  EmailAddress copyWith(void Function(EmailAddress) updates) => super.copyWith((message) => updates(message as EmailAddress));
  $pb.BuilderInfo get info_ => _i;
  static EmailAddress create() => EmailAddress();
  EmailAddress createEmptyInstance() => create();
  static $pb.PbList<EmailAddress> createRepeated() => $pb.PbList<EmailAddress>();
  static EmailAddress getDefault() => _defaultInstance ??= create()..freeze();
  static EmailAddress _defaultInstance;

  $core.String get address => $_getS(0, '');
  set address($core.String v) { $_setString(0, v); }
  $core.bool hasAddress() => $_has(0);
  void clearAddress() => clearField(1);

  $core.bool get validated => $_get(1, false);
  set validated($core.bool v) { $_setBool(1, v); }
  $core.bool hasValidated() => $_has(1);
  void clearValidated() => clearField(2);

  $core.String get name => $_getS(2, '');
  set name($core.String v) { $_setString(2, v); }
  $core.bool hasName() => $_has(2);
  void clearName() => clearField(3);
}

