///
//  Generated code. Do not modify.
//  source: products/SKU.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../commerce/Item.pb.dart' as $20;

import 'SKU.pbenum.dart';
import '../partner/integrations/IntegrationSettings.pbenum.dart' as $36;

export 'SKU.pbenum.dart';

enum MappedSKU_Target {
  unit, 
  variant, 
  notSet
}

class MappedSKU extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, MappedSKU_Target> _MappedSKU_TargetByTag = {
    10 : MappedSKU_Target.unit,
    11 : MappedSKU_Target.variant,
    0 : MappedSKU_Target.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MappedSKU', package: const $pb.PackageName('opencannabis.products.sku'))
    ..aOS(1, 'sku')
    ..aOS(2, 'foreign')
    ..e<SKUType>(3, 'type', $pb.PbFieldType.OE, SKUType.ITEM, SKUType.valueOf, SKUType.values)
    ..e<$36.IntegrationPartner>(4, 'system', $pb.PbFieldType.OE, $36.IntegrationPartner.INTERNAL, $36.IntegrationPartner.valueOf, $36.IntegrationPartner.values)
    ..aOB(10, 'unit')
    ..a<$20.VariantSpec>(11, 'variant', $pb.PbFieldType.OM, $20.VariantSpec.getDefault, $20.VariantSpec.create)
    ..oo(0, [10, 11])
    ..hasRequiredFields = false
  ;

  MappedSKU() : super();
  MappedSKU.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MappedSKU.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MappedSKU clone() => MappedSKU()..mergeFromMessage(this);
  MappedSKU copyWith(void Function(MappedSKU) updates) => super.copyWith((message) => updates(message as MappedSKU));
  $pb.BuilderInfo get info_ => _i;
  static MappedSKU create() => MappedSKU();
  MappedSKU createEmptyInstance() => create();
  static $pb.PbList<MappedSKU> createRepeated() => $pb.PbList<MappedSKU>();
  static MappedSKU getDefault() => _defaultInstance ??= create()..freeze();
  static MappedSKU _defaultInstance;

  MappedSKU_Target whichTarget() => _MappedSKU_TargetByTag[$_whichOneof(0)];
  void clearTarget() => clearField($_whichOneof(0));

  $core.String get sku => $_getS(0, '');
  set sku($core.String v) { $_setString(0, v); }
  $core.bool hasSku() => $_has(0);
  void clearSku() => clearField(1);

  $core.String get foreign => $_getS(1, '');
  set foreign($core.String v) { $_setString(1, v); }
  $core.bool hasForeign() => $_has(1);
  void clearForeign() => clearField(2);

  SKUType get type => $_getN(2);
  set type(SKUType v) { setField(3, v); }
  $core.bool hasType() => $_has(2);
  void clearType() => clearField(3);

  $36.IntegrationPartner get system => $_getN(3);
  set system($36.IntegrationPartner v) { setField(4, v); }
  $core.bool hasSystem() => $_has(3);
  void clearSystem() => clearField(4);

  $core.bool get unit => $_get(4, false);
  set unit($core.bool v) { $_setBool(4, v); }
  $core.bool hasUnit() => $_has(4);
  void clearUnit() => clearField(10);

  $20.VariantSpec get variant => $_getN(5);
  set variant($20.VariantSpec v) { setField(11, v); }
  $core.bool hasVariant() => $_has(5);
  void clearVariant() => clearField(11);
}

