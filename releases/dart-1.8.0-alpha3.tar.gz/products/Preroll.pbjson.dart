///
//  Generated code. Do not modify.
//  source: products/Preroll.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Preroll$json = const {
  '1': 'Preroll',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '10': 'key'},
    const {'1': 'flower', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.base.ProductReference', '10': 'flower'},
    const {'1': 'length', '3': 3, '4': 1, '5': 1, '10': 'length'},
    const {'1': 'thickness', '3': 4, '4': 1, '5': 1, '10': 'thickness'},
    const {'1': 'flags', '3': 5, '4': 3, '5': 14, '6': '.opencannabis.products.Preroll.Flag', '10': 'flags'},
    const {'1': 'product', '3': 6, '4': 1, '5': 11, '6': '.opencannabis.content.ProductContent', '10': 'product'},
    const {'1': 'material', '3': 7, '4': 1, '5': 11, '6': '.opencannabis.content.MaterialsData', '10': 'material'},
  ],
  '4': const [Preroll_Flag$json],
};

const Preroll_Flag$json = const {
  '1': 'Flag',
  '2': const [
    const {'1': 'NO_PREROLL_FLAGS', '2': 0},
    const {'1': 'HASH_INFUSED', '2': 1},
    const {'1': 'KIEF_INFUSED', '2': 2},
    const {'1': 'FORTIFIED', '2': 3},
    const {'1': 'FULL_FLOWER', '2': 4},
    const {'1': 'CONTAINS_TOBACCO', '2': 5},
  ],
};

