///
//  Generated code. Do not modify.
//  source: products/Preroll.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Preroll_Flag extends $pb.ProtobufEnum {
  static const Preroll_Flag NO_PREROLL_FLAGS = Preroll_Flag._(0, 'NO_PREROLL_FLAGS');
  static const Preroll_Flag HASH_INFUSED = Preroll_Flag._(1, 'HASH_INFUSED');
  static const Preroll_Flag KIEF_INFUSED = Preroll_Flag._(2, 'KIEF_INFUSED');
  static const Preroll_Flag FORTIFIED = Preroll_Flag._(3, 'FORTIFIED');
  static const Preroll_Flag FULL_FLOWER = Preroll_Flag._(4, 'FULL_FLOWER');
  static const Preroll_Flag CONTAINS_TOBACCO = Preroll_Flag._(5, 'CONTAINS_TOBACCO');

  static const $core.List<Preroll_Flag> values = <Preroll_Flag> [
    NO_PREROLL_FLAGS,
    HASH_INFUSED,
    KIEF_INFUSED,
    FORTIFIED,
    FULL_FLOWER,
    CONTAINS_TOBACCO,
  ];

  static final $core.Map<$core.int, Preroll_Flag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Preroll_Flag valueOf($core.int value) => _byValue[value];

  const Preroll_Flag._($core.int v, $core.String n) : super(v, n);
}

