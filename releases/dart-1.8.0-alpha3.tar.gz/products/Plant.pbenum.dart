///
//  Generated code. Do not modify.
//  source: products/Plant.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Plant_Type extends $pb.ProtobufEnum {
  static const Plant_Type UNSPECIFIED_PLANT = Plant_Type._(0, 'UNSPECIFIED_PLANT');
  static const Plant_Type SEED = Plant_Type._(1, 'SEED');
  static const Plant_Type CLONE = Plant_Type._(2, 'CLONE');

  static const $core.List<Plant_Type> values = <Plant_Type> [
    UNSPECIFIED_PLANT,
    SEED,
    CLONE,
  ];

  static final $core.Map<$core.int, Plant_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Plant_Type valueOf($core.int value) => _byValue[value];

  const Plant_Type._($core.int v, $core.String n) : super(v, n);
}

