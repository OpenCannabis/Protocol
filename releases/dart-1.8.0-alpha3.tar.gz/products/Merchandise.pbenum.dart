///
//  Generated code. Do not modify.
//  source: products/Merchandise.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class MerchandiseFlag extends $pb.ProtobufEnum {
  static const MerchandiseFlag NO_MERCHANDISE_FLAGS = MerchandiseFlag._(0, 'NO_MERCHANDISE_FLAGS');
  static const MerchandiseFlag MEDICAL_ONLY = MerchandiseFlag._(1, 'MEDICAL_ONLY');
  static const MerchandiseFlag BRAND_SWAG = MerchandiseFlag._(2, 'BRAND_SWAG');

  static const $core.List<MerchandiseFlag> values = <MerchandiseFlag> [
    NO_MERCHANDISE_FLAGS,
    MEDICAL_ONLY,
    BRAND_SWAG,
  ];

  static final $core.Map<$core.int, MerchandiseFlag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static MerchandiseFlag valueOf($core.int value) => _byValue[value];

  const MerchandiseFlag._($core.int v, $core.String n) : super(v, n);
}

class Merchandise_Type extends $pb.ProtobufEnum {
  static const Merchandise_Type UNSPECIFIED_MERCHANDISE = Merchandise_Type._(0, 'UNSPECIFIED_MERCHANDISE');
  static const Merchandise_Type CLOTHING = Merchandise_Type._(1, 'CLOTHING');
  static const Merchandise_Type GLASSWARE = Merchandise_Type._(2, 'GLASSWARE');
  static const Merchandise_Type CONTAINER = Merchandise_Type._(3, 'CONTAINER');
  static const Merchandise_Type LIGHTER = Merchandise_Type._(4, 'LIGHTER');
  static const Merchandise_Type TSHIRT = Merchandise_Type._(5, 'TSHIRT');
  static const Merchandise_Type HOODIE = Merchandise_Type._(6, 'HOODIE');
  static const Merchandise_Type HAT = Merchandise_Type._(7, 'HAT');
  static const Merchandise_Type ACCESSORIES = Merchandise_Type._(8, 'ACCESSORIES');
  static const Merchandise_Type PAPERS = Merchandise_Type._(9, 'PAPERS');

  static const $core.List<Merchandise_Type> values = <Merchandise_Type> [
    UNSPECIFIED_MERCHANDISE,
    CLOTHING,
    GLASSWARE,
    CONTAINER,
    LIGHTER,
    TSHIRT,
    HOODIE,
    HAT,
    ACCESSORIES,
    PAPERS,
  ];

  static final $core.Map<$core.int, Merchandise_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Merchandise_Type valueOf($core.int value) => _byValue[value];

  const Merchandise_Type._($core.int v, $core.String n) : super(v, n);
}

