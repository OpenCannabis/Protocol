///
//  Generated code. Do not modify.
//  source: products/Apothecary.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $16;
import '../content/ProductContent.pb.dart' as $52;
import '../content/MaterialsData.pb.dart' as $53;

import 'Apothecary.pbenum.dart';

export 'Apothecary.pbenum.dart';

class Apothecary extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Apothecary', package: const $pb.PackageName('opencannabis.products'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..e<Apothecary_Type>(2, 'type', $pb.PbFieldType.OE, Apothecary_Type.UNSPECIFIED_APOTHECARY, Apothecary_Type.valueOf, Apothecary_Type.values)
    ..a<$52.ProductContent>(3, 'product', $pb.PbFieldType.OM, $52.ProductContent.getDefault, $52.ProductContent.create)
    ..a<$53.MaterialsData>(4, 'material', $pb.PbFieldType.OM, $53.MaterialsData.getDefault, $53.MaterialsData.create)
    ..hasRequiredFields = false
  ;

  Apothecary() : super();
  Apothecary.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Apothecary.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Apothecary clone() => Apothecary()..mergeFromMessage(this);
  Apothecary copyWith(void Function(Apothecary) updates) => super.copyWith((message) => updates(message as Apothecary));
  $pb.BuilderInfo get info_ => _i;
  static Apothecary create() => Apothecary();
  Apothecary createEmptyInstance() => create();
  static $pb.PbList<Apothecary> createRepeated() => $pb.PbList<Apothecary>();
  static Apothecary getDefault() => _defaultInstance ??= create()..freeze();
  static Apothecary _defaultInstance;

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  Apothecary_Type get type => $_getN(1);
  set type(Apothecary_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $52.ProductContent get product => $_getN(2);
  set product($52.ProductContent v) { setField(3, v); }
  $core.bool hasProduct() => $_has(2);
  void clearProduct() => clearField(3);

  $53.MaterialsData get material => $_getN(3);
  set material($53.MaterialsData v) { setField(4, v); }
  $core.bool hasMaterial() => $_has(3);
  void clearMaterial() => clearField(4);
}

