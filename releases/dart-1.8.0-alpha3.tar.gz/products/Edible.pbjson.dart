///
//  Generated code. Do not modify.
//  source: products/Edible.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const EdibleIngredient$json = const {
  '1': 'EdibleIngredient',
  '2': const [
    const {'1': 'label', '3': 1, '4': 1, '5': 9, '10': 'label'},
    const {'1': 'amount', '3': 2, '4': 1, '5': 9, '10': 'amount'},
  ],
};

const Edible$json = const {
  '1': 'Edible',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '10': 'key'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.products.Edible.Type', '10': 'type'},
    const {'1': 'flags', '3': 3, '4': 3, '5': 14, '6': '.opencannabis.products.Edible.Flag', '10': 'flags'},
    const {'1': 'product', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.content.ProductContent', '10': 'product'},
    const {'1': 'material', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.content.MaterialsData', '10': 'material'},
    const {'1': 'ingredients', '3': 6, '4': 3, '5': 11, '6': '.opencannabis.products.EdibleIngredient', '10': 'ingredients'},
  ],
  '4': const [Edible_Type$json, Edible_Flag$json],
};

const Edible_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'UNSPECIFIED_EDIBLE', '2': 0},
    const {'1': 'CHOCOLATE', '2': 1},
    const {'1': 'BAKED_GOOD', '2': 2},
    const {'1': 'CANDY', '2': 3},
    const {'1': 'BEVERAGE', '2': 4},
    const {'1': 'LOZENGE', '2': 5},
    const {'1': 'SUBLINGUAL', '2': 6},
    const {'1': 'GUMMY', '2': 7},
    const {'1': 'BUTTER', '2': 8},
    const {'1': 'OILS', '2': 9},
    const {'1': 'CEREAL', '2': 10},
    const {'1': 'CAPSULE', '2': 11},
  ],
};

const Edible_Flag$json = const {
  '1': 'Flag',
  '2': const [
    const {'1': 'NO_EDIBLE_FLAG', '2': 0},
    const {'1': 'VEGAN', '2': 1},
    const {'1': 'GLUTEN_FREE', '2': 2},
    const {'1': 'SUGAR_FREE', '2': 3},
    const {'1': 'FAIR_TRADE', '2': 4},
    const {'1': 'ORGANIC', '2': 5},
    const {'1': 'LOCAL', '2': 6},
  ],
};

