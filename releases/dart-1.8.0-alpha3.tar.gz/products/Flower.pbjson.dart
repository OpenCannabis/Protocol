///
//  Generated code. Do not modify.
//  source: products/Flower.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Flower$json = const {
  '1': 'Flower',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '10': 'key'},
    const {'1': 'product', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.content.ProductContent', '10': 'product'},
    const {'1': 'material', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.content.MaterialsData', '10': 'material'},
    const {'1': 'type', '3': 4, '4': 1, '5': 14, '6': '.opencannabis.products.Flower.Type', '10': 'type'},
  ],
  '4': const [Flower_Type$json],
};

const Flower_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'TRIMMED', '2': 0},
    const {'1': 'SHAKE', '2': 1},
    const {'1': 'SMALL_NUGS', '2': 2},
    const {'1': 'PREMIUM_NUGS', '2': 3},
  ],
};

