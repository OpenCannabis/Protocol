///
//  Generated code. Do not modify.
//  source: products/Extract.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Extract_Flag extends $pb.ProtobufEnum {
  static const Extract_Flag NO_EXTRACT_FLAGS = Extract_Flag._(0, 'NO_EXTRACT_FLAGS');
  static const Extract_Flag SOLVENTLESS = Extract_Flag._(1, 'SOLVENTLESS');

  static const $core.List<Extract_Flag> values = <Extract_Flag> [
    NO_EXTRACT_FLAGS,
    SOLVENTLESS,
  ];

  static final $core.Map<$core.int, Extract_Flag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Extract_Flag valueOf($core.int value) => _byValue[value];

  const Extract_Flag._($core.int v, $core.String n) : super(v, n);
}

class Extract_Type extends $pb.ProtobufEnum {
  static const Extract_Type UNSPECIFIED_EXTRACT = Extract_Type._(0, 'UNSPECIFIED_EXTRACT');
  static const Extract_Type OIL = Extract_Type._(1, 'OIL');
  static const Extract_Type WAX = Extract_Type._(2, 'WAX');
  static const Extract_Type SHATTER = Extract_Type._(3, 'SHATTER');
  static const Extract_Type KIEF = Extract_Type._(4, 'KIEF');
  static const Extract_Type HASH = Extract_Type._(5, 'HASH');
  static const Extract_Type LIVE_RESIN = Extract_Type._(6, 'LIVE_RESIN');
  static const Extract_Type ROSIN = Extract_Type._(7, 'ROSIN');
  static const Extract_Type CRUMBLE = Extract_Type._(8, 'CRUMBLE');
  static const Extract_Type SAUCE = Extract_Type._(9, 'SAUCE');
  static const Extract_Type SUGAR = Extract_Type._(10, 'SUGAR');

  static const $core.List<Extract_Type> values = <Extract_Type> [
    UNSPECIFIED_EXTRACT,
    OIL,
    WAX,
    SHATTER,
    KIEF,
    HASH,
    LIVE_RESIN,
    ROSIN,
    CRUMBLE,
    SAUCE,
    SUGAR,
  ];

  static final $core.Map<$core.int, Extract_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Extract_Type valueOf($core.int value) => _byValue[value];

  const Extract_Type._($core.int v, $core.String n) : super(v, n);
}

