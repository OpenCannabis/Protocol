///
//  Generated code. Do not modify.
//  source: products/Merchandise.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const MerchandiseFlag$json = const {
  '1': 'MerchandiseFlag',
  '2': const [
    const {'1': 'NO_MERCHANDISE_FLAGS', '2': 0},
    const {'1': 'MEDICAL_ONLY', '2': 1},
    const {'1': 'BRAND_SWAG', '2': 2},
  ],
};

const Merchandise$json = const {
  '1': 'Merchandise',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.base.ProductKey', '10': 'key'},
    const {'1': 'type', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.products.Merchandise.Type', '10': 'type'},
    const {'1': 'flags', '3': 3, '4': 3, '5': 14, '6': '.opencannabis.products.MerchandiseFlag', '10': 'flags'},
    const {'1': 'product', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.content.ProductContent', '10': 'product'},
  ],
  '4': const [Merchandise_Type$json],
};

const Merchandise_Type$json = const {
  '1': 'Type',
  '2': const [
    const {'1': 'UNSPECIFIED_MERCHANDISE', '2': 0},
    const {'1': 'CLOTHING', '2': 1},
    const {'1': 'GLASSWARE', '2': 2},
    const {'1': 'CONTAINER', '2': 3},
    const {'1': 'LIGHTER', '2': 4},
    const {'1': 'TSHIRT', '2': 5},
    const {'1': 'HOODIE', '2': 6},
    const {'1': 'HAT', '2': 7},
    const {
      '1': 'ACCESSORIES',
      '2': 8,
      '3': const {'1': true},
    },
    const {'1': 'PAPERS', '2': 9},
  ],
};

