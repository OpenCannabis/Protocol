///
//  Generated code. Do not modify.
//  source: products/distribution/DistributionChannel.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'DistributionChannel.pbenum.dart';

export 'DistributionChannel.pbenum.dart';

class DistributionPolicy extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DistributionPolicy', package: const $pb.PackageName('opencannabis.products.distribution'))
    ..aOB(1, 'enabled')
    ..e<Channel>(2, 'channel', $pb.PbFieldType.OE, Channel.UNSPECIFIED_CHANNEL, Channel.valueOf, Channel.values)
    ..e<ChannelType>(3, 'type', $pb.PbFieldType.OE, ChannelType.UNSPECIFIED_CHANNEL_TYPE, ChannelType.valueOf, ChannelType.values)
    ..aOB(4, 'suppress')
    ..hasRequiredFields = false
  ;

  DistributionPolicy() : super();
  DistributionPolicy.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DistributionPolicy.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DistributionPolicy clone() => DistributionPolicy()..mergeFromMessage(this);
  DistributionPolicy copyWith(void Function(DistributionPolicy) updates) => super.copyWith((message) => updates(message as DistributionPolicy));
  $pb.BuilderInfo get info_ => _i;
  static DistributionPolicy create() => DistributionPolicy();
  DistributionPolicy createEmptyInstance() => create();
  static $pb.PbList<DistributionPolicy> createRepeated() => $pb.PbList<DistributionPolicy>();
  static DistributionPolicy getDefault() => _defaultInstance ??= create()..freeze();
  static DistributionPolicy _defaultInstance;

  $core.bool get enabled => $_get(0, false);
  set enabled($core.bool v) { $_setBool(0, v); }
  $core.bool hasEnabled() => $_has(0);
  void clearEnabled() => clearField(1);

  Channel get channel => $_getN(1);
  set channel(Channel v) { setField(2, v); }
  $core.bool hasChannel() => $_has(1);
  void clearChannel() => clearField(2);

  ChannelType get type => $_getN(2);
  set type(ChannelType v) { setField(3, v); }
  $core.bool hasType() => $_has(2);
  void clearType() => clearField(3);

  $core.bool get suppress => $_get(3, false);
  set suppress($core.bool v) { $_setBool(3, v); }
  $core.bool hasSuppress() => $_has(3);
  void clearSuppress() => clearField(4);
}

