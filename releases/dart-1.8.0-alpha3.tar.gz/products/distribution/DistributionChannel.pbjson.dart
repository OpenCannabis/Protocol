///
//  Generated code. Do not modify.
//  source: products/distribution/DistributionChannel.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const Channel$json = const {
  '1': 'Channel',
  '2': const [
    const {'1': 'UNSPECIFIED_CHANNEL', '2': 0},
    const {'1': 'RETAIL', '2': 1},
    const {'1': 'WHOLESALE', '2': 2},
    const {'1': 'BULK', '2': 3},
  ],
};

const ChannelType$json = const {
  '1': 'ChannelType',
  '2': const [
    const {'1': 'UNSPECIFIED_CHANNEL_TYPE', '2': 0},
    const {'1': 'DIRECT', '2': 1},
    const {'1': 'MARKETPLACE', '2': 2},
  ],
};

const DistributionPolicy$json = const {
  '1': 'DistributionPolicy',
  '2': const [
    const {'1': 'enabled', '3': 1, '4': 1, '5': 8, '10': 'enabled'},
    const {'1': 'channel', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.products.distribution.Channel', '10': 'channel'},
    const {'1': 'type', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.products.distribution.ChannelType', '10': 'type'},
    const {'1': 'suppress', '3': 4, '4': 1, '5': 8, '10': 'suppress'},
  ],
};

