///
//  Generated code. Do not modify.
//  source: products/Merchandise.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $16;
import '../content/ProductContent.pb.dart' as $52;

import 'Merchandise.pbenum.dart';

export 'Merchandise.pbenum.dart';

class Merchandise extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Merchandise', package: const $pb.PackageName('opencannabis.products'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..e<Merchandise_Type>(2, 'type', $pb.PbFieldType.OE, Merchandise_Type.UNSPECIFIED_MERCHANDISE, Merchandise_Type.valueOf, Merchandise_Type.values)
    ..pc<MerchandiseFlag>(3, 'flags', $pb.PbFieldType.PE, null, MerchandiseFlag.valueOf, MerchandiseFlag.values)
    ..a<$52.ProductContent>(4, 'product', $pb.PbFieldType.OM, $52.ProductContent.getDefault, $52.ProductContent.create)
    ..hasRequiredFields = false
  ;

  Merchandise() : super();
  Merchandise.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Merchandise.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Merchandise clone() => Merchandise()..mergeFromMessage(this);
  Merchandise copyWith(void Function(Merchandise) updates) => super.copyWith((message) => updates(message as Merchandise));
  $pb.BuilderInfo get info_ => _i;
  static Merchandise create() => Merchandise();
  Merchandise createEmptyInstance() => create();
  static $pb.PbList<Merchandise> createRepeated() => $pb.PbList<Merchandise>();
  static Merchandise getDefault() => _defaultInstance ??= create()..freeze();
  static Merchandise _defaultInstance;

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  Merchandise_Type get type => $_getN(1);
  set type(Merchandise_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $core.List<MerchandiseFlag> get flags => $_getList(2);

  $52.ProductContent get product => $_getN(3);
  set product($52.ProductContent v) { setField(4, v); }
  $core.bool hasProduct() => $_has(3);
  void clearProduct() => clearField(4);
}

