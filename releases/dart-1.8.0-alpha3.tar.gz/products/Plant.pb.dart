///
//  Generated code. Do not modify.
//  source: products/Plant.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $16;
import '../content/ProductContent.pb.dart' as $52;
import '../content/MaterialsData.pb.dart' as $53;

import 'Plant.pbenum.dart';

export 'Plant.pbenum.dart';

class Plant extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Plant', package: const $pb.PackageName('opencannabis.products'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..e<Plant_Type>(2, 'type', $pb.PbFieldType.OE, Plant_Type.UNSPECIFIED_PLANT, Plant_Type.valueOf, Plant_Type.values)
    ..pc<$16.ProductReference>(3, 'origin', $pb.PbFieldType.PM,$16.ProductReference.create)
    ..a<$52.ProductContent>(4, 'product', $pb.PbFieldType.OM, $52.ProductContent.getDefault, $52.ProductContent.create)
    ..a<$53.MaterialsData>(5, 'material', $pb.PbFieldType.OM, $53.MaterialsData.getDefault, $53.MaterialsData.create)
    ..hasRequiredFields = false
  ;

  Plant() : super();
  Plant.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Plant.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Plant clone() => Plant()..mergeFromMessage(this);
  Plant copyWith(void Function(Plant) updates) => super.copyWith((message) => updates(message as Plant));
  $pb.BuilderInfo get info_ => _i;
  static Plant create() => Plant();
  Plant createEmptyInstance() => create();
  static $pb.PbList<Plant> createRepeated() => $pb.PbList<Plant>();
  static Plant getDefault() => _defaultInstance ??= create()..freeze();
  static Plant _defaultInstance;

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  Plant_Type get type => $_getN(1);
  set type(Plant_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $core.List<$16.ProductReference> get origin => $_getList(2);

  $52.ProductContent get product => $_getN(3);
  set product($52.ProductContent v) { setField(4, v); }
  $core.bool hasProduct() => $_has(3);
  void clearProduct() => clearField(4);

  $53.MaterialsData get material => $_getN(4);
  set material($53.MaterialsData v) { setField(5, v); }
  $core.bool hasMaterial() => $_has(4);
  void clearMaterial() => clearField(5);
}

