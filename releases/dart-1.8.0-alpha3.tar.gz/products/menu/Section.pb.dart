///
//  Generated code. Do not modify.
//  source: products/menu/Section.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../../media/MediaItem.pb.dart' as $27;
import '../../content/Name.pb.dart' as $3;

import 'Section.pbenum.dart';

export 'Section.pbenum.dart';

class CustomSection extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CustomSection', package: const $pb.PackageName('opencannabis.products.menu.section'))
    ..aOS(1, 'id')
    ..e<FilteredSection>(2, 'filter', $pb.PbFieldType.OE, FilteredSection.ON_SALE, FilteredSection.valueOf, FilteredSection.values)
    ..hasRequiredFields = false
  ;

  CustomSection() : super();
  CustomSection.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CustomSection.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CustomSection clone() => CustomSection()..mergeFromMessage(this);
  CustomSection copyWith(void Function(CustomSection) updates) => super.copyWith((message) => updates(message as CustomSection));
  $pb.BuilderInfo get info_ => _i;
  static CustomSection create() => CustomSection();
  CustomSection createEmptyInstance() => create();
  static $pb.PbList<CustomSection> createRepeated() => $pb.PbList<CustomSection>();
  static CustomSection getDefault() => _defaultInstance ??= create()..freeze();
  static CustomSection _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  FilteredSection get filter => $_getN(1);
  set filter(FilteredSection v) { setField(2, v); }
  $core.bool hasFilter() => $_has(1);
  void clearFilter() => clearField(2);
}

class SectionMedia extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SectionMedia', package: const $pb.PackageName('opencannabis.products.menu.section'))
    ..a<$27.MediaItem>(2, 'tabletHomescreenMedia', $pb.PbFieldType.OM, $27.MediaItem.getDefault, $27.MediaItem.create)
    ..hasRequiredFields = false
  ;

  SectionMedia() : super();
  SectionMedia.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SectionMedia.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SectionMedia clone() => SectionMedia()..mergeFromMessage(this);
  SectionMedia copyWith(void Function(SectionMedia) updates) => super.copyWith((message) => updates(message as SectionMedia));
  $pb.BuilderInfo get info_ => _i;
  static SectionMedia create() => SectionMedia();
  SectionMedia createEmptyInstance() => create();
  static $pb.PbList<SectionMedia> createRepeated() => $pb.PbList<SectionMedia>();
  static SectionMedia getDefault() => _defaultInstance ??= create()..freeze();
  static SectionMedia _defaultInstance;

  $27.MediaItem get tabletHomescreenMedia => $_getN(0);
  set tabletHomescreenMedia($27.MediaItem v) { setField(2, v); }
  $core.bool hasTabletHomescreenMedia() => $_has(0);
  void clearTabletHomescreenMedia() => clearField(2);
}

class SectionSettings extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SectionSettings', package: const $pb.PackageName('opencannabis.products.menu.section'))
    ..a<$3.Name>(1, 'name', $pb.PbFieldType.OM, $3.Name.getDefault, $3.Name.create)
    ..a<SectionMedia>(2, 'media', $pb.PbFieldType.OM, SectionMedia.getDefault, SectionMedia.create)
    ..hasRequiredFields = false
  ;

  SectionSettings() : super();
  SectionSettings.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SectionSettings.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SectionSettings clone() => SectionSettings()..mergeFromMessage(this);
  SectionSettings copyWith(void Function(SectionSettings) updates) => super.copyWith((message) => updates(message as SectionSettings));
  $pb.BuilderInfo get info_ => _i;
  static SectionSettings create() => SectionSettings();
  SectionSettings createEmptyInstance() => create();
  static $pb.PbList<SectionSettings> createRepeated() => $pb.PbList<SectionSettings>();
  static SectionSettings getDefault() => _defaultInstance ??= create()..freeze();
  static SectionSettings _defaultInstance;

  $3.Name get name => $_getN(0);
  set name($3.Name v) { setField(1, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  SectionMedia get media => $_getN(1);
  set media(SectionMedia v) { setField(2, v); }
  $core.bool hasMedia() => $_has(1);
  void clearMedia() => clearField(2);
}

enum SectionSpec_Spec {
  section, 
  customSection, 
  name, 
  notSet
}

class SectionSpec extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, SectionSpec_Spec> _SectionSpec_SpecByTag = {
    1 : SectionSpec_Spec.section,
    2 : SectionSpec_Spec.customSection,
    3 : SectionSpec_Spec.name,
    0 : SectionSpec_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SectionSpec', package: const $pb.PackageName('opencannabis.products.menu.section'))
    ..e<Section>(1, 'section', $pb.PbFieldType.OE, Section.UNSPECIFIED, Section.valueOf, Section.values)
    ..a<CustomSection>(2, 'customSection', $pb.PbFieldType.OM, CustomSection.getDefault, CustomSection.create)
    ..aOS(3, 'name')
    ..a<SectionSettings>(4, 'settings', $pb.PbFieldType.OM, SectionSettings.getDefault, SectionSettings.create)
    ..pc<SectionFlag>(5, 'flags', $pb.PbFieldType.PE, null, SectionFlag.valueOf, SectionFlag.values)
    ..oo(0, [1, 2, 3])
    ..hasRequiredFields = false
  ;

  SectionSpec() : super();
  SectionSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SectionSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SectionSpec clone() => SectionSpec()..mergeFromMessage(this);
  SectionSpec copyWith(void Function(SectionSpec) updates) => super.copyWith((message) => updates(message as SectionSpec));
  $pb.BuilderInfo get info_ => _i;
  static SectionSpec create() => SectionSpec();
  SectionSpec createEmptyInstance() => create();
  static $pb.PbList<SectionSpec> createRepeated() => $pb.PbList<SectionSpec>();
  static SectionSpec getDefault() => _defaultInstance ??= create()..freeze();
  static SectionSpec _defaultInstance;

  SectionSpec_Spec whichSpec() => _SectionSpec_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  Section get section => $_getN(0);
  set section(Section v) { setField(1, v); }
  $core.bool hasSection() => $_has(0);
  void clearSection() => clearField(1);

  CustomSection get customSection => $_getN(1);
  set customSection(CustomSection v) { setField(2, v); }
  $core.bool hasCustomSection() => $_has(1);
  void clearCustomSection() => clearField(2);

  $core.String get name => $_getS(2, '');
  set name($core.String v) { $_setString(2, v); }
  $core.bool hasName() => $_has(2);
  void clearName() => clearField(3);

  SectionSettings get settings => $_getN(3);
  set settings(SectionSettings v) { setField(4, v); }
  $core.bool hasSettings() => $_has(3);
  void clearSettings() => clearField(4);

  $core.List<SectionFlag> get flags => $_getList(4);
}

