///
//  Generated code. Do not modify.
//  source: products/menu/Menu.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart' as $pb;

import '../../crypto/primitives/Integrity.pb.dart' as $54;
import '../../temporal/Instant.pb.dart' as $0;
import '../../base/ProductKey.pb.dart' as $16;
import '../../media/MediaKey.pb.dart' as $26;
import '../SKU.pb.dart' as $55;
import '../../partner/LocationKey.pb.dart' as $56;
import '../Apothecary.pb.dart' as $57;
import '../Cartridge.pb.dart' as $58;
import '../Edible.pb.dart' as $59;
import '../Extract.pb.dart' as $60;
import '../Flower.pb.dart' as $61;
import '../Merchandise.pb.dart' as $62;
import '../Plant.pb.dart' as $63;
import '../Preroll.pb.dart' as $64;
import 'Section.pb.dart' as $65;

import 'Section.pbenum.dart' as $65;
import 'Menu.pbenum.dart';

export 'Menu.pbenum.dart';

class MenuSettings extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MenuSettings', package: const $pb.PackageName('opencannabis.products.menu'))
    ..aOB(1, 'full')
    ..aOB(2, 'keysOnly')
    ..a<$54.Hash>(3, 'snapshot', $pb.PbFieldType.OM, $54.Hash.getDefault, $54.Hash.create)
    ..a<$54.Hash>(4, 'fingerprint', $pb.PbFieldType.OM, $54.Hash.getDefault, $54.Hash.create)
    ..pc<$65.Section>(5, 'section', $pb.PbFieldType.PE, null, $65.Section.valueOf, $65.Section.values)
    ..pc<$65.Section>(6, 'availableSection', $pb.PbFieldType.PE, null, $65.Section.valueOf, $65.Section.values)
    ..hasRequiredFields = false
  ;

  MenuSettings() : super();
  MenuSettings.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MenuSettings.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MenuSettings clone() => MenuSettings()..mergeFromMessage(this);
  MenuSettings copyWith(void Function(MenuSettings) updates) => super.copyWith((message) => updates(message as MenuSettings));
  $pb.BuilderInfo get info_ => _i;
  static MenuSettings create() => MenuSettings();
  MenuSettings createEmptyInstance() => create();
  static $pb.PbList<MenuSettings> createRepeated() => $pb.PbList<MenuSettings>();
  static MenuSettings getDefault() => _defaultInstance ??= create()..freeze();
  static MenuSettings _defaultInstance;

  $core.bool get full => $_get(0, false);
  set full($core.bool v) { $_setBool(0, v); }
  $core.bool hasFull() => $_has(0);
  void clearFull() => clearField(1);

  $core.bool get keysOnly => $_get(1, false);
  set keysOnly($core.bool v) { $_setBool(1, v); }
  $core.bool hasKeysOnly() => $_has(1);
  void clearKeysOnly() => clearField(2);

  $54.Hash get snapshot => $_getN(2);
  set snapshot($54.Hash v) { setField(3, v); }
  $core.bool hasSnapshot() => $_has(2);
  void clearSnapshot() => clearField(3);

  $54.Hash get fingerprint => $_getN(3);
  set fingerprint($54.Hash v) { setField(4, v); }
  $core.bool hasFingerprint() => $_has(3);
  void clearFingerprint() => clearField(4);

  $core.List<$65.Section> get section => $_getList(4);

  $core.List<$65.Section> get availableSection => $_getList(5);
}

class Metadata extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Metadata', package: const $pb.PackageName('opencannabis.products.menu'))
    ..aOS(1, 'scope')
    ..a<Int64>(2, 'version', $pb.PbFieldType.OU6, Int64.ZERO)
    ..e<Status>(3, 'status', $pb.PbFieldType.OE, Status.UNPUBLISHED, Status.valueOf, Status.values)
    ..pc<Flag>(4, 'flags', $pb.PbFieldType.PE, null, Flag.valueOf, Flag.values)
    ..a<$0.Instant>(5, 'published', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<MenuSettings>(6, 'settings', $pb.PbFieldType.OM, MenuSettings.getDefault, MenuSettings.create)
    ..hasRequiredFields = false
  ;

  Metadata() : super();
  Metadata.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Metadata.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Metadata clone() => Metadata()..mergeFromMessage(this);
  Metadata copyWith(void Function(Metadata) updates) => super.copyWith((message) => updates(message as Metadata));
  $pb.BuilderInfo get info_ => _i;
  static Metadata create() => Metadata();
  Metadata createEmptyInstance() => create();
  static $pb.PbList<Metadata> createRepeated() => $pb.PbList<Metadata>();
  static Metadata getDefault() => _defaultInstance ??= create()..freeze();
  static Metadata _defaultInstance;

  $core.String get scope => $_getS(0, '');
  set scope($core.String v) { $_setString(0, v); }
  $core.bool hasScope() => $_has(0);
  void clearScope() => clearField(1);

  Int64 get version => $_getI64(1);
  set version(Int64 v) { $_setInt64(1, v); }
  $core.bool hasVersion() => $_has(1);
  void clearVersion() => clearField(2);

  Status get status => $_getN(2);
  set status(Status v) { setField(3, v); }
  $core.bool hasStatus() => $_has(2);
  void clearStatus() => clearField(3);

  $core.List<Flag> get flags => $_getList(3);

  $0.Instant get published => $_getN(4);
  set published($0.Instant v) { setField(5, v); }
  $core.bool hasPublished() => $_has(4);
  void clearPublished() => clearField(5);

  MenuSettings get settings => $_getN(5);
  set settings(MenuSettings v) { setField(6, v); }
  $core.bool hasSettings() => $_has(5);
  void clearSettings() => clearField(6);
}

class ProductTag extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ProductTag', package: const $pb.PackageName('opencannabis.products.menu'))
    ..aOS(1, 'id')
    ..aOS(2, 'partner')
    ..aOS(3, 'location')
    ..aOS(4, 'display')
    ..aOS(5, 'color')
    ..aOS(6, 'description')
    ..hasRequiredFields = false
  ;

  ProductTag() : super();
  ProductTag.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ProductTag.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ProductTag clone() => ProductTag()..mergeFromMessage(this);
  ProductTag copyWith(void Function(ProductTag) updates) => super.copyWith((message) => updates(message as ProductTag));
  $pb.BuilderInfo get info_ => _i;
  static ProductTag create() => ProductTag();
  ProductTag createEmptyInstance() => create();
  static $pb.PbList<ProductTag> createRepeated() => $pb.PbList<ProductTag>();
  static ProductTag getDefault() => _defaultInstance ??= create()..freeze();
  static ProductTag _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $core.String get partner => $_getS(1, '');
  set partner($core.String v) { $_setString(1, v); }
  $core.bool hasPartner() => $_has(1);
  void clearPartner() => clearField(2);

  $core.String get location => $_getS(2, '');
  set location($core.String v) { $_setString(2, v); }
  $core.bool hasLocation() => $_has(2);
  void clearLocation() => clearField(3);

  $core.String get display => $_getS(3, '');
  set display($core.String v) { $_setString(3, v); }
  $core.bool hasDisplay() => $_has(3);
  void clearDisplay() => clearField(4);

  $core.String get color => $_getS(4, '');
  set color($core.String v) { $_setString(4, v); }
  $core.bool hasColor() => $_has(4);
  void clearColor() => clearField(5);

  $core.String get description => $_getS(5, '');
  set description($core.String v) { $_setString(5, v); }
  $core.bool hasDescription() => $_has(5);
  void clearDescription() => clearField(6);
}

class ForeignReference extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ForeignReference', package: const $pb.PackageName('opencannabis.products.menu'))
    ..aOS(1, 'id')
    ..aOS(2, 'key')
    ..aOS(3, 'partner')
    ..aOS(4, 'location')
    ..aOS(5, 'domain')
    ..aOS(6, 'link')
    ..a<$0.Instant>(7, 'attached', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(8, 'validated', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..hasRequiredFields = false
  ;

  ForeignReference() : super();
  ForeignReference.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ForeignReference.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ForeignReference clone() => ForeignReference()..mergeFromMessage(this);
  ForeignReference copyWith(void Function(ForeignReference) updates) => super.copyWith((message) => updates(message as ForeignReference));
  $pb.BuilderInfo get info_ => _i;
  static ForeignReference create() => ForeignReference();
  ForeignReference createEmptyInstance() => create();
  static $pb.PbList<ForeignReference> createRepeated() => $pb.PbList<ForeignReference>();
  static ForeignReference getDefault() => _defaultInstance ??= create()..freeze();
  static ForeignReference _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  $core.String get key => $_getS(1, '');
  set key($core.String v) { $_setString(1, v); }
  $core.bool hasKey() => $_has(1);
  void clearKey() => clearField(2);

  $core.String get partner => $_getS(2, '');
  set partner($core.String v) { $_setString(2, v); }
  $core.bool hasPartner() => $_has(2);
  void clearPartner() => clearField(3);

  $core.String get location => $_getS(3, '');
  set location($core.String v) { $_setString(3, v); }
  $core.bool hasLocation() => $_has(3);
  void clearLocation() => clearField(4);

  $core.String get domain => $_getS(4, '');
  set domain($core.String v) { $_setString(4, v); }
  $core.bool hasDomain() => $_has(4);
  void clearDomain() => clearField(5);

  $core.String get link => $_getS(5, '');
  set link($core.String v) { $_setString(5, v); }
  $core.bool hasLink() => $_has(5);
  void clearLink() => clearField(6);

  $0.Instant get attached => $_getN(6);
  set attached($0.Instant v) { setField(7, v); }
  $core.bool hasAttached() => $_has(6);
  void clearAttached() => clearField(7);

  $0.Instant get validated => $_getN(7);
  set validated($0.Instant v) { setField(8, v); }
  $core.bool hasValidated() => $_has(7);
  void clearValidated() => clearField(8);
}

enum MenuProduct_Product {
  apothecary, 
  cartridge, 
  edible, 
  extract, 
  flower, 
  merchandise, 
  plant, 
  preroll, 
  notSet
}

class MenuProduct extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, MenuProduct_Product> _MenuProduct_ProductByTag = {
    10 : MenuProduct_Product.apothecary,
    11 : MenuProduct_Product.cartridge,
    12 : MenuProduct_Product.edible,
    13 : MenuProduct_Product.extract,
    14 : MenuProduct_Product.flower,
    15 : MenuProduct_Product.merchandise,
    16 : MenuProduct_Product.plant,
    17 : MenuProduct_Product.preroll,
    0 : MenuProduct_Product.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('MenuProduct', package: const $pb.PackageName('opencannabis.products.menu'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..pc<ProductTag>(2, 'tag', $pb.PbFieldType.PM,ProductTag.create)
    ..pc<ForeignReference>(3, 'ref', $pb.PbFieldType.PM,ForeignReference.create)
    ..pc<$26.MediaReference>(4, 'media', $pb.PbFieldType.PM,$26.MediaReference.create)
    ..pc<$55.MappedSKU>(5, 'sku', $pb.PbFieldType.PM,$55.MappedSKU.create)
    ..a<$56.LocationKey>(6, 'owner', $pb.PbFieldType.OM, $56.LocationKey.getDefault, $56.LocationKey.create)
    ..a<$57.Apothecary>(10, 'apothecary', $pb.PbFieldType.OM, $57.Apothecary.getDefault, $57.Apothecary.create)
    ..a<$58.Cartridge>(11, 'cartridge', $pb.PbFieldType.OM, $58.Cartridge.getDefault, $58.Cartridge.create)
    ..a<$59.Edible>(12, 'edible', $pb.PbFieldType.OM, $59.Edible.getDefault, $59.Edible.create)
    ..a<$60.Extract>(13, 'extract', $pb.PbFieldType.OM, $60.Extract.getDefault, $60.Extract.create)
    ..a<$61.Flower>(14, 'flower', $pb.PbFieldType.OM, $61.Flower.getDefault, $61.Flower.create)
    ..a<$62.Merchandise>(15, 'merchandise', $pb.PbFieldType.OM, $62.Merchandise.getDefault, $62.Merchandise.create)
    ..a<$63.Plant>(16, 'plant', $pb.PbFieldType.OM, $63.Plant.getDefault, $63.Plant.create)
    ..a<$64.Preroll>(17, 'preroll', $pb.PbFieldType.OM, $64.Preroll.getDefault, $64.Preroll.create)
    ..oo(0, [10, 11, 12, 13, 14, 15, 16, 17])
    ..hasRequiredFields = false
  ;

  MenuProduct() : super();
  MenuProduct.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  MenuProduct.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  MenuProduct clone() => MenuProduct()..mergeFromMessage(this);
  MenuProduct copyWith(void Function(MenuProduct) updates) => super.copyWith((message) => updates(message as MenuProduct));
  $pb.BuilderInfo get info_ => _i;
  static MenuProduct create() => MenuProduct();
  MenuProduct createEmptyInstance() => create();
  static $pb.PbList<MenuProduct> createRepeated() => $pb.PbList<MenuProduct>();
  static MenuProduct getDefault() => _defaultInstance ??= create()..freeze();
  static MenuProduct _defaultInstance;

  MenuProduct_Product whichProduct() => _MenuProduct_ProductByTag[$_whichOneof(0)];
  void clearProduct() => clearField($_whichOneof(0));

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $core.List<ProductTag> get tag => $_getList(1);

  $core.List<ForeignReference> get ref => $_getList(2);

  $core.List<$26.MediaReference> get media => $_getList(3);

  $core.List<$55.MappedSKU> get sku => $_getList(4);

  $56.LocationKey get owner => $_getN(5);
  set owner($56.LocationKey v) { setField(6, v); }
  $core.bool hasOwner() => $_has(5);
  void clearOwner() => clearField(6);

  $57.Apothecary get apothecary => $_getN(6);
  set apothecary($57.Apothecary v) { setField(10, v); }
  $core.bool hasApothecary() => $_has(6);
  void clearApothecary() => clearField(10);

  $58.Cartridge get cartridge => $_getN(7);
  set cartridge($58.Cartridge v) { setField(11, v); }
  $core.bool hasCartridge() => $_has(7);
  void clearCartridge() => clearField(11);

  $59.Edible get edible => $_getN(8);
  set edible($59.Edible v) { setField(12, v); }
  $core.bool hasEdible() => $_has(8);
  void clearEdible() => clearField(12);

  $60.Extract get extract => $_getN(9);
  set extract($60.Extract v) { setField(13, v); }
  $core.bool hasExtract() => $_has(9);
  void clearExtract() => clearField(13);

  $61.Flower get flower => $_getN(10);
  set flower($61.Flower v) { setField(14, v); }
  $core.bool hasFlower() => $_has(10);
  void clearFlower() => clearField(14);

  $62.Merchandise get merchandise => $_getN(11);
  set merchandise($62.Merchandise v) { setField(15, v); }
  $core.bool hasMerchandise() => $_has(11);
  void clearMerchandise() => clearField(15);

  $63.Plant get plant => $_getN(12);
  set plant($63.Plant v) { setField(16, v); }
  $core.bool hasPlant() => $_has(12);
  void clearPlant() => clearField(16);

  $64.Preroll get preroll => $_getN(13);
  set preroll($64.Preroll v) { setField(17, v); }
  $core.bool hasPreroll() => $_has(13);
  void clearPreroll() => clearField(17);
}

class SectionData extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SectionData', package: const $pb.PackageName('opencannabis.products.menu'))
    ..a<$core.int>(1, 'count', $pb.PbFieldType.O3)
    ..a<$65.SectionSpec>(2, 'section', $pb.PbFieldType.OM, $65.SectionSpec.getDefault, $65.SectionSpec.create)
    ..pc<MenuProduct>(3, 'product', $pb.PbFieldType.PM,MenuProduct.create)
    ..hasRequiredFields = false
  ;

  SectionData() : super();
  SectionData.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SectionData.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SectionData clone() => SectionData()..mergeFromMessage(this);
  SectionData copyWith(void Function(SectionData) updates) => super.copyWith((message) => updates(message as SectionData));
  $pb.BuilderInfo get info_ => _i;
  static SectionData create() => SectionData();
  SectionData createEmptyInstance() => create();
  static $pb.PbList<SectionData> createRepeated() => $pb.PbList<SectionData>();
  static SectionData getDefault() => _defaultInstance ??= create()..freeze();
  static SectionData _defaultInstance;

  $core.int get count => $_get(0, 0);
  set count($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasCount() => $_has(0);
  void clearCount() => clearField(1);

  $65.SectionSpec get section => $_getN(1);
  set section($65.SectionSpec v) { setField(2, v); }
  $core.bool hasSection() => $_has(1);
  void clearSection() => clearField(2);

  $core.List<MenuProduct> get product => $_getList(2);
}

class SectionedMenu extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SectionedMenu', package: const $pb.PackageName('opencannabis.products.menu'))
    ..a<$core.int>(1, 'count', $pb.PbFieldType.O3)
    ..pc<SectionData>(2, 'payload', $pb.PbFieldType.PM,SectionData.create)
    ..hasRequiredFields = false
  ;

  SectionedMenu() : super();
  SectionedMenu.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SectionedMenu.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SectionedMenu clone() => SectionedMenu()..mergeFromMessage(this);
  SectionedMenu copyWith(void Function(SectionedMenu) updates) => super.copyWith((message) => updates(message as SectionedMenu));
  $pb.BuilderInfo get info_ => _i;
  static SectionedMenu create() => SectionedMenu();
  SectionedMenu createEmptyInstance() => create();
  static $pb.PbList<SectionedMenu> createRepeated() => $pb.PbList<SectionedMenu>();
  static SectionedMenu getDefault() => _defaultInstance ??= create()..freeze();
  static SectionedMenu _defaultInstance;

  $core.int get count => $_get(0, 0);
  set count($core.int v) { $_setSignedInt32(0, v); }
  $core.bool hasCount() => $_has(0);
  void clearCount() => clearField(1);

  $core.List<SectionData> get payload => $_getList(1);
}

class StaticMenu extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('StaticMenu', package: const $pb.PackageName('opencannabis.products.menu'))
    ..m<$core.String, $57.Apothecary>(1, 'apothecary', 'StaticMenu.ApothecaryEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $57.Apothecary.create, null, null , const $pb.PackageName('opencannabis.products.menu'))
    ..m<$core.String, $58.Cartridge>(2, 'cartridges', 'StaticMenu.CartridgesEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $58.Cartridge.create, null, null , const $pb.PackageName('opencannabis.products.menu'))
    ..m<$core.String, $59.Edible>(3, 'edibles', 'StaticMenu.EdiblesEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $59.Edible.create, null, null , const $pb.PackageName('opencannabis.products.menu'))
    ..m<$core.String, $60.Extract>(4, 'extracts', 'StaticMenu.ExtractsEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $60.Extract.create, null, null , const $pb.PackageName('opencannabis.products.menu'))
    ..m<$core.String, $61.Flower>(5, 'flowers', 'StaticMenu.FlowersEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $61.Flower.create, null, null , const $pb.PackageName('opencannabis.products.menu'))
    ..m<$core.String, $62.Merchandise>(6, 'merchandise', 'StaticMenu.MerchandiseEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $62.Merchandise.create, null, null , const $pb.PackageName('opencannabis.products.menu'))
    ..m<$core.String, $63.Plant>(7, 'plants', 'StaticMenu.PlantsEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $63.Plant.create, null, null , const $pb.PackageName('opencannabis.products.menu'))
    ..m<$core.String, $64.Preroll>(8, 'prerolls', 'StaticMenu.PrerollsEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, $64.Preroll.create, null, null , const $pb.PackageName('opencannabis.products.menu'))
    ..hasRequiredFields = false
  ;

  StaticMenu() : super();
  StaticMenu.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  StaticMenu.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  StaticMenu clone() => StaticMenu()..mergeFromMessage(this);
  StaticMenu copyWith(void Function(StaticMenu) updates) => super.copyWith((message) => updates(message as StaticMenu));
  $pb.BuilderInfo get info_ => _i;
  static StaticMenu create() => StaticMenu();
  StaticMenu createEmptyInstance() => create();
  static $pb.PbList<StaticMenu> createRepeated() => $pb.PbList<StaticMenu>();
  static StaticMenu getDefault() => _defaultInstance ??= create()..freeze();
  static StaticMenu _defaultInstance;

  $core.Map<$core.String, $57.Apothecary> get apothecary => $_getMap(0);

  $core.Map<$core.String, $58.Cartridge> get cartridges => $_getMap(1);

  $core.Map<$core.String, $59.Edible> get edibles => $_getMap(2);

  $core.Map<$core.String, $60.Extract> get extracts => $_getMap(3);

  $core.Map<$core.String, $61.Flower> get flowers => $_getMap(4);

  $core.Map<$core.String, $62.Merchandise> get merchandise => $_getMap(5);

  $core.Map<$core.String, $63.Plant> get plants => $_getMap(6);

  $core.Map<$core.String, $64.Preroll> get prerolls => $_getMap(7);
}

enum Menu_Content {
  payload, 
  menu, 
  notSet
}

class Menu extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Menu_Content> _Menu_ContentByTag = {
    3 : Menu_Content.payload,
    4 : Menu_Content.menu,
    0 : Menu_Content.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Menu', package: const $pb.PackageName('opencannabis.products.menu'))
    ..a<Metadata>(1, 'metadata', $pb.PbFieldType.OM, Metadata.getDefault, Metadata.create)
    ..a<SectionedMenu>(3, 'payload', $pb.PbFieldType.OM, SectionedMenu.getDefault, SectionedMenu.create)
    ..a<StaticMenu>(4, 'menu', $pb.PbFieldType.OM, StaticMenu.getDefault, StaticMenu.create)
    ..oo(0, [3, 4])
    ..hasRequiredFields = false
  ;

  Menu() : super();
  Menu.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Menu.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Menu clone() => Menu()..mergeFromMessage(this);
  Menu copyWith(void Function(Menu) updates) => super.copyWith((message) => updates(message as Menu));
  $pb.BuilderInfo get info_ => _i;
  static Menu create() => Menu();
  Menu createEmptyInstance() => create();
  static $pb.PbList<Menu> createRepeated() => $pb.PbList<Menu>();
  static Menu getDefault() => _defaultInstance ??= create()..freeze();
  static Menu _defaultInstance;

  Menu_Content whichContent() => _Menu_ContentByTag[$_whichOneof(0)];
  void clearContent() => clearField($_whichOneof(0));

  Metadata get metadata => $_getN(0);
  set metadata(Metadata v) { setField(1, v); }
  $core.bool hasMetadata() => $_has(0);
  void clearMetadata() => clearField(1);

  SectionedMenu get payload => $_getN(1);
  set payload(SectionedMenu v) { setField(3, v); }
  $core.bool hasPayload() => $_has(1);
  void clearPayload() => clearField(3);

  @$core.Deprecated('This field is deprecated.')
  StaticMenu get menu => $_getN(2);
  @$core.Deprecated('This field is deprecated.')
  set menu(StaticMenu v) { setField(4, v); }
  @$core.Deprecated('This field is deprecated.')
  $core.bool hasMenu() => $_has(2);
  @$core.Deprecated('This field is deprecated.')
  void clearMenu() => clearField(4);
}

