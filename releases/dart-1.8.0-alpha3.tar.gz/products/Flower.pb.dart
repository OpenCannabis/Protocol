///
//  Generated code. Do not modify.
//  source: products/Flower.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $16;
import '../content/ProductContent.pb.dart' as $52;
import '../content/MaterialsData.pb.dart' as $53;

import 'Flower.pbenum.dart';

export 'Flower.pbenum.dart';

class Flower extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Flower', package: const $pb.PackageName('opencannabis.products'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..a<$52.ProductContent>(2, 'product', $pb.PbFieldType.OM, $52.ProductContent.getDefault, $52.ProductContent.create)
    ..a<$53.MaterialsData>(3, 'material', $pb.PbFieldType.OM, $53.MaterialsData.getDefault, $53.MaterialsData.create)
    ..e<Flower_Type>(4, 'type', $pb.PbFieldType.OE, Flower_Type.TRIMMED, Flower_Type.valueOf, Flower_Type.values)
    ..hasRequiredFields = false
  ;

  Flower() : super();
  Flower.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Flower.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Flower clone() => Flower()..mergeFromMessage(this);
  Flower copyWith(void Function(Flower) updates) => super.copyWith((message) => updates(message as Flower));
  $pb.BuilderInfo get info_ => _i;
  static Flower create() => Flower();
  Flower createEmptyInstance() => create();
  static $pb.PbList<Flower> createRepeated() => $pb.PbList<Flower>();
  static Flower getDefault() => _defaultInstance ??= create()..freeze();
  static Flower _defaultInstance;

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $52.ProductContent get product => $_getN(1);
  set product($52.ProductContent v) { setField(2, v); }
  $core.bool hasProduct() => $_has(1);
  void clearProduct() => clearField(2);

  $53.MaterialsData get material => $_getN(2);
  set material($53.MaterialsData v) { setField(3, v); }
  $core.bool hasMaterial() => $_has(2);
  void clearMaterial() => clearField(3);

  Flower_Type get type => $_getN(3);
  set type(Flower_Type v) { setField(4, v); }
  $core.bool hasType() => $_has(3);
  void clearType() => clearField(4);
}

