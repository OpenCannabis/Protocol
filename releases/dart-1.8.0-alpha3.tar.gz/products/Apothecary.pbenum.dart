///
//  Generated code. Do not modify.
//  source: products/Apothecary.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Apothecary_Type extends $pb.ProtobufEnum {
  static const Apothecary_Type UNSPECIFIED_APOTHECARY = Apothecary_Type._(0, 'UNSPECIFIED_APOTHECARY');
  static const Apothecary_Type TOPICAL = Apothecary_Type._(1, 'TOPICAL');
  static const Apothecary_Type TINCTURE = Apothecary_Type._(2, 'TINCTURE');
  static const Apothecary_Type CAPSULE = Apothecary_Type._(3, 'CAPSULE');
  static const Apothecary_Type INJECTOR = Apothecary_Type._(4, 'INJECTOR');
  static const Apothecary_Type SPRAY = Apothecary_Type._(5, 'SPRAY');
  static const Apothecary_Type SUBLINGUAL = Apothecary_Type._(6, 'SUBLINGUAL');
  static const Apothecary_Type SUPPOSITORY = Apothecary_Type._(7, 'SUPPOSITORY');
  static const Apothecary_Type TRANSDERMAL = Apothecary_Type._(8, 'TRANSDERMAL');
  static const Apothecary_Type BATH_AND_BODY = Apothecary_Type._(9, 'BATH_AND_BODY');
  static const Apothecary_Type LOTION = Apothecary_Type._(10, 'LOTION');

  static const $core.List<Apothecary_Type> values = <Apothecary_Type> [
    UNSPECIFIED_APOTHECARY,
    TOPICAL,
    TINCTURE,
    CAPSULE,
    INJECTOR,
    SPRAY,
    SUBLINGUAL,
    SUPPOSITORY,
    TRANSDERMAL,
    BATH_AND_BODY,
    LOTION,
  ];

  static final $core.Map<$core.int, Apothecary_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Apothecary_Type valueOf($core.int value) => _byValue[value];

  const Apothecary_Type._($core.int v, $core.String n) : super(v, n);
}

