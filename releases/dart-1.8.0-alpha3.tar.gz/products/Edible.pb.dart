///
//  Generated code. Do not modify.
//  source: products/Edible.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $16;
import '../content/ProductContent.pb.dart' as $52;
import '../content/MaterialsData.pb.dart' as $53;

import 'Edible.pbenum.dart';

export 'Edible.pbenum.dart';

class EdibleIngredient extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('EdibleIngredient', package: const $pb.PackageName('opencannabis.products'))
    ..aOS(1, 'label')
    ..aOS(2, 'amount')
    ..hasRequiredFields = false
  ;

  EdibleIngredient() : super();
  EdibleIngredient.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  EdibleIngredient.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  EdibleIngredient clone() => EdibleIngredient()..mergeFromMessage(this);
  EdibleIngredient copyWith(void Function(EdibleIngredient) updates) => super.copyWith((message) => updates(message as EdibleIngredient));
  $pb.BuilderInfo get info_ => _i;
  static EdibleIngredient create() => EdibleIngredient();
  EdibleIngredient createEmptyInstance() => create();
  static $pb.PbList<EdibleIngredient> createRepeated() => $pb.PbList<EdibleIngredient>();
  static EdibleIngredient getDefault() => _defaultInstance ??= create()..freeze();
  static EdibleIngredient _defaultInstance;

  $core.String get label => $_getS(0, '');
  set label($core.String v) { $_setString(0, v); }
  $core.bool hasLabel() => $_has(0);
  void clearLabel() => clearField(1);

  $core.String get amount => $_getS(1, '');
  set amount($core.String v) { $_setString(1, v); }
  $core.bool hasAmount() => $_has(1);
  void clearAmount() => clearField(2);
}

class Edible extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Edible', package: const $pb.PackageName('opencannabis.products'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..e<Edible_Type>(2, 'type', $pb.PbFieldType.OE, Edible_Type.UNSPECIFIED_EDIBLE, Edible_Type.valueOf, Edible_Type.values)
    ..pc<Edible_Flag>(3, 'flags', $pb.PbFieldType.PE, null, Edible_Flag.valueOf, Edible_Flag.values)
    ..a<$52.ProductContent>(4, 'product', $pb.PbFieldType.OM, $52.ProductContent.getDefault, $52.ProductContent.create)
    ..a<$53.MaterialsData>(5, 'material', $pb.PbFieldType.OM, $53.MaterialsData.getDefault, $53.MaterialsData.create)
    ..pc<EdibleIngredient>(6, 'ingredients', $pb.PbFieldType.PM,EdibleIngredient.create)
    ..hasRequiredFields = false
  ;

  Edible() : super();
  Edible.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Edible.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Edible clone() => Edible()..mergeFromMessage(this);
  Edible copyWith(void Function(Edible) updates) => super.copyWith((message) => updates(message as Edible));
  $pb.BuilderInfo get info_ => _i;
  static Edible create() => Edible();
  Edible createEmptyInstance() => create();
  static $pb.PbList<Edible> createRepeated() => $pb.PbList<Edible>();
  static Edible getDefault() => _defaultInstance ??= create()..freeze();
  static Edible _defaultInstance;

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  Edible_Type get type => $_getN(1);
  set type(Edible_Type v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  $core.List<Edible_Flag> get flags => $_getList(2);

  $52.ProductContent get product => $_getN(3);
  set product($52.ProductContent v) { setField(4, v); }
  $core.bool hasProduct() => $_has(3);
  void clearProduct() => clearField(4);

  $53.MaterialsData get material => $_getN(4);
  set material($53.MaterialsData v) { setField(5, v); }
  $core.bool hasMaterial() => $_has(4);
  void clearMaterial() => clearField(5);

  $core.List<EdibleIngredient> get ingredients => $_getList(5);
}

