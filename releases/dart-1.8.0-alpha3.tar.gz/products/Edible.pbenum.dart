///
//  Generated code. Do not modify.
//  source: products/Edible.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Edible_Type extends $pb.ProtobufEnum {
  static const Edible_Type UNSPECIFIED_EDIBLE = Edible_Type._(0, 'UNSPECIFIED_EDIBLE');
  static const Edible_Type CHOCOLATE = Edible_Type._(1, 'CHOCOLATE');
  static const Edible_Type BAKED_GOOD = Edible_Type._(2, 'BAKED_GOOD');
  static const Edible_Type CANDY = Edible_Type._(3, 'CANDY');
  static const Edible_Type BEVERAGE = Edible_Type._(4, 'BEVERAGE');
  static const Edible_Type LOZENGE = Edible_Type._(5, 'LOZENGE');
  static const Edible_Type SUBLINGUAL = Edible_Type._(6, 'SUBLINGUAL');
  static const Edible_Type GUMMY = Edible_Type._(7, 'GUMMY');
  static const Edible_Type BUTTER = Edible_Type._(8, 'BUTTER');
  static const Edible_Type OILS = Edible_Type._(9, 'OILS');
  static const Edible_Type CEREAL = Edible_Type._(10, 'CEREAL');
  static const Edible_Type CAPSULE = Edible_Type._(11, 'CAPSULE');

  static const $core.List<Edible_Type> values = <Edible_Type> [
    UNSPECIFIED_EDIBLE,
    CHOCOLATE,
    BAKED_GOOD,
    CANDY,
    BEVERAGE,
    LOZENGE,
    SUBLINGUAL,
    GUMMY,
    BUTTER,
    OILS,
    CEREAL,
    CAPSULE,
  ];

  static final $core.Map<$core.int, Edible_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Edible_Type valueOf($core.int value) => _byValue[value];

  const Edible_Type._($core.int v, $core.String n) : super(v, n);
}

class Edible_Flag extends $pb.ProtobufEnum {
  static const Edible_Flag NO_EDIBLE_FLAG = Edible_Flag._(0, 'NO_EDIBLE_FLAG');
  static const Edible_Flag VEGAN = Edible_Flag._(1, 'VEGAN');
  static const Edible_Flag GLUTEN_FREE = Edible_Flag._(2, 'GLUTEN_FREE');
  static const Edible_Flag SUGAR_FREE = Edible_Flag._(3, 'SUGAR_FREE');
  static const Edible_Flag FAIR_TRADE = Edible_Flag._(4, 'FAIR_TRADE');
  static const Edible_Flag ORGANIC = Edible_Flag._(5, 'ORGANIC');
  static const Edible_Flag LOCAL = Edible_Flag._(6, 'LOCAL');

  static const $core.List<Edible_Flag> values = <Edible_Flag> [
    NO_EDIBLE_FLAG,
    VEGAN,
    GLUTEN_FREE,
    SUGAR_FREE,
    FAIR_TRADE,
    ORGANIC,
    LOCAL,
  ];

  static final $core.Map<$core.int, Edible_Flag> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Edible_Flag valueOf($core.int value) => _byValue[value];

  const Edible_Flag._($core.int v, $core.String n) : super(v, n);
}

