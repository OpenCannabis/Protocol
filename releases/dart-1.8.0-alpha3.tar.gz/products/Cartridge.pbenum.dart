///
//  Generated code. Do not modify.
//  source: products/Cartridge.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class Cartridge_Type extends $pb.ProtobufEnum {
  static const Cartridge_Type UNSPECIFIED_CARTRIDGE = Cartridge_Type._(0, 'UNSPECIFIED_CARTRIDGE');
  static const Cartridge_Type CARTRIDGE = Cartridge_Type._(1, 'CARTRIDGE');
  static const Cartridge_Type BATTERY = Cartridge_Type._(2, 'BATTERY');
  static const Cartridge_Type KIT = Cartridge_Type._(3, 'KIT');
  static const Cartridge_Type DISPOSABLE = Cartridge_Type._(4, 'DISPOSABLE');
  static const Cartridge_Type E_LIQUID = Cartridge_Type._(5, 'E_LIQUID');

  static const $core.List<Cartridge_Type> values = <Cartridge_Type> [
    UNSPECIFIED_CARTRIDGE,
    CARTRIDGE,
    BATTERY,
    KIT,
    DISPOSABLE,
    E_LIQUID,
  ];

  static final $core.Map<$core.int, Cartridge_Type> _byValue = $pb.ProtobufEnum.initByValue(values);
  static Cartridge_Type valueOf($core.int value) => _byValue[value];

  const Cartridge_Type._($core.int v, $core.String n) : super(v, n);
}

