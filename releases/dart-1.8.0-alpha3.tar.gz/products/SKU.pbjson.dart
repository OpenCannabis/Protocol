///
//  Generated code. Do not modify.
//  source: products/SKU.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const SKUType$json = const {
  '1': 'SKUType',
  '2': const [
    const {'1': 'ITEM', '2': 0},
    const {'1': 'PRODUCT', '2': 1},
  ],
};

const MappedSKU$json = const {
  '1': 'MappedSKU',
  '2': const [
    const {'1': 'sku', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'sku'},
    const {'1': 'foreign', '3': 2, '4': 1, '5': 9, '8': const {}, '10': 'foreign'},
    const {'1': 'type', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.products.sku.SKUType', '8': const {}, '10': 'type'},
    const {'1': 'system', '3': 4, '4': 1, '5': 14, '6': '.bloombox.partner.integrations.IntegrationPartner', '8': const {}, '10': 'system'},
    const {'1': 'unit', '3': 10, '4': 1, '5': 8, '9': 0, '10': 'unit'},
    const {'1': 'variant', '3': 11, '4': 1, '5': 11, '6': '.opencannabis.commerce.VariantSpec', '9': 0, '10': 'variant'},
  ],
  '7': const {},
  '8': const [
    const {'1': 'target'},
  ],
};

