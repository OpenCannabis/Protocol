///
//  Generated code. Do not modify.
//  source: products/Preroll.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $16;
import '../content/ProductContent.pb.dart' as $52;
import '../content/MaterialsData.pb.dart' as $53;

import 'Preroll.pbenum.dart';

export 'Preroll.pbenum.dart';

class Preroll extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Preroll', package: const $pb.PackageName('opencannabis.products'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..a<$16.ProductReference>(2, 'flower', $pb.PbFieldType.OM, $16.ProductReference.getDefault, $16.ProductReference.create)
    ..a<$core.double>(3, 'length', $pb.PbFieldType.OD)
    ..a<$core.double>(4, 'thickness', $pb.PbFieldType.OD)
    ..pc<Preroll_Flag>(5, 'flags', $pb.PbFieldType.PE, null, Preroll_Flag.valueOf, Preroll_Flag.values)
    ..a<$52.ProductContent>(6, 'product', $pb.PbFieldType.OM, $52.ProductContent.getDefault, $52.ProductContent.create)
    ..a<$53.MaterialsData>(7, 'material', $pb.PbFieldType.OM, $53.MaterialsData.getDefault, $53.MaterialsData.create)
    ..hasRequiredFields = false
  ;

  Preroll() : super();
  Preroll.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Preroll.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Preroll clone() => Preroll()..mergeFromMessage(this);
  Preroll copyWith(void Function(Preroll) updates) => super.copyWith((message) => updates(message as Preroll));
  $pb.BuilderInfo get info_ => _i;
  static Preroll create() => Preroll();
  Preroll createEmptyInstance() => create();
  static $pb.PbList<Preroll> createRepeated() => $pb.PbList<Preroll>();
  static Preroll getDefault() => _defaultInstance ??= create()..freeze();
  static Preroll _defaultInstance;

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $16.ProductReference get flower => $_getN(1);
  set flower($16.ProductReference v) { setField(2, v); }
  $core.bool hasFlower() => $_has(1);
  void clearFlower() => clearField(2);

  $core.double get length => $_getN(2);
  set length($core.double v) { $_setDouble(2, v); }
  $core.bool hasLength() => $_has(2);
  void clearLength() => clearField(3);

  $core.double get thickness => $_getN(3);
  set thickness($core.double v) { $_setDouble(3, v); }
  $core.bool hasThickness() => $_has(3);
  void clearThickness() => clearField(4);

  $core.List<Preroll_Flag> get flags => $_getList(4);

  $52.ProductContent get product => $_getN(5);
  set product($52.ProductContent v) { setField(6, v); }
  $core.bool hasProduct() => $_has(5);
  void clearProduct() => clearField(6);

  $53.MaterialsData get material => $_getN(6);
  set material($53.MaterialsData v) { setField(7, v); }
  $core.bool hasMaterial() => $_has(6);
  void clearMaterial() => clearField(7);
}

