///
//  Generated code. Do not modify.
//  source: protoc-gen-swagger/options/openapiv2.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:fixnum/fixnum.dart';
import 'package:protobuf/protobuf.dart' as $pb;

import '../../google/protobuf/any.pb.dart' as $74;

import 'openapiv2.pbenum.dart';

export 'openapiv2.pbenum.dart';

class Swagger extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Swagger', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..aOS(1, 'swagger')
    ..a<Info>(2, 'info', $pb.PbFieldType.OM, Info.getDefault, Info.create)
    ..aOS(3, 'host')
    ..aOS(4, 'basePath')
    ..pc<Swagger_SwaggerScheme>(5, 'schemes', $pb.PbFieldType.PE, null, Swagger_SwaggerScheme.valueOf, Swagger_SwaggerScheme.values)
    ..pPS(6, 'consumes')
    ..pPS(7, 'produces')
    ..a<SecurityDefinitions>(11, 'securityDefinitions', $pb.PbFieldType.OM, SecurityDefinitions.getDefault, SecurityDefinitions.create)
    ..pc<SecurityRequirement>(12, 'security', $pb.PbFieldType.PM,SecurityRequirement.create)
    ..a<ExternalDocumentation>(14, 'externalDocs', $pb.PbFieldType.OM, ExternalDocumentation.getDefault, ExternalDocumentation.create)
    ..hasRequiredFields = false
  ;

  Swagger() : super();
  Swagger.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Swagger.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Swagger clone() => Swagger()..mergeFromMessage(this);
  Swagger copyWith(void Function(Swagger) updates) => super.copyWith((message) => updates(message as Swagger));
  $pb.BuilderInfo get info_ => _i;
  static Swagger create() => Swagger();
  Swagger createEmptyInstance() => create();
  static $pb.PbList<Swagger> createRepeated() => $pb.PbList<Swagger>();
  static Swagger getDefault() => _defaultInstance ??= create()..freeze();
  static Swagger _defaultInstance;

  $core.String get swagger => $_getS(0, '');
  set swagger($core.String v) { $_setString(0, v); }
  $core.bool hasSwagger() => $_has(0);
  void clearSwagger() => clearField(1);

  Info get info => $_getN(1);
  set info(Info v) { setField(2, v); }
  $core.bool hasInfo() => $_has(1);
  void clearInfo() => clearField(2);

  $core.String get host => $_getS(2, '');
  set host($core.String v) { $_setString(2, v); }
  $core.bool hasHost() => $_has(2);
  void clearHost() => clearField(3);

  $core.String get basePath => $_getS(3, '');
  set basePath($core.String v) { $_setString(3, v); }
  $core.bool hasBasePath() => $_has(3);
  void clearBasePath() => clearField(4);

  $core.List<Swagger_SwaggerScheme> get schemes => $_getList(4);

  $core.List<$core.String> get consumes => $_getList(5);

  $core.List<$core.String> get produces => $_getList(6);

  SecurityDefinitions get securityDefinitions => $_getN(7);
  set securityDefinitions(SecurityDefinitions v) { setField(11, v); }
  $core.bool hasSecurityDefinitions() => $_has(7);
  void clearSecurityDefinitions() => clearField(11);

  $core.List<SecurityRequirement> get security => $_getList(8);

  ExternalDocumentation get externalDocs => $_getN(9);
  set externalDocs(ExternalDocumentation v) { setField(14, v); }
  $core.bool hasExternalDocs() => $_has(9);
  void clearExternalDocs() => clearField(14);
}

class Operation extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Operation', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..pPS(1, 'tags')
    ..aOS(2, 'summary')
    ..aOS(3, 'description')
    ..a<ExternalDocumentation>(4, 'externalDocs', $pb.PbFieldType.OM, ExternalDocumentation.getDefault, ExternalDocumentation.create)
    ..aOS(5, 'operationId')
    ..pPS(6, 'consumes')
    ..pPS(7, 'produces')
    ..pPS(10, 'schemes')
    ..aOB(11, 'deprecated')
    ..pc<SecurityRequirement>(12, 'security', $pb.PbFieldType.PM,SecurityRequirement.create)
    ..hasRequiredFields = false
  ;

  Operation() : super();
  Operation.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Operation.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Operation clone() => Operation()..mergeFromMessage(this);
  Operation copyWith(void Function(Operation) updates) => super.copyWith((message) => updates(message as Operation));
  $pb.BuilderInfo get info_ => _i;
  static Operation create() => Operation();
  Operation createEmptyInstance() => create();
  static $pb.PbList<Operation> createRepeated() => $pb.PbList<Operation>();
  static Operation getDefault() => _defaultInstance ??= create()..freeze();
  static Operation _defaultInstance;

  $core.List<$core.String> get tags => $_getList(0);

  $core.String get summary => $_getS(1, '');
  set summary($core.String v) { $_setString(1, v); }
  $core.bool hasSummary() => $_has(1);
  void clearSummary() => clearField(2);

  $core.String get description => $_getS(2, '');
  set description($core.String v) { $_setString(2, v); }
  $core.bool hasDescription() => $_has(2);
  void clearDescription() => clearField(3);

  ExternalDocumentation get externalDocs => $_getN(3);
  set externalDocs(ExternalDocumentation v) { setField(4, v); }
  $core.bool hasExternalDocs() => $_has(3);
  void clearExternalDocs() => clearField(4);

  $core.String get operationId => $_getS(4, '');
  set operationId($core.String v) { $_setString(4, v); }
  $core.bool hasOperationId() => $_has(4);
  void clearOperationId() => clearField(5);

  $core.List<$core.String> get consumes => $_getList(5);

  $core.List<$core.String> get produces => $_getList(6);

  $core.List<$core.String> get schemes => $_getList(7);

  $core.bool get deprecated => $_get(8, false);
  set deprecated($core.bool v) { $_setBool(8, v); }
  $core.bool hasDeprecated() => $_has(8);
  void clearDeprecated() => clearField(11);

  $core.List<SecurityRequirement> get security => $_getList(9);
}

class Info extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Info', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..aOS(1, 'title')
    ..aOS(2, 'description')
    ..aOS(3, 'termsOfService')
    ..a<Contact>(4, 'contact', $pb.PbFieldType.OM, Contact.getDefault, Contact.create)
    ..aOS(6, 'version')
    ..hasRequiredFields = false
  ;

  Info() : super();
  Info.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Info.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Info clone() => Info()..mergeFromMessage(this);
  Info copyWith(void Function(Info) updates) => super.copyWith((message) => updates(message as Info));
  $pb.BuilderInfo get info_ => _i;
  static Info create() => Info();
  Info createEmptyInstance() => create();
  static $pb.PbList<Info> createRepeated() => $pb.PbList<Info>();
  static Info getDefault() => _defaultInstance ??= create()..freeze();
  static Info _defaultInstance;

  $core.String get title => $_getS(0, '');
  set title($core.String v) { $_setString(0, v); }
  $core.bool hasTitle() => $_has(0);
  void clearTitle() => clearField(1);

  $core.String get description => $_getS(1, '');
  set description($core.String v) { $_setString(1, v); }
  $core.bool hasDescription() => $_has(1);
  void clearDescription() => clearField(2);

  $core.String get termsOfService => $_getS(2, '');
  set termsOfService($core.String v) { $_setString(2, v); }
  $core.bool hasTermsOfService() => $_has(2);
  void clearTermsOfService() => clearField(3);

  Contact get contact => $_getN(3);
  set contact(Contact v) { setField(4, v); }
  $core.bool hasContact() => $_has(3);
  void clearContact() => clearField(4);

  $core.String get version => $_getS(4, '');
  set version($core.String v) { $_setString(4, v); }
  $core.bool hasVersion() => $_has(4);
  void clearVersion() => clearField(6);
}

class Contact extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Contact', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..aOS(1, 'name')
    ..aOS(2, 'url')
    ..aOS(3, 'email')
    ..hasRequiredFields = false
  ;

  Contact() : super();
  Contact.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Contact.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Contact clone() => Contact()..mergeFromMessage(this);
  Contact copyWith(void Function(Contact) updates) => super.copyWith((message) => updates(message as Contact));
  $pb.BuilderInfo get info_ => _i;
  static Contact create() => Contact();
  Contact createEmptyInstance() => create();
  static $pb.PbList<Contact> createRepeated() => $pb.PbList<Contact>();
  static Contact getDefault() => _defaultInstance ??= create()..freeze();
  static Contact _defaultInstance;

  $core.String get name => $_getS(0, '');
  set name($core.String v) { $_setString(0, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  $core.String get url => $_getS(1, '');
  set url($core.String v) { $_setString(1, v); }
  $core.bool hasUrl() => $_has(1);
  void clearUrl() => clearField(2);

  $core.String get email => $_getS(2, '');
  set email($core.String v) { $_setString(2, v); }
  $core.bool hasEmail() => $_has(2);
  void clearEmail() => clearField(3);
}

class ExternalDocumentation extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('ExternalDocumentation', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..aOS(1, 'description')
    ..aOS(2, 'url')
    ..hasRequiredFields = false
  ;

  ExternalDocumentation() : super();
  ExternalDocumentation.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  ExternalDocumentation.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  ExternalDocumentation clone() => ExternalDocumentation()..mergeFromMessage(this);
  ExternalDocumentation copyWith(void Function(ExternalDocumentation) updates) => super.copyWith((message) => updates(message as ExternalDocumentation));
  $pb.BuilderInfo get info_ => _i;
  static ExternalDocumentation create() => ExternalDocumentation();
  ExternalDocumentation createEmptyInstance() => create();
  static $pb.PbList<ExternalDocumentation> createRepeated() => $pb.PbList<ExternalDocumentation>();
  static ExternalDocumentation getDefault() => _defaultInstance ??= create()..freeze();
  static ExternalDocumentation _defaultInstance;

  $core.String get description => $_getS(0, '');
  set description($core.String v) { $_setString(0, v); }
  $core.bool hasDescription() => $_has(0);
  void clearDescription() => clearField(1);

  $core.String get url => $_getS(1, '');
  set url($core.String v) { $_setString(1, v); }
  $core.bool hasUrl() => $_has(1);
  void clearUrl() => clearField(2);
}

class Schema extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Schema', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..a<JSONSchema>(1, 'jsonSchema', $pb.PbFieldType.OM, JSONSchema.getDefault, JSONSchema.create)
    ..aOS(2, 'discriminator')
    ..aOB(3, 'readOnly')
    ..a<ExternalDocumentation>(5, 'externalDocs', $pb.PbFieldType.OM, ExternalDocumentation.getDefault, ExternalDocumentation.create)
    ..a<$74.Any>(6, 'example', $pb.PbFieldType.OM, $74.Any.getDefault, $74.Any.create)
    ..hasRequiredFields = false
  ;

  Schema() : super();
  Schema.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Schema.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Schema clone() => Schema()..mergeFromMessage(this);
  Schema copyWith(void Function(Schema) updates) => super.copyWith((message) => updates(message as Schema));
  $pb.BuilderInfo get info_ => _i;
  static Schema create() => Schema();
  Schema createEmptyInstance() => create();
  static $pb.PbList<Schema> createRepeated() => $pb.PbList<Schema>();
  static Schema getDefault() => _defaultInstance ??= create()..freeze();
  static Schema _defaultInstance;

  JSONSchema get jsonSchema => $_getN(0);
  set jsonSchema(JSONSchema v) { setField(1, v); }
  $core.bool hasJsonSchema() => $_has(0);
  void clearJsonSchema() => clearField(1);

  $core.String get discriminator => $_getS(1, '');
  set discriminator($core.String v) { $_setString(1, v); }
  $core.bool hasDiscriminator() => $_has(1);
  void clearDiscriminator() => clearField(2);

  $core.bool get readOnly => $_get(2, false);
  set readOnly($core.bool v) { $_setBool(2, v); }
  $core.bool hasReadOnly() => $_has(2);
  void clearReadOnly() => clearField(3);

  ExternalDocumentation get externalDocs => $_getN(3);
  set externalDocs(ExternalDocumentation v) { setField(5, v); }
  $core.bool hasExternalDocs() => $_has(3);
  void clearExternalDocs() => clearField(5);

  $74.Any get example => $_getN(4);
  set example($74.Any v) { setField(6, v); }
  $core.bool hasExample() => $_has(4);
  void clearExample() => clearField(6);
}

class JSONSchema extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('JSONSchema', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..aOS(5, 'title')
    ..aOS(6, 'description')
    ..aOS(7, 'default_7')
    ..a<$core.double>(10, 'multipleOf', $pb.PbFieldType.OD)
    ..a<$core.double>(11, 'maximum', $pb.PbFieldType.OD)
    ..aOB(12, 'exclusiveMaximum')
    ..a<$core.double>(13, 'minimum', $pb.PbFieldType.OD)
    ..aOB(14, 'exclusiveMinimum')
    ..a<Int64>(15, 'maxLength', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(16, 'minLength', $pb.PbFieldType.OU6, Int64.ZERO)
    ..aOS(17, 'pattern')
    ..a<Int64>(20, 'maxItems', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(21, 'minItems', $pb.PbFieldType.OU6, Int64.ZERO)
    ..aOB(22, 'uniqueItems')
    ..a<Int64>(24, 'maxProperties', $pb.PbFieldType.OU6, Int64.ZERO)
    ..a<Int64>(25, 'minProperties', $pb.PbFieldType.OU6, Int64.ZERO)
    ..pPS(26, 'required')
    ..pPS(34, 'array')
    ..pc<JSONSchema_JSONSchemaSimpleTypes>(35, 'type', $pb.PbFieldType.PE, null, JSONSchema_JSONSchemaSimpleTypes.valueOf, JSONSchema_JSONSchemaSimpleTypes.values)
    ..hasRequiredFields = false
  ;

  JSONSchema() : super();
  JSONSchema.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  JSONSchema.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  JSONSchema clone() => JSONSchema()..mergeFromMessage(this);
  JSONSchema copyWith(void Function(JSONSchema) updates) => super.copyWith((message) => updates(message as JSONSchema));
  $pb.BuilderInfo get info_ => _i;
  static JSONSchema create() => JSONSchema();
  JSONSchema createEmptyInstance() => create();
  static $pb.PbList<JSONSchema> createRepeated() => $pb.PbList<JSONSchema>();
  static JSONSchema getDefault() => _defaultInstance ??= create()..freeze();
  static JSONSchema _defaultInstance;

  $core.String get title => $_getS(0, '');
  set title($core.String v) { $_setString(0, v); }
  $core.bool hasTitle() => $_has(0);
  void clearTitle() => clearField(5);

  $core.String get description => $_getS(1, '');
  set description($core.String v) { $_setString(1, v); }
  $core.bool hasDescription() => $_has(1);
  void clearDescription() => clearField(6);

  $core.String get default_7 => $_getS(2, '');
  set default_7($core.String v) { $_setString(2, v); }
  $core.bool hasDefault_7() => $_has(2);
  void clearDefault_7() => clearField(7);

  $core.double get multipleOf => $_getN(3);
  set multipleOf($core.double v) { $_setDouble(3, v); }
  $core.bool hasMultipleOf() => $_has(3);
  void clearMultipleOf() => clearField(10);

  $core.double get maximum => $_getN(4);
  set maximum($core.double v) { $_setDouble(4, v); }
  $core.bool hasMaximum() => $_has(4);
  void clearMaximum() => clearField(11);

  $core.bool get exclusiveMaximum => $_get(5, false);
  set exclusiveMaximum($core.bool v) { $_setBool(5, v); }
  $core.bool hasExclusiveMaximum() => $_has(5);
  void clearExclusiveMaximum() => clearField(12);

  $core.double get minimum => $_getN(6);
  set minimum($core.double v) { $_setDouble(6, v); }
  $core.bool hasMinimum() => $_has(6);
  void clearMinimum() => clearField(13);

  $core.bool get exclusiveMinimum => $_get(7, false);
  set exclusiveMinimum($core.bool v) { $_setBool(7, v); }
  $core.bool hasExclusiveMinimum() => $_has(7);
  void clearExclusiveMinimum() => clearField(14);

  Int64 get maxLength => $_getI64(8);
  set maxLength(Int64 v) { $_setInt64(8, v); }
  $core.bool hasMaxLength() => $_has(8);
  void clearMaxLength() => clearField(15);

  Int64 get minLength => $_getI64(9);
  set minLength(Int64 v) { $_setInt64(9, v); }
  $core.bool hasMinLength() => $_has(9);
  void clearMinLength() => clearField(16);

  $core.String get pattern => $_getS(10, '');
  set pattern($core.String v) { $_setString(10, v); }
  $core.bool hasPattern() => $_has(10);
  void clearPattern() => clearField(17);

  Int64 get maxItems => $_getI64(11);
  set maxItems(Int64 v) { $_setInt64(11, v); }
  $core.bool hasMaxItems() => $_has(11);
  void clearMaxItems() => clearField(20);

  Int64 get minItems => $_getI64(12);
  set minItems(Int64 v) { $_setInt64(12, v); }
  $core.bool hasMinItems() => $_has(12);
  void clearMinItems() => clearField(21);

  $core.bool get uniqueItems => $_get(13, false);
  set uniqueItems($core.bool v) { $_setBool(13, v); }
  $core.bool hasUniqueItems() => $_has(13);
  void clearUniqueItems() => clearField(22);

  Int64 get maxProperties => $_getI64(14);
  set maxProperties(Int64 v) { $_setInt64(14, v); }
  $core.bool hasMaxProperties() => $_has(14);
  void clearMaxProperties() => clearField(24);

  Int64 get minProperties => $_getI64(15);
  set minProperties(Int64 v) { $_setInt64(15, v); }
  $core.bool hasMinProperties() => $_has(15);
  void clearMinProperties() => clearField(25);

  $core.List<$core.String> get required => $_getList(16);

  $core.List<$core.String> get array => $_getList(17);

  $core.List<JSONSchema_JSONSchemaSimpleTypes> get type => $_getList(18);
}

class Tag extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Tag', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..aOS(2, 'description')
    ..a<ExternalDocumentation>(3, 'externalDocs', $pb.PbFieldType.OM, ExternalDocumentation.getDefault, ExternalDocumentation.create)
    ..hasRequiredFields = false
  ;

  Tag() : super();
  Tag.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Tag.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Tag clone() => Tag()..mergeFromMessage(this);
  Tag copyWith(void Function(Tag) updates) => super.copyWith((message) => updates(message as Tag));
  $pb.BuilderInfo get info_ => _i;
  static Tag create() => Tag();
  Tag createEmptyInstance() => create();
  static $pb.PbList<Tag> createRepeated() => $pb.PbList<Tag>();
  static Tag getDefault() => _defaultInstance ??= create()..freeze();
  static Tag _defaultInstance;

  $core.String get description => $_getS(0, '');
  set description($core.String v) { $_setString(0, v); }
  $core.bool hasDescription() => $_has(0);
  void clearDescription() => clearField(2);

  ExternalDocumentation get externalDocs => $_getN(1);
  set externalDocs(ExternalDocumentation v) { setField(3, v); }
  $core.bool hasExternalDocs() => $_has(1);
  void clearExternalDocs() => clearField(3);
}

class SecurityDefinitions extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SecurityDefinitions', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..m<$core.String, SecurityScheme>(1, 'security', 'SecurityDefinitions.SecurityEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, SecurityScheme.create, null, null , const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..hasRequiredFields = false
  ;

  SecurityDefinitions() : super();
  SecurityDefinitions.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SecurityDefinitions.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SecurityDefinitions clone() => SecurityDefinitions()..mergeFromMessage(this);
  SecurityDefinitions copyWith(void Function(SecurityDefinitions) updates) => super.copyWith((message) => updates(message as SecurityDefinitions));
  $pb.BuilderInfo get info_ => _i;
  static SecurityDefinitions create() => SecurityDefinitions();
  SecurityDefinitions createEmptyInstance() => create();
  static $pb.PbList<SecurityDefinitions> createRepeated() => $pb.PbList<SecurityDefinitions>();
  static SecurityDefinitions getDefault() => _defaultInstance ??= create()..freeze();
  static SecurityDefinitions _defaultInstance;

  $core.Map<$core.String, SecurityScheme> get security => $_getMap(0);
}

class SecurityScheme extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SecurityScheme', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..e<SecurityScheme_Type>(1, 'type', $pb.PbFieldType.OE, SecurityScheme_Type.TYPE_INVALID, SecurityScheme_Type.valueOf, SecurityScheme_Type.values)
    ..aOS(2, 'description')
    ..aOS(3, 'name')
    ..e<SecurityScheme_In>(4, 'in_4', $pb.PbFieldType.OE, SecurityScheme_In.IN_INVALID, SecurityScheme_In.valueOf, SecurityScheme_In.values)
    ..e<SecurityScheme_Flow>(5, 'flow', $pb.PbFieldType.OE, SecurityScheme_Flow.FLOW_INVALID, SecurityScheme_Flow.valueOf, SecurityScheme_Flow.values)
    ..aOS(6, 'authorizationUrl')
    ..aOS(7, 'tokenUrl')
    ..a<Scopes>(8, 'scopes', $pb.PbFieldType.OM, Scopes.getDefault, Scopes.create)
    ..hasRequiredFields = false
  ;

  SecurityScheme() : super();
  SecurityScheme.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SecurityScheme.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SecurityScheme clone() => SecurityScheme()..mergeFromMessage(this);
  SecurityScheme copyWith(void Function(SecurityScheme) updates) => super.copyWith((message) => updates(message as SecurityScheme));
  $pb.BuilderInfo get info_ => _i;
  static SecurityScheme create() => SecurityScheme();
  SecurityScheme createEmptyInstance() => create();
  static $pb.PbList<SecurityScheme> createRepeated() => $pb.PbList<SecurityScheme>();
  static SecurityScheme getDefault() => _defaultInstance ??= create()..freeze();
  static SecurityScheme _defaultInstance;

  SecurityScheme_Type get type => $_getN(0);
  set type(SecurityScheme_Type v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  $core.String get description => $_getS(1, '');
  set description($core.String v) { $_setString(1, v); }
  $core.bool hasDescription() => $_has(1);
  void clearDescription() => clearField(2);

  $core.String get name => $_getS(2, '');
  set name($core.String v) { $_setString(2, v); }
  $core.bool hasName() => $_has(2);
  void clearName() => clearField(3);

  SecurityScheme_In get in_4 => $_getN(3);
  set in_4(SecurityScheme_In v) { setField(4, v); }
  $core.bool hasIn_4() => $_has(3);
  void clearIn_4() => clearField(4);

  SecurityScheme_Flow get flow => $_getN(4);
  set flow(SecurityScheme_Flow v) { setField(5, v); }
  $core.bool hasFlow() => $_has(4);
  void clearFlow() => clearField(5);

  $core.String get authorizationUrl => $_getS(5, '');
  set authorizationUrl($core.String v) { $_setString(5, v); }
  $core.bool hasAuthorizationUrl() => $_has(5);
  void clearAuthorizationUrl() => clearField(6);

  $core.String get tokenUrl => $_getS(6, '');
  set tokenUrl($core.String v) { $_setString(6, v); }
  $core.bool hasTokenUrl() => $_has(6);
  void clearTokenUrl() => clearField(7);

  Scopes get scopes => $_getN(7);
  set scopes(Scopes v) { setField(8, v); }
  $core.bool hasScopes() => $_has(7);
  void clearScopes() => clearField(8);
}

class SecurityRequirement_SecurityRequirementValue extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SecurityRequirement.SecurityRequirementValue', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..pPS(1, 'scope')
    ..hasRequiredFields = false
  ;

  SecurityRequirement_SecurityRequirementValue() : super();
  SecurityRequirement_SecurityRequirementValue.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SecurityRequirement_SecurityRequirementValue.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SecurityRequirement_SecurityRequirementValue clone() => SecurityRequirement_SecurityRequirementValue()..mergeFromMessage(this);
  SecurityRequirement_SecurityRequirementValue copyWith(void Function(SecurityRequirement_SecurityRequirementValue) updates) => super.copyWith((message) => updates(message as SecurityRequirement_SecurityRequirementValue));
  $pb.BuilderInfo get info_ => _i;
  static SecurityRequirement_SecurityRequirementValue create() => SecurityRequirement_SecurityRequirementValue();
  SecurityRequirement_SecurityRequirementValue createEmptyInstance() => create();
  static $pb.PbList<SecurityRequirement_SecurityRequirementValue> createRepeated() => $pb.PbList<SecurityRequirement_SecurityRequirementValue>();
  static SecurityRequirement_SecurityRequirementValue getDefault() => _defaultInstance ??= create()..freeze();
  static SecurityRequirement_SecurityRequirementValue _defaultInstance;

  $core.List<$core.String> get scope => $_getList(0);
}

class SecurityRequirement extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('SecurityRequirement', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..m<$core.String, SecurityRequirement_SecurityRequirementValue>(1, 'securityRequirement', 'SecurityRequirement.SecurityRequirementEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OM, SecurityRequirement_SecurityRequirementValue.create, null, null , const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..hasRequiredFields = false
  ;

  SecurityRequirement() : super();
  SecurityRequirement.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  SecurityRequirement.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  SecurityRequirement clone() => SecurityRequirement()..mergeFromMessage(this);
  SecurityRequirement copyWith(void Function(SecurityRequirement) updates) => super.copyWith((message) => updates(message as SecurityRequirement));
  $pb.BuilderInfo get info_ => _i;
  static SecurityRequirement create() => SecurityRequirement();
  SecurityRequirement createEmptyInstance() => create();
  static $pb.PbList<SecurityRequirement> createRepeated() => $pb.PbList<SecurityRequirement>();
  static SecurityRequirement getDefault() => _defaultInstance ??= create()..freeze();
  static SecurityRequirement _defaultInstance;

  $core.Map<$core.String, SecurityRequirement_SecurityRequirementValue> get securityRequirement => $_getMap(0);
}

class Scopes extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Scopes', package: const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..m<$core.String, $core.String>(1, 'scope', 'Scopes.ScopeEntry',$pb.PbFieldType.OS, $pb.PbFieldType.OS, null, null, null , const $pb.PackageName('grpc.gateway.protoc_gen_swagger.options'))
    ..hasRequiredFields = false
  ;

  Scopes() : super();
  Scopes.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Scopes.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Scopes clone() => Scopes()..mergeFromMessage(this);
  Scopes copyWith(void Function(Scopes) updates) => super.copyWith((message) => updates(message as Scopes));
  $pb.BuilderInfo get info_ => _i;
  static Scopes create() => Scopes();
  Scopes createEmptyInstance() => create();
  static $pb.PbList<Scopes> createRepeated() => $pb.PbList<Scopes>();
  static Scopes getDefault() => _defaultInstance ??= create()..freeze();
  static Scopes _defaultInstance;

  $core.Map<$core.String, $core.String> get scope => $_getMap(0);
}

