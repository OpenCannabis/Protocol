///
//  Generated code. Do not modify.
//  source: protoc-gen-swagger/options/swagger.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'openapiv2.pb.dart' as $75;

class Swagger {
  static final $pb.Extension openapiv2Swagger = $pb.Extension<$75.Swagger>('google.protobuf.FileOptions', 'openapiv2Swagger', 1042, $pb.PbFieldType.OM, $75.Swagger.getDefault, $75.Swagger.create);
  static final $pb.Extension openapiv2Operation = $pb.Extension<$75.Operation>('google.protobuf.MethodOptions', 'openapiv2Operation', 1042, $pb.PbFieldType.OM, $75.Operation.getDefault, $75.Operation.create);
  static final $pb.Extension openapiv2Schema = $pb.Extension<$75.Schema>('google.protobuf.MessageOptions', 'openapiv2Schema', 1042, $pb.PbFieldType.OM, $75.Schema.getDefault, $75.Schema.create);
  static final $pb.Extension openapiv2Tag = $pb.Extension<$75.Tag>('google.protobuf.ServiceOptions', 'openapiv2Tag', 1042, $pb.PbFieldType.OM, $75.Tag.getDefault, $75.Tag.create);
  static void registerAllExtensions($pb.ExtensionRegistry registry) {
    registry.add(openapiv2Swagger);
    registry.add(openapiv2Operation);
    registry.add(openapiv2Schema);
    registry.add(openapiv2Tag);
  }
}

