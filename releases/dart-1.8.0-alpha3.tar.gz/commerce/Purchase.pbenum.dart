///
//  Generated code. Do not modify.
//  source: commerce/Purchase.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class PurchaseStatus extends $pb.ProtobufEnum {
  static const PurchaseStatus FRESH = PurchaseStatus._(0, 'FRESH');
  static const PurchaseStatus OPEN = PurchaseStatus._(1, 'OPEN');
  static const PurchaseStatus CLOSED = PurchaseStatus._(2, 'CLOSED');
  static const PurchaseStatus VOIDED = PurchaseStatus._(3, 'VOIDED');
  static const PurchaseStatus FINALIZED = PurchaseStatus._(4, 'FINALIZED');
  static const PurchaseStatus RECONCILED = PurchaseStatus._(5, 'RECONCILED');

  static const $core.List<PurchaseStatus> values = <PurchaseStatus> [
    FRESH,
    OPEN,
    CLOSED,
    VOIDED,
    FINALIZED,
    RECONCILED,
  ];

  static final $core.Map<$core.int, PurchaseStatus> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PurchaseStatus valueOf($core.int value) => _byValue[value];

  const PurchaseStatus._($core.int v, $core.String n) : super(v, n);
}

class PurchaseAuthority extends $pb.ProtobufEnum {
  static const PurchaseAuthority STANDARD = PurchaseAuthority._(0, 'STANDARD');
  static const PurchaseAuthority MEDICAL = PurchaseAuthority._(1, 'MEDICAL');
  static const PurchaseAuthority ADULT_USE = PurchaseAuthority._(2, 'ADULT_USE');

  static const $core.List<PurchaseAuthority> values = <PurchaseAuthority> [
    STANDARD,
    MEDICAL,
    ADULT_USE,
  ];

  static final $core.Map<$core.int, PurchaseAuthority> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PurchaseAuthority valueOf($core.int value) => _byValue[value];

  const PurchaseAuthority._($core.int v, $core.String n) : super(v, n);
}

class PurchaseEvent extends $pb.ProtobufEnum {
  static const PurchaseEvent STATUS = PurchaseEvent._(0, 'STATUS');
  static const PurchaseEvent SAVE = PurchaseEvent._(1, 'SAVE');
  static const PurchaseEvent LOAD = PurchaseEvent._(2, 'LOAD');
  static const PurchaseEvent ITEM_ADDED = PurchaseEvent._(10, 'ITEM_ADDED');
  static const PurchaseEvent ITEM_REMOVED = PurchaseEvent._(11, 'ITEM_REMOVED');
  static const PurchaseEvent ITEM_QUANTITY_CHANGED = PurchaseEvent._(12, 'ITEM_QUANTITY_CHANGED');
  static const PurchaseEvent ITEM_DISCOUNT_ADDED = PurchaseEvent._(13, 'ITEM_DISCOUNT_ADDED');
  static const PurchaseEvent ITEM_DISCOUNT_REMOVED = PurchaseEvent._(14, 'ITEM_DISCOUNT_REMOVED');
  static const PurchaseEvent PURCHASE_VOID = PurchaseEvent._(20, 'PURCHASE_VOID');
  static const PurchaseEvent PURCHASE_FINALIZE = PurchaseEvent._(21, 'PURCHASE_FINALIZE');

  static const $core.List<PurchaseEvent> values = <PurchaseEvent> [
    STATUS,
    SAVE,
    LOAD,
    ITEM_ADDED,
    ITEM_REMOVED,
    ITEM_QUANTITY_CHANGED,
    ITEM_DISCOUNT_ADDED,
    ITEM_DISCOUNT_REMOVED,
    PURCHASE_VOID,
    PURCHASE_FINALIZE,
  ];

  static final $core.Map<$core.int, PurchaseEvent> _byValue = $pb.ProtobufEnum.initByValue(values);
  static PurchaseEvent valueOf($core.int value) => _byValue[value];

  const PurchaseEvent._($core.int v, $core.String n) : super(v, n);
}

