///
//  Generated code. Do not modify.
//  source: commerce/payments/Payment.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const PaymentMethod$json = const {
  '1': 'PaymentMethod',
  '2': const [
    const {'1': 'CASH', '2': 0},
    const {'1': 'CHECK', '2': 1},
    const {'1': 'DEBIT', '2': 2},
    const {'1': 'CREDIT', '2': 3},
    const {'1': 'DIGITAL', '2': 4},
    const {'1': 'ACH', '2': 5},
    const {'1': 'WIRE', '2': 6},
    const {'1': 'BLOCKCHAIN', '2': 7},
  ],
};

const PaymentCardType$json = const {
  '1': 'PaymentCardType',
  '2': const [
    const {'1': 'NO_CARD_TYPE', '2': 0},
    const {'1': 'VISA', '2': 1},
    const {'1': 'MASTERCARD', '2': 2},
    const {'1': 'DISCOVER', '2': 3},
    const {'1': 'AMEX', '2': 4},
    const {'1': 'DINERS_CLUB', '2': 5},
    const {'1': 'MAESTRO', '2': 6},
  ],
};

const DigitalPaymentNetwork$json = const {
  '1': 'DigitalPaymentNetwork',
  '2': const [
    const {'1': 'UNSPECIFIED_NETWORK', '2': 0},
    const {'1': 'PAYPAL', '2': 1},
    const {'1': 'VENMO', '2': 2},
    const {'1': 'SQUARE', '2': 3},
  ],
};

const PaymentStatus$json = const {
  '1': 'PaymentStatus',
  '2': const [
    const {'1': 'NOT_APPLICABLE', '2': 0},
    const {'1': 'WAITING', '2': 1},
    const {'1': 'PREAUTHORIZED', '2': 2},
    const {'1': 'BOUNCED', '2': 3},
    const {'1': 'RETRIED', '2': 4},
  ],
};

const BillStatus$json = const {
  '1': 'BillStatus',
  '2': const [
    const {'1': 'SUSPENSE', '2': 0},
    const {'1': 'PARTIAL', '2': 3},
    const {'1': 'SETTLED', '2': 4},
  ],
};

