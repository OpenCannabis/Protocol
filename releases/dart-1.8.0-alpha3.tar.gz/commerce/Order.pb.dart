///
//  Generated code. Do not modify.
//  source: commerce/Order.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../temporal/Instant.pb.dart' as $0;
import 'Customer.pb.dart' as $18;
import 'Delivery.pb.dart' as $19;
import 'Item.pb.dart' as $20;

import 'Order.pbenum.dart';
import 'payments/Payment.pbenum.dart' as $21;

export 'Order.pbenum.dart';

class OrderScheduling extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('OrderScheduling', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<SchedulingType>(1, 'scheduling', $pb.PbFieldType.OE, SchedulingType.ASAP, SchedulingType.valueOf, SchedulingType.values)
    ..a<$0.Instant>(2, 'desiredTime', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..hasRequiredFields = false
  ;

  OrderScheduling() : super();
  OrderScheduling.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  OrderScheduling.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  OrderScheduling clone() => OrderScheduling()..mergeFromMessage(this);
  OrderScheduling copyWith(void Function(OrderScheduling) updates) => super.copyWith((message) => updates(message as OrderScheduling));
  $pb.BuilderInfo get info_ => _i;
  static OrderScheduling create() => OrderScheduling();
  OrderScheduling createEmptyInstance() => create();
  static $pb.PbList<OrderScheduling> createRepeated() => $pb.PbList<OrderScheduling>();
  static OrderScheduling getDefault() => _defaultInstance ??= create()..freeze();
  static OrderScheduling _defaultInstance;

  SchedulingType get scheduling => $_getN(0);
  set scheduling(SchedulingType v) { setField(1, v); }
  $core.bool hasScheduling() => $_has(0);
  void clearScheduling() => clearField(1);

  $0.Instant get desiredTime => $_getN(1);
  set desiredTime($0.Instant v) { setField(2, v); }
  $core.bool hasDesiredTime() => $_has(1);
  void clearDesiredTime() => clearField(2);
}

class OrderPayment extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('OrderPayment', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<$21.PaymentStatus>(1, 'status', $pb.PbFieldType.OE, $21.PaymentStatus.NOT_APPLICABLE, $21.PaymentStatus.valueOf, $21.PaymentStatus.values)
    ..e<$21.PaymentMethod>(2, 'method', $pb.PbFieldType.OE, $21.PaymentMethod.CASH, $21.PaymentMethod.valueOf, $21.PaymentMethod.values)
    ..a<$core.double>(3, 'tax', $pb.PbFieldType.OD)
    ..a<$core.double>(4, 'paid', $pb.PbFieldType.OD)
    ..hasRequiredFields = false
  ;

  OrderPayment() : super();
  OrderPayment.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  OrderPayment.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  OrderPayment clone() => OrderPayment()..mergeFromMessage(this);
  OrderPayment copyWith(void Function(OrderPayment) updates) => super.copyWith((message) => updates(message as OrderPayment));
  $pb.BuilderInfo get info_ => _i;
  static OrderPayment create() => OrderPayment();
  OrderPayment createEmptyInstance() => create();
  static $pb.PbList<OrderPayment> createRepeated() => $pb.PbList<OrderPayment>();
  static OrderPayment getDefault() => _defaultInstance ??= create()..freeze();
  static OrderPayment _defaultInstance;

  $21.PaymentStatus get status => $_getN(0);
  set status($21.PaymentStatus v) { setField(1, v); }
  $core.bool hasStatus() => $_has(0);
  void clearStatus() => clearField(1);

  $21.PaymentMethod get method => $_getN(1);
  set method($21.PaymentMethod v) { setField(2, v); }
  $core.bool hasMethod() => $_has(1);
  void clearMethod() => clearField(2);

  $core.double get tax => $_getN(2);
  set tax($core.double v) { $_setDouble(2, v); }
  $core.bool hasTax() => $_has(2);
  void clearTax() => clearField(3);

  $core.double get paid => $_getN(3);
  set paid($core.double v) { $_setDouble(3, v); }
  $core.bool hasPaid() => $_has(3);
  void clearPaid() => clearField(4);
}

class StatusCheckin extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('StatusCheckin', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<OrderStatus>(1, 'status', $pb.PbFieldType.OE, OrderStatus.PENDING, OrderStatus.valueOf, OrderStatus.values)
    ..a<$0.Instant>(2, 'instant', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..aOS(3, 'message')
    ..hasRequiredFields = false
  ;

  StatusCheckin() : super();
  StatusCheckin.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  StatusCheckin.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  StatusCheckin clone() => StatusCheckin()..mergeFromMessage(this);
  StatusCheckin copyWith(void Function(StatusCheckin) updates) => super.copyWith((message) => updates(message as StatusCheckin));
  $pb.BuilderInfo get info_ => _i;
  static StatusCheckin create() => StatusCheckin();
  StatusCheckin createEmptyInstance() => create();
  static $pb.PbList<StatusCheckin> createRepeated() => $pb.PbList<StatusCheckin>();
  static StatusCheckin getDefault() => _defaultInstance ??= create()..freeze();
  static StatusCheckin _defaultInstance;

  OrderStatus get status => $_getN(0);
  set status(OrderStatus v) { setField(1, v); }
  $core.bool hasStatus() => $_has(0);
  void clearStatus() => clearField(1);

  $0.Instant get instant => $_getN(1);
  set instant($0.Instant v) { setField(2, v); }
  $core.bool hasInstant() => $_has(1);
  void clearInstant() => clearField(2);

  $core.String get message => $_getS(2, '');
  set message($core.String v) { $_setString(2, v); }
  $core.bool hasMessage() => $_has(2);
  void clearMessage() => clearField(3);
}

class OrderKey extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('OrderKey', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'id')
    ..hasRequiredFields = false
  ;

  OrderKey() : super();
  OrderKey.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  OrderKey.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  OrderKey clone() => OrderKey()..mergeFromMessage(this);
  OrderKey copyWith(void Function(OrderKey) updates) => super.copyWith((message) => updates(message as OrderKey));
  $pb.BuilderInfo get info_ => _i;
  static OrderKey create() => OrderKey();
  OrderKey createEmptyInstance() => create();
  static $pb.PbList<OrderKey> createRepeated() => $pb.PbList<OrderKey>();
  static OrderKey getDefault() => _defaultInstance ??= create()..freeze();
  static OrderKey _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);
}

class Order extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Order', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'id')
    ..e<OrderType>(2, 'type', $pb.PbFieldType.OE, OrderType.PICKUP, OrderType.valueOf, OrderType.values)
    ..e<OrderStatus>(3, 'status', $pb.PbFieldType.OE, OrderStatus.PENDING, OrderStatus.valueOf, OrderStatus.values)
    ..a<$18.Customer>(4, 'customer', $pb.PbFieldType.OM, $18.Customer.getDefault, $18.Customer.create)
    ..a<OrderScheduling>(5, 'scheduling', $pb.PbFieldType.OM, OrderScheduling.getDefault, OrderScheduling.create)
    ..a<$19.DeliveryDestination>(6, 'destination', $pb.PbFieldType.OM, $19.DeliveryDestination.getDefault, $19.DeliveryDestination.create)
    ..aOS(7, 'notes')
    ..pc<$20.Item>(8, 'item', $pb.PbFieldType.PM,$20.Item.create)
    ..pc<StatusCheckin>(9, 'actionLog', $pb.PbFieldType.PM,StatusCheckin.create)
    ..a<$0.Instant>(10, 'createdAt', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$core.double>(11, 'subtotal', $pb.PbFieldType.OD)
    ..a<$0.Instant>(12, 'updatedAt', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..aOS(13, 'sid')
    ..a<OrderPayment>(14, 'payment', $pb.PbFieldType.OM, OrderPayment.getDefault, OrderPayment.create)
    ..hasRequiredFields = false
  ;

  Order() : super();
  Order.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Order.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Order clone() => Order()..mergeFromMessage(this);
  Order copyWith(void Function(Order) updates) => super.copyWith((message) => updates(message as Order));
  $pb.BuilderInfo get info_ => _i;
  static Order create() => Order();
  Order createEmptyInstance() => create();
  static $pb.PbList<Order> createRepeated() => $pb.PbList<Order>();
  static Order getDefault() => _defaultInstance ??= create()..freeze();
  static Order _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  OrderType get type => $_getN(1);
  set type(OrderType v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  OrderStatus get status => $_getN(2);
  set status(OrderStatus v) { setField(3, v); }
  $core.bool hasStatus() => $_has(2);
  void clearStatus() => clearField(3);

  $18.Customer get customer => $_getN(3);
  set customer($18.Customer v) { setField(4, v); }
  $core.bool hasCustomer() => $_has(3);
  void clearCustomer() => clearField(4);

  OrderScheduling get scheduling => $_getN(4);
  set scheduling(OrderScheduling v) { setField(5, v); }
  $core.bool hasScheduling() => $_has(4);
  void clearScheduling() => clearField(5);

  $19.DeliveryDestination get destination => $_getN(5);
  set destination($19.DeliveryDestination v) { setField(6, v); }
  $core.bool hasDestination() => $_has(5);
  void clearDestination() => clearField(6);

  $core.String get notes => $_getS(6, '');
  set notes($core.String v) { $_setString(6, v); }
  $core.bool hasNotes() => $_has(6);
  void clearNotes() => clearField(7);

  $core.List<$20.Item> get item => $_getList(7);

  $core.List<StatusCheckin> get actionLog => $_getList(8);

  $0.Instant get createdAt => $_getN(9);
  set createdAt($0.Instant v) { setField(10, v); }
  $core.bool hasCreatedAt() => $_has(9);
  void clearCreatedAt() => clearField(10);

  $core.double get subtotal => $_getN(10);
  set subtotal($core.double v) { $_setDouble(10, v); }
  $core.bool hasSubtotal() => $_has(10);
  void clearSubtotal() => clearField(11);

  $0.Instant get updatedAt => $_getN(11);
  set updatedAt($0.Instant v) { setField(12, v); }
  $core.bool hasUpdatedAt() => $_has(11);
  void clearUpdatedAt() => clearField(12);

  $core.String get sid => $_getS(12, '');
  set sid($core.String v) { $_setString(12, v); }
  $core.bool hasSid() => $_has(12);
  void clearSid() => clearField(13);

  OrderPayment get payment => $_getN(13);
  set payment(OrderPayment v) { setField(14, v); }
  $core.bool hasPayment() => $_has(13);
  void clearPayment() => clearField(14);
}

