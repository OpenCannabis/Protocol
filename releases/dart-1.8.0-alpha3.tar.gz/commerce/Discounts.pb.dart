///
//  Generated code. Do not modify.
//  source: commerce/Discounts.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../temporal/Instant.pb.dart' as $0;

import 'Discounts.pbenum.dart';

export 'Discounts.pbenum.dart';

enum DiscountSpec_Rate {
  percentage, 
  staticValue, 
  notSet
}

class DiscountSpec extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, DiscountSpec_Rate> _DiscountSpec_RateByTag = {
    3 : DiscountSpec_Rate.percentage,
    4 : DiscountSpec_Rate.staticValue,
    0 : DiscountSpec_Rate.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DiscountSpec', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<DiscountType>(1, 'type', $pb.PbFieldType.OE, DiscountType.CUSTOM, DiscountType.valueOf, DiscountType.values)
    ..e<DiscountBasis>(2, 'basis', $pb.PbFieldType.OE, DiscountBasis.ITEM, DiscountBasis.valueOf, DiscountBasis.values)
    ..a<$core.double>(3, 'percentage', $pb.PbFieldType.OD)
    ..a<$core.double>(4, 'staticValue', $pb.PbFieldType.OD)
    ..oo(0, [3, 4])
    ..hasRequiredFields = false
  ;

  DiscountSpec() : super();
  DiscountSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DiscountSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DiscountSpec clone() => DiscountSpec()..mergeFromMessage(this);
  DiscountSpec copyWith(void Function(DiscountSpec) updates) => super.copyWith((message) => updates(message as DiscountSpec));
  $pb.BuilderInfo get info_ => _i;
  static DiscountSpec create() => DiscountSpec();
  DiscountSpec createEmptyInstance() => create();
  static $pb.PbList<DiscountSpec> createRepeated() => $pb.PbList<DiscountSpec>();
  static DiscountSpec getDefault() => _defaultInstance ??= create()..freeze();
  static DiscountSpec _defaultInstance;

  DiscountSpec_Rate whichRate() => _DiscountSpec_RateByTag[$_whichOneof(0)];
  void clearRate() => clearField($_whichOneof(0));

  DiscountType get type => $_getN(0);
  set type(DiscountType v) { setField(1, v); }
  $core.bool hasType() => $_has(0);
  void clearType() => clearField(1);

  DiscountBasis get basis => $_getN(1);
  set basis(DiscountBasis v) { setField(2, v); }
  $core.bool hasBasis() => $_has(1);
  void clearBasis() => clearField(2);

  $core.double get percentage => $_getN(2);
  set percentage($core.double v) { $_setDouble(2, v); }
  $core.bool hasPercentage() => $_has(2);
  void clearPercentage() => clearField(3);

  $core.double get staticValue => $_getN(3);
  set staticValue($core.double v) { $_setDouble(3, v); }
  $core.bool hasStaticValue() => $_has(3);
  void clearStaticValue() => clearField(4);
}

class Discount extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Discount', package: const $pb.PackageName('opencannabis.commerce'))
    ..aOS(1, 'id')
    ..a<DiscountSpec>(2, 'spec', $pb.PbFieldType.OM, DiscountSpec.getDefault, DiscountSpec.create)
    ..aOS(3, 'name')
    ..aOS(4, 'label')
    ..aOS(5, 'description')
    ..a<$0.Instant>(6, 'createdAt', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..a<$0.Instant>(7, 'modifiedAt', $pb.PbFieldType.OM, $0.Instant.getDefault, $0.Instant.create)
    ..hasRequiredFields = false
  ;

  Discount() : super();
  Discount.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Discount.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Discount clone() => Discount()..mergeFromMessage(this);
  Discount copyWith(void Function(Discount) updates) => super.copyWith((message) => updates(message as Discount));
  $pb.BuilderInfo get info_ => _i;
  static Discount create() => Discount();
  Discount createEmptyInstance() => create();
  static $pb.PbList<Discount> createRepeated() => $pb.PbList<Discount>();
  static Discount getDefault() => _defaultInstance ??= create()..freeze();
  static Discount _defaultInstance;

  $core.String get id => $_getS(0, '');
  set id($core.String v) { $_setString(0, v); }
  $core.bool hasId() => $_has(0);
  void clearId() => clearField(1);

  DiscountSpec get spec => $_getN(1);
  set spec(DiscountSpec v) { setField(2, v); }
  $core.bool hasSpec() => $_has(1);
  void clearSpec() => clearField(2);

  $core.String get name => $_getS(2, '');
  set name($core.String v) { $_setString(2, v); }
  $core.bool hasName() => $_has(2);
  void clearName() => clearField(3);

  $core.String get label => $_getS(3, '');
  set label($core.String v) { $_setString(3, v); }
  $core.bool hasLabel() => $_has(3);
  void clearLabel() => clearField(4);

  $core.String get description => $_getS(4, '');
  set description($core.String v) { $_setString(4, v); }
  $core.bool hasDescription() => $_has(4);
  void clearDescription() => clearField(5);

  $0.Instant get createdAt => $_getN(5);
  set createdAt($0.Instant v) { setField(6, v); }
  $core.bool hasCreatedAt() => $_has(5);
  void clearCreatedAt() => clearField(6);

  $0.Instant get modifiedAt => $_getN(6);
  set modifiedAt($0.Instant v) { setField(7, v); }
  $core.bool hasModifiedAt() => $_has(6);
  void clearModifiedAt() => clearField(7);
}

