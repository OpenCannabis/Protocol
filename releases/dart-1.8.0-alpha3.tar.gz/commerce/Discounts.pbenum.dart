///
//  Generated code. Do not modify.
//  source: commerce/Discounts.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class DiscountType extends $pb.ProtobufEnum {
  static const DiscountType CUSTOM = DiscountType._(0, 'CUSTOM');
  static const DiscountType STATUTORY = DiscountType._(1, 'STATUTORY');
  static const DiscountType COMMERCIAL = DiscountType._(2, 'COMMERCIAL');

  static const $core.List<DiscountType> values = <DiscountType> [
    CUSTOM,
    STATUTORY,
    COMMERCIAL,
  ];

  static final $core.Map<$core.int, DiscountType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static DiscountType valueOf($core.int value) => _byValue[value];

  const DiscountType._($core.int v, $core.String n) : super(v, n);
}

class DiscountBasis extends $pb.ProtobufEnum {
  static const DiscountBasis ITEM = DiscountBasis._(0, 'ITEM');
  static const DiscountBasis ORDER_SUBTOTAL = DiscountBasis._(1, 'ORDER_SUBTOTAL');
  static const DiscountBasis ORDER_TOTAL = DiscountBasis._(2, 'ORDER_TOTAL');

  static const $core.List<DiscountBasis> values = <DiscountBasis> [
    ITEM,
    ORDER_SUBTOTAL,
    ORDER_TOTAL,
  ];

  static final $core.Map<$core.int, DiscountBasis> _byValue = $pb.ProtobufEnum.initByValue(values);
  static DiscountBasis valueOf($core.int value) => _byValue[value];

  const DiscountBasis._($core.int v, $core.String n) : super(v, n);
}

