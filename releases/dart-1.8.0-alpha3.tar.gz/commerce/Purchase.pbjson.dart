///
//  Generated code. Do not modify.
//  source: commerce/Purchase.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const PurchaseStatus$json = const {
  '1': 'PurchaseStatus',
  '2': const [
    const {'1': 'FRESH', '2': 0},
    const {'1': 'OPEN', '2': 1},
    const {'1': 'CLOSED', '2': 2},
    const {'1': 'VOIDED', '2': 3},
    const {'1': 'FINALIZED', '2': 4},
    const {'1': 'RECONCILED', '2': 5},
  ],
};

const PurchaseAuthority$json = const {
  '1': 'PurchaseAuthority',
  '2': const [
    const {'1': 'STANDARD', '2': 0},
    const {'1': 'MEDICAL', '2': 1},
    const {'1': 'ADULT_USE', '2': 2},
  ],
};

const PurchaseEvent$json = const {
  '1': 'PurchaseEvent',
  '2': const [
    const {'1': 'STATUS', '2': 0},
    const {'1': 'SAVE', '2': 1},
    const {'1': 'LOAD', '2': 2},
    const {'1': 'ITEM_ADDED', '2': 10},
    const {'1': 'ITEM_REMOVED', '2': 11},
    const {'1': 'ITEM_QUANTITY_CHANGED', '2': 12},
    const {'1': 'ITEM_DISCOUNT_ADDED', '2': 13},
    const {'1': 'ITEM_DISCOUNT_REMOVED', '2': 14},
    const {'1': 'PURCHASE_VOID', '2': 20},
    const {'1': 'PURCHASE_FINALIZE', '2': 21},
  ],
};

const PurchaseLogEntry$json = const {
  '1': 'PurchaseLogEntry',
  '2': const [
    const {'1': 'status', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.PurchaseStatus', '10': 'status'},
    const {'1': 'event', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.commerce.PurchaseEvent', '10': 'event'},
    const {'1': 'instant', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'instant'},
    const {'1': 'sku', '3': 4, '4': 1, '5': 9, '10': 'sku'},
    const {'1': 'message', '3': 5, '4': 1, '5': 9, '10': 'message'},
  ],
};

const BillOfCharges$json = const {
  '1': 'BillOfCharges',
  '2': const [
    const {'1': 'status', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.BillStatus', '10': 'status'},
    const {'1': 'tax', '3': 2, '4': 3, '5': 11, '6': '.opencannabis.taxes.Tax', '10': 'tax'},
    const {'1': 'discount', '3': 3, '4': 3, '5': 11, '6': '.opencannabis.commerce.Discount', '10': 'discount'},
    const {'1': 'price', '3': 4, '4': 1, '5': 1, '10': 'price'},
    const {'1': 'taxes', '3': 5, '4': 1, '5': 1, '10': 'taxes'},
    const {'1': 'discounts', '3': 6, '4': 1, '5': 1, '10': 'discounts'},
    const {'1': 'subtotal', '3': 7, '4': 1, '5': 1, '10': 'subtotal'},
    const {'1': 'total', '3': 8, '4': 1, '5': 1, '10': 'total'},
  ],
};

const TicketItem$json = const {
  '1': 'TicketItem',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.inventory.InventoryKey', '10': 'key'},
    const {'1': 'sku', '3': 2, '4': 1, '5': 9, '10': 'sku'},
    const {'1': 'item', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.commerce.Item', '10': 'item'},
    const {'1': 'line', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.commerce.BillOfCharges', '10': 'line'},
  ],
};

const PurchaseTimestamps$json = const {
  '1': 'PurchaseTimestamps',
  '2': const [
    const {'1': 'established', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'established'},
    const {'1': 'created', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'created'},
    const {'1': 'modified', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'modified'},
    const {'1': 'executed', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'executed'},
    const {'1': 'finalized', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.temporal.Instant', '10': 'finalized'},
  ],
};

const PurchaseKey$json = const {
  '1': 'PurchaseKey',
  '2': const [
    const {'1': 'uuid', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'uuid'},
  ],
};

const PurchaseSignature$json = const {
  '1': 'PurchaseSignature',
  '2': const [
    const {'1': 'nonce', '3': 1, '4': 1, '5': 9, '10': 'nonce'},
    const {'1': 'facilitator', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.crypto.Signature', '10': 'facilitator'},
    const {'1': 'customer', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.crypto.Signature', '10': 'customer'},
  ],
};

const PurchaseCustomer$json = const {
  '1': 'PurchaseCustomer',
  '2': const [
    const {'1': 'unique_id', '3': 1, '4': 1, '5': 9, '10': 'uniqueId'},
    const {'1': 'signature', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.commerce.PurchaseSignature', '10': 'signature'},
  ],
};

const PurchaseFacilitator$json = const {
  '1': 'PurchaseFacilitator',
  '2': const [
    const {'1': 'authority', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.PurchaseAuthority', '10': 'authority'},
    const {'1': 'agent', '3': 2, '4': 1, '5': 9, '10': 'agent'},
    const {'1': 'device', '3': 3, '4': 1, '5': 9, '10': 'device'},
    const {'1': 'signature', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.commerce.PurchaseSignature', '10': 'signature'},
  ],
};

const PaymentKey$json = const {
  '1': 'PaymentKey',
  '2': const [
    const {'1': 'uuid', '3': 1, '4': 1, '5': 9, '8': const {}, '10': 'uuid'},
  ],
};

const Payment$json = const {
  '1': 'Payment',
  '2': const [
    const {'1': 'key', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.commerce.PaymentKey', '8': const {}, '10': 'key'},
    const {'1': 'method', '3': 2, '4': 1, '5': 14, '6': '.opencannabis.commerce.PaymentMethod', '10': 'method'},
    const {'1': 'status', '3': 3, '4': 1, '5': 14, '6': '.opencannabis.commerce.PaymentStatus', '10': 'status'},
    const {'1': 'amount', '3': 4, '4': 1, '5': 1, '10': 'amount'},
    const {'1': 'full', '3': 5, '4': 1, '5': 8, '10': 'full'},
    const {'1': 'cash', '3': 10, '4': 1, '5': 11, '6': '.opencannabis.commerce.Payment.CashPayment', '9': 0, '10': 'cash'},
    const {'1': 'check', '3': 11, '4': 1, '5': 11, '6': '.opencannabis.commerce.Payment.CheckPayment', '9': 0, '10': 'check'},
    const {'1': 'card', '3': 12, '4': 1, '5': 11, '6': '.opencannabis.commerce.Payment.CardPayment', '9': 0, '10': 'card'},
    const {'1': 'bank', '3': 13, '4': 1, '5': 11, '6': '.opencannabis.commerce.Payment.BankPayment', '9': 0, '10': 'bank'},
    const {'1': 'digital', '3': 14, '4': 1, '5': 11, '6': '.opencannabis.commerce.Payment.DigitalPayment', '9': 0, '10': 'digital'},
  ],
  '3': const [Payment_CashPayment$json, Payment_CheckPayment$json, Payment_CardPayment$json, Payment_BankPayment$json, Payment_DigitalPayment$json],
  '8': const [
    const {'1': 'spec'},
  ],
};

const Payment_CashPayment$json = const {
  '1': 'CashPayment',
  '2': const [
    const {'1': 'tendered', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.commerce.CurrencyValue', '10': 'tendered'},
    const {'1': 'change', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.commerce.CurrencyValue', '10': 'change'},
  ],
};

const Payment_CheckPayment$json = const {
  '1': 'CheckPayment',
  '2': const [
    const {'1': 'check_number', '3': 1, '4': 1, '5': 9, '10': 'checkNumber'},
    const {'1': 'routing_number', '3': 2, '4': 1, '5': 9, '10': 'routingNumber'},
    const {'1': 'account_number', '3': 3, '4': 1, '5': 9, '10': 'accountNumber'},
    const {'1': 'institution', '3': 4, '4': 1, '5': 9, '10': 'institution'},
    const {'1': 'certified', '3': 5, '4': 1, '5': 8, '10': 'certified'},
  ],
};

const Payment_CardPayment$json = const {
  '1': 'CardPayment',
  '2': const [
    const {'1': 'card_type', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.PaymentCardType', '10': 'cardType'},
  ],
};

const Payment_BankPayment$json = const {
  '1': 'BankPayment',
  '2': const [
    const {'1': 'routing_number', '3': 1, '4': 1, '5': 9, '10': 'routingNumber'},
    const {'1': 'account_number', '3': 2, '4': 1, '5': 9, '10': 'accountNumber'},
    const {'1': 'reference', '3': 3, '4': 1, '5': 9, '10': 'reference'},
  ],
};

const Payment_DigitalPayment$json = const {
  '1': 'DigitalPayment',
  '2': const [
    const {'1': 'network', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.commerce.DigitalPaymentNetwork', '10': 'network'},
    const {'1': 'username', '3': 2, '4': 1, '5': 9, '10': 'username'},
    const {'1': 'reference', '3': 3, '4': 1, '5': 9, '10': 'reference'},
  ],
};

