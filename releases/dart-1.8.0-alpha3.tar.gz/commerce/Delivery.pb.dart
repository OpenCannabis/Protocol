///
//  Generated code. Do not modify.
//  source: commerce/Delivery.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../geo/Address.pb.dart' as $1;

class DeliveryDestination extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DeliveryDestination', package: const $pb.PackageName('opencannabis.commerce'))
    ..a<$1.Address>(1, 'address', $pb.PbFieldType.OM, $1.Address.getDefault, $1.Address.create)
    ..aOS(2, 'instructions')
    ..hasRequiredFields = false
  ;

  DeliveryDestination() : super();
  DeliveryDestination.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DeliveryDestination.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DeliveryDestination clone() => DeliveryDestination()..mergeFromMessage(this);
  DeliveryDestination copyWith(void Function(DeliveryDestination) updates) => super.copyWith((message) => updates(message as DeliveryDestination));
  $pb.BuilderInfo get info_ => _i;
  static DeliveryDestination create() => DeliveryDestination();
  DeliveryDestination createEmptyInstance() => create();
  static $pb.PbList<DeliveryDestination> createRepeated() => $pb.PbList<DeliveryDestination>();
  static DeliveryDestination getDefault() => _defaultInstance ??= create()..freeze();
  static DeliveryDestination _defaultInstance;

  $1.Address get address => $_getN(0);
  set address($1.Address v) { setField(1, v); }
  $core.bool hasAddress() => $_has(0);
  void clearAddress() => clearField(1);

  $core.String get instructions => $_getS(1, '');
  set instructions($core.String v) { $_setString(1, v); }
  $core.bool hasInstructions() => $_has(1);
  void clearInstructions() => clearField(2);
}

