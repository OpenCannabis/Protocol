///
//  Generated code. Do not modify.
//  source: commerce/Item.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../base/ProductKey.pb.dart' as $16;

import 'Item.pbenum.dart';
import '../structs/pricing/PricingDescriptor.pbenum.dart' as $17;

export 'Item.pbenum.dart';

enum VariantSpec_Spec {
  weight, 
  size, 
  color, 
  notSet
}

class VariantSpec extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, VariantSpec_Spec> _VariantSpec_SpecByTag = {
    2 : VariantSpec_Spec.weight,
    3 : VariantSpec_Spec.size,
    4 : VariantSpec_Spec.color,
    0 : VariantSpec_Spec.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('VariantSpec', package: const $pb.PackageName('opencannabis.commerce'))
    ..e<ProductVariant>(1, 'variant', $pb.PbFieldType.OE, ProductVariant.WEIGHT, ProductVariant.valueOf, ProductVariant.values)
    ..e<$17.PricingWeightTier>(2, 'weight', $pb.PbFieldType.OE, $17.PricingWeightTier.NO_WEIGHT, $17.PricingWeightTier.valueOf, $17.PricingWeightTier.values)
    ..aOS(3, 'size')
    ..aOS(4, 'color')
    ..oo(0, [2, 3, 4])
    ..hasRequiredFields = false
  ;

  VariantSpec() : super();
  VariantSpec.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  VariantSpec.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  VariantSpec clone() => VariantSpec()..mergeFromMessage(this);
  VariantSpec copyWith(void Function(VariantSpec) updates) => super.copyWith((message) => updates(message as VariantSpec));
  $pb.BuilderInfo get info_ => _i;
  static VariantSpec create() => VariantSpec();
  VariantSpec createEmptyInstance() => create();
  static $pb.PbList<VariantSpec> createRepeated() => $pb.PbList<VariantSpec>();
  static VariantSpec getDefault() => _defaultInstance ??= create()..freeze();
  static VariantSpec _defaultInstance;

  VariantSpec_Spec whichSpec() => _VariantSpec_SpecByTag[$_whichOneof(0)];
  void clearSpec() => clearField($_whichOneof(0));

  ProductVariant get variant => $_getN(0);
  set variant(ProductVariant v) { setField(1, v); }
  $core.bool hasVariant() => $_has(0);
  void clearVariant() => clearField(1);

  $17.PricingWeightTier get weight => $_getN(1);
  set weight($17.PricingWeightTier v) { setField(2, v); }
  $core.bool hasWeight() => $_has(1);
  void clearWeight() => clearField(2);

  $core.String get size => $_getS(2, '');
  set size($core.String v) { $_setString(2, v); }
  $core.bool hasSize() => $_has(2);
  void clearSize() => clearField(3);

  $core.String get color => $_getS(3, '');
  set color($core.String v) { $_setString(3, v); }
  $core.bool hasColor() => $_has(3);
  void clearColor() => clearField(4);
}

class Item extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Item', package: const $pb.PackageName('opencannabis.commerce'))
    ..a<$16.ProductKey>(1, 'key', $pb.PbFieldType.OM, $16.ProductKey.getDefault, $16.ProductKey.create)
    ..pc<VariantSpec>(2, 'variant', $pb.PbFieldType.PM,VariantSpec.create)
    ..a<$core.int>(3, 'count', $pb.PbFieldType.OU3)
    ..aOS(4, 'uri')
    ..aOS(5, 'imageUri')
    ..hasRequiredFields = false
  ;

  Item() : super();
  Item.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Item.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Item clone() => Item()..mergeFromMessage(this);
  Item copyWith(void Function(Item) updates) => super.copyWith((message) => updates(message as Item));
  $pb.BuilderInfo get info_ => _i;
  static Item create() => Item();
  Item createEmptyInstance() => create();
  static $pb.PbList<Item> createRepeated() => $pb.PbList<Item>();
  static Item getDefault() => _defaultInstance ??= create()..freeze();
  static Item _defaultInstance;

  $16.ProductKey get key => $_getN(0);
  set key($16.ProductKey v) { setField(1, v); }
  $core.bool hasKey() => $_has(0);
  void clearKey() => clearField(1);

  $core.List<VariantSpec> get variant => $_getList(1);

  $core.int get count => $_get(2, 0);
  set count($core.int v) { $_setUnsignedInt32(2, v); }
  $core.bool hasCount() => $_has(2);
  void clearCount() => clearField(3);

  $core.String get uri => $_getS(3, '');
  set uri($core.String v) { $_setString(3, v); }
  $core.bool hasUri() => $_has(3);
  void clearUri() => clearField(4);

  $core.String get imageUri => $_getS(4, '');
  set imageUri($core.String v) { $_setString(4, v); }
  $core.bool hasImageUri() => $_has(4);
  void clearImageUri() => clearField(5);
}

