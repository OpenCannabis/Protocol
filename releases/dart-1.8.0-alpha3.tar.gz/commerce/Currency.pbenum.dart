///
//  Generated code. Do not modify.
//  source: commerce/Currency.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class CurrencyType extends $pb.ProtobufEnum {
  static const CurrencyType FIAT = CurrencyType._(0, 'FIAT');
  static const CurrencyType REAL = CurrencyType._(1, 'REAL');
  static const CurrencyType CRYPTO = CurrencyType._(2, 'CRYPTO');

  static const $core.List<CurrencyType> values = <CurrencyType> [
    FIAT,
    REAL,
    CRYPTO,
  ];

  static final $core.Map<$core.int, CurrencyType> _byValue = $pb.ProtobufEnum.initByValue(values);
  static CurrencyType valueOf($core.int value) => _byValue[value];

  const CurrencyType._($core.int v, $core.String n) : super(v, n);
}

class FiatCurrency extends $pb.ProtobufEnum {
  static const FiatCurrency USD = FiatCurrency._(0, 'USD');
  static const FiatCurrency CAD = FiatCurrency._(1, 'CAD');
  static const FiatCurrency EUR = FiatCurrency._(2, 'EUR');

  static const $core.List<FiatCurrency> values = <FiatCurrency> [
    USD,
    CAD,
    EUR,
  ];

  static final $core.Map<$core.int, FiatCurrency> _byValue = $pb.ProtobufEnum.initByValue(values);
  static FiatCurrency valueOf($core.int value) => _byValue[value];

  const FiatCurrency._($core.int v, $core.String n) : super(v, n);
}

