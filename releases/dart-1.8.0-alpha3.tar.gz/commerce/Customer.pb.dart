///
//  Generated code. Do not modify.
//  source: commerce/Customer.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import '../person/Person.pb.dart' as $12;

class Customer extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Customer', package: const $pb.PackageName('opencannabis.commerce'))
    ..a<$12.Person>(1, 'person', $pb.PbFieldType.OM, $12.Person.getDefault, $12.Person.create)
    ..aOS(2, 'foreignId')
    ..aOS(3, 'userKey')
    ..hasRequiredFields = false
  ;

  Customer() : super();
  Customer.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Customer.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Customer clone() => Customer()..mergeFromMessage(this);
  Customer copyWith(void Function(Customer) updates) => super.copyWith((message) => updates(message as Customer));
  $pb.BuilderInfo get info_ => _i;
  static Customer create() => Customer();
  Customer createEmptyInstance() => create();
  static $pb.PbList<Customer> createRepeated() => $pb.PbList<Customer>();
  static Customer getDefault() => _defaultInstance ??= create()..freeze();
  static Customer _defaultInstance;

  $12.Person get person => $_getN(0);
  set person($12.Person v) { setField(1, v); }
  $core.bool hasPerson() => $_has(0);
  void clearPerson() => clearField(1);

  $core.String get foreignId => $_getS(1, '');
  set foreignId($core.String v) { $_setString(1, v); }
  $core.bool hasForeignId() => $_has(1);
  void clearForeignId() => clearField(2);

  $core.String get userKey => $_getS(2, '');
  set userKey($core.String v) { $_setString(2, v); }
  $core.bool hasUserKey() => $_has(2);
  void clearUserKey() => clearField(3);
}

