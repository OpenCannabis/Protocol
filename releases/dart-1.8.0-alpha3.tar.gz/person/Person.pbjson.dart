///
//  Generated code. Do not modify.
//  source: person/Person.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

const GenderCategory$json = const {
  '1': 'GenderCategory',
  '2': const [
    const {'1': 'UNSPECIFIED', '2': 0},
    const {'1': 'MALE', '2': 1},
    const {'1': 'CIS_MALE', '2': 1},
    const {'1': 'FEMALE', '2': 2},
    const {'1': 'CIS_FEMALE', '2': 2},
    const {'1': 'TRANS_MALE', '2': 3},
    const {'1': 'TRANS_FEMALE', '2': 4},
    const {'1': 'NON_BINARY', '2': 5},
    const {'1': 'GENDER_FLUID', '2': 6},
    const {'1': 'BI_GENDER', '2': 7},
    const {'1': 'PAN_GENDER', '2': 8},
    const {'1': 'DECLINE_TO_STATE', '2': 99},
  ],
  '3': const {'2': true},
};

const KnownPronouns$json = const {
  '1': 'KnownPronouns',
  '2': const [
    const {'1': 'NORMATIVE', '2': 0},
    const {'1': 'HE', '2': 1},
    const {'1': 'SHE', '2': 2},
    const {'1': 'IT', '2': 3},
    const {'1': 'THEY', '2': 4},
    const {'1': 'NE', '2': 5},
    const {'1': 'VE', '2': 6},
    const {'1': 'SPIVAK', '2': 7},
    const {'1': 'ZE', '2': 8},
    const {'1': 'XE', '2': 9},
  ],
};

const CustomPronouns$json = const {
  '1': 'CustomPronouns',
  '2': const [
    const {'1': 'nominative', '3': 1, '4': 1, '5': 9, '10': 'nominative'},
    const {'1': 'objective', '3': 2, '4': 1, '5': 9, '10': 'objective'},
    const {'1': 'determiner', '3': 3, '4': 1, '5': 9, '10': 'determiner'},
    const {'1': 'pronoun', '3': 4, '4': 1, '5': 9, '10': 'pronoun'},
    const {'1': 'reflexive', '3': 5, '4': 1, '5': 9, '10': 'reflexive'},
  ],
};

const Gender$json = const {
  '1': 'Gender',
  '2': const [
    const {'1': 'gender', '3': 1, '4': 1, '5': 14, '6': '.opencannabis.person.GenderCategory', '10': 'gender'},
    const {'1': 'known', '3': 10, '4': 1, '5': 14, '6': '.opencannabis.person.KnownPronouns', '9': 0, '10': 'known'},
    const {'1': 'custom', '3': 11, '4': 1, '5': 11, '6': '.opencannabis.person.CustomPronouns', '9': 0, '10': 'custom'},
  ],
  '8': const [
    const {'1': 'pronouns'},
  ],
};

const Person$json = const {
  '1': 'Person',
  '2': const [
    const {'1': 'name', '3': 1, '4': 1, '5': 11, '6': '.opencannabis.person.Name', '8': const {}, '10': 'name'},
    const {'1': 'legal_name', '3': 2, '4': 1, '5': 11, '6': '.opencannabis.person.Name', '8': const {}, '10': 'legalName'},
    const {'1': 'alternate_name', '3': 3, '4': 1, '5': 11, '6': '.opencannabis.person.Name', '8': const {}, '10': 'alternateName'},
    const {'1': 'contact', '3': 4, '4': 1, '5': 11, '6': '.opencannabis.contact.ContactInfo', '8': const {}, '10': 'contact'},
    const {'1': 'date_of_birth', '3': 5, '4': 1, '5': 11, '6': '.opencannabis.temporal.Date', '8': const {}, '10': 'dateOfBirth'},
    const {'1': 'gender', '3': 6, '4': 1, '5': 11, '6': '.opencannabis.person.Gender', '8': const {}, '10': 'gender'},
  ],
};

