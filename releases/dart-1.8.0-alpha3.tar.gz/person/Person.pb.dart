///
//  Generated code. Do not modify.
//  source: person/Person.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'PersonName.pb.dart' as $9;
import '../contact/ContactInfo.pb.dart' as $10;
import '../temporal/Date.pb.dart' as $11;

import 'Person.pbenum.dart';

export 'Person.pbenum.dart';

class CustomPronouns extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('CustomPronouns', package: const $pb.PackageName('opencannabis.person'))
    ..aOS(1, 'nominative')
    ..aOS(2, 'objective')
    ..aOS(3, 'determiner')
    ..aOS(4, 'pronoun')
    ..aOS(5, 'reflexive')
    ..hasRequiredFields = false
  ;

  CustomPronouns() : super();
  CustomPronouns.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  CustomPronouns.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  CustomPronouns clone() => CustomPronouns()..mergeFromMessage(this);
  CustomPronouns copyWith(void Function(CustomPronouns) updates) => super.copyWith((message) => updates(message as CustomPronouns));
  $pb.BuilderInfo get info_ => _i;
  static CustomPronouns create() => CustomPronouns();
  CustomPronouns createEmptyInstance() => create();
  static $pb.PbList<CustomPronouns> createRepeated() => $pb.PbList<CustomPronouns>();
  static CustomPronouns getDefault() => _defaultInstance ??= create()..freeze();
  static CustomPronouns _defaultInstance;

  $core.String get nominative => $_getS(0, '');
  set nominative($core.String v) { $_setString(0, v); }
  $core.bool hasNominative() => $_has(0);
  void clearNominative() => clearField(1);

  $core.String get objective => $_getS(1, '');
  set objective($core.String v) { $_setString(1, v); }
  $core.bool hasObjective() => $_has(1);
  void clearObjective() => clearField(2);

  $core.String get determiner => $_getS(2, '');
  set determiner($core.String v) { $_setString(2, v); }
  $core.bool hasDeterminer() => $_has(2);
  void clearDeterminer() => clearField(3);

  $core.String get pronoun => $_getS(3, '');
  set pronoun($core.String v) { $_setString(3, v); }
  $core.bool hasPronoun() => $_has(3);
  void clearPronoun() => clearField(4);

  $core.String get reflexive => $_getS(4, '');
  set reflexive($core.String v) { $_setString(4, v); }
  $core.bool hasReflexive() => $_has(4);
  void clearReflexive() => clearField(5);
}

enum Gender_Pronouns {
  known, 
  custom, 
  notSet
}

class Gender extends $pb.GeneratedMessage {
  static const $core.Map<$core.int, Gender_Pronouns> _Gender_PronounsByTag = {
    10 : Gender_Pronouns.known,
    11 : Gender_Pronouns.custom,
    0 : Gender_Pronouns.notSet
  };
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Gender', package: const $pb.PackageName('opencannabis.person'))
    ..e<GenderCategory>(1, 'gender', $pb.PbFieldType.OE, GenderCategory.UNSPECIFIED, GenderCategory.valueOf, GenderCategory.values)
    ..e<KnownPronouns>(10, 'known', $pb.PbFieldType.OE, KnownPronouns.NORMATIVE, KnownPronouns.valueOf, KnownPronouns.values)
    ..a<CustomPronouns>(11, 'custom', $pb.PbFieldType.OM, CustomPronouns.getDefault, CustomPronouns.create)
    ..oo(0, [10, 11])
    ..hasRequiredFields = false
  ;

  Gender() : super();
  Gender.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Gender.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Gender clone() => Gender()..mergeFromMessage(this);
  Gender copyWith(void Function(Gender) updates) => super.copyWith((message) => updates(message as Gender));
  $pb.BuilderInfo get info_ => _i;
  static Gender create() => Gender();
  Gender createEmptyInstance() => create();
  static $pb.PbList<Gender> createRepeated() => $pb.PbList<Gender>();
  static Gender getDefault() => _defaultInstance ??= create()..freeze();
  static Gender _defaultInstance;

  Gender_Pronouns whichPronouns() => _Gender_PronounsByTag[$_whichOneof(0)];
  void clearPronouns() => clearField($_whichOneof(0));

  GenderCategory get gender => $_getN(0);
  set gender(GenderCategory v) { setField(1, v); }
  $core.bool hasGender() => $_has(0);
  void clearGender() => clearField(1);

  KnownPronouns get known => $_getN(1);
  set known(KnownPronouns v) { setField(10, v); }
  $core.bool hasKnown() => $_has(1);
  void clearKnown() => clearField(10);

  CustomPronouns get custom => $_getN(2);
  set custom(CustomPronouns v) { setField(11, v); }
  $core.bool hasCustom() => $_has(2);
  void clearCustom() => clearField(11);
}

class Person extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Person', package: const $pb.PackageName('opencannabis.person'))
    ..a<$9.Name>(1, 'name', $pb.PbFieldType.OM, $9.Name.getDefault, $9.Name.create)
    ..a<$9.Name>(2, 'legalName', $pb.PbFieldType.OM, $9.Name.getDefault, $9.Name.create)
    ..a<$9.Name>(3, 'alternateName', $pb.PbFieldType.OM, $9.Name.getDefault, $9.Name.create)
    ..a<$10.ContactInfo>(4, 'contact', $pb.PbFieldType.OM, $10.ContactInfo.getDefault, $10.ContactInfo.create)
    ..a<$11.Date>(5, 'dateOfBirth', $pb.PbFieldType.OM, $11.Date.getDefault, $11.Date.create)
    ..a<Gender>(6, 'gender', $pb.PbFieldType.OM, Gender.getDefault, Gender.create)
    ..hasRequiredFields = false
  ;

  Person() : super();
  Person.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Person.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Person clone() => Person()..mergeFromMessage(this);
  Person copyWith(void Function(Person) updates) => super.copyWith((message) => updates(message as Person));
  $pb.BuilderInfo get info_ => _i;
  static Person create() => Person();
  Person createEmptyInstance() => create();
  static $pb.PbList<Person> createRepeated() => $pb.PbList<Person>();
  static Person getDefault() => _defaultInstance ??= create()..freeze();
  static Person _defaultInstance;

  $9.Name get name => $_getN(0);
  set name($9.Name v) { setField(1, v); }
  $core.bool hasName() => $_has(0);
  void clearName() => clearField(1);

  $9.Name get legalName => $_getN(1);
  set legalName($9.Name v) { setField(2, v); }
  $core.bool hasLegalName() => $_has(1);
  void clearLegalName() => clearField(2);

  $9.Name get alternateName => $_getN(2);
  set alternateName($9.Name v) { setField(3, v); }
  $core.bool hasAlternateName() => $_has(2);
  void clearAlternateName() => clearField(3);

  $10.ContactInfo get contact => $_getN(3);
  set contact($10.ContactInfo v) { setField(4, v); }
  $core.bool hasContact() => $_has(3);
  void clearContact() => clearField(4);

  $11.Date get dateOfBirth => $_getN(4);
  set dateOfBirth($11.Date v) { setField(5, v); }
  $core.bool hasDateOfBirth() => $_has(4);
  void clearDateOfBirth() => clearField(5);

  Gender get gender => $_getN(5);
  set gender(Gender v) { setField(6, v); }
  $core.bool hasGender() => $_has(5);
  void clearGender() => clearField(6);
}

