///
//  Generated code. Do not modify.
//  source: person/Person.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

// ignore_for_file: UNDEFINED_SHOWN_NAME,UNUSED_SHOWN_NAME
import 'dart:core' as $core show int, dynamic, String, List, Map;
import 'package:protobuf/protobuf.dart' as $pb;

class GenderCategory extends $pb.ProtobufEnum {
  static const GenderCategory UNSPECIFIED = GenderCategory._(0, 'UNSPECIFIED');
  static const GenderCategory MALE = GenderCategory._(1, 'MALE');
  static const GenderCategory FEMALE = GenderCategory._(2, 'FEMALE');
  static const GenderCategory TRANS_MALE = GenderCategory._(3, 'TRANS_MALE');
  static const GenderCategory TRANS_FEMALE = GenderCategory._(4, 'TRANS_FEMALE');
  static const GenderCategory NON_BINARY = GenderCategory._(5, 'NON_BINARY');
  static const GenderCategory GENDER_FLUID = GenderCategory._(6, 'GENDER_FLUID');
  static const GenderCategory BI_GENDER = GenderCategory._(7, 'BI_GENDER');
  static const GenderCategory PAN_GENDER = GenderCategory._(8, 'PAN_GENDER');
  static const GenderCategory DECLINE_TO_STATE = GenderCategory._(99, 'DECLINE_TO_STATE');

  static const GenderCategory CIS_MALE = MALE;
  static const GenderCategory CIS_FEMALE = FEMALE;

  static const $core.List<GenderCategory> values = <GenderCategory> [
    UNSPECIFIED,
    MALE,
    FEMALE,
    TRANS_MALE,
    TRANS_FEMALE,
    NON_BINARY,
    GENDER_FLUID,
    BI_GENDER,
    PAN_GENDER,
    DECLINE_TO_STATE,
  ];

  static final $core.Map<$core.int, GenderCategory> _byValue = $pb.ProtobufEnum.initByValue(values);
  static GenderCategory valueOf($core.int value) => _byValue[value];

  const GenderCategory._($core.int v, $core.String n) : super(v, n);
}

class KnownPronouns extends $pb.ProtobufEnum {
  static const KnownPronouns NORMATIVE = KnownPronouns._(0, 'NORMATIVE');
  static const KnownPronouns HE = KnownPronouns._(1, 'HE');
  static const KnownPronouns SHE = KnownPronouns._(2, 'SHE');
  static const KnownPronouns IT = KnownPronouns._(3, 'IT');
  static const KnownPronouns THEY = KnownPronouns._(4, 'THEY');
  static const KnownPronouns NE = KnownPronouns._(5, 'NE');
  static const KnownPronouns VE = KnownPronouns._(6, 'VE');
  static const KnownPronouns SPIVAK = KnownPronouns._(7, 'SPIVAK');
  static const KnownPronouns ZE = KnownPronouns._(8, 'ZE');
  static const KnownPronouns XE = KnownPronouns._(9, 'XE');

  static const $core.List<KnownPronouns> values = <KnownPronouns> [
    NORMATIVE,
    HE,
    SHE,
    IT,
    THEY,
    NE,
    VE,
    SPIVAK,
    ZE,
    XE,
  ];

  static final $core.Map<$core.int, KnownPronouns> _byValue = $pb.ProtobufEnum.initByValue(values);
  static KnownPronouns valueOf($core.int value) => _byValue[value];

  const KnownPronouns._($core.int v, $core.String n) : super(v, n);
}

