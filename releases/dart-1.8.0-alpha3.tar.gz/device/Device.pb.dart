///
//  Generated code. Do not modify.
//  source: device/Device.proto
///
// ignore_for_file: camel_case_types,non_constant_identifier_names,library_prefixes,unused_import,unused_shown_name

import 'dart:core' as $core show bool, Deprecated, double, int, List, Map, override, String;

import 'package:protobuf/protobuf.dart' as $pb;

import 'Device.pbenum.dart';

export 'Device.pbenum.dart';

class Device extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('Device', package: const $pb.PackageName('opencannabis.device'))
    ..aOS(1, 'uuid')
    ..e<DeviceType>(2, 'type', $pb.PbFieldType.OE, DeviceType.UNKNOWN_DEVICE_TYPE, DeviceType.valueOf, DeviceType.values)
    ..a<DeviceFlags>(3, 'flags', $pb.PbFieldType.OM, DeviceFlags.getDefault, DeviceFlags.create)
    ..a<DeviceCredentials>(4, 'key', $pb.PbFieldType.OM, DeviceCredentials.getDefault, DeviceCredentials.create)
    ..hasRequiredFields = false
  ;

  Device() : super();
  Device.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  Device.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  Device clone() => Device()..mergeFromMessage(this);
  Device copyWith(void Function(Device) updates) => super.copyWith((message) => updates(message as Device));
  $pb.BuilderInfo get info_ => _i;
  static Device create() => Device();
  Device createEmptyInstance() => create();
  static $pb.PbList<Device> createRepeated() => $pb.PbList<Device>();
  static Device getDefault() => _defaultInstance ??= create()..freeze();
  static Device _defaultInstance;

  $core.String get uuid => $_getS(0, '');
  set uuid($core.String v) { $_setString(0, v); }
  $core.bool hasUuid() => $_has(0);
  void clearUuid() => clearField(1);

  DeviceType get type => $_getN(1);
  set type(DeviceType v) { setField(2, v); }
  $core.bool hasType() => $_has(1);
  void clearType() => clearField(2);

  DeviceFlags get flags => $_getN(2);
  set flags(DeviceFlags v) { setField(3, v); }
  $core.bool hasFlags() => $_has(2);
  void clearFlags() => clearField(3);

  DeviceCredentials get key => $_getN(3);
  set key(DeviceCredentials v) { setField(4, v); }
  $core.bool hasKey() => $_has(3);
  void clearKey() => clearField(4);
}

class DeviceFlags extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DeviceFlags', package: const $pb.PackageName('opencannabis.device'))
    ..aOB(1, 'ephemeral')
    ..aOB(2, 'managed')
    ..hasRequiredFields = false
  ;

  DeviceFlags() : super();
  DeviceFlags.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DeviceFlags.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DeviceFlags clone() => DeviceFlags()..mergeFromMessage(this);
  DeviceFlags copyWith(void Function(DeviceFlags) updates) => super.copyWith((message) => updates(message as DeviceFlags));
  $pb.BuilderInfo get info_ => _i;
  static DeviceFlags create() => DeviceFlags();
  DeviceFlags createEmptyInstance() => create();
  static $pb.PbList<DeviceFlags> createRepeated() => $pb.PbList<DeviceFlags>();
  static DeviceFlags getDefault() => _defaultInstance ??= create()..freeze();
  static DeviceFlags _defaultInstance;

  $core.bool get ephemeral => $_get(0, false);
  set ephemeral($core.bool v) { $_setBool(0, v); }
  $core.bool hasEphemeral() => $_has(0);
  void clearEphemeral() => clearField(1);

  $core.bool get managed => $_get(1, false);
  set managed($core.bool v) { $_setBool(1, v); }
  $core.bool hasManaged() => $_has(1);
  void clearManaged() => clearField(2);
}

class DeviceCredentials extends $pb.GeneratedMessage {
  static final $pb.BuilderInfo _i = $pb.BuilderInfo('DeviceCredentials', package: const $pb.PackageName('opencannabis.device'))
    ..a<$core.List<$core.int>>(1, 'publicKey', $pb.PbFieldType.OY)
    ..a<$core.List<$core.int>>(2, 'privateKey', $pb.PbFieldType.OY)
    ..aOS(3, 'sha256')
    ..aOS(4, 'identity')
    ..p<$core.List<$core.int>>(5, 'authorities', $pb.PbFieldType.PY)
    ..hasRequiredFields = false
  ;

  DeviceCredentials() : super();
  DeviceCredentials.fromBuffer($core.List<$core.int> i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromBuffer(i, r);
  DeviceCredentials.fromJson($core.String i, [$pb.ExtensionRegistry r = $pb.ExtensionRegistry.EMPTY]) : super.fromJson(i, r);
  DeviceCredentials clone() => DeviceCredentials()..mergeFromMessage(this);
  DeviceCredentials copyWith(void Function(DeviceCredentials) updates) => super.copyWith((message) => updates(message as DeviceCredentials));
  $pb.BuilderInfo get info_ => _i;
  static DeviceCredentials create() => DeviceCredentials();
  DeviceCredentials createEmptyInstance() => create();
  static $pb.PbList<DeviceCredentials> createRepeated() => $pb.PbList<DeviceCredentials>();
  static DeviceCredentials getDefault() => _defaultInstance ??= create()..freeze();
  static DeviceCredentials _defaultInstance;

  $core.List<$core.int> get publicKey => $_getN(0);
  set publicKey($core.List<$core.int> v) { $_setBytes(0, v); }
  $core.bool hasPublicKey() => $_has(0);
  void clearPublicKey() => clearField(1);

  $core.List<$core.int> get privateKey => $_getN(1);
  set privateKey($core.List<$core.int> v) { $_setBytes(1, v); }
  $core.bool hasPrivateKey() => $_has(1);
  void clearPrivateKey() => clearField(2);

  $core.String get sha256 => $_getS(2, '');
  set sha256($core.String v) { $_setString(2, v); }
  $core.bool hasSha256() => $_has(2);
  void clearSha256() => clearField(3);

  $core.String get identity => $_getS(3, '');
  set identity($core.String v) { $_setString(3, v); }
  $core.bool hasIdentity() => $_has(3);
  void clearIdentity() => clearField(4);

  $core.List<$core.List<$core.int>> get authorities => $_getList(4);
}

