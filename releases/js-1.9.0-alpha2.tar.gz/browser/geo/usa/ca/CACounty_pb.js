// source: geo/usa/ca/CACounty.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.opencannabis.geo.usa.ca.CaliforniaCounty', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.geo.usa.ca.CaliforniaCounty = {
  UNKNOWN_COUNTY: 0,
  ALAMEDA: 1,
  ALPINE: 2,
  AMADOR: 3,
  BUTTE: 4,
  CALAVERAS: 5,
  COLUSA: 6,
  CONTRA_COSTA: 7,
  DEL_NORTE: 8,
  EL_DORADO: 9,
  FRESNO: 10,
  GLENN: 11,
  HUMBOLDT: 12,
  IMERIAL: 13,
  INYO: 14,
  KERN: 15,
  KINGS: 16,
  LAKE: 17,
  LASSEN: 18,
  LOS_ANGELES: 19,
  MADERA: 20,
  MARIN: 21,
  MARIPOSA: 22,
  MENDOCINO: 23,
  MERCED: 24,
  MODOC: 25,
  MONO: 26,
  MONTEREY: 27,
  NAPA: 28,
  ORANGE: 29,
  PLACER: 30,
  PLUMAS: 31,
  RIVERSIDE: 32,
  SACRAMENTO: 33,
  SAN_BENITO: 34,
  SAN_BERNADINO: 35,
  SAN_DIEGO: 36,
  SAN_FRANCISCO: 37,
  SAN_JOAQUIN: 38,
  SAN_LUIS_OBISPO: 39,
  SAN_MATEO: 40,
  SANTA_CLARA: 41,
  SANTA_CRUZ: 42,
  SHASTA: 43,
  SIERRA: 44,
  SISKIYOU: 45,
  SONOMA: 46,
  STANISLAUS: 47,
  SUTTER: 48,
  TRINITY: 49,
  TULARE: 50,
  TUOLOMNE: 51,
  VENTURA: 52,
  YOLO: 53,
  YUBA: 54
};

