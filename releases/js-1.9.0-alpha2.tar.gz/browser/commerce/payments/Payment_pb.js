// source: commerce/payments/Payment.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.opencannabis.commerce.BillStatus', null, global);
goog.exportSymbol('proto.opencannabis.commerce.DigitalPaymentNetwork', null, global);
goog.exportSymbol('proto.opencannabis.commerce.PaymentCardType', null, global);
goog.exportSymbol('proto.opencannabis.commerce.PaymentMethod', null, global);
goog.exportSymbol('proto.opencannabis.commerce.PaymentStatus', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.commerce.PaymentMethod = {
  CASH: 0,
  CHECK: 1,
  DEBIT: 2,
  CREDIT: 3,
  DIGITAL: 4,
  ACH: 5,
  WIRE: 6,
  BLOCKCHAIN: 7
};

/**
 * @enum {number}
 */
proto.opencannabis.commerce.PaymentCardType = {
  NO_CARD_TYPE: 0,
  VISA: 1,
  MASTERCARD: 2,
  DISCOVER: 3,
  AMEX: 4,
  DINERS_CLUB: 5,
  MAESTRO: 6
};

/**
 * @enum {number}
 */
proto.opencannabis.commerce.DigitalPaymentNetwork = {
  UNSPECIFIED_NETWORK: 0,
  PAYPAL: 1,
  VENMO: 2,
  SQUARE: 3
};

/**
 * @enum {number}
 */
proto.opencannabis.commerce.PaymentStatus = {
  NOT_APPLICABLE: 0,
  WAITING: 1,
  PREAUTHORIZED: 2,
  BOUNCED: 3,
  RETRIED: 4
};

/**
 * @enum {number}
 */
proto.opencannabis.commerce.BillStatus = {
  SUSPENSE: 0,
  PARTIAL: 3,
  SETTLED: 4
};

