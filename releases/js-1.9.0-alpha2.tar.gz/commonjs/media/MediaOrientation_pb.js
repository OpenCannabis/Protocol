// source: media/MediaOrientation.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();

goog.exportSymbol('proto.opencannabis.media.MediaOrientation', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.media.MediaOrientation = {
  UP: 0,
  DOWN: 1,
  LEFT: 2,
  RIGHT: 3,
  UP_MIRRORED: 4,
  DOWN_MIRRORED: 5,
  LEFT_MIRRORED: 6,
  RIGHT_MIRRORED: 7
};

goog.object.extend(exports, proto.opencannabis.media);
