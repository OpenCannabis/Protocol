// source: catalog/Policy.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.catalog.policy.PolicyStatus');

/**
 * @enum {number}
 */
proto.opencannabis.catalog.policy.PolicyStatus = {
  UNKNOWN_POLICY_STATUS: 0,
  INACTIVE: 1,
  ACTIVE: 2
};

