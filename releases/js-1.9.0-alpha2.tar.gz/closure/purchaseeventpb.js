// source: commerce/Purchase.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.commerce.PurchaseEvent');

/**
 * @enum {number}
 */
proto.opencannabis.commerce.PurchaseEvent = {
  STATUS: 0,
  SAVE: 1,
  LOAD: 2,
  ITEM_ADDED: 10,
  ITEM_REMOVED: 11,
  ITEM_QUANTITY_CHANGED: 12,
  ITEM_DISCOUNT_ADDED: 13,
  ITEM_DISCOUNT_REMOVED: 14,
  PURCHASE_VOID: 20,
  PURCHASE_FINALIZE: 21
};

