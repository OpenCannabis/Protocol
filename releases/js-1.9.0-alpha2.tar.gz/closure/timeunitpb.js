// source: temporal/Duration.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.temporal.TimeUnit');

/**
 * @enum {number}
 */
proto.opencannabis.temporal.TimeUnit = {
  MILLISECONDS: 0,
  MICROSECONDS: 1,
  SECONDS: 2,
  MINUTES: 3,
  HOURS: 4,
  DAYS: 5,
  WEEKS: 6,
  MONTHS: 7,
  YEARS: 8
};

