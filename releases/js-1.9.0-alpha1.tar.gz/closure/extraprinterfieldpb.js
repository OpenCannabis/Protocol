// source: google/cloudprint/GoogleCloudPrint.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.google.cloudprint.ExtraPrinterField');

/**
 * @enum {number}
 */
proto.google.cloudprint.ExtraPrinterField = {
  UNKNOWN_EXTRA_FIELDS: 0,
  CONNECTION_STATUS: 1,
  SEMANTIC_STATE: 2,
  UI_STATE: 3,
  QUEUED_JOBS_COUNT: 4
};

