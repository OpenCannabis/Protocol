// source: products/distribution/DistributionChannel.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.distribution.ChannelType');

/**
 * @enum {number}
 */
proto.opencannabis.products.distribution.ChannelType = {
  UNSPECIFIED_CHANNEL_TYPE: 0,
  DIRECT: 1,
  MARKETPLACE: 2
};

