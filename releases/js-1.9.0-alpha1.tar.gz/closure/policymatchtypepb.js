// source: catalog/Policy.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.catalog.policy.PolicyMatchType');

/**
 * @enum {number}
 */
proto.opencannabis.catalog.policy.PolicyMatchType = {
  UNKNOWN_MATCH_TYPE: 0,
  BY_CATEGORY: 1,
  BY_PROPERTY: 2
};

