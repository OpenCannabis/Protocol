// source: commerce/payments/Payment.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.commerce.PaymentCardType');

/**
 * @enum {number}
 */
proto.opencannabis.commerce.PaymentCardType = {
  NO_CARD_TYPE: 0,
  VISA: 1,
  MASTERCARD: 2,
  DISCOVER: 3,
  AMEX: 4,
  DINERS_CLUB: 5,
  MAESTRO: 6
};

