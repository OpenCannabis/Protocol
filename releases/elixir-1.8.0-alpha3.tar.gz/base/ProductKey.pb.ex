defmodule Opencannabis.Base.ProductReference do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: Opencannabis.Content.Name.t() | nil,
          key: Opencannabis.Base.ProductKey.t() | nil
        }
  defstruct [:name, :key]

  field :name, 1, type: Opencannabis.Content.Name
  field :key, 2, type: Opencannabis.Base.ProductKey
end

defmodule Opencannabis.Base.ProductKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          type: atom | integer
        }
  defstruct [:id, :type]

  field :id, 1, type: :string
  field :type, 2, type: Opencannabis.Base.ProductKind, enum: true
end
