defmodule Opencannabis.Base.Language do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :LANGUAGE_UNSPECIFIED, 0
  field :ENGLISH, 1
  field :SPANISH, 2
  field :FRENCH, 3
end
