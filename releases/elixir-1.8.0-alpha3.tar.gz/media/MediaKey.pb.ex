defmodule Opencannabis.Media.MediaKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t()
        }
  defstruct [:id]

  field :id, 1, type: :string
end

defmodule Opencannabis.Media.MediaReference do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Media.MediaKey.t() | nil,
          uri: String.t(),
          type: Opencannabis.Media.MediaType.t() | nil
        }
  defstruct [:key, :uri, :type]

  field :key, 1, type: Opencannabis.Media.MediaKey
  field :uri, 2, type: :string
  field :type, 3, type: Opencannabis.Media.MediaType
end
