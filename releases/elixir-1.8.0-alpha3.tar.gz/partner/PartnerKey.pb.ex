defmodule Bloombox.Partner.PartnerKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          code: String.t()
        }
  defstruct [:code]

  field :code, 1, type: :string
end
