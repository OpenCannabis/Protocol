defmodule Opencannabis.Content.DataFormat do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNKNOWN_FORMAT, 0
  field :CSV, 10
  field :TSV, 11
  field :EXCEL_CSV, 12
  field :EXCEL_XLS, 13
  field :EXCEL_XLSX, 14
  field :MSGPACK, 20
  field :AVRO, 30
  field :SQL, 40
  field :JSON, 50
  field :OCP_TEXT, 61
  field :OCP_BINARY, 62
end
