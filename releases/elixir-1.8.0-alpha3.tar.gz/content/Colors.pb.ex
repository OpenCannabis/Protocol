defmodule Opencannabis.Content.RGBAColorSpec do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          r: non_neg_integer,
          g: non_neg_integer,
          b: non_neg_integer,
          a: non_neg_integer
        }
  defstruct [:r, :g, :b, :a]

  field :r, 1, type: :uint64
  field :g, 2, type: :uint64
  field :b, 3, type: :uint64
  field :a, 4, type: :uint64
end

defmodule Opencannabis.Content.HSBColorSpec do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          h: non_neg_integer,
          s: non_neg_integer,
          b: non_neg_integer
        }
  defstruct [:h, :s, :b]

  field :h, 1, type: :uint64
  field :s, 2, type: :uint64
  field :b, 3, type: :uint64
end

defmodule Opencannabis.Content.CMYKColorSpec do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          c: non_neg_integer,
          m: non_neg_integer,
          y: non_neg_integer,
          k: non_neg_integer
        }
  defstruct [:c, :m, :y, :k]

  field :c, 1, type: :uint64
  field :m, 2, type: :uint64
  field :y, 3, type: :uint64
  field :k, 4, type: :uint64
end

defmodule Opencannabis.Content.Color do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          spec: {atom, any}
        }
  defstruct [:spec]

  oneof :spec, 0
  field :standard, 1, type: Opencannabis.Content.StandardColor, enum: true, oneof: 0
  field :hex, 2, type: :string, oneof: 0
  field :rgba, 3, type: Opencannabis.Content.RGBAColorSpec, oneof: 0
  field :hsb, 4, type: Opencannabis.Content.HSBColorSpec, oneof: 0
  field :cmyk, 5, type: Opencannabis.Content.CMYKColorSpec, oneof: 0
end

defmodule Opencannabis.Content.ColorScheme do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          primary: Opencannabis.Content.Color.t() | nil,
          secondary: Opencannabis.Content.Color.t() | nil,
          alert: Opencannabis.Content.Color.t() | nil,
          shades: [Opencannabis.Content.Color.t()]
        }
  defstruct [:primary, :secondary, :alert, :shades]

  field :primary, 1, type: Opencannabis.Content.Color
  field :secondary, 2, type: Opencannabis.Content.Color
  field :alert, 3, type: Opencannabis.Content.Color
  field :shades, 4, repeated: true, type: Opencannabis.Content.Color
end

defmodule Opencannabis.Content.StandardColor do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_COLOR, 0
  field :RED, 1
  field :GREEN, 2
  field :BLUE, 3
  field :YELLOW, 4
  field :PURPLE, 5
  field :ORANGE, 6
  field :PINK, 7
  field :GRAY, 8
  field :BROWN, 9
end
