defmodule Opencannabis.Content.RasterGraphic do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          standard: Opencannabis.Media.MediaReference.t() | nil,
          retina: Opencannabis.Media.MediaReference.t() | nil
        }
  defstruct [:standard, :retina]

  field :standard, 1, type: Opencannabis.Media.MediaReference
  field :retina, 2, type: Opencannabis.Media.MediaReference
end

defmodule Opencannabis.Content.BrandAsset do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          raster: Opencannabis.Content.RasterGraphic.t() | nil,
          vector: Opencannabis.Media.MediaReference.t() | nil
        }
  defstruct [:raster, :vector]

  field :raster, 1, type: Opencannabis.Content.RasterGraphic
  field :vector, 2, type: Opencannabis.Media.MediaReference
end

defmodule Opencannabis.Content.Brand do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: Opencannabis.Content.Name.t() | nil,
          parent: Opencannabis.Content.Brand.t() | nil,
          summary: Opencannabis.Content.Content.t() | nil,
          media: [Opencannabis.Content.BrandAsset.t()],
          theme: Opencannabis.Content.ColorScheme.t() | nil
        }
  defstruct [:name, :parent, :summary, :media, :theme]

  field :name, 1, type: Opencannabis.Content.Name
  field :parent, 2, type: Opencannabis.Content.Brand
  field :summary, 3, type: Opencannabis.Content.Content
  field :media, 20, repeated: true, type: Opencannabis.Content.BrandAsset
  field :theme, 21, type: Opencannabis.Content.ColorScheme
end
