defmodule Opencannabis.Content.MaterialsData do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          species: atom | integer,
          genetics: Opencannabis.Structs.Genetics.t() | nil,
          grow: atom | integer,
          shelf: atom | integer,
          channel: [Opencannabis.Products.Distribution.DistributionPolicy.t()]
        }
  defstruct [:species, :genetics, :grow, :shelf, :channel]

  field :species, 1, type: Opencannabis.Structs.Species, enum: true
  field :genetics, 2, type: Opencannabis.Structs.Genetics
  field :grow, 3, type: Opencannabis.Structs.Grow, enum: true
  field :shelf, 4, type: Opencannabis.Structs.Shelf, enum: true
  field :channel, 5, repeated: true, type: Opencannabis.Products.Distribution.DistributionPolicy
end
