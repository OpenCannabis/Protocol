defmodule Opencannabis.Regulatory.Usa.Ca.CaliforniaAgency do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNKNOWN_AGENCY, 0
  field :CDFA, 1
  field :CBCC, 2
  field :CDCA, 3
  field :CDPH, 4
end
