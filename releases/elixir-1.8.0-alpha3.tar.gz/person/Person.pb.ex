defmodule Opencannabis.Person.CustomPronouns do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          nominative: String.t(),
          objective: String.t(),
          determiner: String.t(),
          pronoun: String.t(),
          reflexive: String.t()
        }
  defstruct [:nominative, :objective, :determiner, :pronoun, :reflexive]

  field :nominative, 1, type: :string
  field :objective, 2, type: :string
  field :determiner, 3, type: :string
  field :pronoun, 4, type: :string
  field :reflexive, 5, type: :string
end

defmodule Opencannabis.Person.Gender do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          pronouns: {atom, any},
          gender: atom | integer
        }
  defstruct [:pronouns, :gender]

  oneof :pronouns, 0
  field :gender, 1, type: Opencannabis.Person.GenderCategory, enum: true
  field :known, 10, type: Opencannabis.Person.KnownPronouns, enum: true, oneof: 0
  field :custom, 11, type: Opencannabis.Person.CustomPronouns, oneof: 0
end

defmodule Opencannabis.Person.Person do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: Opencannabis.Person.Name.t() | nil,
          legal_name: Opencannabis.Person.Name.t() | nil,
          alternate_name: Opencannabis.Person.Name.t() | nil,
          contact: Opencannabis.Contact.ContactInfo.t() | nil,
          date_of_birth: Opencannabis.Temporal.Date.t() | nil,
          gender: Opencannabis.Person.Gender.t() | nil
        }
  defstruct [:name, :legal_name, :alternate_name, :contact, :date_of_birth, :gender]

  field :name, 1, type: Opencannabis.Person.Name
  field :legal_name, 2, type: Opencannabis.Person.Name
  field :alternate_name, 3, type: Opencannabis.Person.Name
  field :contact, 4, type: Opencannabis.Contact.ContactInfo
  field :date_of_birth, 5, type: Opencannabis.Temporal.Date
  field :gender, 6, type: Opencannabis.Person.Gender
end

defmodule Opencannabis.Person.GenderCategory do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED, 0
  field :MALE, 1
  field :CIS_MALE, 1
  field :FEMALE, 2
  field :CIS_FEMALE, 2
  field :TRANS_MALE, 3
  field :TRANS_FEMALE, 4
  field :NON_BINARY, 5
  field :GENDER_FLUID, 6
  field :BI_GENDER, 7
  field :PAN_GENDER, 8
  field :DECLINE_TO_STATE, 99
end

defmodule Opencannabis.Person.KnownPronouns do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NORMATIVE, 0
  field :HE, 1
  field :SHE, 2
  field :IT, 3
  field :THEY, 4
  field :NE, 5
  field :VE, 6
  field :SPIVAK, 7
  field :ZE, 8
  field :XE, 9
end
