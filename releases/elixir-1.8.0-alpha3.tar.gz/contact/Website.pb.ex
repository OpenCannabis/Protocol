defmodule Opencannabis.Contact.Website do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          uri: String.t(),
          title: String.t(),
          icon: binary
        }
  defstruct [:uri, :title, :icon]

  field :uri, 1, type: :string
  field :title, 2, type: :string
  field :icon, 3, type: :bytes
end
