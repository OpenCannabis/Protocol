defmodule Opencannabis.Contact.PhoneNumber do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          e164: String.t(),
          validated: boolean,
          display: String.t(),
          text_capable: boolean,
          voice_capable: boolean
        }
  defstruct [:e164, :validated, :display, :text_capable, :voice_capable]

  field :e164, 1, type: :string
  field :validated, 2, type: :bool
  field :display, 3, type: :string
  field :text_capable, 4, type: :bool
  field :voice_capable, 5, type: :bool
end
