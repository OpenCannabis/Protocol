defmodule Opencannabis.Temporal.Schedule do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          spec: {atom, any}
        }
  defstruct [:spec]

  oneof :spec, 0
  field :absolute, 1, type: Opencannabis.Temporal.Instant, oneof: 0
  field :time, 2, type: Opencannabis.Temporal.Time, oneof: 0
  field :interval, 3, type: Opencannabis.Temporal.Interval, enum: true, oneof: 0
end
