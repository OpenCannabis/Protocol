defmodule Opencannabis.Temporal.Timehash do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          component: [String.t()]
        }
  defstruct [:component]

  field :component, 1, repeated: true, type: :string
end
