defmodule Opencannabis.Commerce.Customer do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          person: Opencannabis.Person.Person.t() | nil,
          foreign_id: String.t(),
          user_key: String.t()
        }
  defstruct [:person, :foreign_id, :user_key]

  field :person, 1, type: Opencannabis.Person.Person
  field :foreign_id, 2, type: :string
  field :user_key, 3, type: :string
end
