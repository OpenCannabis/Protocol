defmodule Opencannabis.Commerce.PurchaseLogEntry do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          status: atom | integer,
          event: atom | integer,
          instant: Opencannabis.Temporal.Instant.t() | nil,
          sku: String.t(),
          message: String.t()
        }
  defstruct [:status, :event, :instant, :sku, :message]

  field :status, 1, type: Opencannabis.Commerce.PurchaseStatus, enum: true
  field :event, 2, type: Opencannabis.Commerce.PurchaseEvent, enum: true
  field :instant, 3, type: Opencannabis.Temporal.Instant
  field :sku, 4, type: :string
  field :message, 5, type: :string
end

defmodule Opencannabis.Commerce.BillOfCharges do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          status: atom | integer,
          tax: [Opencannabis.Taxes.Tax.t()],
          discount: [Opencannabis.Commerce.Discount.t()],
          price: float,
          taxes: float,
          discounts: float,
          subtotal: float,
          total: float
        }
  defstruct [:status, :tax, :discount, :price, :taxes, :discounts, :subtotal, :total]

  field :status, 1, type: Opencannabis.Commerce.BillStatus, enum: true
  field :tax, 2, repeated: true, type: Opencannabis.Taxes.Tax
  field :discount, 3, repeated: true, type: Opencannabis.Commerce.Discount
  field :price, 4, type: :double
  field :taxes, 5, type: :double
  field :discounts, 6, type: :double
  field :subtotal, 7, type: :double
  field :total, 8, type: :double
end

defmodule Opencannabis.Commerce.TicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Inventory.InventoryKey.t() | nil,
          sku: String.t(),
          item: Opencannabis.Commerce.Item.t() | nil,
          line: Opencannabis.Commerce.BillOfCharges.t() | nil
        }
  defstruct [:key, :sku, :item, :line]

  field :key, 1, type: Opencannabis.Inventory.InventoryKey
  field :sku, 2, type: :string
  field :item, 3, type: Opencannabis.Commerce.Item
  field :line, 4, type: Opencannabis.Commerce.BillOfCharges
end

defmodule Opencannabis.Commerce.PurchaseTimestamps do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          established: Opencannabis.Temporal.Instant.t() | nil,
          created: Opencannabis.Temporal.Instant.t() | nil,
          modified: Opencannabis.Temporal.Instant.t() | nil,
          executed: Opencannabis.Temporal.Instant.t() | nil,
          finalized: Opencannabis.Temporal.Instant.t() | nil
        }
  defstruct [:established, :created, :modified, :executed, :finalized]

  field :established, 1, type: Opencannabis.Temporal.Instant
  field :created, 2, type: Opencannabis.Temporal.Instant
  field :modified, 3, type: Opencannabis.Temporal.Instant
  field :executed, 4, type: Opencannabis.Temporal.Instant
  field :finalized, 5, type: Opencannabis.Temporal.Instant
end

defmodule Opencannabis.Commerce.PurchaseKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          uuid: String.t()
        }
  defstruct [:uuid]

  field :uuid, 1, type: :string
end

defmodule Opencannabis.Commerce.PurchaseSignature do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          nonce: String.t(),
          facilitator: Opencannabis.Crypto.Signature.t() | nil,
          customer: Opencannabis.Crypto.Signature.t() | nil
        }
  defstruct [:nonce, :facilitator, :customer]

  field :nonce, 1, type: :string
  field :facilitator, 2, type: Opencannabis.Crypto.Signature
  field :customer, 3, type: Opencannabis.Crypto.Signature
end

defmodule Opencannabis.Commerce.PurchaseCustomer do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          unique_id: String.t(),
          signature: Opencannabis.Commerce.PurchaseSignature.t() | nil
        }
  defstruct [:unique_id, :signature]

  field :unique_id, 1, type: :string
  field :signature, 2, type: Opencannabis.Commerce.PurchaseSignature
end

defmodule Opencannabis.Commerce.PurchaseFacilitator do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          authority: atom | integer,
          agent: String.t(),
          device: String.t(),
          signature: Opencannabis.Commerce.PurchaseSignature.t() | nil
        }
  defstruct [:authority, :agent, :device, :signature]

  field :authority, 1, type: Opencannabis.Commerce.PurchaseAuthority, enum: true
  field :agent, 2, type: :string
  field :device, 3, type: :string
  field :signature, 4, type: Opencannabis.Commerce.PurchaseSignature
end

defmodule Opencannabis.Commerce.PaymentKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          uuid: String.t()
        }
  defstruct [:uuid]

  field :uuid, 1, type: :string
end

defmodule Opencannabis.Commerce.Payment do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          spec: {atom, any},
          key: Opencannabis.Commerce.PaymentKey.t() | nil,
          method: atom | integer,
          status: atom | integer,
          amount: float,
          full: boolean
        }
  defstruct [:spec, :key, :method, :status, :amount, :full]

  oneof :spec, 0
  field :key, 1, type: Opencannabis.Commerce.PaymentKey
  field :method, 2, type: Opencannabis.Commerce.PaymentMethod, enum: true
  field :status, 3, type: Opencannabis.Commerce.PaymentStatus, enum: true
  field :amount, 4, type: :double
  field :full, 5, type: :bool
  field :cash, 10, type: Opencannabis.Commerce.Payment.CashPayment, oneof: 0
  field :check, 11, type: Opencannabis.Commerce.Payment.CheckPayment, oneof: 0
  field :card, 12, type: Opencannabis.Commerce.Payment.CardPayment, oneof: 0
  field :bank, 13, type: Opencannabis.Commerce.Payment.BankPayment, oneof: 0
  field :digital, 14, type: Opencannabis.Commerce.Payment.DigitalPayment, oneof: 0
end

defmodule Opencannabis.Commerce.Payment.CashPayment do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          tendered: Opencannabis.Commerce.CurrencyValue.t() | nil,
          change: Opencannabis.Commerce.CurrencyValue.t() | nil
        }
  defstruct [:tendered, :change]

  field :tendered, 1, type: Opencannabis.Commerce.CurrencyValue
  field :change, 2, type: Opencannabis.Commerce.CurrencyValue
end

defmodule Opencannabis.Commerce.Payment.CheckPayment do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          check_number: String.t(),
          routing_number: String.t(),
          account_number: String.t(),
          institution: String.t(),
          certified: boolean
        }
  defstruct [:check_number, :routing_number, :account_number, :institution, :certified]

  field :check_number, 1, type: :string
  field :routing_number, 2, type: :string
  field :account_number, 3, type: :string
  field :institution, 4, type: :string
  field :certified, 5, type: :bool
end

defmodule Opencannabis.Commerce.Payment.CardPayment do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          card_type: atom | integer
        }
  defstruct [:card_type]

  field :card_type, 1, type: Opencannabis.Commerce.PaymentCardType, enum: true
end

defmodule Opencannabis.Commerce.Payment.BankPayment do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          routing_number: String.t(),
          account_number: String.t(),
          reference: String.t()
        }
  defstruct [:routing_number, :account_number, :reference]

  field :routing_number, 1, type: :string
  field :account_number, 2, type: :string
  field :reference, 3, type: :string
end

defmodule Opencannabis.Commerce.Payment.DigitalPayment do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          network: atom | integer,
          username: String.t(),
          reference: String.t()
        }
  defstruct [:network, :username, :reference]

  field :network, 1, type: Opencannabis.Commerce.DigitalPaymentNetwork, enum: true
  field :username, 2, type: :string
  field :reference, 3, type: :string
end

defmodule Opencannabis.Commerce.PurchaseStatus do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :FRESH, 0
  field :OPEN, 1
  field :CLOSED, 2
  field :VOIDED, 3
  field :FINALIZED, 4
  field :RECONCILED, 5
end

defmodule Opencannabis.Commerce.PurchaseAuthority do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :STANDARD, 0
  field :MEDICAL, 1
  field :ADULT_USE, 2
end

defmodule Opencannabis.Commerce.PurchaseEvent do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :STATUS, 0
  field :SAVE, 1
  field :LOAD, 2
  field :ITEM_ADDED, 10
  field :ITEM_REMOVED, 11
  field :ITEM_QUANTITY_CHANGED, 12
  field :ITEM_DISCOUNT_ADDED, 13
  field :ITEM_DISCOUNT_REMOVED, 14
  field :PURCHASE_VOID, 20
  field :PURCHASE_FINALIZE, 21
end
