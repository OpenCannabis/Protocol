defmodule Opencannabis.Commerce.DeliveryDestination do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          address: Opencannabis.Geo.Address.t() | nil,
          instructions: String.t()
        }
  defstruct [:address, :instructions]

  field :address, 1, type: Opencannabis.Geo.Address
  field :instructions, 2, type: :string
end
