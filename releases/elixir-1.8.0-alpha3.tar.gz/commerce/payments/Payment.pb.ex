defmodule Opencannabis.Commerce.PaymentMethod do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CASH, 0
  field :CHECK, 1
  field :DEBIT, 2
  field :CREDIT, 3
  field :DIGITAL, 4
  field :ACH, 5
  field :WIRE, 6
  field :BLOCKCHAIN, 7
end

defmodule Opencannabis.Commerce.PaymentCardType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_CARD_TYPE, 0
  field :VISA, 1
  field :MASTERCARD, 2
  field :DISCOVER, 3
  field :AMEX, 4
  field :DINERS_CLUB, 5
  field :MAESTRO, 6
end

defmodule Opencannabis.Commerce.DigitalPaymentNetwork do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_NETWORK, 0
  field :PAYPAL, 1
  field :VENMO, 2
  field :SQUARE, 3
end

defmodule Opencannabis.Commerce.PaymentStatus do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NOT_APPLICABLE, 0
  field :WAITING, 1
  field :PREAUTHORIZED, 2
  field :BOUNCED, 3
  field :RETRIED, 4
end

defmodule Opencannabis.Commerce.BillStatus do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :SUSPENSE, 0
  field :PARTIAL, 3
  field :SETTLED, 4
end
