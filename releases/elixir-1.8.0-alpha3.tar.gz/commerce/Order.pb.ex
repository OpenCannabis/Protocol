defmodule Opencannabis.Commerce.OrderScheduling do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          scheduling: atom | integer,
          desired_time: Opencannabis.Temporal.Instant.t() | nil
        }
  defstruct [:scheduling, :desired_time]

  field :scheduling, 1, type: Opencannabis.Commerce.SchedulingType, enum: true
  field :desired_time, 2, type: Opencannabis.Temporal.Instant
end

defmodule Opencannabis.Commerce.OrderPayment do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          status: atom | integer,
          method: atom | integer,
          tax: float,
          paid: float
        }
  defstruct [:status, :method, :tax, :paid]

  field :status, 1, type: Opencannabis.Commerce.PaymentStatus, enum: true
  field :method, 2, type: Opencannabis.Commerce.PaymentMethod, enum: true
  field :tax, 3, type: :double
  field :paid, 4, type: :double
end

defmodule Opencannabis.Commerce.StatusCheckin do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          status: atom | integer,
          instant: Opencannabis.Temporal.Instant.t() | nil,
          message: String.t()
        }
  defstruct [:status, :instant, :message]

  field :status, 1, type: Opencannabis.Commerce.OrderStatus, enum: true
  field :instant, 2, type: Opencannabis.Temporal.Instant
  field :message, 3, type: :string
end

defmodule Opencannabis.Commerce.OrderKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t()
        }
  defstruct [:id]

  field :id, 1, type: :string
end

defmodule Opencannabis.Commerce.Order do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          type: atom | integer,
          status: atom | integer,
          customer: Opencannabis.Commerce.Customer.t() | nil,
          scheduling: Opencannabis.Commerce.OrderScheduling.t() | nil,
          destination: Opencannabis.Commerce.DeliveryDestination.t() | nil,
          notes: String.t(),
          item: [Opencannabis.Commerce.Item.t()],
          action_log: [Opencannabis.Commerce.StatusCheckin.t()],
          created_at: Opencannabis.Temporal.Instant.t() | nil,
          subtotal: float,
          updated_at: Opencannabis.Temporal.Instant.t() | nil,
          sid: String.t(),
          payment: Opencannabis.Commerce.OrderPayment.t() | nil
        }
  defstruct [
    :id,
    :type,
    :status,
    :customer,
    :scheduling,
    :destination,
    :notes,
    :item,
    :action_log,
    :created_at,
    :subtotal,
    :updated_at,
    :sid,
    :payment
  ]

  field :id, 1, type: :string
  field :type, 2, type: Opencannabis.Commerce.OrderType, enum: true
  field :status, 3, type: Opencannabis.Commerce.OrderStatus, enum: true
  field :customer, 4, type: Opencannabis.Commerce.Customer
  field :scheduling, 5, type: Opencannabis.Commerce.OrderScheduling
  field :destination, 6, type: Opencannabis.Commerce.DeliveryDestination
  field :notes, 7, type: :string
  field :item, 8, repeated: true, type: Opencannabis.Commerce.Item
  field :action_log, 9, repeated: true, type: Opencannabis.Commerce.StatusCheckin
  field :created_at, 10, type: Opencannabis.Temporal.Instant
  field :subtotal, 11, type: :double
  field :updated_at, 12, type: Opencannabis.Temporal.Instant
  field :sid, 13, type: :string
  field :payment, 14, type: Opencannabis.Commerce.OrderPayment
end

defmodule Opencannabis.Commerce.OrderType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PICKUP, 0
  field :DELIVERY, 1
  field :ONSITE, 2
end

defmodule Opencannabis.Commerce.SchedulingType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :ASAP, 0
  field :TIMED, 1
end

defmodule Opencannabis.Commerce.OrderStatus do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PENDING, 0
  field :APPROVED, 1
  field :REJECTED, 2
  field :ASSIGNED, 3
  field :EN_ROUTE, 4
  field :FULFILLED, 5
end
