defmodule Opencannabis.Crypto.Signature do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          signature: {atom, any},
          public_key: Opencannabis.Crypto.KeyMaterial.t() | nil,
          fingerprint: Opencannabis.Crypto.Hash.t() | nil
        }
  defstruct [:signature, :public_key, :fingerprint]

  oneof :signature, 0
  field :public_key, 1, type: Opencannabis.Crypto.KeyMaterial
  field :fingerprint, 2, type: Opencannabis.Crypto.Hash
  field :raw, 5, type: :bytes, oneof: 0
  field :b64, 6, type: :string, oneof: 0
  field :hex, 7, type: :string, oneof: 0
end
