defmodule Opencannabis.Crypto.EncryptedData do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          data: binary,
          encoding: atom | integer,
          compression: Opencannabis.Base.Compression.t() | nil,
          fingerprint: Opencannabis.Crypto.Hash.t() | nil
        }
  defstruct [:data, :encoding, :compression, :fingerprint]

  field :data, 1, type: :bytes
  field :encoding, 2, type: Opencannabis.Content.Encoding, enum: true
  field :compression, 3, type: Opencannabis.Base.Compression
  field :fingerprint, 4, type: Opencannabis.Crypto.Hash
end

defmodule Opencannabis.Crypto.EncryptedContainer do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          parameters: {atom, any},
          payload: Opencannabis.Crypto.EncryptedData.t() | nil,
          keying: atom | integer,
          vector: Opencannabis.Crypto.InitializationVector.t() | nil
        }
  defstruct [:parameters, :payload, :keying, :vector]

  oneof :parameters, 0
  field :payload, 1, type: Opencannabis.Crypto.EncryptedData
  field :keying, 2, type: Opencannabis.Crypto.KeyType, enum: true
  field :vector, 3, type: Opencannabis.Crypto.InitializationVector
  field :key, 4, type: Opencannabis.Crypto.SymmetricKeyParameters, oneof: 0
  field :keypair, 5, type: Opencannabis.Crypto.AsymmetricKeypairParameters, oneof: 0
end
