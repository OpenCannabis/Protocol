defmodule Opencannabis.Crypto.BlockCipherParameters do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          algorithm: atom | integer,
          mode: atom | integer
        }
  defstruct [:algorithm, :mode]

  field :algorithm, 1, type: Opencannabis.Crypto.BlockCipher, enum: true
  field :mode, 2, type: Opencannabis.Crypto.BlockMode, enum: true
end

defmodule Opencannabis.Crypto.SymmetricKeyParameters do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          cipher: {atom, any}
        }
  defstruct [:cipher]

  oneof :cipher, 0
  field :stream, 1, type: Opencannabis.Crypto.StreamCipher, enum: true, oneof: 0
  field :block, 2, type: Opencannabis.Crypto.BlockCipherParameters, oneof: 0
end

defmodule Opencannabis.Crypto.AsymmetricKeypairParameters do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          scheme: atom | integer,
          fingerprint: Opencannabis.Crypto.Hash.t() | nil
        }
  defstruct [:scheme, :fingerprint]

  field :scheme, 1, type: Opencannabis.Crypto.KeyingScheme, enum: true
  field :fingerprint, 2, type: Opencannabis.Crypto.Hash
end

defmodule Opencannabis.Crypto.KeyParameters do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          architecture: {atom, any},
          algorithm: String.t(),
          format: String.t(),
          bits: non_neg_integer,
          type: atom | integer,
          disposition: atom | integer
        }
  defstruct [:architecture, :algorithm, :format, :bits, :type, :disposition]

  oneof :architecture, 0
  field :algorithm, 1, type: :string
  field :format, 2, type: :string
  field :bits, 3, type: :uint32
  field :type, 4, type: Opencannabis.Crypto.KeyType, enum: true
  field :disposition, 5, type: Opencannabis.Crypto.KeyDisposition, enum: true
  field :scheme, 10, type: Opencannabis.Crypto.KeyingScheme, enum: true, oneof: 0
  field :symmetric, 11, type: Opencannabis.Crypto.SymmetricKeyParameters, oneof: 0
end

defmodule Opencannabis.Crypto.InitializationVector do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          value: {atom, any},
          mode: atom | integer
        }
  defstruct [:value, :mode]

  oneof :value, 0
  field :mode, 1, type: Opencannabis.Crypto.InitializationVectorMode, enum: true
  field :raw, 10, type: :bytes, oneof: 0
  field :b64, 11, type: :string, oneof: 0
  field :number, 12, type: :uint32, oneof: 0
end

defmodule Opencannabis.Crypto.SymmetricKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          data: {atom, any},
          bits: non_neg_integer,
          iv: Opencannabis.Crypto.InitializationVector.t() | nil
        }
  defstruct [:data, :bits, :iv]

  oneof :data, 0
  field :bits, 1, type: :uint32
  field :iv, 2, type: Opencannabis.Crypto.InitializationVector
  field :raw, 10, type: :bytes, oneof: 0
  field :b64, 11, type: :string, oneof: 0
end

defmodule Opencannabis.Crypto.KeyMaterial do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          data: {atom, any},
          fingerprint: Opencannabis.Crypto.Hash.t() | nil,
          params: Opencannabis.Crypto.KeyParameters.t() | nil
        }
  defstruct [:data, :fingerprint, :params]

  oneof :data, 0
  field :fingerprint, 1, type: Opencannabis.Crypto.Hash
  field :params, 2, type: Opencannabis.Crypto.KeyParameters
  field :raw, 10, type: :bytes, oneof: 0
  field :pem, 11, type: :string, oneof: 0
end

defmodule Opencannabis.Crypto.Keypair do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          public: Opencannabis.Crypto.KeyMaterial.t() | nil,
          private: Opencannabis.Crypto.KeyMaterial.t() | nil
        }
  defstruct [:public, :private]

  field :public, 1, type: Opencannabis.Crypto.KeyMaterial
  field :private, 2, type: Opencannabis.Crypto.KeyMaterial
end

defmodule Opencannabis.Crypto.KeyType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :SYMMETRIC, 0
  field :ASYMMETRIC, 1
end

defmodule Opencannabis.Crypto.KeyDisposition do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PRIVATE, 0
  field :EPHEMERAL, 1
  field :PUBLIC, 2
end

defmodule Opencannabis.Crypto.BlockCipher do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_BLOCK_CIPHER, 0
  field :AES, 1
  field :CAMELLIA, 2
end

defmodule Opencannabis.Crypto.StreamCipher do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_STREAM_CIPHER, 0
  field :RC5, 1
  field :RC6, 2
  field :CHACHA20, 3
end

defmodule Opencannabis.Crypto.KeyAgreement do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_KEY_AGREEMENT, 0
  field :DHE, 1
  field :ECDHE, 2
end

defmodule Opencannabis.Crypto.BlockMode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_BLOCK_MODE, 0
  field :ECB, 1
  field :CBC, 2
  field :CFB, 3
  field :OFB, 4
  field :CTR, 5
  field :CCM, 6
  field :GCM, 7
  field :XTS, 8
  field :KWP, 9
end

defmodule Opencannabis.Crypto.KeyingScheme do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :RSA, 0
  field :ECC, 1
  field :DSA, 2
  field :EdDSA, 3
end

defmodule Opencannabis.Crypto.InitializationVectorMode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :STATIC_IV, 0
  field :TOTP, 1
  field :COUNTER, 2
end
