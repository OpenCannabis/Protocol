defmodule Opencannabis.Products.Cartridge do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          type: atom | integer,
          product: Opencannabis.Content.ProductContent.t() | nil,
          material: Opencannabis.Content.MaterialsData.t() | nil
        }
  defstruct [:key, :type, :product, :material]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :type, 2, type: Opencannabis.Products.Cartridge.Type, enum: true
  field :product, 3, type: Opencannabis.Content.ProductContent
  field :material, 4, type: Opencannabis.Content.MaterialsData
end

defmodule Opencannabis.Products.Cartridge.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_CARTRIDGE, 0
  field :CARTRIDGE, 1
  field :BATTERY, 2
  field :KIT, 3
  field :DISPOSABLE, 4
  field :E_LIQUID, 5
end
