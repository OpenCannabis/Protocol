defmodule Opencannabis.Products.Merchandise do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          type: atom | integer,
          flags: [atom | integer],
          product: Opencannabis.Content.ProductContent.t() | nil
        }
  defstruct [:key, :type, :flags, :product]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :type, 2, type: Opencannabis.Products.Merchandise.Type, enum: true
  field :flags, 3, repeated: true, type: Opencannabis.Products.MerchandiseFlag, enum: true
  field :product, 4, type: Opencannabis.Content.ProductContent
end

defmodule Opencannabis.Products.Merchandise.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_MERCHANDISE, 0
  field :CLOTHING, 1
  field :GLASSWARE, 2
  field :CONTAINER, 3
  field :LIGHTER, 4
  field :TSHIRT, 5
  field :HOODIE, 6
  field :HAT, 7
  field :ACCESSORIES, 8
  field :PAPERS, 9
end

defmodule Opencannabis.Products.MerchandiseFlag do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_MERCHANDISE_FLAGS, 0
  field :MEDICAL_ONLY, 1
  field :BRAND_SWAG, 2
end
