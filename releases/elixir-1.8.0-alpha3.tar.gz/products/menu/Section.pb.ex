defmodule Opencannabis.Products.Menu.Section.CustomSection do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          filter: atom | integer
        }
  defstruct [:id, :filter]

  field :id, 1, type: :string
  field :filter, 2, type: Opencannabis.Products.Menu.Section.FilteredSection, enum: true
end

defmodule Opencannabis.Products.Menu.Section.SectionMedia do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          tablet_homescreen_media: Opencannabis.Media.MediaItem.t() | nil
        }
  defstruct [:tablet_homescreen_media]

  field :tablet_homescreen_media, 2, type: Opencannabis.Media.MediaItem
end

defmodule Opencannabis.Products.Menu.Section.SectionSettings do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: Opencannabis.Content.Name.t() | nil,
          media: Opencannabis.Products.Menu.Section.SectionMedia.t() | nil
        }
  defstruct [:name, :media]

  field :name, 1, type: Opencannabis.Content.Name
  field :media, 2, type: Opencannabis.Products.Menu.Section.SectionMedia
end

defmodule Opencannabis.Products.Menu.Section.SectionSpec do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          spec: {atom, any},
          settings: Opencannabis.Products.Menu.Section.SectionSettings.t() | nil,
          flags: [atom | integer]
        }
  defstruct [:spec, :settings, :flags]

  oneof :spec, 0
  field :section, 1, type: Opencannabis.Products.Menu.Section.Section, enum: true, oneof: 0
  field :custom_section, 2, type: Opencannabis.Products.Menu.Section.CustomSection, oneof: 0
  field :name, 3, type: :string, oneof: 0
  field :settings, 4, type: Opencannabis.Products.Menu.Section.SectionSettings

  field :flags, 5,
    repeated: true,
    type: Opencannabis.Products.Menu.Section.SectionFlag,
    enum: true
end

defmodule Opencannabis.Products.Menu.Section.SectionFlag do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :HIDDEN, 0
  field :FEATURED, 1
end

defmodule Opencannabis.Products.Menu.Section.Section do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED, 0
  field :FLOWERS, 1
  field :EXTRACTS, 2
  field :EDIBLES, 3
  field :CARTRIDGES, 4
  field :APOTHECARY, 5
  field :PREROLLS, 6
  field :PLANTS, 7
  field :MERCHANDISE, 8
end

defmodule Opencannabis.Products.Menu.Section.FilteredSection do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :ON_SALE, 0
  field :HOUSE, 1
  field :CBD, 2
  field :SEARCH, 3
end
