defmodule Opencannabis.Products.Apothecary do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          type: atom | integer,
          product: Opencannabis.Content.ProductContent.t() | nil,
          material: Opencannabis.Content.MaterialsData.t() | nil
        }
  defstruct [:key, :type, :product, :material]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :type, 2, type: Opencannabis.Products.Apothecary.Type, enum: true
  field :product, 3, type: Opencannabis.Content.ProductContent
  field :material, 4, type: Opencannabis.Content.MaterialsData
end

defmodule Opencannabis.Products.Apothecary.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_APOTHECARY, 0
  field :TOPICAL, 1
  field :TINCTURE, 2
  field :CAPSULE, 3
  field :INJECTOR, 4
  field :SPRAY, 5
  field :SUBLINGUAL, 6
  field :SUPPOSITORY, 7
  field :TRANSDERMAL, 8
  field :BATH_AND_BODY, 9
  field :LOTION, 10
end
