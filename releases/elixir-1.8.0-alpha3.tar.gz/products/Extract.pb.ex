defmodule Opencannabis.Products.Extract do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          type: atom | integer,
          flag: [atom | integer],
          flower: Opencannabis.Base.ProductReference.t() | nil,
          product: Opencannabis.Content.ProductContent.t() | nil,
          material: Opencannabis.Content.MaterialsData.t() | nil
        }
  defstruct [:key, :type, :flag, :flower, :product, :material]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :type, 2, type: Opencannabis.Products.Extract.Type, enum: true
  field :flag, 3, repeated: true, type: Opencannabis.Products.Extract.Flag, enum: true
  field :flower, 4, type: Opencannabis.Base.ProductReference
  field :product, 5, type: Opencannabis.Content.ProductContent
  field :material, 6, type: Opencannabis.Content.MaterialsData
end

defmodule Opencannabis.Products.Extract.Flag do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_EXTRACT_FLAGS, 0
  field :SOLVENTLESS, 1
end

defmodule Opencannabis.Products.Extract.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_EXTRACT, 0
  field :OIL, 1
  field :WAX, 2
  field :SHATTER, 3
  field :KIEF, 4
  field :HASH, 5
  field :LIVE_RESIN, 6
  field :ROSIN, 7
  field :CRUMBLE, 8
  field :SAUCE, 9
  field :SUGAR, 10
end
