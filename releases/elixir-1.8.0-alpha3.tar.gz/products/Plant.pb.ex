defmodule Opencannabis.Products.Plant do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          type: atom | integer,
          origin: [Opencannabis.Base.ProductReference.t()],
          product: Opencannabis.Content.ProductContent.t() | nil,
          material: Opencannabis.Content.MaterialsData.t() | nil
        }
  defstruct [:key, :type, :origin, :product, :material]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :type, 2, type: Opencannabis.Products.Plant.Type, enum: true
  field :origin, 3, repeated: true, type: Opencannabis.Base.ProductReference
  field :product, 4, type: Opencannabis.Content.ProductContent
  field :material, 5, type: Opencannabis.Content.MaterialsData
end

defmodule Opencannabis.Products.Plant.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_PLANT, 0
  field :SEED, 1
  field :CLONE, 2
end
