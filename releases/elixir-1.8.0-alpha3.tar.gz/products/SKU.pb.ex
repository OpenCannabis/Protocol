defmodule Opencannabis.Products.Sku.MappedSKU do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          target: {atom, any},
          sku: String.t(),
          foreign: String.t(),
          type: atom | integer,
          system: atom | integer
        }
  defstruct [:target, :sku, :foreign, :type, :system]

  oneof :target, 0
  field :sku, 1, type: :string
  field :foreign, 2, type: :string
  field :type, 3, type: Opencannabis.Products.Sku.SKUType, enum: true
  field :system, 4, type: Bloombox.Partner.Integrations.IntegrationPartner, enum: true
  field :unit, 10, type: :bool, oneof: 0
  field :variant, 11, type: Opencannabis.Commerce.VariantSpec, oneof: 0
end

defmodule Opencannabis.Products.Sku.SKUType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :ITEM, 0
  field :PRODUCT, 1
end
