defmodule Opencannabis.Products.Flower do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          product: Opencannabis.Content.ProductContent.t() | nil,
          material: Opencannabis.Content.MaterialsData.t() | nil,
          type: atom | integer
        }
  defstruct [:key, :product, :material, :type]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :product, 2, type: Opencannabis.Content.ProductContent
  field :material, 3, type: Opencannabis.Content.MaterialsData
  field :type, 4, type: Opencannabis.Products.Flower.Type, enum: true
end

defmodule Opencannabis.Products.Flower.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :TRIMMED, 0
  field :SHAKE, 1
  field :SMALL_NUGS, 2
  field :PREMIUM_NUGS, 3
end
