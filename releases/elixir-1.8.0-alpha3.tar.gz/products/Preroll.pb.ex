defmodule Opencannabis.Products.Preroll do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          key: Opencannabis.Base.ProductKey.t() | nil,
          flower: Opencannabis.Base.ProductReference.t() | nil,
          length: float,
          thickness: float,
          flags: [atom | integer],
          product: Opencannabis.Content.ProductContent.t() | nil,
          material: Opencannabis.Content.MaterialsData.t() | nil
        }
  defstruct [:key, :flower, :length, :thickness, :flags, :product, :material]

  field :key, 1, type: Opencannabis.Base.ProductKey
  field :flower, 2, type: Opencannabis.Base.ProductReference
  field :length, 3, type: :double
  field :thickness, 4, type: :double
  field :flags, 5, repeated: true, type: Opencannabis.Products.Preroll.Flag, enum: true
  field :product, 6, type: Opencannabis.Content.ProductContent
  field :material, 7, type: Opencannabis.Content.MaterialsData
end

defmodule Opencannabis.Products.Preroll.Flag do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_PREROLL_FLAGS, 0
  field :HASH_INFUSED, 1
  field :KIEF_INFUSED, 2
  field :FORTIFIED, 3
  field :FULL_FLOWER, 4
  field :CONTAINS_TOBACCO, 5
end
