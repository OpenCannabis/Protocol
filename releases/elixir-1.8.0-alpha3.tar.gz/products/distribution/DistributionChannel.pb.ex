defmodule Opencannabis.Products.Distribution.DistributionPolicy do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          enabled: boolean,
          channel: atom | integer,
          type: atom | integer,
          suppress: boolean
        }
  defstruct [:enabled, :channel, :type, :suppress]

  field :enabled, 1, type: :bool
  field :channel, 2, type: Opencannabis.Products.Distribution.Channel, enum: true
  field :type, 3, type: Opencannabis.Products.Distribution.ChannelType, enum: true
  field :suppress, 4, type: :bool
end

defmodule Opencannabis.Products.Distribution.Channel do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_CHANNEL, 0
  field :RETAIL, 1
  field :WHOLESALE, 2
  field :BULK, 3
end

defmodule Opencannabis.Products.Distribution.ChannelType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_CHANNEL_TYPE, 0
  field :DIRECT, 1
  field :MARKETPLACE, 2
end
