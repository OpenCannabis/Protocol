defmodule Core.DatapointOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          visibility: atom | integer,
          required: boolean,
          concrete: boolean,
          ephemeral: boolean
        }
  defstruct [:visibility, :required, :concrete, :ephemeral]

  field :visibility, 1, type: Core.Visibility, enum: true
  field :required, 2, type: :bool
  field :concrete, 3, type: :bool
  field :ephemeral, 4, type: :bool
end

defmodule Core.PersistenceOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          mode: atom | integer,
          path: String.t(),
          parent: String.t()
        }
  defstruct [:mode, :path, :parent]

  field :mode, 1, type: Core.CollectionMode, enum: true
  field :path, 2, type: :string
  field :parent, 3, type: :string
end

defmodule Core.TableOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: String.t(),
          description: String.t()
        }
  defstruct [:name, :description]

  field :name, 1, type: :string
  field :description, 2, type: :string
end

defmodule Core.SubmessageOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          mode: atom | integer,
          concrete: String.t(),
          path: String.t(),
          embed: boolean
        }
  defstruct [:mode, :concrete, :path, :embed]

  field :mode, 1, type: Core.CollectionMode, enum: true
  field :concrete, 2, type: :string
  field :path, 3, type: :string
  field :embed, 4, type: :bool
end

defmodule Core.FieldPersistenceOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          description: String.t(),
          summary: String.t(),
          stamp_update: boolean,
          stamp_create: boolean,
          read_only: boolean,
          immutable: boolean,
          explicit: boolean,
          visibility: atom | integer
        }
  defstruct [
    :type,
    :description,
    :summary,
    :stamp_update,
    :stamp_create,
    :read_only,
    :immutable,
    :explicit,
    :visibility
  ]

  field :type, 1, type: Core.FieldType, enum: true
  field :description, 2, type: :string
  field :summary, 3, type: :string
  field :stamp_update, 5, type: :bool
  field :stamp_create, 6, type: :bool
  field :read_only, 7, type: :bool
  field :immutable, 8, type: :bool
  field :explicit, 9, type: :bool
  field :visibility, 10, type: Core.FieldVisibility, enum: true
end

defmodule Core.TableFieldOptions do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          require: boolean,
          ignore: boolean,
          bqtype: String.t()
        }
  defstruct [:require, :ignore, :bqtype]

  field :require, 1, type: :bool
  field :ignore, 2, type: :bool
  field :bqtype, 3, type: :string
end

defmodule Core.ObjectMapping do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          instance: [String.t()]
        }
  defstruct [:instance]

  field :instance, 1, repeated: true, type: :string
end

defmodule Core.Visibility do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PUBLIC, 0
  field :PRIVATE, 1
  field :PROTECTED, 2
  field :PACKAGE, 3
  field :EXPORT, 4
end

defmodule Core.CollectionMode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NESTED, 0
  field :COLLECTION, 1
  field :GROUP, 2
end

defmodule Core.FieldType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :STANDARD, 0
  field :KEY, 1
  field :ID, 2
  field :TAGS, 3
  field :FLAGS, 4
  field :REFERENCE, 5
  field :TIMESTAMP, 6
  field :PARENT, 7
end

defmodule Core.FieldVisibility do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :DEFAULT_VISIBILITY, 0
  field :OPEN, 1
  field :AUTHORIZED, 2
  field :OWNER, 3
  field :INTERNAL, 4
end
