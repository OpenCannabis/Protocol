defmodule Opencannabis.Geo.Location do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: Opencannabis.Content.Name.t() | nil,
          address: Opencannabis.Geo.Address.t() | nil,
          point: Opencannabis.Geo.Point.t() | nil,
          accuracy: Opencannabis.Geo.LocationAccuracy.t() | nil
        }
  defstruct [:name, :address, :point, :accuracy]

  field :name, 1, type: Opencannabis.Content.Name
  field :address, 2, type: Opencannabis.Geo.Address
  field :point, 3, type: Opencannabis.Geo.Point
  field :accuracy, 4, type: Opencannabis.Geo.LocationAccuracy
end
