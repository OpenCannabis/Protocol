defmodule Opencannabis.Geo.Province do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          spec: {atom, any}
        }
  defstruct [:spec]

  oneof :spec, 0
  field :state, 1, type: Opencannabis.Geo.Usa.USState, enum: true, oneof: 0
  field :province, 2, type: :string, oneof: 0
end
