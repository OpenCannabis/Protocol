defmodule Opencannabis.Geo.LocationAccuracy do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          estimate: boolean,
          value: Opencannabis.Geo.DistanceValue.t() | nil
        }
  defstruct [:estimate, :value]

  field :estimate, 1, type: :bool
  field :value, 2, type: Opencannabis.Geo.DistanceValue
end

defmodule Opencannabis.Geo.DistanceValue do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          unit: atom | integer,
          value: float
        }
  defstruct [:unit, :value]

  field :unit, 1, type: Opencannabis.Geo.DistanceUnit, enum: true
  field :value, 3, type: :double
end

defmodule Opencannabis.Geo.Distance do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          estimate: boolean,
          accuracy: Opencannabis.Geo.LocationAccuracy.t() | nil,
          unit: atom | integer
        }
  defstruct [:estimate, :accuracy, :unit]

  field :estimate, 1, type: :bool
  field :accuracy, 2, type: Opencannabis.Geo.LocationAccuracy
  field :unit, 3, type: Opencannabis.Geo.DistanceUnit, enum: true
end

defmodule Opencannabis.Geo.DistanceUnit do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :METERS, 0
  field :INCHES, 1
  field :FEET, 2
  field :MILLIMETERS, 3
  field :CENTIMETERS, 4
  field :KILOMETERS, 5
  field :MILES, 6
end
