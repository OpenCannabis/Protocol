defmodule Opencannabis.Geo.Point do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          latitude: float,
          longitude: float,
          elevation: Opencannabis.Geo.Distance.t() | nil,
          accuracy: Opencannabis.Geo.Distance.t() | nil
        }
  defstruct [:latitude, :longitude, :elevation, :accuracy]

  field :latitude, 1, type: :double
  field :longitude, 2, type: :double
  field :elevation, 3, type: Opencannabis.Geo.Distance
  field :accuracy, 4, type: Opencannabis.Geo.Distance
end

defmodule Opencannabis.Geo.WorldCoordinate do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          right: float,
          down: float,
          elevation: Opencannabis.Geo.Distance.t() | nil,
          accuracy: Opencannabis.Geo.Distance.t() | nil
        }
  defstruct [:right, :down, :elevation, :accuracy]

  field :right, 1, type: :double
  field :down, 2, type: :double
  field :elevation, 3, type: Opencannabis.Geo.Distance
  field :accuracy, 4, type: Opencannabis.Geo.Distance
end

defmodule Opencannabis.Geo.MapCoordinate do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          x: non_neg_integer,
          y: non_neg_integer,
          right: non_neg_integer,
          down: non_neg_integer
        }
  defstruct [:x, :y, :right, :down]

  field :x, 1, type: :uint32
  field :y, 2, type: :uint32
  field :right, 3, type: :uint32
  field :down, 4, type: :uint32
end

defmodule Opencannabis.Geo.MapPosition do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          point: Opencannabis.Geo.Point.t() | nil,
          tile: Opencannabis.Geo.MapCoordinate.t() | nil,
          coordinate: Opencannabis.Geo.WorldCoordinate.t() | nil,
          zoom: non_neg_integer
        }
  defstruct [:point, :tile, :coordinate, :zoom]

  field :point, 1, type: Opencannabis.Geo.Point
  field :tile, 2, type: Opencannabis.Geo.MapCoordinate
  field :coordinate, 3, type: Opencannabis.Geo.WorldCoordinate
  field :zoom, 4, type: :uint32
end
