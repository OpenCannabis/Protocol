defmodule Bloombox.Identity.UserKey do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          uid: String.t(),
          identity: String.t()
        }
  defstruct [:uid, :identity]

  field :uid, 1, type: :string
  field :identity, 2, type: :string
end
