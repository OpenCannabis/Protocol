defmodule Opencannabis.Structs.Pricing.PricingTierAvailability do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          offered: boolean,
          available: boolean
        }
  defstruct [:offered, :available]

  field :offered, 1, type: :bool
  field :available, 2, type: :bool
end

defmodule Opencannabis.Structs.Pricing.UnitPricingDescriptor do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          price: Opencannabis.Commerce.CurrencyValue.t() | nil,
          status: Opencannabis.Structs.Pricing.PricingTierAvailability.t() | nil,
          discounts: [Opencannabis.Structs.Pricing.SaleDescriptor.t()]
        }
  defstruct [:price, :status, :discounts]

  field :price, 1, type: Opencannabis.Commerce.CurrencyValue
  field :status, 2, type: Opencannabis.Structs.Pricing.PricingTierAvailability
  field :discounts, 3, repeated: true, type: Opencannabis.Structs.Pricing.SaleDescriptor
end

defmodule Opencannabis.Structs.Pricing.WeightedPricingDescriptor do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          weight: atom | integer,
          tier: Opencannabis.Structs.Pricing.UnitPricingDescriptor.t() | nil,
          weight_in_grams: float
        }
  defstruct [:weight, :tier, :weight_in_grams]

  field :weight, 1, type: Opencannabis.Structs.Pricing.PricingWeightTier, enum: true
  field :tier, 2, type: Opencannabis.Structs.Pricing.UnitPricingDescriptor
  field :weight_in_grams, 3, type: :float
end

defmodule Opencannabis.Structs.Pricing.PricingDescriptor do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          tier: {atom, any},
          type: atom | integer
        }
  defstruct [:tier, :type]

  oneof :tier, 0
  field :type, 1, type: Opencannabis.Structs.Pricing.PricingType, enum: true
  field :unit, 20, type: Opencannabis.Structs.Pricing.UnitPricingDescriptor, oneof: 0
  field :weighted, 21, type: Opencannabis.Structs.Pricing.WeightedPricingDescriptor, oneof: 0
end

defmodule Opencannabis.Structs.Pricing.ProductPricing do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          discounts: [Opencannabis.Structs.Pricing.SaleDescriptor.t()],
          manifest: [Opencannabis.Structs.Pricing.PricingDescriptor.t()]
        }
  defstruct [:discounts, :manifest]

  field :discounts, 1, repeated: true, type: Opencannabis.Structs.Pricing.SaleDescriptor
  field :manifest, 2, repeated: true, type: Opencannabis.Structs.Pricing.PricingDescriptor
end

defmodule Opencannabis.Structs.Pricing.PricingType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNIT, 0
  field :WEIGHTED, 1
end

defmodule Opencannabis.Structs.Pricing.PricingWeightTier do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_WEIGHT, 0
  field :GRAM, 1
  field :HALFGRAM, 2
  field :QUARTERGRAM, 3
  field :DUB, 4
  field :EIGHTH, 5
  field :QUARTER, 6
  field :HALF, 7
  field :OUNCE, 8
  field :QUARTERPOUND, 9
  field :HALFPOUND, 10
  field :POUND, 11
  field :KILO, 12
  field :TON, 13
  field :OTHER, 99
end
