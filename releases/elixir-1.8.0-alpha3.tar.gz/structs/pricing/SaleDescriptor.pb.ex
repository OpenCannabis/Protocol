defmodule Opencannabis.Structs.Pricing.PercentageDiscount do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          discount: non_neg_integer
        }
  defstruct [:discount]

  field :discount, 20, type: :uint32
end

defmodule Opencannabis.Structs.Pricing.BOGODiscount do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          trigger: non_neg_integer,
          reward: non_neg_integer
        }
  defstruct [:trigger, :reward]

  field :trigger, 21, type: :uint32
  field :reward, 22, type: :uint32
end

defmodule Opencannabis.Structs.Pricing.LoyaltyDiscount do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          trigger: non_neg_integer,
          reward: non_neg_integer
        }
  defstruct [:trigger, :reward]

  field :trigger, 23, type: :uint32
  field :reward, 24, type: :uint32
end

defmodule Opencannabis.Structs.Pricing.SaleDescriptor do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          sale: {atom, any},
          type: atom | integer,
          effective: Opencannabis.Temporal.Instant.t() | nil,
          expiration: Opencannabis.Temporal.Instant.t() | nil
        }
  defstruct [:sale, :type, :effective, :expiration]

  oneof :sale, 0
  field :type, 1, type: Opencannabis.Structs.Pricing.SaleType, enum: true
  field :effective, 2, type: Opencannabis.Temporal.Instant
  field :expiration, 3, type: Opencannabis.Temporal.Instant
  field :percentage_off, 4, type: Opencannabis.Structs.Pricing.PercentageDiscount, oneof: 0
  field :bogo, 5, type: Opencannabis.Structs.Pricing.BOGODiscount, oneof: 0
  field :loyalty, 6, type: Opencannabis.Structs.Pricing.LoyaltyDiscount, oneof: 0
end

defmodule Opencannabis.Structs.Pricing.SaleType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PERCENTAGE_REDUCTION, 0
  field :VALUE_REDUCTION, 1
  field :BOGO, 2
  field :LOYALTY, 3
end
