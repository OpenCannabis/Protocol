defmodule Opencannabis.Structs.Shelf do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :GENERIC_SHELF, 0
  field :ECONOMY, 1
  field :MIDSHELF, 2
  field :TOPSHELF, 3
end
