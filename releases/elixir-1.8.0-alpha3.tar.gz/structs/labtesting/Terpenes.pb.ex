defmodule Opencannabis.Structs.Labtesting.Terpene do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CAMPHENE, 0
  field :CARENE, 1
  field :BETA_CARYOPHYLLENE, 2
  field :CARYOPHYLLENE_OXIDE, 3
  field :EUCALYPTOL, 4
  field :FENCHOL, 5
  field :ALPHA_HUMULENE, 6
  field :LIMONENE, 7
  field :LINALOOL, 8
  field :MYRCENE, 9
  field :ALPHA_OCIMENE, 10
  field :BETA_OCIMENE, 11
  field :ALPHA_PHELLANDRENE, 12
  field :ALPHA_PINENE, 13
  field :BETA_PINENE, 14
  field :ALPHA_TERPINEOL, 15
  field :ALPHA_TERPININE, 16
  field :GAMMA_TERPININE, 17
  field :TERPINOLENE, 18
  field :VALENCENE, 19
  field :GERANIOL, 20
  field :PHELLANDRENE, 21
  field :BORNEOL, 22
  field :ISOBORNEOL, 23
  field :BISABOLOL, 24
  field :PHYTOL, 25
  field :SABINENE, 26
  field :CAMPHOR, 27
  field :MENTHOL, 28
  field :CEDRENE, 29
  field :NEROL, 30
  field :NEROLIDOL, 31
  field :GUAIOL, 32
  field :ISOPULEGOL, 33
  field :GERANYL_ACETATE, 34
  field :CYMENE, 35
  field :PULEGONE, 36
  field :CINEOLE, 37
  field :FENCHONE, 38
  field :TERPINENE, 39
  field :CITRONELLOL, 40
  field :DELTA_3_CARENE, 41
end
