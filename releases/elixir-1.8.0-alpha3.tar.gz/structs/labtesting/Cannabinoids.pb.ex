defmodule Opencannabis.Structs.Labtesting.Cannabinoid do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :THC, 0
  field :THC_A, 1
  field :THC_V, 2
  field :THC_VA, 3
  field :THC_8, 4
  field :THC_9, 5
  field :CBD, 10
  field :CBD_A, 11
  field :CBD_V, 12
  field :CBD_VA, 13
  field :CBC, 20
  field :CBC_A, 21
  field :CBG, 30
  field :CBG_A, 31
  field :CBN, 40
  field :CBN_A, 41
  field :CBV, 50
  field :CBV_A, 51
  field :TAC, 60
  field :CBL, 70
  field :CBL_A, 71
end

defmodule Opencannabis.Structs.Labtesting.CannabinoidRatio do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_CANNABINOID_PREFERENCE, 0
  field :THC_ONLY, 1
  field :THC_OVER_CBD, 2
  field :EQUAL, 3
  field :CBD_OVER_THC, 4
  field :CBD_ONLY, 5
end
