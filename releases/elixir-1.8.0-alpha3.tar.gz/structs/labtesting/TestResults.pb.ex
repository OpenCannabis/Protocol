defmodule Opencannabis.Structs.Labtesting.Contaminants do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          pesticides: Opencannabis.Structs.Labtesting.Pesticides.t() | nil,
          metals: Opencannabis.Structs.Labtesting.Metals.t() | nil,
          mold_mildew: Opencannabis.Structs.Labtesting.MoldMildew.t() | nil,
          other_contaminants: Opencannabis.Structs.Labtesting.OtherContaminants.t() | nil
        }
  defstruct [:pesticides, :metals, :mold_mildew, :other_contaminants]

  field :pesticides, 1, type: Opencannabis.Structs.Labtesting.Pesticides
  field :metals, 2, type: Opencannabis.Structs.Labtesting.Metals
  field :mold_mildew, 3, type: Opencannabis.Structs.Labtesting.MoldMildew
  field :other_contaminants, 4, type: Opencannabis.Structs.Labtesting.OtherContaminants
end

defmodule Opencannabis.Structs.Labtesting.TestSuite do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          method: atom | integer,
          results: Opencannabis.Structs.Labtesting.TestResults.t() | nil,
          comments: String.t()
        }
  defstruct [:method, :results, :comments]

  field :method, 1, type: Opencannabis.Structs.Labtesting.TestMethod, enum: true
  field :results, 2, type: Opencannabis.Structs.Labtesting.TestResults
  field :comments, 3, type: :string
end

defmodule Opencannabis.Structs.Labtesting.TestResults do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          available: boolean,
          media: [Opencannabis.Structs.Labtesting.TestMedia.t()],
          last_updated: Opencannabis.Temporal.Instant.t() | nil,
          sealed: Opencannabis.Temporal.Instant.t() | nil,
          coordinates: Opencannabis.Structs.Labtesting.TestCoordinates.t() | nil,
          cannabinoids: Opencannabis.Structs.Labtesting.Cannabinoids.t() | nil,
          terpenes: Opencannabis.Structs.Labtesting.Terpenes.t() | nil,
          contaminants: Opencannabis.Structs.Labtesting.Contaminants.t() | nil,
          moisture: Opencannabis.Structs.Labtesting.Moisture.t() | nil,
          subjective: Opencannabis.Structs.Labtesting.Subjective.t() | nil,
          aroma: [atom | integer],
          data: [Opencannabis.Structs.Labtesting.TestResults.t()]
        }
  defstruct [
    :available,
    :media,
    :last_updated,
    :sealed,
    :coordinates,
    :cannabinoids,
    :terpenes,
    :contaminants,
    :moisture,
    :subjective,
    :aroma,
    :data
  ]

  field :available, 1, type: :bool
  field :media, 2, repeated: true, type: Opencannabis.Structs.Labtesting.TestMedia
  field :last_updated, 3, type: Opencannabis.Temporal.Instant
  field :sealed, 4, type: Opencannabis.Temporal.Instant
  field :coordinates, 5, type: Opencannabis.Structs.Labtesting.TestCoordinates
  field :cannabinoids, 30, type: Opencannabis.Structs.Labtesting.Cannabinoids
  field :terpenes, 31, type: Opencannabis.Structs.Labtesting.Terpenes
  field :contaminants, 32, type: Opencannabis.Structs.Labtesting.Contaminants
  field :moisture, 33, type: Opencannabis.Structs.Labtesting.Moisture
  field :subjective, 34, type: Opencannabis.Structs.Labtesting.Subjective
  field :aroma, 35, repeated: true, type: Opencannabis.Structs.Labtesting.TasteNote, enum: true
  field :data, 36, repeated: true, type: Opencannabis.Structs.Labtesting.TestResults
end

defmodule Opencannabis.Structs.Labtesting.TestCoordinates do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          zone: String.t(),
          lot: String.t(),
          batch: String.t(),
          sample_id: String.t()
        }
  defstruct [:zone, :lot, :batch, :sample_id]

  field :zone, 1, type: :string
  field :lot, 2, type: :string
  field :batch, 3, type: :string
  field :sample_id, 4, type: :string
end

defmodule Opencannabis.Structs.Labtesting.Cannabinoids do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          thc: Opencannabis.Structs.Labtesting.TestValue.t() | nil,
          cbd: Opencannabis.Structs.Labtesting.TestValue.t() | nil,
          results: [Opencannabis.Structs.Labtesting.Cannabinoids.Result.t()],
          ratio: atom | integer,
          potency: atom | integer
        }
  defstruct [:thc, :cbd, :results, :ratio, :potency]

  field :thc, 1, type: Opencannabis.Structs.Labtesting.TestValue
  field :cbd, 2, type: Opencannabis.Structs.Labtesting.TestValue
  field :results, 3, repeated: true, type: Opencannabis.Structs.Labtesting.Cannabinoids.Result
  field :ratio, 4, type: Opencannabis.Structs.Labtesting.CannabinoidRatio, enum: true
  field :potency, 5, type: Opencannabis.Structs.Labtesting.PotencyEstimate, enum: true
end

defmodule Opencannabis.Structs.Labtesting.Cannabinoids.Result do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          cannabinoid: atom | integer,
          measurement: Opencannabis.Structs.Labtesting.TestValue.t() | nil
        }
  defstruct [:cannabinoid, :measurement]

  field :cannabinoid, 1, type: Opencannabis.Structs.Labtesting.Cannabinoid, enum: true
  field :measurement, 3, type: Opencannabis.Structs.Labtesting.TestValue
end

defmodule Opencannabis.Structs.Labtesting.Subjective do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          description: Opencannabis.Content.Content.t() | nil,
          taste: Opencannabis.Content.Content.t() | nil,
          potency: atom | integer,
          feeling: [atom | integer],
          aroma: [atom | integer]
        }
  defstruct [:description, :taste, :potency, :feeling, :aroma]

  field :description, 1, type: Opencannabis.Content.Content
  field :taste, 2, type: Opencannabis.Content.Content
  field :potency, 3, type: Opencannabis.Structs.Labtesting.PotencyEstimate, enum: true
  field :feeling, 4, repeated: true, type: Opencannabis.Structs.Labtesting.Feeling, enum: true
  field :aroma, 5, repeated: true, type: Opencannabis.Structs.Labtesting.TasteNote, enum: true
end

defmodule Opencannabis.Structs.Labtesting.Pesticides do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          pesticide_free: boolean,
          measurements: %{String.t() => Opencannabis.Structs.Labtesting.TestValue.t() | nil}
        }
  defstruct [:pesticide_free, :measurements]

  field :pesticide_free, 1, type: :bool

  field :measurements, 2,
    repeated: true,
    type: Opencannabis.Structs.Labtesting.Pesticides.MeasurementsEntry,
    map: true
end

defmodule Opencannabis.Structs.Labtesting.Pesticides.MeasurementsEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Structs.Labtesting.TestValue.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Structs.Labtesting.TestValue
end

defmodule Opencannabis.Structs.Labtesting.Metals do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          metal_free: boolean,
          measurements: %{String.t() => Opencannabis.Structs.Labtesting.TestValue.t() | nil}
        }
  defstruct [:metal_free, :measurements]

  field :metal_free, 1, type: :bool

  field :measurements, 2,
    repeated: true,
    type: Opencannabis.Structs.Labtesting.Metals.MeasurementsEntry,
    map: true
end

defmodule Opencannabis.Structs.Labtesting.Metals.MeasurementsEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Structs.Labtesting.TestValue.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Structs.Labtesting.TestValue
end

defmodule Opencannabis.Structs.Labtesting.MoldMildew do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          mold_mildew_free: boolean,
          measurements: %{String.t() => Opencannabis.Structs.Labtesting.TestValue.t() | nil}
        }
  defstruct [:mold_mildew_free, :measurements]

  field :mold_mildew_free, 1, type: :bool

  field :measurements, 2,
    repeated: true,
    type: Opencannabis.Structs.Labtesting.MoldMildew.MeasurementsEntry,
    map: true
end

defmodule Opencannabis.Structs.Labtesting.MoldMildew.MeasurementsEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Structs.Labtesting.TestValue.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Structs.Labtesting.TestValue
end

defmodule Opencannabis.Structs.Labtesting.OtherContaminants do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          measurements: %{String.t() => Opencannabis.Structs.Labtesting.TestValue.t() | nil}
        }
  defstruct [:measurements]

  field :measurements, 1,
    repeated: true,
    type: Opencannabis.Structs.Labtesting.OtherContaminants.MeasurementsEntry,
    map: true
end

defmodule Opencannabis.Structs.Labtesting.OtherContaminants.MeasurementsEntry do
  @moduledoc false
  use Protobuf, map: true, syntax: :proto3

  @type t :: %__MODULE__{
          key: String.t(),
          value: Opencannabis.Structs.Labtesting.TestValue.t() | nil
        }
  defstruct [:key, :value]

  field :key, 1, type: :string
  field :value, 2, type: Opencannabis.Structs.Labtesting.TestValue
end

defmodule Opencannabis.Structs.Labtesting.Moisture do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          measurement: Opencannabis.Structs.Labtesting.TestValue.t() | nil
        }
  defstruct [:measurement]

  field :measurement, 1, type: Opencannabis.Structs.Labtesting.TestValue
end

defmodule Opencannabis.Structs.Labtesting.Terpenes do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          available: boolean,
          terpene: [Opencannabis.Structs.Labtesting.Terpenes.Result.t()],
          feeling: [atom | integer],
          aroma: [atom | integer]
        }
  defstruct [:available, :terpene, :feeling, :aroma]

  field :available, 1, type: :bool
  field :terpene, 10, repeated: true, type: Opencannabis.Structs.Labtesting.Terpenes.Result
  field :feeling, 2, repeated: true, type: Opencannabis.Structs.Labtesting.Feeling, enum: true
  field :aroma, 3, repeated: true, type: Opencannabis.Structs.Labtesting.TasteNote, enum: true
end

defmodule Opencannabis.Structs.Labtesting.Terpenes.Result do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          terpene: atom | integer,
          measurement: Opencannabis.Structs.Labtesting.TestValue.t() | nil
        }
  defstruct [:terpene, :measurement]

  field :terpene, 1, type: Opencannabis.Structs.Labtesting.Terpene, enum: true
  field :measurement, 2, type: Opencannabis.Structs.Labtesting.TestValue
end

defmodule Opencannabis.Structs.Labtesting.TestMethod do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_METHOD, 0
  field :GCMS, 1
  field :LCMS, 2
  field :CLASSIC_PCR, 3
  field :qPCR, 4
  field :ELISA, 5
end

defmodule Opencannabis.Structs.Labtesting.Feeling do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_FEELING_PREFERENCE, 0
  field :GROUNDING, 1
  field :SLEEP, 2
  field :CALMING, 3
  field :STIMULATING, 4
  field :FUNNY, 5
  field :FOCUS, 6
  field :PASSION, 7
end

defmodule Opencannabis.Structs.Labtesting.TasteNote do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_TASTE_PREFERENCE, 0
  field :SWEET, 1
  field :SOUR, 2
  field :SPICE, 3
  field :SMOOTH, 4
  field :CITRUS, 5
  field :PINE, 6
  field :FRUIT, 7
  field :TROPICS, 8
  field :FLORAL, 9
  field :HERB, 10
  field :EARTH, 11
end

defmodule Opencannabis.Structs.Labtesting.PotencyEstimate do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :LIGHT, 0
  field :MEDIUM, 1
  field :HEAVY, 2
  field :SUPER, 3
end
