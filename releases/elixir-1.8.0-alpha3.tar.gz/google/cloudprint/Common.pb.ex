defmodule Google.Cloudprint.Marker do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          type: atom | integer,
          color: Google.Cloudprint.Marker.Color.t() | nil,
          custom_display_name: String.t(),
          custom_display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [:vendor_id, :type, :color, :custom_display_name, :custom_display_name_localized]

  field :vendor_id, 1, type: :string
  field :type, 2, type: Google.Cloudprint.Marker.Type, enum: true
  field :color, 3, type: Google.Cloudprint.Marker.Color
  field :custom_display_name, 4, type: :string
  field :custom_display_name_localized, 5, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.Marker.Color do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          custom_display_name: String.t(),
          custom_display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [:type, :custom_display_name, :custom_display_name_localized]

  field :type, 1, type: Google.Cloudprint.Marker.Color.Type, enum: true
  field :custom_display_name, 2, type: :string
  field :custom_display_name_localized, 3, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.Marker.Color.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CUSTOM, 0
  field :BLACK, 1
  field :COLOR, 2
  field :CYAN, 3
  field :MAGENTA, 4
  field :YELLOW, 5
  field :LIGHT_CYAN, 6
  field :LIGHT_MAGENTA, 7
  field :GRAY, 8
  field :LIGHT_GRAY, 9
  field :PIGMENT_BLACK, 10
  field :MATTE_BLACK, 11
  field :PHOTO_CYAN, 12
  field :PHOTO_MAGENTA, 13
  field :PHOTO_YELLOW, 14
  field :PHOTO_GRAY, 15
  field :RED, 16
  field :GREEN, 17
  field :BLUE, 18
end

defmodule Google.Cloudprint.Marker.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CUSTOM, 0
  field :TONER, 1
  field :INK, 2
  field :STAPLES, 3
end

defmodule Google.Cloudprint.Cover do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          type: atom | integer,
          index: integer,
          custom_display_name: String.t(),
          custom_display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [:vendor_id, :type, :index, :custom_display_name, :custom_display_name_localized]

  field :vendor_id, 1, type: :string
  field :type, 2, type: Google.Cloudprint.Cover.Type, enum: true
  field :index, 3, type: :int64
  field :custom_display_name, 4, type: :string
  field :custom_display_name_localized, 5, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.Cover.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CUSTOM, 0
  field :DOOR, 1
  field :COVER, 2
end

defmodule Google.Cloudprint.MediaPath do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t()
        }
  defstruct [:vendor_id]

  field :vendor_id, 1, type: :string
end

defmodule Google.Cloudprint.VendorCapability do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          display_name: String.t(),
          type: atom | integer,
          range_cap: Google.Cloudprint.RangeCapability.t() | nil,
          select_cap: Google.Cloudprint.SelectCapability.t() | nil,
          typed_value_cap: Google.Cloudprint.TypedValueCapability.t() | nil,
          display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [
    :id,
    :display_name,
    :type,
    :range_cap,
    :select_cap,
    :typed_value_cap,
    :display_name_localized
  ]

  field :id, 1, type: :string
  field :display_name, 2, type: :string
  field :type, 3, type: Google.Cloudprint.VendorCapability.Type, enum: true
  field :range_cap, 4, type: Google.Cloudprint.RangeCapability
  field :select_cap, 5, type: Google.Cloudprint.SelectCapability
  field :typed_value_cap, 6, type: Google.Cloudprint.TypedValueCapability
  field :display_name_localized, 7, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.VendorCapability.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :RANGE, 0
  field :SELECT, 1
  field :TYPED_VALUE, 2
end

defmodule Google.Cloudprint.RangeCapability do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          value_type: atom | integer,
          default: String.t(),
          min: String.t(),
          max: String.t()
        }
  defstruct [:value_type, :default, :min, :max]

  field :value_type, 1, type: Google.Cloudprint.RangeCapability.ValueType, enum: true
  field :default, 2, type: :string
  field :min, 3, type: :string
  field :max, 4, type: :string
end

defmodule Google.Cloudprint.RangeCapability.ValueType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :FLOAT, 0
  field :INTEGER, 1
end

defmodule Google.Cloudprint.SelectCapability do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.SelectCapability.Option.t()]
        }
  defstruct [:option]

  field :option, 1, repeated: true, type: Google.Cloudprint.SelectCapability.Option
end

defmodule Google.Cloudprint.SelectCapability.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          value: String.t(),
          display_name: String.t(),
          is_default: boolean,
          display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [:value, :display_name, :is_default, :display_name_localized]

  field :value, 1, type: :string
  field :display_name, 2, type: :string
  field :is_default, 3, type: :bool
  field :display_name_localized, 4, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.TypedValueCapability do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          value_type: atom | integer,
          default: String.t()
        }
  defstruct [:value_type, :default]

  field :value_type, 1, type: Google.Cloudprint.TypedValueCapability.ValueType, enum: true
  field :default, 2, type: :string
end

defmodule Google.Cloudprint.TypedValueCapability.ValueType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :BOOLEAN, 0
  field :FLOAT, 1
  field :INTEGER, 2
  field :STRING, 3
end

defmodule Google.Cloudprint.Color do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.Color.Option.t()]
        }
  defstruct [:option]

  field :option, 1, repeated: true, type: Google.Cloudprint.Color.Option
end

defmodule Google.Cloudprint.Color.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          type: atom | integer,
          custom_display_name: String.t(),
          is_default: boolean,
          custom_display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [:vendor_id, :type, :custom_display_name, :is_default, :custom_display_name_localized]

  field :vendor_id, 1, type: :string
  field :type, 2, type: Google.Cloudprint.Color.Type, enum: true
  field :custom_display_name, 3, type: :string
  field :is_default, 4, type: :bool
  field :custom_display_name_localized, 5, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.Color.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :STANDARD_COLOR, 0
  field :STANDARD_MONOCHROME, 1
  field :CUSTOM_COLOR, 2
  field :CUSTOM_MONOCHROME, 3
  field :AUTO, 4
end

defmodule Google.Cloudprint.Duplex do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.Duplex.Option.t()]
        }
  defstruct [:option]

  field :option, 1, repeated: true, type: Google.Cloudprint.Duplex.Option
end

defmodule Google.Cloudprint.Duplex.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          is_default: boolean
        }
  defstruct [:type, :is_default]

  field :type, 1, type: Google.Cloudprint.Duplex.Type, enum: true
  field :is_default, 2, type: :bool
end

defmodule Google.Cloudprint.Duplex.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_DUPLEX, 0
  field :LONG_EDGE, 1
  field :SHORT_EDGE, 2
end

defmodule Google.Cloudprint.PageOrientation do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.PageOrientation.Option.t()]
        }
  defstruct [:option]

  field :option, 1, repeated: true, type: Google.Cloudprint.PageOrientation.Option
end

defmodule Google.Cloudprint.PageOrientation.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          is_default: boolean
        }
  defstruct [:type, :is_default]

  field :type, 1, type: Google.Cloudprint.PageOrientation.Type, enum: true
  field :is_default, 2, type: :bool
end

defmodule Google.Cloudprint.PageOrientation.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :PORTRAIT, 0
  field :LANDSCAPE, 1
  field :AUTO, 2
end

defmodule Google.Cloudprint.Copies do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          default: integer,
          max: integer
        }
  defstruct [:default, :max]

  field :default, 1, type: :int32
  field :max, 2, type: :int32
end

defmodule Google.Cloudprint.Margins do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.Margins.Option.t()]
        }
  defstruct [:option]

  field :option, 1, repeated: true, type: Google.Cloudprint.Margins.Option
end

defmodule Google.Cloudprint.Margins.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          top_microns: integer,
          right_microns: integer,
          bottom_microns: integer,
          left_microns: integer,
          is_default: boolean
        }
  defstruct [:type, :top_microns, :right_microns, :bottom_microns, :left_microns, :is_default]

  field :type, 1, type: Google.Cloudprint.Margins.Type, enum: true
  field :top_microns, 2, type: :int32
  field :right_microns, 3, type: :int32
  field :bottom_microns, 4, type: :int32
  field :left_microns, 5, type: :int32
  field :is_default, 6, type: :bool
end

defmodule Google.Cloudprint.Margins.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :BORDERLESS, 0
  field :STANDARD, 1
  field :CUSTOM, 2
end

defmodule Google.Cloudprint.Dpi do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.Dpi.Option.t()],
          min_horizontal_dpi: integer,
          max_horizontal_dpi: integer,
          min_vertical_dpi: integer,
          max_vertical_dpi: integer
        }
  defstruct [
    :option,
    :min_horizontal_dpi,
    :max_horizontal_dpi,
    :min_vertical_dpi,
    :max_vertical_dpi
  ]

  field :option, 1, repeated: true, type: Google.Cloudprint.Dpi.Option
  field :min_horizontal_dpi, 2, type: :int32
  field :max_horizontal_dpi, 3, type: :int32
  field :min_vertical_dpi, 4, type: :int32
  field :max_vertical_dpi, 5, type: :int32
end

defmodule Google.Cloudprint.Dpi.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          horizontal_dpi: integer,
          vertical_dpi: integer,
          is_default: boolean,
          custom_display_name: String.t(),
          vendor_id: String.t(),
          custom_display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [
    :horizontal_dpi,
    :vertical_dpi,
    :is_default,
    :custom_display_name,
    :vendor_id,
    :custom_display_name_localized
  ]

  field :horizontal_dpi, 1, type: :int32
  field :vertical_dpi, 2, type: :int32
  field :is_default, 3, type: :bool
  field :custom_display_name, 4, type: :string
  field :vendor_id, 5, type: :string
  field :custom_display_name_localized, 6, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.FitToPage do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.FitToPage.Option.t()]
        }
  defstruct [:option]

  field :option, 1, repeated: true, type: Google.Cloudprint.FitToPage.Option
end

defmodule Google.Cloudprint.FitToPage.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          is_default: boolean
        }
  defstruct [:type, :is_default]

  field :type, 1, type: Google.Cloudprint.FitToPage.Type, enum: true
  field :is_default, 2, type: :bool
end

defmodule Google.Cloudprint.FitToPage.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_FITTING, 0
  field :FIT_TO_PAGE, 1
  field :GROW_TO_PAGE, 2
  field :SHRINK_TO_PAGE, 3
  field :FILL_PAGE, 4
end

defmodule Google.Cloudprint.PageRange do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          default: [Google.Cloudprint.PageRange.Interval.t()]
        }
  defstruct [:default]

  field :default, 1, repeated: true, type: Google.Cloudprint.PageRange.Interval
end

defmodule Google.Cloudprint.PageRange.Interval do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          start: integer,
          end: integer
        }
  defstruct [:start, :end]

  field :start, 1, type: :int32
  field :end, 2, type: :int32
end

defmodule Google.Cloudprint.MediaSize do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.MediaSize.Option.t()],
          max_width_microns: integer,
          max_height_microns: integer,
          min_width_microns: integer,
          min_height_microns: integer
        }
  defstruct [
    :option,
    :max_width_microns,
    :max_height_microns,
    :min_width_microns,
    :min_height_microns
  ]

  field :option, 1, repeated: true, type: Google.Cloudprint.MediaSize.Option
  field :max_width_microns, 2, type: :int32
  field :max_height_microns, 3, type: :int32
  field :min_width_microns, 4, type: :int32
  field :min_height_microns, 5, type: :int32
end

defmodule Google.Cloudprint.MediaSize.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          name: atom | integer,
          width_microns: integer,
          height_microns: integer,
          is_continuous_feed: boolean,
          is_default: boolean,
          custom_display_name: String.t(),
          vendor_id: String.t(),
          custom_display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [
    :name,
    :width_microns,
    :height_microns,
    :is_continuous_feed,
    :is_default,
    :custom_display_name,
    :vendor_id,
    :custom_display_name_localized
  ]

  field :name, 1, type: Google.Cloudprint.MediaSize.Name, enum: true
  field :width_microns, 2, type: :int32
  field :height_microns, 3, type: :int32
  field :is_continuous_feed, 4, type: :bool
  field :is_default, 5, type: :bool
  field :custom_display_name, 6, type: :string
  field :vendor_id, 7, type: :string
  field :custom_display_name_localized, 8, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.MediaSize.Name do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CUSTOM, 0
  field :NA_INDEX_3X5, 100
  field :NA_PERSONAL, 101
  field :NA_MONARCH, 102
  field :NA_NUMBER_9, 103
  field :NA_INDEX_4X6, 104
  field :NA_NUMBER_10, 105
  field :NA_A2, 106
  field :NA_NUMBER_11, 107
  field :NA_NUMBER_12, 108
  field :NA_5X7, 109
  field :NA_INDEX_5X8, 110
  field :NA_NUMBER_14, 111
  field :NA_INVOICE, 112
  field :NA_INDEX_4X6_EXT, 113
  field :NA_6X9, 114
  field :NA_C5, 115
  field :NA_7X9, 116
  field :NA_EXECUTIVE, 117
  field :NA_GOVT_LETTER, 118
  field :NA_GOVT_LEGAL, 119
  field :NA_QUARTO, 120
  field :NA_LETTER, 121
  field :NA_FANFOLD_EUR, 122
  field :NA_LETTER_PLUS, 123
  field :NA_FOOLSCAP, 124
  field :NA_LEGAL, 125
  field :NA_SUPER_A, 126
  field :NA_9X11, 127
  field :NA_ARCH_A, 128
  field :NA_LETTER_EXTRA, 129
  field :NA_LEGAL_EXTRA, 130
  field :NA_10X11, 131
  field :NA_10X13, 132
  field :NA_10X14, 133
  field :NA_10X15, 134
  field :NA_11X12, 135
  field :NA_EDP, 136
  field :NA_FANFOLD_US, 137
  field :NA_11X15, 138
  field :NA_LEDGER, 139
  field :NA_EUR_EDP, 140
  field :NA_ARCH_B, 141
  field :NA_12X19, 142
  field :NA_B_PLUS, 143
  field :NA_SUPER_B, 144
  field :NA_C, 145
  field :NA_ARCH_C, 146
  field :NA_D, 147
  field :NA_ARCH_D, 148
  field :NA_ASME_F, 149
  field :NA_WIDE_FORMAT, 150
  field :NA_E, 151
  field :NA_ARCH_E, 152
  field :NA_F, 153
  field :ROC_16K, 200
  field :ROC_8K, 201
  field :PRC_32K, 202
  field :PRC_1, 203
  field :PRC_2, 204
  field :PRC_4, 205
  field :PRC_5, 206
  field :PRC_8, 207
  field :PRC_6, 208
  field :PRC_3, 209
  field :PRC_16K, 210
  field :PRC_7, 211
  field :OM_JUURO_KU_KAI, 212
  field :OM_PA_KAI, 213
  field :OM_DAI_PA_KAI, 214
  field :PRC_10, 215
  field :ISO_A10, 301
  field :ISO_A9, 302
  field :ISO_A8, 303
  field :ISO_A7, 304
  field :ISO_A6, 305
  field :ISO_A5, 306
  field :ISO_A5_EXTRA, 307
  field :ISO_A4, 308
  field :ISO_A4_TAB, 309
  field :ISO_A4_EXTRA, 310
  field :ISO_A3, 311
  field :ISO_A4X3, 312
  field :ISO_A4X4, 313
  field :ISO_A4X5, 314
  field :ISO_A4X6, 315
  field :ISO_A4X7, 316
  field :ISO_A4X8, 317
  field :ISO_A4X9, 318
  field :ISO_A3_EXTRA, 319
  field :ISO_A2, 320
  field :ISO_A3X3, 321
  field :ISO_A3X4, 322
  field :ISO_A3X5, 323
  field :ISO_A3X6, 324
  field :ISO_A3X7, 325
  field :ISO_A1, 326
  field :ISO_A2X3, 327
  field :ISO_A2X4, 328
  field :ISO_A2X5, 329
  field :ISO_A0, 330
  field :ISO_A1X3, 331
  field :ISO_A1X4, 332
  field :ISO_2A0, 333
  field :ISO_A0X3, 334
  field :ISO_B10, 335
  field :ISO_B9, 336
  field :ISO_B8, 337
  field :ISO_B7, 338
  field :ISO_B6, 339
  field :ISO_B6C4, 340
  field :ISO_B5, 341
  field :ISO_B5_EXTRA, 342
  field :ISO_B4, 343
  field :ISO_B3, 344
  field :ISO_B2, 345
  field :ISO_B1, 346
  field :ISO_B0, 347
  field :ISO_C10, 348
  field :ISO_C9, 349
  field :ISO_C8, 350
  field :ISO_C7, 351
  field :ISO_C7C6, 352
  field :ISO_C6, 353
  field :ISO_C6C5, 354
  field :ISO_C5, 355
  field :ISO_C4, 356
  field :ISO_C3, 357
  field :ISO_C2, 358
  field :ISO_C1, 359
  field :ISO_C0, 360
  field :ISO_DL, 361
  field :ISO_RA2, 362
  field :ISO_SRA2, 363
  field :ISO_RA1, 364
  field :ISO_SRA1, 365
  field :ISO_RA0, 366
  field :ISO_SRA0, 367
  field :JIS_B10, 400
  field :JIS_B9, 401
  field :JIS_B8, 402
  field :JIS_B7, 403
  field :JIS_B6, 404
  field :JIS_B5, 405
  field :JIS_B4, 406
  field :JIS_B3, 407
  field :JIS_B2, 408
  field :JIS_B1, 409
  field :JIS_B0, 410
  field :JIS_EXEC, 411
  field :JPN_CHOU4, 412
  field :JPN_HAGAKI, 413
  field :JPN_YOU4, 414
  field :JPN_CHOU2, 415
  field :JPN_CHOU3, 416
  field :JPN_OUFUKU, 417
  field :JPN_KAHU, 418
  field :JPN_KAKU2, 419
  field :OM_SMALL_PHOTO, 500
  field :OM_ITALIAN, 501
  field :OM_POSTFIX, 502
  field :OM_LARGE_PHOTO, 503
  field :OM_FOLIO, 504
  field :OM_FOLIO_SP, 505
  field :OM_INVITE, 506
end

defmodule Google.Cloudprint.Collate do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          default: boolean
        }
  defstruct [:default]

  field :default, 1, type: :bool
end

defmodule Google.Cloudprint.ReverseOrder do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          default: boolean
        }
  defstruct [:default]

  field :default, 1, type: :bool
end

defmodule Google.Cloudprint.LocalizedString do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          locale: atom | integer,
          value: String.t()
        }
  defstruct [:locale, :value]

  field :locale, 1, type: Google.Cloudprint.LocalizedString.Locale, enum: true
  field :value, 2, type: :string
end

defmodule Google.Cloudprint.LocalizedString.Locale do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :AF, 0
  field :AM, 1
  field :AR, 2
  field :AR_XB, 3
  field :BG, 4
  field :BN, 5
  field :CA, 6
  field :CS, 7
  field :CY, 8
  field :DA, 9
  field :DE, 10
  field :DE_AT, 11
  field :DE_CH, 12
  field :EL, 13
  field :EN, 14
  field :EN_GB, 15
  field :EN_IE, 16
  field :EN_IN, 17
  field :EN_SG, 18
  field :EN_XA, 19
  field :EN_XC, 20
  field :EN_ZA, 21
  field :ES, 22
  field :ES_419, 23
  field :ES_AR, 24
  field :ES_BO, 25
  field :ES_CL, 26
  field :ES_CO, 27
  field :ES_CR, 28
  field :ES_DO, 29
  field :ES_EC, 30
  field :ES_GT, 31
  field :ES_HN, 32
  field :ES_MX, 33
  field :ES_NI, 34
  field :ES_PA, 35
  field :ES_PE, 36
  field :ES_PR, 37
  field :ES_PY, 38
  field :ES_SV, 39
  field :ES_US, 40
  field :ES_UY, 41
  field :ES_VE, 42
  field :ET, 43
  field :EU, 44
  field :FA, 45
  field :FI, 46
  field :FR, 47
  field :FR_CA, 48
  field :FR_CH, 49
  field :GL, 50
  field :GU, 51
  field :HE, 52
  field :HI, 53
  field :HR, 54
  field :HU, 55
  field :HY, 56
  field :ID, 57
  field :IN, 58
  field :IT, 59
  field :JA, 60
  field :KA, 61
  field :KM, 62
  field :KN, 63
  field :KO, 64
  field :LN, 65
  field :LO, 66
  field :LT, 67
  field :LV, 68
  field :ML, 69
  field :MO, 70
  field :MR, 71
  field :MS, 72
  field :NB, 73
  field :NE, 74
  field :NL, 75
  field :NO, 76
  field :PL, 77
  field :PT, 78
  field :PT_BR, 79
  field :PT_PT, 80
  field :RM, 81
  field :RO, 82
  field :RU, 83
  field :SK, 84
  field :SL, 85
  field :SR, 86
  field :SR_LATN, 87
  field :SV, 88
  field :SW, 89
  field :TA, 90
  field :TE, 91
  field :TH, 92
  field :TL, 93
  field :TR, 94
  field :UK, 95
  field :UR, 96
  field :VI, 97
  field :ZH, 98
  field :ZH_CN, 99
  field :ZH_HK, 100
  field :ZH_TW, 101
  field :ZU, 102
end

defmodule Google.Cloudprint.SupportedContentType do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          content_type: String.t(),
          min_version: String.t(),
          max_version: String.t()
        }
  defstruct [:content_type, :min_version, :max_version]

  field :content_type, 1, type: :string
  field :min_version, 2, type: :string
  field :max_version, 3, type: :string
end

defmodule Google.Cloudprint.PrintingSpeed do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          option: [Google.Cloudprint.PrintingSpeed.Option.t()]
        }
  defstruct [:option]

  field :option, 1, repeated: true, type: Google.Cloudprint.PrintingSpeed.Option
end

defmodule Google.Cloudprint.PrintingSpeed.Option do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          speed_ppm: float,
          color_type: [atom | integer],
          media_size_name: [atom | integer]
        }
  defstruct [:speed_ppm, :color_type, :media_size_name]

  field :speed_ppm, 1, type: :float
  field :color_type, 2, repeated: true, type: Google.Cloudprint.Color.Type, enum: true
  field :media_size_name, 3, repeated: true, type: Google.Cloudprint.MediaSize.Name, enum: true
end

defmodule Google.Cloudprint.PwgRasterConfig do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          document_resolution_supported: [Google.Cloudprint.PwgRasterConfig.Resolution.t()],
          document_type_supported: [atom | integer],
          document_sheet_back: atom | integer,
          reverse_order_streaming: boolean,
          rotate_all_pages: boolean,
          transformation: [Google.Cloudprint.PwgRasterConfig.Transformation.t()]
        }
  defstruct [
    :document_resolution_supported,
    :document_type_supported,
    :document_sheet_back,
    :reverse_order_streaming,
    :rotate_all_pages,
    :transformation
  ]

  field :document_resolution_supported, 2,
    repeated: true,
    type: Google.Cloudprint.PwgRasterConfig.Resolution

  field :document_type_supported, 3,
    repeated: true,
    type: Google.Cloudprint.PwgRasterConfig.PwgDocumentTypeSupported,
    enum: true

  field :document_sheet_back, 4,
    type: Google.Cloudprint.PwgRasterConfig.DocumentSheetBack,
    enum: true

  field :reverse_order_streaming, 5, type: :bool
  field :rotate_all_pages, 6, type: :bool
  field :transformation, 1, repeated: true, type: Google.Cloudprint.PwgRasterConfig.Transformation
end

defmodule Google.Cloudprint.PwgRasterConfig.Resolution do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          cross_feed_dir: integer,
          feed_dir: integer
        }
  defstruct [:cross_feed_dir, :feed_dir]

  field :cross_feed_dir, 1, type: :int32
  field :feed_dir, 2, type: :int32
end

defmodule Google.Cloudprint.PwgRasterConfig.Transformation do
  @moduledoc false
  use Protobuf, deprecated: true, syntax: :proto3

  @type t :: %__MODULE__{
          operation: atom | integer,
          operand: atom | integer,
          duplex_type: [atom | integer]
        }
  defstruct [:operation, :operand, :duplex_type]

  field :operation, 1,
    type: Google.Cloudprint.PwgRasterConfig.Transformation.Operation,
    enum: true

  field :operand, 2, type: Google.Cloudprint.PwgRasterConfig.Transformation.Operand, enum: true
  field :duplex_type, 3, repeated: true, type: Google.Cloudprint.Duplex.Type, enum: true
end

defmodule Google.Cloudprint.PwgRasterConfig.Transformation.Operation do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :ROTATE_180, 0
  field :FLIP_ON_LONG_EDGE, 1
  field :FLIP_ON_SHORT_EDGE, 2
end

defmodule Google.Cloudprint.PwgRasterConfig.Transformation.Operand do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :ALL_PAGES, 0
  field :ONLY_DUPLEXED_EVEN_PAGES, 1
  field :ONLY_DUPLEXED_ODD_PAGES, 2
  field :EVEN_PAGES, 3
  field :ODD_PAGES, 4
end

defmodule Google.Cloudprint.PwgRasterConfig.DocumentSheetBack do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NORMAL, 0
  field :ROTATED, 1
  field :MANUAL_TUMBLE, 2
  field :FLIPPED, 3
end

defmodule Google.Cloudprint.PwgRasterConfig.PwgDocumentTypeSupported do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNSPECIFIED_PWG_DOCUMENT_TYPE, 0
  field :BLACK_1, 1
  field :SGRAY_1, 2
  field :ADOBE_RGB_8, 3
  field :BLACK_8, 4
  field :CMYK_8, 5
  field :DEVICE1_8, 6
  field :DEVICE2_8, 7
  field :DEVICE3_8, 8
  field :DEVICE4_8, 9
  field :DEVICE5_8, 10
  field :DEVICE6_8, 11
  field :DEVICE7_8, 12
  field :DEVICE8_8, 13
  field :DEVICE9_8, 14
  field :DEVICE10_8, 15
  field :DEVICE11_8, 16
  field :DEVICE12_8, 17
  field :DEVICE13_8, 18
  field :DEVICE14_8, 19
  field :DEVICE15_8, 20
  field :RGB_8, 21
  field :SGRAY_8, 22
  field :SRGB_8, 23
  field :ADOBE_RGB_16, 24
  field :BLACK_16, 25
  field :CMYK_16, 26
  field :DEVICE1_16, 27
  field :DEVICE2_16, 28
  field :DEVICE3_16, 29
  field :DEVICE4_16, 30
  field :DEVICE5_16, 31
  field :DEVICE6_16, 32
  field :DEVICE7_16, 33
  field :DEVICE8_16, 34
  field :DEVICE9_16, 35
  field :DEVICE10_16, 36
  field :DEVICE11_16, 37
  field :DEVICE12_16, 38
  field :DEVICE13_16, 39
  field :DEVICE14_16, 40
  field :DEVICE15_16, 41
  field :RGB_16, 42
  field :SGRAY_16, 43
  field :SRGB_16, 44
end

defmodule Google.Cloudprint.InputTrayUnit do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          type: atom | integer,
          index: integer,
          custom_display_name: String.t(),
          custom_display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [:vendor_id, :type, :index, :custom_display_name, :custom_display_name_localized]

  field :vendor_id, 1, type: :string
  field :type, 2, type: Google.Cloudprint.InputTrayUnit.Type, enum: true
  field :index, 3, type: :int64
  field :custom_display_name, 4, type: :string
  field :custom_display_name_localized, 5, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.InputTrayUnit.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CUSTOM, 0
  field :INPUT_TRAY, 1
  field :BYPASS_TRAY, 2
  field :MANUAL_FEED_TRAY, 3
  field :LCT, 4
  field :ENVELOPE_TRAY, 5
  field :ROLL, 6
end

defmodule Google.Cloudprint.OutputBinUnit do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          type: atom | integer,
          index: integer,
          custom_display_name: String.t(),
          custom_display_name_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [:vendor_id, :type, :index, :custom_display_name, :custom_display_name_localized]

  field :vendor_id, 1, type: :string
  field :type, 2, type: Google.Cloudprint.OutputBinUnit.Type, enum: true
  field :index, 3, type: :int64
  field :custom_display_name, 4, type: :string
  field :custom_display_name_localized, 5, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.OutputBinUnit.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CUSTOM, 0
  field :OUTPUT_BIN, 1
  field :MAILBOX, 2
  field :STACKER, 3
end

defmodule Google.Cloudprint.PrinterType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NO_PRINTER_TYPE_FILTER, 0
  field :GOOGLE, 1
  field :HP, 2
  field :DRIVE, 3
  field :FEDEX, 4
  field :ANDROID_CHROME_SNAPSHOT, 5
  field :IOS_CHROME_SNAPSHOT, 6
end

defmodule Google.Cloudprint.NotificationChannel do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNRECOGNIZED_CHANNEL, 0
  field :XMPP_CHANNEL, 1
end
