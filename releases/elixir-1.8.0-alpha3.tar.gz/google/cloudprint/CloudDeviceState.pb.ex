defmodule Google.Cloudprint.CloudDeviceState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          version: String.t(),
          cloud_connection_state: atom | integer,
          printer: Google.Cloudprint.PrinterStateSection.t() | nil
        }
  defstruct [:version, :cloud_connection_state, :printer]

  field :version, 1, type: :string

  field :cloud_connection_state, 2,
    type: Google.Cloudprint.CloudDeviceState.CloudConnectionStateType,
    enum: true

  field :printer, 3, type: Google.Cloudprint.PrinterStateSection
end

defmodule Google.Cloudprint.CloudDeviceState.StateType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :IDLE, 0
  field :PROCESSING, 1
  field :STOPPED, 2
end

defmodule Google.Cloudprint.CloudDeviceState.CloudConnectionStateType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNKNOWN, 0
  field :NOT_CONFIGURED, 1
  field :ONLINE, 2
  field :OFFLINE, 3
end

defmodule Google.Cloudprint.CloudDeviceUiState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          summary: atom | integer,
          severity: atom | integer,
          num_issues: integer,
          caption: String.t(),
          printer: Google.Cloudprint.PrinterUiStateSection.t() | nil
        }
  defstruct [:summary, :severity, :num_issues, :caption, :printer]

  field :summary, 1, type: Google.Cloudprint.CloudDeviceUiState.Summary, enum: true
  field :severity, 2, type: Google.Cloudprint.CloudDeviceUiState.Severity, enum: true
  field :num_issues, 3, type: :int32
  field :caption, 4, type: :string
  field :printer, 5, type: Google.Cloudprint.PrinterUiStateSection
end

defmodule Google.Cloudprint.CloudDeviceUiState.Summary do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :IDLE, 0
  field :PROCESSING, 1
  field :STOPPED, 2
  field :OFFLINE, 3
end

defmodule Google.Cloudprint.CloudDeviceUiState.Severity do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :NONE, 0
  field :LOW, 1
  field :MEDIUM, 2
  field :HIGH, 3
end

defmodule Google.Cloudprint.PrinterUiStateSection do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_item: [Google.Cloudprint.PrinterUiStateSection.Item.t()],
          input_tray_item: [Google.Cloudprint.PrinterUiStateSection.Item.t()],
          output_bin_item: [Google.Cloudprint.PrinterUiStateSection.Item.t()],
          marker_item: [Google.Cloudprint.PrinterUiStateSection.Item.t()],
          cover_item: [Google.Cloudprint.PrinterUiStateSection.Item.t()],
          media_path_item: [Google.Cloudprint.PrinterUiStateSection.Item.t()]
        }
  defstruct [
    :vendor_item,
    :input_tray_item,
    :output_bin_item,
    :marker_item,
    :cover_item,
    :media_path_item
  ]

  field :vendor_item, 1, repeated: true, type: Google.Cloudprint.PrinterUiStateSection.Item
  field :input_tray_item, 2, repeated: true, type: Google.Cloudprint.PrinterUiStateSection.Item
  field :output_bin_item, 3, repeated: true, type: Google.Cloudprint.PrinterUiStateSection.Item
  field :marker_item, 4, repeated: true, type: Google.Cloudprint.PrinterUiStateSection.Item
  field :cover_item, 5, repeated: true, type: Google.Cloudprint.PrinterUiStateSection.Item
  field :media_path_item, 6, repeated: true, type: Google.Cloudprint.PrinterUiStateSection.Item
end

defmodule Google.Cloudprint.PrinterUiStateSection.Item do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          severity: atom | integer,
          message: String.t(),
          vendor_message: String.t(),
          level_percent: integer,
          color: atom | integer
        }
  defstruct [:severity, :message, :vendor_message, :level_percent, :color]

  field :severity, 1, type: Google.Cloudprint.CloudDeviceUiState.Severity, enum: true
  field :message, 2, type: :string
  field :vendor_message, 3, type: :string
  field :level_percent, 4, type: :int32
  field :color, 5, type: Google.Cloudprint.Marker.Color.Type, enum: true
end

defmodule Google.Cloudprint.PrinterStateSection do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          state: atom | integer,
          input_tray_state: Google.Cloudprint.InputTrayState.t() | nil,
          output_bin_state: Google.Cloudprint.OutputBinState.t() | nil,
          marker_state: Google.Cloudprint.MarkerState.t() | nil,
          cover_state: Google.Cloudprint.CoverState.t() | nil,
          media_path_state: Google.Cloudprint.MediaPathState.t() | nil,
          vendor_state: Google.Cloudprint.VendorState.t() | nil
        }
  defstruct [
    :state,
    :input_tray_state,
    :output_bin_state,
    :marker_state,
    :cover_state,
    :media_path_state,
    :vendor_state
  ]

  field :state, 1, type: Google.Cloudprint.CloudDeviceState.StateType, enum: true
  field :input_tray_state, 2, type: Google.Cloudprint.InputTrayState
  field :output_bin_state, 3, type: Google.Cloudprint.OutputBinState
  field :marker_state, 4, type: Google.Cloudprint.MarkerState
  field :cover_state, 5, type: Google.Cloudprint.CoverState
  field :media_path_state, 6, type: Google.Cloudprint.MediaPathState
  field :vendor_state, 101, type: Google.Cloudprint.VendorState
end

defmodule Google.Cloudprint.InputTrayState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          item: [Google.Cloudprint.InputTrayState.Item.t()]
        }
  defstruct [:item]

  field :item, 1, repeated: true, type: Google.Cloudprint.InputTrayState.Item
end

defmodule Google.Cloudprint.InputTrayState.Item do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          state: atom | integer,
          level_percent: integer,
          vendor_message: String.t()
        }
  defstruct [:vendor_id, :state, :level_percent, :vendor_message]

  field :vendor_id, 1, type: :string
  field :state, 2, type: Google.Cloudprint.InputTrayState.Item.StateType, enum: true
  field :level_percent, 3, type: :int32
  field :vendor_message, 101, type: :string
end

defmodule Google.Cloudprint.InputTrayState.Item.StateType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :OK, 0
  field :EMPTY, 1
  field :OPEN, 2
  field :OFF, 3
  field :FAILURE, 4
end

defmodule Google.Cloudprint.OutputBinState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          item: [Google.Cloudprint.OutputBinState.Item.t()]
        }
  defstruct [:item]

  field :item, 1, repeated: true, type: Google.Cloudprint.OutputBinState.Item
end

defmodule Google.Cloudprint.OutputBinState.Item do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          state: atom | integer,
          level_percent: integer,
          vendor_message: String.t()
        }
  defstruct [:vendor_id, :state, :level_percent, :vendor_message]

  field :vendor_id, 1, type: :string
  field :state, 2, type: Google.Cloudprint.OutputBinState.Item.StateType, enum: true
  field :level_percent, 3, type: :int32
  field :vendor_message, 101, type: :string
end

defmodule Google.Cloudprint.OutputBinState.Item.StateType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :OK, 0
  field :FULL, 1
  field :OPEN, 2
  field :OFF, 3
  field :FAILURE, 4
end

defmodule Google.Cloudprint.MarkerState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          item: [Google.Cloudprint.MarkerState.Item.t()]
        }
  defstruct [:item]

  field :item, 1, repeated: true, type: Google.Cloudprint.MarkerState.Item
end

defmodule Google.Cloudprint.MarkerState.Item do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          state: atom | integer,
          level_percent: integer,
          level_pages: integer,
          vendor_message: String.t()
        }
  defstruct [:vendor_id, :state, :level_percent, :level_pages, :vendor_message]

  field :vendor_id, 1, type: :string
  field :state, 2, type: Google.Cloudprint.MarkerState.Item.StateType, enum: true
  field :level_percent, 3, type: :int32
  field :level_pages, 4, type: :int32
  field :vendor_message, 101, type: :string
end

defmodule Google.Cloudprint.MarkerState.Item.StateType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :OK, 0
  field :EXHAUSTED, 1
  field :REMOVED, 2
  field :FAILURE, 3
end

defmodule Google.Cloudprint.CoverState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          item: [Google.Cloudprint.CoverState.Item.t()]
        }
  defstruct [:item]

  field :item, 1, repeated: true, type: Google.Cloudprint.CoverState.Item
end

defmodule Google.Cloudprint.CoverState.Item do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          state: atom | integer,
          vendor_message: String.t()
        }
  defstruct [:vendor_id, :state, :vendor_message]

  field :vendor_id, 1, type: :string
  field :state, 2, type: Google.Cloudprint.CoverState.Item.StateType, enum: true
  field :vendor_message, 101, type: :string
end

defmodule Google.Cloudprint.CoverState.Item.StateType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :OK, 0
  field :OPEN, 1
  field :FAILURE, 2
end

defmodule Google.Cloudprint.MediaPathState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          item: [Google.Cloudprint.MediaPathState.Item.t()]
        }
  defstruct [:item]

  field :item, 1, repeated: true, type: Google.Cloudprint.MediaPathState.Item
end

defmodule Google.Cloudprint.MediaPathState.Item do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          state: atom | integer,
          vendor_message: String.t()
        }
  defstruct [:vendor_id, :state, :vendor_message]

  field :vendor_id, 1, type: :string
  field :state, 2, type: Google.Cloudprint.MediaPathState.Item.StateType, enum: true
  field :vendor_message, 101, type: :string
end

defmodule Google.Cloudprint.MediaPathState.Item.StateType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :OK, 0
  field :MEDIA_JAM, 1
  field :FAILURE, 2
end

defmodule Google.Cloudprint.VendorState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          item: [Google.Cloudprint.VendorState.Item.t()]
        }
  defstruct [:item]

  field :item, 1, repeated: true, type: Google.Cloudprint.VendorState.Item
end

defmodule Google.Cloudprint.VendorState.Item do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          state: atom | integer,
          description: String.t(),
          description_localized: [Google.Cloudprint.LocalizedString.t()]
        }
  defstruct [:state, :description, :description_localized]

  field :state, 1, type: Google.Cloudprint.VendorState.Item.StateType, enum: true
  field :description, 2, type: :string
  field :description_localized, 3, repeated: true, type: Google.Cloudprint.LocalizedString
end

defmodule Google.Cloudprint.VendorState.Item.StateType do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :ERROR, 0
  field :WARNING, 1
  field :INFO, 2
end
