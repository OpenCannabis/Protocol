defmodule Google.Cloudprint.SubmitJobRequest do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          printerid: String.t(),
          title: String.t(),
          ticket: Google.Cloudprint.CloudJobTicket.t() | nil,
          content: String.t(),
          content_type: String.t(),
          tag: [String.t()]
        }
  defstruct [:printerid, :title, :ticket, :content, :content_type, :tag]

  field :printerid, 1, type: :string
  field :title, 2, type: :string
  field :ticket, 3, type: Google.Cloudprint.CloudJobTicket
  field :content, 4, type: :string
  field :content_type, 5, type: :string
  field :tag, 6, repeated: true, type: :string
end

defmodule Google.Cloudprint.SubmitJobResponse do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          success: boolean,
          message: String.t(),
          error_code: non_neg_integer,
          request: Google.Cloudprint.SubmitJobRequest.t() | nil
        }
  defstruct [:success, :message, :error_code, :request]

  field :success, 1, type: :bool
  field :message, 2, type: :string
  field :error_code, 3, type: :uint32
  field :request, 4, type: Google.Cloudprint.SubmitJobRequest
end

defmodule Google.Cloudprint.DeleteJobRequest do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          jobid: String.t()
        }
  defstruct [:jobid]

  field :jobid, 1, type: :string
end

defmodule Google.Cloudprint.DeleteJobResponse do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          success: boolean,
          message: String.t(),
          error_code: non_neg_integer,
          request: Google.Cloudprint.DeleteJobRequest.t() | nil
        }
  defstruct [:success, :message, :error_code, :request]

  field :success, 1, type: :bool
  field :message, 2, type: :string
  field :error_code, 3, type: :uint32
  field :request, 4, type: Google.Cloudprint.DeleteJobRequest
end

defmodule Google.Cloudprint.ListJobsRequest do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          printerid: String.t(),
          owner: String.t(),
          status: String.t(),
          q: String.t(),
          offset: non_neg_integer,
          limit: non_neg_integer,
          sortorder: atom | integer
        }
  defstruct [:printerid, :owner, :status, :q, :offset, :limit, :sortorder]

  field :printerid, 1, type: :string
  field :owner, 2, type: :string
  field :status, 3, type: :string
  field :q, 4, type: :string
  field :offset, 5, type: :uint32
  field :limit, 6, type: :uint32
  field :sortorder, 7, type: Google.Cloudprint.ListJobsRequest.JobListSortOrder, enum: true
end

defmodule Google.Cloudprint.ListJobsRequest.JobListSortOrder do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CREATE_TIME_DESC, 0
  field :CREATE_TIME, 1
  field :STATUS, 2
  field :STATUS_DESC, 3
  field :TITLE, 4
  field :TITLE_DESC, 5
end

defmodule Google.Cloudprint.ListJobsResponse do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          success: boolean
        }
  defstruct [:success]

  field :success, 1, type: :bool
end

defmodule Google.Cloudprint.GetPrinterRequest do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          printerid: String.t(),
          client: String.t(),
          extra_fields: String.t()
        }
  defstruct [:printerid, :client, :extra_fields]

  field :printerid, 1, type: :string
  field :client, 2, type: :string
  field :extra_fields, 3, type: :string
end

defmodule Google.Cloudprint.GetPrinterResponse do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          success: boolean
        }
  defstruct [:success]

  field :success, 1, type: :bool
end

defmodule Google.Cloudprint.SearchPrintersRequest do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          connection_status_filter: {atom, any},
          q: String.t(),
          type: atom | integer,
          use_cdd: boolean,
          extra_fields: [atom | integer]
        }
  defstruct [:connection_status_filter, :q, :type, :use_cdd, :extra_fields]

  oneof :connection_status_filter, 0
  field :q, 1, type: :string
  field :type, 2, type: Google.Cloudprint.PrinterType, enum: true
  field :all_connection_statuses, 3, type: :bool, oneof: 0

  field :connection_status, 4,
    type: Google.Cloudprint.PrinterConnectionStatus,
    enum: true,
    oneof: 0

  field :use_cdd, 5, type: :bool
  field :extra_fields, 6, repeated: true, type: Google.Cloudprint.ExtraPrinterField, enum: true
end

defmodule Google.Cloudprint.CloudPrinter do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          gcp_version: String.t(),
          id: String.t(),
          uuid: String.t(),
          type: atom | integer,
          name: String.t(),
          display_name: String.t(),
          default_display_name: String.t(),
          description: String.t(),
          owner_id: String.t(),
          owner_name: String.t(),
          proxy: String.t(),
          status: atom | integer,
          tags: [String.t()],
          caps_hash: String.t(),
          is_tos_accepted: boolean,
          supported_content_types: String.t(),
          local_settings: Google.Cloudprint.LocalSettings.t() | nil,
          notification_channel: atom | integer,
          manufacturer: String.t(),
          model: String.t(),
          support_url: String.t(),
          update_url: String.t(),
          setup_url: String.t(),
          certification_id: String.t(),
          firmware: String.t(),
          access_time: String.t(),
          update_time: String.t(),
          create_time: String.t()
        }
  defstruct [
    :gcp_version,
    :id,
    :uuid,
    :type,
    :name,
    :display_name,
    :default_display_name,
    :description,
    :owner_id,
    :owner_name,
    :proxy,
    :status,
    :tags,
    :caps_hash,
    :is_tos_accepted,
    :supported_content_types,
    :local_settings,
    :notification_channel,
    :manufacturer,
    :model,
    :support_url,
    :update_url,
    :setup_url,
    :certification_id,
    :firmware,
    :access_time,
    :update_time,
    :create_time
  ]

  field :gcp_version, 1, type: :string
  field :id, 2, type: :string
  field :uuid, 3, type: :string
  field :type, 4, type: Google.Cloudprint.PrinterType, enum: true
  field :name, 5, type: :string
  field :display_name, 6, type: :string
  field :default_display_name, 7, type: :string
  field :description, 8, type: :string
  field :owner_id, 9, type: :string
  field :owner_name, 10, type: :string
  field :proxy, 11, type: :string
  field :status, 12, type: Google.Cloudprint.PrinterConnectionStatus, enum: true
  field :tags, 13, repeated: true, type: :string
  field :caps_hash, 14, type: :string
  field :is_tos_accepted, 15, type: :bool
  field :supported_content_types, 16, type: :string
  field :local_settings, 17, type: Google.Cloudprint.LocalSettings
  field :notification_channel, 18, type: Google.Cloudprint.NotificationChannel, enum: true
  field :manufacturer, 19, type: :string
  field :model, 20, type: :string
  field :support_url, 21, type: :string
  field :update_url, 22, type: :string
  field :setup_url, 23, type: :string
  field :certification_id, 24, type: :string
  field :firmware, 25, type: :string
  field :access_time, 97, type: :string
  field :update_time, 98, type: :string
  field :create_time, 99, type: :string
end

defmodule Google.Cloudprint.SearchPrintersResponse do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          success: boolean,
          xsrf_token: String.t(),
          printers: [Google.Cloudprint.CloudPrinter.t()]
        }
  defstruct [:success, :xsrf_token, :printers]

  field :success, 1, type: :bool
  field :xsrf_token, 2, type: :string
  field :printers, 3, repeated: true, type: Google.Cloudprint.CloudPrinter
end

defmodule Google.Cloudprint.LocalSettings do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          current: Google.Cloudprint.LocalSettings.Settings.t() | nil,
          pending: Google.Cloudprint.LocalSettings.Settings.t() | nil
        }
  defstruct [:current, :pending]

  field :current, 1, type: Google.Cloudprint.LocalSettings.Settings
  field :pending, 2, type: Google.Cloudprint.LocalSettings.Settings
end

defmodule Google.Cloudprint.LocalSettings.Settings do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          local_discovery: boolean,
          access_token_enabled: boolean,
          local_printing_enabled: boolean,
          conversion_printing_enabled: boolean,
          xmpp_timeout_value: integer
        }
  defstruct [
    :local_discovery,
    :access_token_enabled,
    :local_printing_enabled,
    :conversion_printing_enabled,
    :xmpp_timeout_value
  ]

  field :local_discovery, 1, type: :bool
  field :access_token_enabled, 2, type: :bool
  field :local_printing_enabled, 3, type: :bool
  field :conversion_printing_enabled, 4, type: :bool
  field :xmpp_timeout_value, 5, type: :int32
end

defmodule Google.Cloudprint.CloudJobTicket do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          version: String.t(),
          print: Google.Cloudprint.PrintTicketSection.t() | nil
        }
  defstruct [:version, :print]

  field :version, 1, type: :string
  field :print, 101, type: Google.Cloudprint.PrintTicketSection
end

defmodule Google.Cloudprint.CloudDeviceDescription do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          version: String.t(),
          printer: Google.Cloudprint.PrinterDescriptionSection.t() | nil
        }
  defstruct [:version, :printer]

  field :version, 1, type: :string
  field :printer, 101, type: Google.Cloudprint.PrinterDescriptionSection
end

defmodule Google.Cloudprint.PrintJobState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          version: String.t(),
          state: Google.Cloudprint.JobState.t() | nil,
          pages_printed: integer,
          delivery_attempts: integer
        }
  defstruct [:version, :state, :pages_printed, :delivery_attempts]

  field :version, 1, type: :string
  field :state, 2, type: Google.Cloudprint.JobState
  field :pages_printed, 3, type: :int32
  field :delivery_attempts, 4, type: :int32
end

defmodule Google.Cloudprint.PrintJobStateDiff do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          state: Google.Cloudprint.JobState.t() | nil,
          pages_printed: integer
        }
  defstruct [:state, :pages_printed]

  field :state, 1, type: Google.Cloudprint.JobState
  field :pages_printed, 2, type: :int32
end

defmodule Google.Cloudprint.PrinterConnectionStatus do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNKNOWN, 0
  field :DORMANT, 1
  field :OFFLINE, 2
  field :ONLINE, 3
end

defmodule Google.Cloudprint.ExtraPrinterField do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :UNKNOWN_EXTRA_FIELDS, 0
  field :CONNECTION_STATUS, 1
  field :SEMANTIC_STATE, 2
  field :UI_STATE, 3
  field :QUEUED_JOBS_COUNT, 4
end
