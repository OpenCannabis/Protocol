defmodule Google.Cloudprint.PrintTicketSection do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_ticket_item: [Google.Cloudprint.PrintTicketSection.VendorTicketItem.t()],
          color: Google.Cloudprint.PrintTicketSection.ColorTicketItem.t() | nil,
          duplex: Google.Cloudprint.PrintTicketSection.DuplexTicketItem.t() | nil,
          page_orientation:
            Google.Cloudprint.PrintTicketSection.PageOrientationTicketItem.t() | nil,
          copies: Google.Cloudprint.PrintTicketSection.CopiesTicketItem.t() | nil,
          margins: Google.Cloudprint.PrintTicketSection.MarginsTicketItem.t() | nil,
          dpi: Google.Cloudprint.PrintTicketSection.DpiTicketItem.t() | nil,
          fit_to_page: Google.Cloudprint.PrintTicketSection.FitToPageTicketItem.t() | nil,
          page_range: Google.Cloudprint.PrintTicketSection.PageRangeTicketItem.t() | nil,
          media_size: Google.Cloudprint.PrintTicketSection.MediaSizeTicketItem.t() | nil,
          collate: Google.Cloudprint.PrintTicketSection.CollateTicketItem.t() | nil,
          reverse_order: Google.Cloudprint.PrintTicketSection.ReverseOrderTicketItem.t() | nil
        }
  defstruct [
    :vendor_ticket_item,
    :color,
    :duplex,
    :page_orientation,
    :copies,
    :margins,
    :dpi,
    :fit_to_page,
    :page_range,
    :media_size,
    :collate,
    :reverse_order
  ]

  field :vendor_ticket_item, 1,
    repeated: true,
    type: Google.Cloudprint.PrintTicketSection.VendorTicketItem

  field :color, 2, type: Google.Cloudprint.PrintTicketSection.ColorTicketItem
  field :duplex, 3, type: Google.Cloudprint.PrintTicketSection.DuplexTicketItem
  field :page_orientation, 4, type: Google.Cloudprint.PrintTicketSection.PageOrientationTicketItem
  field :copies, 5, type: Google.Cloudprint.PrintTicketSection.CopiesTicketItem
  field :margins, 6, type: Google.Cloudprint.PrintTicketSection.MarginsTicketItem
  field :dpi, 7, type: Google.Cloudprint.PrintTicketSection.DpiTicketItem
  field :fit_to_page, 8, type: Google.Cloudprint.PrintTicketSection.FitToPageTicketItem
  field :page_range, 9, type: Google.Cloudprint.PrintTicketSection.PageRangeTicketItem
  field :media_size, 10, type: Google.Cloudprint.PrintTicketSection.MediaSizeTicketItem
  field :collate, 11, type: Google.Cloudprint.PrintTicketSection.CollateTicketItem
  field :reverse_order, 12, type: Google.Cloudprint.PrintTicketSection.ReverseOrderTicketItem
end

defmodule Google.Cloudprint.PrintTicketSection.VendorTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          id: String.t(),
          value: String.t()
        }
  defstruct [:id, :value]

  field :id, 1, type: :string
  field :value, 2, type: :string
end

defmodule Google.Cloudprint.PrintTicketSection.ColorTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          vendor_id: String.t(),
          type: atom | integer
        }
  defstruct [:vendor_id, :type]

  field :vendor_id, 1, type: :string
  field :type, 2, type: Google.Cloudprint.Color.Type, enum: true
end

defmodule Google.Cloudprint.PrintTicketSection.DuplexTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer
        }
  defstruct [:type]

  field :type, 1, type: Google.Cloudprint.Duplex.Type, enum: true
end

defmodule Google.Cloudprint.PrintTicketSection.PageOrientationTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer
        }
  defstruct [:type]

  field :type, 1, type: Google.Cloudprint.PageOrientation.Type, enum: true
end

defmodule Google.Cloudprint.PrintTicketSection.CopiesTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          copies: integer
        }
  defstruct [:copies]

  field :copies, 1, type: :int32
end

defmodule Google.Cloudprint.PrintTicketSection.MarginsTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          top_microns: integer,
          right_microns: integer,
          bottom_microns: integer,
          left_microns: integer
        }
  defstruct [:top_microns, :right_microns, :bottom_microns, :left_microns]

  field :top_microns, 1, type: :int32
  field :right_microns, 2, type: :int32
  field :bottom_microns, 3, type: :int32
  field :left_microns, 4, type: :int32
end

defmodule Google.Cloudprint.PrintTicketSection.DpiTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          horizontal_dpi: integer,
          vertical_dpi: integer,
          vendor_id: String.t()
        }
  defstruct [:horizontal_dpi, :vertical_dpi, :vendor_id]

  field :horizontal_dpi, 1, type: :int32
  field :vertical_dpi, 2, type: :int32
  field :vendor_id, 3, type: :string
end

defmodule Google.Cloudprint.PrintTicketSection.FitToPageTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer
        }
  defstruct [:type]

  field :type, 1, type: Google.Cloudprint.FitToPage.Type, enum: true
end

defmodule Google.Cloudprint.PrintTicketSection.PageRangeTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          interval: [Google.Cloudprint.PageRange.Interval.t()]
        }
  defstruct [:interval]

  field :interval, 1, repeated: true, type: Google.Cloudprint.PageRange.Interval
end

defmodule Google.Cloudprint.PrintTicketSection.MediaSizeTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          width_microns: integer,
          height_microns: integer,
          is_continuous_feed: boolean,
          vendor_id: String.t()
        }
  defstruct [:width_microns, :height_microns, :is_continuous_feed, :vendor_id]

  field :width_microns, 1, type: :int32
  field :height_microns, 2, type: :int32
  field :is_continuous_feed, 3, type: :bool
  field :vendor_id, 4, type: :string
end

defmodule Google.Cloudprint.PrintTicketSection.CollateTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          collate: boolean
        }
  defstruct [:collate]

  field :collate, 1, type: :bool
end

defmodule Google.Cloudprint.PrintTicketSection.ReverseOrderTicketItem do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          reverse_order: boolean
        }
  defstruct [:reverse_order]

  field :reverse_order, 1, type: :bool
end
