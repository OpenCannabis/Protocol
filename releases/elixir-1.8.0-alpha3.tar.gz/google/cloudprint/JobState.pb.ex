defmodule Google.Cloudprint.JobState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          type: atom | integer,
          user_action_cause: Google.Cloudprint.JobState.UserActionCause.t() | nil,
          device_state_cause: Google.Cloudprint.JobState.DeviceStateCause.t() | nil,
          device_action_cause: Google.Cloudprint.JobState.DeviceActionCause.t() | nil,
          service_action_cause: Google.Cloudprint.JobState.ServiceActionCause.t() | nil
        }
  defstruct [
    :type,
    :user_action_cause,
    :device_state_cause,
    :device_action_cause,
    :service_action_cause
  ]

  field :type, 1, type: Google.Cloudprint.JobState.Type, enum: true
  field :user_action_cause, 2, type: Google.Cloudprint.JobState.UserActionCause
  field :device_state_cause, 3, type: Google.Cloudprint.JobState.DeviceStateCause
  field :device_action_cause, 4, type: Google.Cloudprint.JobState.DeviceActionCause
  field :service_action_cause, 5, type: Google.Cloudprint.JobState.ServiceActionCause
end

defmodule Google.Cloudprint.JobState.UserActionCause do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          action_code: atom | integer
        }
  defstruct [:action_code]

  field :action_code, 1, type: Google.Cloudprint.JobState.UserActionCause.ActionCode, enum: true
end

defmodule Google.Cloudprint.JobState.UserActionCause.ActionCode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :CANCELLED, 0
  field :PAUSED, 1
  field :OTHER, 100
end

defmodule Google.Cloudprint.JobState.DeviceStateCause do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          error_code: atom | integer
        }
  defstruct [:error_code]

  field :error_code, 1, type: Google.Cloudprint.JobState.DeviceStateCause.ErrorCode, enum: true
end

defmodule Google.Cloudprint.JobState.DeviceStateCause.ErrorCode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :INPUT_TRAY, 0
  field :MARKER, 1
  field :MEDIA_PATH, 2
  field :MEDIA_SIZE, 3
  field :MEDIA_TYPE, 4
  field :OTHER, 100
end

defmodule Google.Cloudprint.JobState.DeviceActionCause do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          error_code: atom | integer
        }
  defstruct [:error_code]

  field :error_code, 1, type: Google.Cloudprint.JobState.DeviceActionCause.ErrorCode, enum: true
end

defmodule Google.Cloudprint.JobState.DeviceActionCause.ErrorCode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :DOWNLOAD_FAILURE, 0
  field :INVALID_TICKET, 1
  field :PRINT_FAILURE, 2
  field :OTHER, 100
end

defmodule Google.Cloudprint.JobState.ServiceActionCause do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          error_code: atom | integer
        }
  defstruct [:error_code]

  field :error_code, 1, type: Google.Cloudprint.JobState.ServiceActionCause.ErrorCode, enum: true
end

defmodule Google.Cloudprint.JobState.ServiceActionCause.ErrorCode do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :COMMUNICATION_WITH_DEVICE_ERROR, 0
  field :CONVERSION_ERROR, 1
  field :CONVERSION_FILE_TOO_BIG, 2
  field :CONVERSION_UNSUPPORTED_CONTENT_TYPE, 3
  field :DELIVERY_FAILURE, 11
  field :EXPIRATION, 14
  field :FETCH_DOCUMENT_FORBIDDEN, 4
  field :FETCH_DOCUMENT_NOT_FOUND, 5
  field :GOOGLE_DRIVE_QUOTA, 15
  field :INCONSISTENT_JOB, 6
  field :INCONSISTENT_PRINTER, 13
  field :PRINTER_DELETED, 12
  field :REMOTE_JOB_NO_LONGER_EXISTS, 7
  field :REMOTE_JOB_ERROR, 8
  field :REMOTE_JOB_TIMEOUT, 9
  field :REMOTE_JOB_ABORTED, 10
  field :OTHER, 100
end

defmodule Google.Cloudprint.JobState.Type do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :DRAFT, 0
  field :HELD, 1
  field :QUEUED, 2
  field :IN_PROGRESS, 3
  field :STOPPED, 4
  field :DONE, 5
  field :ABORTED, 6
end

defmodule Google.Cloudprint.PrintJobUiState do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          summary: atom | integer,
          progress: String.t(),
          cause: String.t()
        }
  defstruct [:summary, :progress, :cause]

  field :summary, 1, type: Google.Cloudprint.PrintJobUiState.Summary, enum: true
  field :progress, 2, type: :string
  field :cause, 3, type: :string
end

defmodule Google.Cloudprint.PrintJobUiState.Summary do
  @moduledoc false
  use Protobuf, enum: true, syntax: :proto3

  field :DRAFT, 0
  field :QUEUED, 1
  field :IN_PROGRESS, 2
  field :PAUSED, 3
  field :DONE, 4
  field :CANCELLED, 5
  field :ERROR, 6
  field :EXPIRED, 7
end
