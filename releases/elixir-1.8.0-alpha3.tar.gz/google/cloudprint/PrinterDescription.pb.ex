defmodule Google.Cloudprint.PrinterDescriptionSection do
  @moduledoc false
  use Protobuf, syntax: :proto3

  @type t :: %__MODULE__{
          supported_content_type: [Google.Cloudprint.SupportedContentType.t()],
          printing_speed: Google.Cloudprint.PrintingSpeed.t() | nil,
          pwg_raster_config: Google.Cloudprint.PwgRasterConfig.t() | nil,
          input_tray_unit: [Google.Cloudprint.InputTrayUnit.t()],
          output_bin_unit: [Google.Cloudprint.OutputBinUnit.t()],
          marker: [Google.Cloudprint.Marker.t()],
          cover: [Google.Cloudprint.Cover.t()],
          media_path: [Google.Cloudprint.MediaPath.t()],
          vendor_capability: [Google.Cloudprint.VendorCapability.t()],
          color: Google.Cloudprint.Color.t() | nil,
          duplex: Google.Cloudprint.Duplex.t() | nil,
          page_orientation: Google.Cloudprint.PageOrientation.t() | nil,
          copies: Google.Cloudprint.Copies.t() | nil,
          margins: Google.Cloudprint.Margins.t() | nil,
          dpi: Google.Cloudprint.Dpi.t() | nil,
          fit_to_page: Google.Cloudprint.FitToPage.t() | nil,
          page_range: Google.Cloudprint.PageRange.t() | nil,
          media_size: Google.Cloudprint.MediaSize.t() | nil,
          collate: Google.Cloudprint.Collate.t() | nil,
          reverse_order: Google.Cloudprint.ReverseOrder.t() | nil
        }
  defstruct [
    :supported_content_type,
    :printing_speed,
    :pwg_raster_config,
    :input_tray_unit,
    :output_bin_unit,
    :marker,
    :cover,
    :media_path,
    :vendor_capability,
    :color,
    :duplex,
    :page_orientation,
    :copies,
    :margins,
    :dpi,
    :fit_to_page,
    :page_range,
    :media_size,
    :collate,
    :reverse_order
  ]

  field :supported_content_type, 1, repeated: true, type: Google.Cloudprint.SupportedContentType
  field :printing_speed, 2, type: Google.Cloudprint.PrintingSpeed
  field :pwg_raster_config, 3, type: Google.Cloudprint.PwgRasterConfig
  field :input_tray_unit, 4, repeated: true, type: Google.Cloudprint.InputTrayUnit
  field :output_bin_unit, 5, repeated: true, type: Google.Cloudprint.OutputBinUnit
  field :marker, 6, repeated: true, type: Google.Cloudprint.Marker
  field :cover, 7, repeated: true, type: Google.Cloudprint.Cover
  field :media_path, 8, repeated: true, type: Google.Cloudprint.MediaPath
  field :vendor_capability, 101, repeated: true, type: Google.Cloudprint.VendorCapability
  field :color, 102, type: Google.Cloudprint.Color
  field :duplex, 103, type: Google.Cloudprint.Duplex
  field :page_orientation, 104, type: Google.Cloudprint.PageOrientation
  field :copies, 105, type: Google.Cloudprint.Copies
  field :margins, 106, type: Google.Cloudprint.Margins
  field :dpi, 107, type: Google.Cloudprint.Dpi
  field :fit_to_page, 108, type: Google.Cloudprint.FitToPage
  field :page_range, 109, type: Google.Cloudprint.PageRange
  field :media_size, 110, type: Google.Cloudprint.MediaSize
  field :collate, 111, type: Google.Cloudprint.Collate
  field :reverse_order, 112, type: Google.Cloudprint.ReverseOrder
end
