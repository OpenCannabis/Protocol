// source: structs/labtesting/TestResults.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.structs.labtesting.Feeling');

/**
 * @enum {number}
 */
proto.opencannabis.structs.labtesting.Feeling = {
  NO_FEELING_PREFERENCE: 0,
  GROUNDING: 1,
  SLEEP: 2,
  CALMING: 3,
  STIMULATING: 4,
  FUNNY: 5,
  FOCUS: 6,
  PASSION: 7
};

