// source: commerce/payments/Payment.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.commerce.DigitalPaymentNetwork');

/**
 * @enum {number}
 */
proto.opencannabis.commerce.DigitalPaymentNetwork = {
  UNSPECIFIED_NETWORK: 0,
  PAYPAL: 1,
  VENMO: 2,
  SQUARE: 3
};

