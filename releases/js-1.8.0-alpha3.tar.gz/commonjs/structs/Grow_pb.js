// source: structs/Grow.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

var jspb = require('google-protobuf');
var goog = jspb;
var global = Function('return this')();

goog.exportSymbol('proto.opencannabis.structs.Grow', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.structs.Grow = {
  GENERIC: 0,
  INDOOR: 1,
  GREENHOUSE: 2,
  OUTDOOR: 3
};

goog.object.extend(exports, proto.opencannabis.structs);
