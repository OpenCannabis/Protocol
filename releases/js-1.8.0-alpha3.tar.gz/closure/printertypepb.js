// source: google/cloudprint/Common.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.google.cloudprint.PrinterType');

/**
 * @enum {number}
 */
proto.google.cloudprint.PrinterType = {
  NO_PRINTER_TYPE_FILTER: 0,
  GOOGLE: 1,
  HP: 2,
  DRIVE: 3,
  FEDEX: 4,
  ANDROID_CHROME_SNAPSHOT: 5,
  IOS_CHROME_SNAPSHOT: 6
};

