// source: products/menu/Section.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.opencannabis.products.menu.section.Section');

/**
 * @enum {number}
 */
proto.opencannabis.products.menu.section.Section = {
  UNSPECIFIED: 0,
  FLOWERS: 1,
  EXTRACTS: 2,
  EDIBLES: 3,
  CARTRIDGES: 4,
  APOTHECARY: 5,
  PREROLLS: 6,
  PLANTS: 7,
  MERCHANDISE: 8
};

