// source: core/Datamodel.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.provide('proto.core.CollectionMode');

/**
 * @enum {number}
 */
proto.core.CollectionMode = {
  NESTED: 0,
  COLLECTION: 1,
  GROUP: 2
};

