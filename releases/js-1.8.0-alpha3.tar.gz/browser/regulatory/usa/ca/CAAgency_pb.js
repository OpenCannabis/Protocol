// source: regulatory/usa/ca/CAAgency.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!

goog.exportSymbol('proto.opencannabis.regulatory.usa.ca.CaliforniaAgency', null, global);
/**
 * @enum {number}
 */
proto.opencannabis.regulatory.usa.ca.CaliforniaAgency = {
  UNKNOWN_AGENCY: 0,
  CDFA: 1,
  CBCC: 2,
  CDCA: 3,
  CDPH: 4
};

